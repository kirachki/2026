"""
Created on Mon April 16 15:19:19 2024
@author: hidtoshi.kurosu@rakuten-bank.co.jp
"""
# standard libraries
import configparser
import csv
import re
import datetime
import logging
import os
import re
from typing import Dict, List, Optional, Union
import time
import pandas as pd
import sys
import time
import win32com.client
import numpy as np

# 3rd parties' libraries
import pandas as pd
import selenium
# import pyperclip
from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions
from selenium.common.exceptions import TimeoutException

# constants
formatter: logging.Formatter = logging.Formatter("%(asctime)s %(name)s:%(lineno)s %(funcName)s [%(levelname)s]: %(message)s")
LOGGER: logging.Logger = logging.getLogger(__name__)
handler: logging.Handler = logging.StreamHandler()
handler.setFormatter(formatter)
handler.setLevel(logging.DEBUG)
LOGGER.setLevel(logging.DEBUG)
for _handler in LOGGER.handlers:
    LOGGER.removeHandler(_handler)
LOGGER.addHandler(handler)
LOGGER.propagate = False

BASE_PATH: str = os.path.dirname(__file__)

CONFIG_INI = configparser.ConfigParser(interpolation=configparser.ExtendedInterpolation())
CONFIG_INI_PATH: str = os.path.splitext(__file__)[0] + ".conf"
assert os.path.exists(CONFIG_INI_PATH)
CONFIG_INI.read(CONFIG_INI_PATH, encoding="utf-8")
DEFAULT = CONFIG_INI["DEFAULT"]

INFO_FILE_PATH: str = os.path.join(BASE_PATH, DEFAULT.get("INFO_CSV_FILE"))

AKS_URL: str = DEFAULT.get("AKS_URL")

CHROME_DRIVER: str = os.path.join(BASE_PATH, DEFAULT.get("CHROME_DRIVER"))
IE_DRIVER: str = os.path.join(BASE_PATH, DEFAULT.get("IE_DRIVER"))
FF_DRIVER: str = os.path.join(BASE_PATH, DEFAULT.get("FF_DRIVER"))

WEB_DRIVER: str = DEFAULT.get("WEB_DRIVER")
# WEB_DRIVER: str = DEFAULT.get("WEB_DRIVER")
assert WEB_DRIVER in ("CHROME", "IE", "FF")
DISPLAY_POS:int = 3
DELIMITER="\t"
SEP = ","

# def get_fromto_date(browser, fromto: str) -> datetime.date:
#     """
#     get FROM_DATE or TO_DATE (取引日指定の開始日または終了日) on 入出金明細発行_検索画面

#     called from: get_from_date(), get_to_date()
#     """
#     yyyy: str = browser.find_element(By.XPATH, f"//input[@name='{fromto}_DATE_Y']").get_attribute("value")
#     mm: str = browser.find_element(By.XPATH, f"//input[@name='{fromto}_DATE_M']").get_attribute("value")
#     dd: str = browser.find_element(By.XPATH, f"//input[@name='{fromto}_DATE_D']").get_attribute("value")
#     assert re.match(r"\d{4}", yyyy) and re.match(r"\d{2}", mm) and re.match(r"\d{2}", dd)
#     return datetime.date(int(yyyy), int(mm), int(dd))


# def get_from_date(browser) -> datetime.date:
#     """
#     get FROM_DATE (取引日指定の開始日) on 入出金明細発行_検索画面

#     called from: get_details()
#     """
#     return get_fromto_date(browser, "FROM")


# def get_to_date(browser) -> datetime.date:
#     """
#     get TO_DATE (取引日指定の終了日) on 入出金明細発行_検索画面

#     called from: get_details()
#     """
#     return get_fromto_date(browser, "TO")


# def set_fromto_date(browser, fromto: str, date: datetime.date) -> None:
#     """
#     set FROM_DATE or TO_DATE (取引日指定の開始日または終了日) on 入出金明細発行_検索画面

#     called_from: set_from_date(), set_to_date()
#     """
#     yyyymmdd: str = date.strftime("%Y%m%d")
#     set_text(browser.find_element(By.XPATH, f"//input[@name='{fromto}_DATE_Y']"), yyyymmdd[0:4])
#     set_text(browser.find_element(By.XPATH, f"//input[@name='{fromto}_DATE_M']"), yyyymmdd[4:6])
#     set_text(browser.find_element(By.XPATH, f"//input[@name='{fromto}_DATE_D']"), yyyymmdd[6:8])
#     return


# def set_from_date(browser, date: datetime.date) -> None:
#     """
#     set FROM_DATE (取引日指定の開始日) on 入出金明細発行_検索画面

#     called_from: request_query()
#     """
#     set_fromto_date(browser, "FROM", date)
#     return


# def set_to_date(browser, date: datetime.date) -> None:
#     """
#     set TO_DATE (取引日指定の終了日) on 入出金明細発行_検索画面

#     called_from: request_query()
#     """
#     set_fromto_date(browser, "TO", date)

    
def set_text(text_input: WebElement, text: str) -> None:
    """
    set text string to <input/>

    called_from: request_query(), set_fromto_date()
    """
    #text_input.send_keys(Keys.CONTROL + "a")
    #text_input.send_keys(Keys.DELETE)
    text_input.clear()
    text_input.send_keys(text)
    return


# def reset_query(browser) -> None:
#     """
#     """
#     browser.find_element(By.XPATH, "//input[@type='BUTTON' and @value='リセット']").click()
#     return


# def request_query(browser, branch_code: str, user_number: str, from_date: Optional[datetime.date], to_date: Optional[datetime.date], currency_type: str) -> None:
#     """
#     request 検索
    
#     called_from: get_details()
#     """

#     assert re.match(r"\d{3}", branch_code) and re.match(r"\d{7}", user_number)
#     from_account_start_date: bool = from_date is None and to_date is None
#     if from_account_start_date:
#         checkbox: WebElement = browser.find_element(By.XPATH, "//input[@type='checkbox' and @name='FROM_ACCOUNT_START_DATE']")
#         if not checkbox.is_selected():
#             checkbox.click()
#     else:
#         checkbox: WebElement = browser.find_element(By.XPATH, "//input[@type='checkbox' and @name='FROM_ACCOUNT_START_DATE']")
#         if checkbox.is_selected():
#             checkbox.click()
#         set_from_date(browser, from_date)
#         set_to_date(browser, to_date)

#     set_text(browser.find_element(By.XPATH, "//input[@type='TEXT' and @name='BRANCHCODE']"), branch_code)
#     set_text(browser.find_element(By.XPATH, "//input[@type='TEXT' and @name='ACCOUNT_NUMBER']"), user_number)

#     if currency_type == "円貨普通":
#         browser.find_element(By.XPATH, "//input[@type='RADIO' and @name='CURRENCYTYPE' and @value='0']").click()
#     elif currency_type == "外貨普通":
#         browser.find_element(By.XPATH, "//input[@type='RADIO' and @name='CURRENCYTYPE' and @value='1']").click()
#     elif currency_type == "外貨定期":
#         browser.find_element(By.XPATH, "//input[@type='RADIO' and @name='CURRENCYTYPE' and @value='2']").click()
    
#     browser.find_element(By.XPATH, "//input[@type='BUTTON' and @value='検　索']").click()
#     return


def get_webdriver_object() -> Union[webdriver.Chrome, webdriver.Ie, webdriver.Firefox]:
    """
    get WebDriver object

    called_from: main()
    """
    global CHROME_DRIVER, IE_DRIVER, FF_DRIVER
    global WEB_DRIVER
    if selenium.__version__.startswith("4."):
        if WEB_DRIVER == "CHROME":
            assert os.path.exists(CHROME_DRIVER)
            chrome_service = webdriver.chrome.service.Service(executable_path=CHROME_DRIVER)
            browser = webdriver.Chrome(service=chrome_service)
        elif WEB_DRIVER == "IE":
            assert os.path.exists(IE_DRIVER)
            ie_service = webdriver.ie.service.Service(executable_path=IE_DRIVER)
            browser = webdriver.Ie(service=ie_service)
        elif WEB_DRIVER == "FF":
            assert os.path.exists(FF_DRIVER)
            ff_service = webdriver.firefox.service.Service(executable_path=FF_DRIVER)
            ff_options = webdriver.FirefoxOptions()
            ff_options.binary_location = "C:/Program Files/Mozilla Firefox/firefox.exe"
            browser = webdriver.Firefox(service=ff_service, options=ff_options)
        # end of if
    elif selenium.__version__.startswith("3."):
        if WEB_DRIVER == "CHROME":
            browser = webdriver.Chrome(executable_path=CHROME_DRIVER)
        elif WEB_DRIVER == "IE":
            browser = webdriver.Ie(executable_path=IE_DRIVER)
        elif WEB_DRIVER == "FF":
            browser = webdriver.Firefox(executable_path=FF_DRIVER)
        # end of if
    else:
        raise f"Unknown selenium version: {selenium.__version__}"
    # end of if
    return browser

def create_folder(folder_path) -> None:
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)

def save_to_csv(data, output_file):
    with open(output_file, 'w', newline='') as f:
        writer = csv.writer(f)
        for row in data:
            writer.writerow(row)

def extract_folder_path(full_path):
    foler_path, _ = os.path.split(full_path)
    return foler_path

# def f_get_otherFirstDate(date_str, diff_months):
#     # parse input date string
#     year, month, _ = map(int, date_str.split('/'))
#     # 計算する月
#     new_month = month + diff_months

#     # 年の繰り上げ・繰り下げ処理
#     new_year = year + (new_month - 1) // 12
#     new_month = (new_month - 1) % 12 + 1
#     return f"{new_year}/{new_month}/1"


def main() -> None:

    # 引数チェック
    if len(sys.argv) < 6:
         sys.exit(1)

    # 引数:1, 2 振替実施日
    start_date_list = sys.argv[1].split('/')
    end_date_list = sys.argv[2].split('/')

    # # メルマネ・マスペプラスの場合、振替実施日2ヶ月前の1日を設定
    # start_date2 = f_get_otherFirstDate(sys.argv[1], -2)
    # start_date2_list = start_date2.split('/')




    wk_Filter_yyyymm = start_date_list[0] + f"{int(start_date_list[1]):02d}"
    LOGGER.info(f"* wk_Filter_yyyymm {wk_Filter_yyyymm}")

    # 引数:3 処理エクセルのフルパス
    file_name = sys.argv[3]

    # 引数:4 処理エクセルのシート名
    sheet_name = sys.argv[4]

    # 引数:5 スクリーンショット保管場所のフルパス
    screen_save_name = sys.argv[5]
    # LOGGER.info(f" *** file_name : {file_name}")

    # LOGGER.info(f" *** sheet_name {sheet_name}")
    # LOGGER.info(f" *** screen_save_name {screen_save_name}")

    # 引数:6兵庫県など特別対応の日付期間クリーンショット保管場所のフルパス
    start_date2 = sys.argv[6]
    start_date2_list = start_date2.split('/')

    end_date2 = sys.argv[7]
    end_date2_list = end_date2.split('/')




    # LOGGER.info(f"振替実施日日が{sys.argv[1]}から{sys.argv[2]}までの情報を処理する")

    # # init the driver
    browser: Union[webdriver.Chrome, webdriver.Ie, webdriver.Firefox] = get_webdriver_object()
    browser.implicitly_wait(15)
    global AKS_URL
    browser.get(AKS_URL)

    # # 「マスサービス管理」を押す
    # WebDriverWait(browser, 60.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "/html/body/form/table/tbody/tr[3]/td[3]/table/tbody/tr/td/span/div"))).click()
    # WebDriverWait(browser, 600.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "/html/body/form/table/tbody/tr[3]/td[5]/table/tbody/tr/td/span/div"))).click()
    WebDriverWait(browser, 3.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "/html/body/form/table/tbody/tr[7]/td[1]/table/tbody/tr/td/span/div"))).click()

    # # 「マスサービス受付管理」を押す
    WebDriverWait(browser, 60.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "//input[@type='BUTTON' and @value='収納精査照会']"))).click()


    # output header
    out_header = ['未使用', '収納機関コード', '請求書番号', '依頼件数', '処理件数', '該当サービス', '処理対象外フラグ']
    out_data = [out_header]

    # xlsxを読んで支店番号と口座番号を取得
    df = pd.read_excel(file_name, sheet_name=sheet_name, header=51)
    for index, row in df.iterrows():

        # 1.処理対象=1でなければ処理対象外
        taishoo_flg = str(row[15])
        if len(taishoo_flg) == 0:
            continue

        try:
            int_taishoo_flg = int(float(taishoo_flg))
            str_taishoo_flg = str(int_taishoo_flg)
        except Exception as e:
            #LOGGER.info(rf'@@@@@ 数字じゃない @@@@@')
            continue

        if len(str_taishoo_flg) != 1:
            continue

        if str_taishoo_flg != "1":
            continue

        #  # 2.支店番号はなし（収納機関コードのみ）
        branch_code    = ""

        # 3.収納機関コード
        account_number = str(row[2])

        # 4.エビデンス作成時の特別対応(SP1:兵庫県は日付期間指定が独自)
        special_treat_kbn = str(row[16])


        #  下記にPhxxの記載のあるフェーズは対応済
        # Ph1.5 : メルマネマスペ	4
        # Ph1.0 : マスペイメント	1 
        #       : メルマネ・マスペプラス	5
        #       : 給与賞与振込	6
        # Ph1.0 : 自動引落	2 
        # Ph1.0 : 自動引落(処理済件数）	2 
        #       : 自動引落（振込のみ）	!
        #       : マルチペイメント（ペイジー）	!

        service_kind = str(row[4])
        if service_kind != "マルチペイメント（ペイジー）":
            continue
        # LOGGER.info(f"@@@@@ X service_kind : {service_kind}")

        # 請求書番号 請求書番号:H177形式の4桁 + α(4桁以内に注釈)でなければクリア
        seikyuu_no = str(row[10])
        if len(seikyuu_no) >= 4 + 4:
            seikyuu_no = ""

        seikyuu_no = str(row[10])


        # サービス種別を設定する(記号！は下記にない。要追加)
            # WebDriverWait(browser, 60.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "/html/body/form/table/tbody/tr[1]/td/select/option[1]"))).click()

        # 開始年月日、終了年月日の設定 ※SP1:兵庫県は日付期間指定が独自
        if special_treat_kbn == "SP1":
            set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[2]/td/input[1]"), start_date2_list[0])
            set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[2]/td/input[2]"), start_date2_list[1])
            set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[2]/td/input[3]"), start_date2_list[2])

            set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[2]/td/input[4]"), end_date2_list[0])
            set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[2]/td/input[5]"), end_date2_list[1])
            set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[2]/td/input[6]"), end_date2_list[2])
        else:
            set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[2]/td/input[1]"), start_date_list[0])
            set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[2]/td/input[2]"), start_date_list[1])
            set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[2]/td/input[3]"), start_date_list[2])

            set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[2]/td/input[4]"), end_date_list[0])
            set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[2]/td/input[5]"), end_date_list[1])
            set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[2]/td/input[6]"), end_date_list[2])



        # # 支店番号
        # set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[3]/td[1]/input"), branch_code)

        # 収納機関コード
        set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[3]/td/input"), account_number)

        # 集計単位
        WebDriverWait(browser, 1000.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "/html/body/form/table/tbody/tr[4]/td/input[2]"))).click()


        # 「検索」を押す
        # WebDriverWait(browser, 1000.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "//input[@type='button' and @value='検　索']"))).click()
        # browser.implicitly_wait(3000.0)
        # ページロード自体のタイムアウトを3000秒に設定（これが最も重要です）
        browser.set_page_load_timeout(5000)
        try:
            WebDriverWait(browser, 30).until(expected_conditions.element_to_be_clickable((By.XPATH, "//input[@type='button' and @value='検　索']"))).click()
        except Exception as e:
            LOGGER.info(rf'@@@@@ 検索で例外だよ {e} @@@@@')


        # # 検索結果画面 start---------------------------------------------------------------- 

        # スクリーンショットを取得する
        str_screenshot_name = f"{branch_code}-{account_number}-{seikyuu_no}"
        # 格納フォルダを振り分ける
        sub_forder = r"マルチペイメント（ペイジー）"
        create_folder(rf"{screen_save_name}\{sub_forder}")

        # browser.save_screenshot(rf"{screen_save_name}\{sub_forder}\{str_screenshot_name}.png")

        # # 1ページ単位の処理
        # current_pos_total = 0
        irai_sum = 0
        shori_sum = 0
        current_page_count = 0
        while True:

            current_page_count += 1


            # --loop終了条件--
            browser.implicitly_wait(1300.0)
            th: WebElement = browser.find_element(By.XPATH, "//th[contains(text(), '件中') and contains(text(), '件を表示しています')]")
            # th: WebElement = WebDriverWait(browser, 50000.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "//th[contains(text(), '件中') and contains(text(), '件を表示しています')]"))).click()
            counts = re.findall(r"全(\d+)件中(\d+)-(\d+)件を表示しています", th.text)[0]

            (total_count, display_current_pos_from, display_current_pos_to) = (int(count) for count in counts)
            # LOGGER.info(rf"total:{total_count}, start:{display_current_pos_from}, ends:{display_current_pos_to}")
            # --loop終了条件--

            # tbodyを取得
            tbody = browser.find_element(By.XPATH, f"/html/body/form/center[2]/table/tbody")

            # rowsを取得（ヘッダーのみの場合は3となる）
            tbody_rows =  tbody.find_elements(By.TAG_NAME, "tr")

            date_range = rf"{start_date_list[0]}{start_date_list[1]}{start_date_list[2]}-{end_date_list[0]}{end_date_list[1]}{end_date_list[2]}"

            browser.save_screenshot(rf"{screen_save_name}\{sub_forder}\{str_screenshot_name}-{current_page_count}-{date_range}.png")

            # LOGGER.info(f"\n")
            LOGGER.info(f"@ {str_screenshot_name}-{service_kind} : {total_count} 件")
            LOGGER.info(rf"total:{total_count}, start:{display_current_pos_from}, ends:{display_current_pos_to}")
            # LOGGER.info(rf"tbody_rows:{len(tbody_rows)}")

            if len(tbody_rows) <= DISPLAY_POS:
            #    total_count == 0:
                # LOGGER.info(rf'@@@@@ 処理対象がないため終了します... @@@@@')
                break


            details_tbody  = browser.find_element(By.XPATH, f"/html/body/form/center[2]/table")

            html = details_tbody.get_attribute('outerHTML')

            df_list = pd.read_html(html, header=None)

            internal_table = df_list[0]
            # 先頭２行を削除して、３行目以降のデータを取得する場合は以下。ただし、上記の"header=None"で除去される様子
            # internal_table = df_list[0].iloc[2:]

            time.sleep(2)

            wk_irai_sum = internal_table.iloc[0,2]
            irai_sum = wk_irai_sum.replace(",","").replace("件","")
            LOGGER.info(f"***** irai_sum: {irai_sum}")


            # LOGGER.info(f"@@@@@ service_kind : {service_kind}")
            # LOGGER.info(rf'---------------------- irai_sum : {irai_sum}')
            # LOGGER.info(rf'---------------------- shori_sum : {shori_sum}')

            # LOGGER.info(rf'***** {total_count}-{display_current_pos_to}')
            # loop終了を判定
            if  total_count <= display_current_pos_to :
                break

            # 「次」を押す
            time.sleep(2)
            # WebDriverWait(browser, 1000.0).until(expected_conditions.element_to_be_clickable((By.LINK_TEXT, "次>>"))).click()
            browser.set_page_load_timeout(5000)
            try:
                WebDriverWait(browser, 30.0).until(expected_conditions.element_to_be_clickable((By.LINK_TEXT, "次>>"))).click()
            except Exception as e:
                LOGGER.info(rf'@@@@@ 次へで例外だよ {e} @@@@@')


        # JINOSに処理させない時はこのフラグを1にするために設けた
        taishoo_gai_flg = 0
        # if len(seikyuu_no) != 4:
        #     taishoo_gai_flg = 1
        # if irai_sum == 0 and\
        #    shori_sum == 0:
        #     taishoo_gai_flg = 1

        # 出力イメージを配列に格納
        out_data.append([branch_code, account_number, seikyuu_no, irai_sum, shori_sum, service_kind, taishoo_gai_flg ])

        WebDriverWait(browser, 300.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "//input[@type='button' and @value='戻　る']"))).click()

    browser.close()


    # for row in out_data:
    #     print(row)

    # out_file_prefix = rf"{start_date_list[0]}{start_date_list[1]}{start_date_list[2]}-{end_date_list[0]}{end_date_list[1]}{end_date_list[2]}-out"
    out_file_prefix = rf"{start_date_list[0]}{start_date_list[1]}{start_date_list[2]}-{end_date_list[0]}{end_date_list[1]}{end_date_list[2]}-out2"

    # 出力結果はinputと同じ場所に格納
    out_folder_path = extract_folder_path(file_name)
    # csvで保存 
    save_to_csv(out_data, rf"{out_folder_path}\{out_file_prefix}.csv")
    # xlsxで保存 
    tmp_df = pd.DataFrame(out_data)
    tmp_df.to_excel(rf"{out_folder_path}\{out_file_prefix}.xlsx", index = False, header=False)

    return

    # # ---------------------------------------------------------------------------
    # try:
    #     # メニュー画面に戻る
    #     browser.find_element(By.XPATH, "//input[@type='button' and @value='戻　る']").click()

    #     # 「法人管理」を押す
    #     WebDriverWait(browser, 10.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "/html/body/form/table/tbody/tr[1]/td[1]/table/tbody/tr/td/span/div"))).click()

    #     # 「口座検索」を押す
    #     WebDriverWait(browser, 10.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "//input[@type='BUTTON' and @value='口座検索']"))).click()

    #     browser.close()

    # except Exception as e:
    #         LOGGER.info(rf'@@@@@ 処理対象がないため終了します(2/2)... @@@@@')

    # return


if __name__ == "__main__":
    LOGGER.info("starts")
    main()
    LOGGER.info("ends")

