import uuid
from fastapi import FastAPI, HTTPException, status
from schema import SupportRequest, SupportResponse, SupportTicket, TicketStatus
from agent import SupportAgent

app = FastAPI(
    title="Hybrid Customer Support API",
    description="AIと人間が協調するハイブリッド型カスタマーサポートのバックエンドサンプル",
    version="1.0.0"
)

# AIエージェントの初期化
agent = SupportAgent()

# 擬似データベース（メモリ上にチケットを保存）
ticket_db = {}


@app.post(
    "/api/v1/support/tickets", 
    response_model=SupportResponse, 
    status_code=status.HTTP_201_CREATED,
    summary="問い合わせの新規受付"
)
async def create_ticket(request: SupportRequest):
    """
    ユーザーからの新規問い合わせを受け付け、AIが対応方針を自動で判定します。
    """
    # 1. LLMエージェントを呼び出して、問い合わせを分析
    analysis = agent.process_message(request.message)
    
    # 2. チケットIDの一意な生成
    ticket_id = f"TICK-{uuid.uuid4().hex[:8].upper()}"
    
    # 3. 判定結果に応じたステータスとレスポンスの分岐
    if analysis.next_action == "AI":
        ticket_status = TicketStatus.AI_RESOLVED
        assigned_to = "AI"
        return_message = analysis.draft_reply  # ユーザーへの直接の回答
    else:
        ticket_status = TicketStatus.HUMAN_REQUIRED
        assigned_to = "Human"
        # オペレーターへの引き継ぎ文言をセット
        return_message = f"【オペレーターへ引き継ぎ】\n理由: {analysis.reason}\n要約: {analysis.draft_reply}"

    # 4. データベース（メモリ）へ保存
    new_ticket = SupportTicket(
        ticket_id=ticket_id,
        user_id=request.user_id,
        initial_message=request.message,
        ai_response=analysis.draft_reply if assigned_to == "AI" else None,
        status=ticket_status,
        assigned_to=assigned_to
    )
    ticket_db[ticket_id] = new_ticket

    # 5. クライアントへのレスポンス（ここで途切れていた部分を完成）
    return SupportResponse(
        ticket_id=ticket_id,
        status=ticket_status,
        message=return_message
    )


@app.get(
    "/api/v1/support/tickets",
    response_model=list[SupportTicket],
    status_code=status.HTTP_200_OK,
    summary="チケット一覧の取得（オペレーター管理画面用）"
)
async def get_tickets():
    """
    蓄積されたすべてのサポートチケットを返します。
    """
    return list(ticket_db.values())


@app.patch(
    "/api/v1/support/tickets/{ticket_id}",
    response_model=SupportTicket,
    status_code=status.HTTP_200_OK,
    summary="チケットステータスの更新"
)
async def update_ticket_status(ticket_id: str, current_status: TicketStatus):
    """
    人間（オペレーター）が対応を完了した際などに、ステータスを更新します。
    """
    if ticket_id not in ticket_db:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Ticket {ticket_id} not found"
        )
    
    ticket = ticket_db[ticket_id]
    ticket.status = current_status
    
    # 人間が解決した場合は、担当者を更新するなどのロジックを追加可能
    if current_status == TicketStatus.RESOLVED:
        ticket.assigned_to = "Human"
        
    ticket_db[ticket_id] = ticket
    return ticket