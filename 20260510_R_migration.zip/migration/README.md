# 会社PC向け データ移行キット

`SH_xxx` テーブルが存在しない別 PC（会社PC等）に、現環境とまったく同じスキーマ・データを構築するためのファイル一式です。

---

## ファイル構成

| ファイル | 役割 | 実行する場所 |
|---|---|---|
| `01_ddl.sql` | SH 系テーブルだけの完全版 DDL（DROP & CREATE） | 会社PC（新環境） |
| `full_schema_ddl.sql` | **SH 系 + 連携表 `t1_loginuser` まで含む「アプリ全体」DDL**（`01_ddl.sql` と同内容＋後段に CRM ログインユーザ表） | 会社PC（新環境） |
| `02_export_data.py` | 旧PCの DB から `SH_xxx` 全件を `data_dump.sql` として出力 | 自宅PC（移行元） |
| `03_import.bat` | 会社PCで DDL → データ投入を一括実行する Windows バッチ | 会社PC（新環境） |
| `data_dump.sql` | `02_export_data.py` の出力。会社PCに持ち込む生データ | 自動生成 |

`03_import.bat` は既定で `01_ddl.sql` を流します。スタッフ追加時のログイン候補（`t1_loginuser`）まで新規 DB に作りたい場合は、バッチ内の `01_ddl.sql` を `full_schema_ddl.sql` に書き換えるか、手順 3-B と同様に `mysql ... < full_schema_ddl.sql` を実行してください。その後 `python scripts\import_t1_loginuser.py` で `user.csv` から投入できます。

---

## 移行フロー（全体像）

```
[ 自宅PC ]                                  [ 会社PC ]
  shift_app DB                                空（SH_xxx 無し）
       │
       │ ① 02_export_data.py を実行
       ▼
  data_dump.sql ─── USB / メール / クラウド ───►  migration\data_dump.sql
                                                       │
                                                       │ ② 03_import.bat を実行
                                                       ▼
                                                  shift_app DB
                                                  （DDL + 全データ投入済み）
```

---

## 手順 1：自宅PCでデータをエクスポート

### 1-1. アプリの仮想環境に入る

```powershell
cd C:\study\SHIFTS\shift_app
venv\Scripts\activate
```

### 1-2. エクスポートスクリプトを実行

```powershell
python migration\02_export_data.py
```

- 接続情報は `database.py` の `_DB_CONFIG` をそのまま使用します。
- 別 DB から取りたい場合は引数で上書き可能です。

```powershell
python migration\02_export_data.py --host localhost --user root --password kuro0711 --database sakila
```

成功すると `migration\data_dump.sql` が生成されます。

### 1-3. 出力内容の確認

`data_dump.sql` には以下が出力されます。

- 文字コード設定（`SET NAMES utf8mb4 …`）
- 子→親の順での `TRUNCATE`（再投入時に重複しないようにするため）
- 親→子の順での `INSERT`（FK 整合を維持）
- `id` 列も含めて完全一致のコピー（参照整合のため）

---

## 手順 2：会社PCにファイルを持ち込む

`migration` フォルダごと会社PCにコピーしてください（`data_dump.sql` を必ず含めること）。

```
C:\study\SHIFTS\shift_app\migration\
    01_ddl.sql
    02_export_data.py
    03_import.bat
    README.md
    data_dump.sql      ← これを忘れない
```

---

## 手順 3：会社PCで DDL とデータを投入

### 3-A. バッチで一括投入（おすすめ）

```powershell
cd C:\study\SHIFTS\shift_app\migration
03_import.bat
```

実行すると、

1. データベース `shift_app` が無ければ作成
2. `01_ddl.sql` で全テーブルを DROP & CREATE
3. `data_dump.sql` で全データを投入

の順に処理します。MySQL の root パスワードは対話入力します。

接続先・DB 名を変えたい場合は `03_import.bat` の冒頭を編集してください。

```bat
set MYSQL_HOST=localhost
set MYSQL_USER=root
set MYSQL_DB=shift_app
```

### 3-B. 手動で実行する場合

```powershell
mysql -u root -p --default-character-set=utf8mb4 -e "CREATE DATABASE IF NOT EXISTS shift_app DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
mysql -u root -p --default-character-set=utf8mb4 shift_app < 01_ddl.sql
mysql -u root -p --default-character-set=utf8mb4 shift_app < data_dump.sql
```

---

## 手順 4：アプリ側の接続先を切り替え

会社PCの `database.py` を編集し、`_DB_CONFIG` を会社PCの環境に合わせます。

```python
_DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "<会社PCのMySQLパスワード>",
    "database": "shift_app",
    "charset": "utf8mb4",
}
```

その後、通常通り起動します。

```powershell
cd C:\study\SHIFTS\shift_app
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8001
```

---

## テーブル投入順（依存関係）

`02_export_data.py` および `01_ddl.sql` は以下の順を厳守しています（FK の親→子）。

1. `SH_TEAMS`
2. `SH_WORK_PTN`
3. `SH_STAFF`
4. `SH_SHIFT_TYPES`
5. `SH_SCHEDULE_PERIODS`
6. `SH_CLOSED_DAYS`
7. `SH_PERIOD_SHIFT_WEEKDAY_DEMAND`
8. `SH_PERIOD_SHIFT_DATE_DEMAND`
9. `SH_CONSTRAINTS`
10. `SH_LEAVE_HALF_DAY_RULES`
11. `SH_LEAVE_REQUESTS`
12. `SH_STAFF_SHIFT_ELIGIBILITY`
13. `SH_STAFF_SHIFT_PAIR_FORBIDDEN`
14. `SH_STAFF_SHIFT_COMPANION_RULE`
15. `SH_STAFF_SHIFT_COMPANION_MEMBER`
16. `SH_STAFF_SHIFT_COMPANION_TARGET_SHIFT`
17. `SH_SHIFT_ASSIGNMENTS`

---

## トラブルシューティング

### 文字化けする
- MySQL クライアントに `--default-character-set=utf8mb4` を必ず付ける
- ファイルが UTF-8（BOMなし）で保存されているか確認

### `ERROR 1062 Duplicate entry`
- すでにデータがある DB に再投入した可能性あり
- `data_dump.sql` 冒頭の `TRUNCATE` が効いていない場合は、手動で全テーブル DELETE してから再実行

### `ERROR 1452` 外部キー制約エラー
- データの並び順が崩れている可能性
- `data_dump.sql` を再生成して投入し直してください

### `02_export_data.py` で `[WARN] xxx を取得できませんでした`
- 移行元 DB に該当テーブルが無い場合のメッセージ。スキップして処理は続行します
