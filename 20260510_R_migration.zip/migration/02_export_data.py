"""SH_xxx テーブルのデータを INSERT 文として data_dump.sql にエクスポートする。

【使い方（旧PC・データ元）】
    cd C:\\study\\SHIFTS\\shift_app
    venv\\Scripts\\activate
    python migration\\02_export_data.py

【出力】
    migration\\data_dump.sql
        - utf8 (BOM なし)
        - 親→子の順に INSERT 文を並べる
        - id 列も含めて完全コピー（参照整合のため）
        - 実行前に各テーブルを TRUNCATE するため、何度でも投入可能

【接続先】
    親フォルダの database.py の _DB_CONFIG をそのまま使用する。
    別 DB から取りたい場合は database.py を一時的に書き換えるか、
    --host/--user/--password/--database 引数で上書きできる。
"""

from __future__ import annotations

import argparse
import datetime as _dt
import os
import sys
from decimal import Decimal
from pathlib import Path

# 親ディレクトリ（shift_app/）を import path に追加し、database.py の設定を再利用する。
_THIS_DIR = Path(__file__).resolve().parent
_APP_DIR = _THIS_DIR.parent
sys.path.insert(0, str(_APP_DIR))

import pymysql  # noqa: E402  既存 requirements.txt に含まれる
from pymysql.cursors import DictCursor  # noqa: E402

from database import _DB_CONFIG  # noqa: E402  接続情報の流用


# 親 → 子の順。INSERT もこの順、TRUNCATE は逆順で実施する。
TABLES_IN_DEPENDENCY_ORDER: list[str] = [
    "SH_TEAMS",
    "SH_WORK_PTN",
    "SH_STAFF",
    "SH_SHIFT_TYPES",
    "SH_SCHEDULE_PERIODS",
    "SH_CLOSED_DAYS",
    "SH_PERIOD_SHIFT_WEEKDAY_DEMAND",
    "SH_PERIOD_SHIFT_DATE_DEMAND",
    "SH_CONSTRAINTS",
    "SH_LEAVE_HALF_DAY_RULES",
    "SH_LEAVE_REQUESTS",
    "SH_STAFF_SHIFT_ELIGIBILITY",
    "SH_STAFF_SHIFT_PAIR_FORBIDDEN",
    "SH_STAFF_SHIFT_COMPANION_RULE",
    "SH_STAFF_SHIFT_COMPANION_MEMBER",
    "SH_STAFF_SHIFT_COMPANION_TARGET_SHIFT",
    "SH_SHIFT_ASSIGNMENTS",
]


def _format_value(val: object) -> str:
    """Python の値を MySQL リテラルへ変換する。"""
    if val is None:
        return "NULL"
    if isinstance(val, bool):
        return "1" if val else "0"
    if isinstance(val, (int,)):
        return str(val)
    if isinstance(val, Decimal):
        return str(val)
    if isinstance(val, float):
        # NaN / inf は INSERT で受け付けないので NULL に倒す
        if val != val or val in (float("inf"), float("-inf")):
            return "NULL"
        return repr(val)
    if isinstance(val, _dt.datetime):
        return f"'{val.strftime('%Y-%m-%d %H:%M:%S')}'"
    if isinstance(val, _dt.date):
        return f"'{val.strftime('%Y-%m-%d')}'"
    if isinstance(val, _dt.timedelta):
        # MySQL の TIME 型は timedelta で返ってくる
        total = int(val.total_seconds())
        sign = "-" if total < 0 else ""
        total = abs(total)
        h, rem = divmod(total, 3600)
        m, s = divmod(rem, 60)
        return f"'{sign}{h:02d}:{m:02d}:{s:02d}'"
    if isinstance(val, (bytes, bytearray)):
        # バイナリは 16 進リテラルで安全に出力
        return "0x" + val.hex() if val else "''"

    text = str(val)
    # MySQL の標準モードでは ANSI_QUOTES が無いため、'...' でクオート。
    # シングルクオートとバックスラッシュをエスケープする。
    text = text.replace("\\", "\\\\").replace("'", "''")
    text = text.replace("\r", "\\r").replace("\n", "\\n").replace("\t", "\\t")
    return f"'{text}'"


def _fetch_table(cur: DictCursor, table: str) -> tuple[list[str], list[dict]]:
    cur.execute(f"SELECT * FROM `{table}`")
    rows = cur.fetchall()
    columns: list[str] = [d[0] for d in cur.description] if cur.description else []
    return columns, list(rows)


def _build_insert_sql(table: str, columns: list[str], rows: list[dict]) -> list[str]:
    if not rows:
        return [f"-- {table}: 0 rows"]
    col_list = ", ".join(f"`{c}`" for c in columns)
    out: list[str] = [f"-- {table}: {len(rows)} rows"]
    # 1 行 1 INSERT で十分（読みやすさ・差分追跡優先）
    for row in rows:
        values = ", ".join(_format_value(row[c]) for c in columns)
        out.append(f"INSERT INTO `{table}` ({col_list}) VALUES ({values});")
    return out


def export(conn: pymysql.connections.Connection, output_path: Path) -> None:
    sql_lines: list[str] = []
    sql_lines.append("-- ============================================================")
    sql_lines.append("-- SH_xxx テーブル データダンプ（02_export_data.py 自動生成）")
    sql_lines.append(f"-- 生成日時: {_dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    sql_lines.append(f"-- 接続元 DB: {_DB_CONFIG['database']}@{_DB_CONFIG['host']}")
    sql_lines.append("-- ============================================================")
    sql_lines.append("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;")
    sql_lines.append("SET FOREIGN_KEY_CHECKS = 0;")
    sql_lines.append("SET UNIQUE_CHECKS = 0;")
    sql_lines.append("SET @OLD_AUTOCOMMIT := @@AUTOCOMMIT;")
    sql_lines.append("SET AUTOCOMMIT = 0;")
    sql_lines.append("START TRANSACTION;")
    sql_lines.append("")

    # 既存データを子→親の順で TRUNCATE（再投入しても重複しない）
    sql_lines.append("-- 既存データを全削除（子→親の順）")
    for table in reversed(TABLES_IN_DEPENDENCY_ORDER):
        sql_lines.append(f"TRUNCATE TABLE `{table}`;")
    sql_lines.append("")

    with conn.cursor(DictCursor) as cur:
        # CHARSET を明示
        cur.execute("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;")

        for table in TABLES_IN_DEPENDENCY_ORDER:
            try:
                columns, rows = _fetch_table(cur, table)
            except pymysql.err.ProgrammingError as exc:
                # 移行元の DB にまだそのテーブルが無い場合は警告だけ出して続行
                sql_lines.append(f"-- [WARN] {table} を取得できませんでした: {exc}")
                sql_lines.append("")
                continue

            sql_lines.extend(_build_insert_sql(table, columns, rows))
            sql_lines.append("")

    sql_lines.append("COMMIT;")
    sql_lines.append("SET AUTOCOMMIT = @OLD_AUTOCOMMIT;")
    sql_lines.append("SET FOREIGN_KEY_CHECKS = 1;")
    sql_lines.append("SET UNIQUE_CHECKS = 1;")

    output_path.write_text("\n".join(sql_lines) + "\n", encoding="utf-8")


def _build_connection(args: argparse.Namespace) -> pymysql.connections.Connection:
    cfg = dict(_DB_CONFIG)
    if args.host:
        cfg["host"] = args.host
    if args.user:
        cfg["user"] = args.user
    if args.password is not None:
        cfg["password"] = args.password
    if args.database:
        cfg["database"] = args.database

    return pymysql.connect(
        host=cfg["host"],
        user=cfg["user"],
        password=cfg["password"],
        database=cfg["database"],
        charset=cfg.get("charset", "utf8mb4"),
        autocommit=False,
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="SH_xxx テーブルを data_dump.sql にエクスポート")
    parser.add_argument("--host", help="移行元 MySQL ホスト（未指定時は database.py の値）")
    parser.add_argument("--user", help="移行元 ユーザー（未指定時は database.py の値）")
    parser.add_argument("--password", help="移行元 パスワード（未指定時は database.py の値）")
    parser.add_argument("--database", help="移行元 データベース名（未指定時は database.py の値）")
    parser.add_argument(
        "--out",
        default=str(_THIS_DIR / "data_dump.sql"),
        help="出力先 SQL ファイル（既定: migration/data_dump.sql）",
    )
    args = parser.parse_args()

    output_path = Path(args.out)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    print(f"[INFO] 接続先 DB: "
          f"{args.database or _DB_CONFIG['database']}@"
          f"{args.host or _DB_CONFIG['host']}")
    print(f"[INFO] 出力先   : {output_path}")

    conn = _build_connection(args)
    try:
        export(conn, output_path)
    finally:
        conn.close()

    size_kb = os.path.getsize(output_path) / 1024
    print(f"[OK] エクスポート完了 ({size_kb:.1f} KB)")
    print(f"[NEXT] 出力された SQL を会社PCに持ち込み、03_import.bat の手順で投入してください。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
