@echo off
chcp 65001 > nul
setlocal EnableDelayedExpansion

rem ============================================================
rem 会社PC側で実行する DDL + データ投入バッチ
rem
rem 想定フォルダ構成:
rem   migration\
rem     01_ddl.sql             … SH_* のみ DDL
rem     full_schema_ddl.sql    … SH_* + t1_loginuser（下で DDL_FILE で切替）
rem     02_export_data.py
rem     03_import.bat    … 本ファイル
rem     data_dump.sql    … 旧PCで 02_export_data.py により生成
rem
rem 事前条件:
rem   - MySQL 8.0+ がインストール済み
rem   - mysql.exe / mysqladmin.exe が PATH に通っている
rem   - 投入先 DB（既定: shift_app）が CREATE 済み（無ければ自動作成）
rem ============================================================

set MYSQL_HOST=localhost
set MYSQL_USER=root
set MYSQL_DB=shift_app
rem DDL を選ぶ: SH のみなら 01_ddl.sql / ログインユーザ表までなら full_schema_ddl.sql
set DDL_FILE=01_ddl.sql
rem set DDL_FILE=full_schema_ddl.sql
set "SCRIPT_DIR=%~dp0"

echo.
echo ============================================================
echo  Shift App  DB 移行ツール
echo ============================================================
echo  ホスト  : %MYSQL_HOST%
echo  ユーザ  : %MYSQL_USER%
echo  DB 名   : %MYSQL_DB%
echo  DDL file: %DDL_FILE%
echo  作業先  : %SCRIPT_DIR%
echo ============================================================
echo.

set /p MYSQL_PWD="MySQL の %MYSQL_USER% パスワードを入力してください: "
echo.

rem -----------------------------------------------------------
rem 1) DB が無ければ作成
rem -----------------------------------------------------------
echo [1/3] データベース %MYSQL_DB% を作成（既にあればスキップ）...
mysql -h %MYSQL_HOST% -u %MYSQL_USER% -p%MYSQL_PWD% --default-character-set=utf8mb4 -e ^
  "CREATE DATABASE IF NOT EXISTS `%MYSQL_DB%` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
if errorlevel 1 (
    echo [ERROR] データベースの作成に失敗しました。
    goto :fail
)

rem -----------------------------------------------------------
rem 2) DDL 投入
rem -----------------------------------------------------------
echo [2/3] DDL を投入: %DDL_FILE%
mysql -h %MYSQL_HOST% -u %MYSQL_USER% -p%MYSQL_PWD% --default-character-set=utf8mb4 %MYSQL_DB% < "%SCRIPT_DIR%%DDL_FILE%"
if errorlevel 1 (
    echo [ERROR] DDL の投入に失敗しました。
    goto :fail
)

rem -----------------------------------------------------------
rem 3) データ投入
rem -----------------------------------------------------------
if not exist "%SCRIPT_DIR%data_dump.sql" (
    echo.
    echo [SKIP] data_dump.sql が見つかりません。
    echo        旧PCで `python migration\02_export_data.py` を実行し、
    echo        生成された data_dump.sql を本フォルダに置いてから再実行してください。
    echo.
    echo [DONE] DDL のみ投入完了しました。
    goto :end
)

echo [3/3] データを投入: data_dump.sql
mysql -h %MYSQL_HOST% -u %MYSQL_USER% -p%MYSQL_PWD% --default-character-set=utf8mb4 %MYSQL_DB% < "%SCRIPT_DIR%data_dump.sql"
if errorlevel 1 (
    echo [ERROR] データ投入に失敗しました。
    goto :fail
)

echo.
echo [OK] DDL とデータの投入が完了しました。
goto :end

:fail
echo.
echo [NG] 処理を中断しました。
echo      パスワード／DB 接続／SQL ファイルの内容を確認してください。
exit /b 1

:end
echo.
pause
endlocal
