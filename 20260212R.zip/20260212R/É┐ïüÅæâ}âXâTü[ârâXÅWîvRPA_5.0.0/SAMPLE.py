# -*- coding: utf-8 -*-

"""
Created on Mon April 16 15:19:19 2024
@author: hidtoshi.kurosu@rakuten-bank.co.jp
"""
# standard libraries
import configparser
import csv
import re
import datetime
import logging
import os
import re
from typing import Dict, List, Optional, Union
import time
import pandas as pd
import sys
import time
import win32com.client

# 3rd parties' libraries
import pandas as pd
import selenium
# import pyperclip
from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.firefox.service import Service
from selenium.webdriver.firefox.options import Options

from typing import List, Dict
from selenium.webdriver.common.action_chains import ActionChains


# constants
formatter: logging.Formatter = logging.Formatter("%(asctime)s %(name)s:%(lineno)s %(funcName)s [%(levelname)s]: %(message)s")
LOGGER: logging.Logger = logging.getLogger(__name__)
handler: logging.Handler = logging.StreamHandler()
handler.setFormatter(formatter)
handler.setLevel(logging.DEBUG)
LOGGER.setLevel(logging.DEBUG)
for _handler in LOGGER.handlers:
    LOGGER.removeHandler(_handler)
LOGGER.addHandler(handler)
LOGGER.propagate = False

BASE_PATH: str = os.path.dirname(__file__)

CONFIG_INI = configparser.ConfigParser(interpolation=configparser.ExtendedInterpolation())
CONFIG_INI_PATH: str = os.path.splitext(__file__)[0] + ".conf"
assert os.path.exists(CONFIG_INI_PATH)
CONFIG_INI.read(CONFIG_INI_PATH, encoding="utf-8")
DEFAULT = CONFIG_INI["DEFAULT"]

INFO_FILE_PATH: str = os.path.join(BASE_PATH, DEFAULT.get("INFO_CSV_FILE"))

AKS_URL: str = DEFAULT.get("AKS_URL")

CHROME_DRIVER: str = os.path.join(BASE_PATH, DEFAULT.get("CHROME_DRIVER"))
IE_DRIVER: str = os.path.join(BASE_PATH, DEFAULT.get("IE_DRIVER"))
FF_DRIVER: str = os.path.join(BASE_PATH, DEFAULT.get("FF_DRIVER"))

WEB_DRIVER: str = DEFAULT.get("WEB_DRIVER")
# WEB_DRIVER: str = DEFAULT.get("WEB_DRIVER")
assert WEB_DRIVER in ("CHROME", "IE", "FF")
DISPLAY_POS:int = 3
DELIMITER="\t"
SEP = ","

# グローバル変数を定義
csv_save_dir = None



def f_split_month(yyyymm: str, split_num: int) -> List[Dict[str, int]]:
    """
    指定されたyyyymmの前月をsplit_num分割し、各分割のfrom/toをyyyy,mm,ddで返却する。
    返却値: [{'from_yyyy': xxxx, 'from_mm': xx, 'from_dd': xx, 'to_yyyy': xxxx, 'to_mm': xx, 'to_dd': xx}, ...]
    """
    import calendar
    from datetime import datetime, timedelta

    # yyyymmから前月を計算
    year = int(yyyymm[:4])
    month = int(yyyymm[4:6])
    if month == 1:
        prev_year = year - 1
        prev_month = 12
    else:
        prev_year = year
        prev_month = month - 1

    # 前月の月初・月末
    from_date = datetime(prev_year, prev_month, 1)
    last_day = calendar.monthrange(prev_year, prev_month)[1]
    to_date = datetime(prev_year, prev_month, last_day)

    total_days = (to_date - from_date).days + 1  # 日数

    result = []
    for i in range(split_num):
        # 各分割の開始日
        start_offset = (total_days * i) // split_num
        end_offset = (total_days * (i + 1)) // split_num - 1

        split_from = from_date + timedelta(days=start_offset)
        split_to = from_date + timedelta(days=end_offset)

        result.append({
            'from_yyyy': split_from.year,
            'from_mm': split_from.month,
            'from_dd': split_from.day,
            'to_yyyy': split_to.year,
            'to_mm': split_to.month,
            'to_dd': split_to.day
        })

    return result


def set_text(text_input: WebElement, text: str) -> None:
    """
    set text string to <input/>

    called_from: request_query(), set_fromto_date()
    """
    #text_input.send_keys(Keys.CONTROL + "a")
    #text_input.send_keys(Keys.DELETE)
    text_input.clear()
    text_input.send_keys(text)
    return

def get_webdriver_object() -> Union[webdriver.Chrome, webdriver.Ie, webdriver.Firefox]:
    """
    get WebDriver object

    called_from: main()
    """
    global CHROME_DRIVER, IE_DRIVER, FF_DRIVER
    global WEB_DRIVER
    if selenium.__version__.startswith("4."):
        if WEB_DRIVER == "CHROME":
            assert os.path.exists(CHROME_DRIVER)
            chrome_service = webdriver.chrome.service.Service(executable_path=CHROME_DRIVER)
            browser = webdriver.Chrome(service=chrome_service)
        elif WEB_DRIVER == "IE":
            assert os.path.exists(IE_DRIVER)
            ie_service = webdriver.ie.service.Service(executable_path=IE_DRIVER)
            browser = webdriver.Ie(service=ie_service)
        elif WEB_DRIVER == "FF":
            assert os.path.exists(FF_DRIVER)
            ff_service = webdriver.firefox.service.Service(executable_path=FF_DRIVER)

            # ff_options = webdriver.FirefoxOptions()
            ff_options = Options()
            ff_options.binary_location = "C:/Program Files/Mozilla Firefox/firefox.exe"

            # Firefoxのオプションを設定
            global csv_save_dir
            ff_options.set_preference("browser.download.folderList", 2)  # 2: 指定したフォルダ
            ff_options.set_preference("browser.download.dir", csv_save_dir)
            # ff_options.set_preference("browser.helperApps.neverAsk.saveToDisk", "application/pdf")  # PDFのMIMEタイプ
            ff_options.set_preference("browser.helperApps.neverAsk.saveToDisk", "text/csv,application/csv,application/vnd.ms-excel")  # CSVのMIMEタイプ

            ff_options.set_preference("pdfjs.disabled", True)  # PDFビューアを無効にする

            # ダウンロード確認ダイアログを抑止
            ff_options.set_preference("browser.download.panel.shown", False)
            ff_options.set_preference("browser.download.panel.defaultSession", True)
            ff_options.set_preference("browser.download.useDownloadDir", True)
            ff_options.set_preference("browser.download.manager.showAlertOnComplete", False)
            ff_options.set_preference("browser.download.manager.showWhenStarting", False)
            ff_options.set_preference("browser.download.manager.focusWhenStarting", False)
            ff_options.set_preference("browser.download.manager.closeWhenDone", True)

            browser = webdriver.Firefox(service=ff_service, options=ff_options)
        # end of if
    elif selenium.__version__.startswith("3."):
        if WEB_DRIVER == "CHROME":
            browser = webdriver.Chrome(executable_path=CHROME_DRIVER)
        elif WEB_DRIVER == "IE":
            browser = webdriver.Ie(executable_path=IE_DRIVER)
        elif WEB_DRIVER == "FF":
            browser = webdriver.Firefox(executable_path=FF_DRIVER)
        # end of if
    else:
        raise f"Unknown selenium version: {selenium.__version__}"
    # end of if
    return browser

def create_folder(folder_path) -> None:
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)

def save_to_csv(data, output_file):
    with open(output_file, 'w', newline='') as f:
        writer = csv.writer(f)
        for row in data:
            writer.writerow(row)

def extract_folder_path(full_path):
    foler_path, _ = os.path.split(full_path)
    return foler_path

def main() -> None:

    # 引数チェック
    if len(sys.argv) < 3:
         sys.exit(1)

    # 引数:1, 2 ”入出金明細発行_検索”画面の”取引日指定”欄
    yyyymmdd = "20250701"
    yyyymmdd2 = "20250710"
    start_date_list = yyyymmdd.split('/')
    end_date_list = yyyymmdd2.split('/')

    # 引数1 : 対象年月 yyyymm
    wk_yyyymm = sys.argv[1]

    # 引数2 : CSVの格納フォルダ
    wk_root_folder = sys.argv[2]

    # 引数3 : CSV DL時の日付分割回数指定エクセル
    wk_csv_slplit_Exls = sys.argv[3]

    # # 引数:5 PDFの保管場所のフルパス
    global csv_save_dir
    csv_save_dir = os.path.join(wk_root_folder,wk_yyyymm)

    # # pdfを保存するフォルダが存在しない場合は作成し、存在する場合は配下のファイルをすべて削除する
    if not os.path.exists(csv_save_dir):
        os.makedirs(csv_save_dir)
    else:
        for file in os.listdir(csv_save_dir):
            file_path = os.path.join(csv_save_dir, file)
            if os.path.isfile(file_path):
                os.remove(file_path)

    # LOGGER.info(f"入出金明細発行画面で取引日が{sys.argv[1]}から{sys.argv[2]}までの情報を処理する")

    # driver 初期化
    browser: Union[webdriver.Chrome, webdriver.Ie, webdriver.Firefox] = get_webdriver_object()
    browser.implicitly_wait(15.0)
    global AKS_URL
    browser.get(AKS_URL)

    # オリジナルエクセルにダウンロード期間の分割回数が設定されているので、それに合わせてFromとtOを設定する。
    # e.g.)分割回数が3と指定されていた場合、日付を３分割された3行が挿入されることになる。
    try:
        file_name = os.path.join(wk_root_folder,wk_csv_slplit_Exls)
        df_work = pd.read_excel(file_name, sheet_name="最新", header=0)
        print(" Excelファイルの読み込み成功")
    except Exception as e:
        print(f" Excelファイルの読み込み失敗: {e}")
        return

    columns = [
        "支店番号", "口座番号", "分割回数",
        "FROM_DATE_OF_YEAR", "FROM_DATE_OF_MONTH", "FROM_DATE_OF_DAY",
        "TO_DATE_OF_YEAR", "TO_DATE_OF_MONTH", "TO_DATE_OF_DAY"
    ]
    df = pd.DataFrame(columns=columns)

    for _, row in df_work.iterrows():
        try:
            branch_code = row.iloc[0]
            account_number = row.iloc[1]
            split_num = int(row.iloc[2])

            # print(f"支店番号: {branch_code}, 口座番号: {account_number}, 分割回数: {split_num}")

            split_result = f_split_month(wk_yyyymm, split_num)

            for date_range in split_result:
                df = pd.concat([df, pd.DataFrame([{
                    "支店番号": branch_code,
                    "口座番号": account_number,
                    "分割回数": split_num,
                    "FROM_DATE_OF_YEAR": date_range["from_yyyy"],
                    "FROM_DATE_OF_MONTH": date_range["from_mm"],
                    "FROM_DATE_OF_DAY": date_range["from_dd"],
                    "TO_DATE_OF_YEAR": date_range["to_yyyy"],
                    "TO_DATE_OF_MONTH": date_range["to_mm"],
                    "TO_DATE_OF_DAY": date_range["to_dd"]
                }])], ignore_index=True)

        except Exception as e_row:
            print(f"& 行の処理中にエラーが発生しました: {e_row}")
            continue

    for index, row in df.iterrows():
        branch_code    = str(row['支店番号'])
        account_number    = str(row['口座番号'])
        split_count    = str(row['分割回数'])

        FROM_DATE_OF_YEAR    = str(row['FROM_DATE_OF_YEAR'])
        FROM_DATE_OF_MONTH    = str(row['FROM_DATE_OF_MONTH'])
        FROM_DATE_OF_DAY    = str(row['FROM_DATE_OF_DAY'])

        TO_DATE_OF_YEAR    = str(row['TO_DATE_OF_YEAR'])
        TO_DATE_OF_MONTH    = str(row['TO_DATE_OF_MONTH'])
        TO_DATE_OF_DAY    = str(row['TO_DATE_OF_DAY'])

        LOGGER.info(rf'@ : {branch_code}-{account_number}-{split_count} @@@@@')
        LOGGER.info(rf'@F: {FROM_DATE_OF_YEAR}-{FROM_DATE_OF_MONTH}-{FROM_DATE_OF_DAY} @@@@@')
        LOGGER.info(rf'@T: {TO_DATE_OF_YEAR}-{TO_DATE_OF_MONTH}-{TO_DATE_OF_DAY} @@@@@')

        # 支店番号
        set_text(browser.find_element(By.XPATH, "/html/body/div/form/table/tbody/tr[1]/td/input"), branch_code)

        # 口座番号
        set_text(browser.find_element(By.XPATH, "/html/body/div/form/table/tbody/tr[2]/td/input"), account_number)

        # 「口座検索」画面で「検索」を押す
        WebDriverWait(browser, 100000.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "//input[@type='BUTTON' and @value='照　会']"))).click()
        browser.implicitly_wait(3.0)

        # メニューから"入出金照会"を押す
        browser.find_element(By.LINK_TEXT, "入出金照会").click()
        time.sleep(1)

        try:
            # 開始年月日
            element = browser.find_element(By.NAME, "FROM_DATE_OF_YEAR")
            element.clear()
            element.send_keys(FROM_DATE_OF_YEAR)

            element = browser.find_element(By.NAME, "FROM_DATE_OF_MONTH")
            element.clear()
            element.send_keys(FROM_DATE_OF_MONTH)

            element = browser.find_element(By.NAME, "FROM_DATE_OF_DAY")
            element.clear()
            element.send_keys(FROM_DATE_OF_DAY)

            # 終了年月日
            element = browser.find_element(By.NAME, "TO_DATE_OF_YEAR")
            element.clear()
            element.send_keys(TO_DATE_OF_YEAR)

            element = browser.find_element(By.NAME, "TO_DATE_OF_MONTH")
            element.clear()
            element.send_keys(TO_DATE_OF_MONTH)

            element = browser.find_element(By.NAME, "TO_DATE_OF_DAY")
            element.clear()
            element.send_keys(TO_DATE_OF_DAY)


            # browser.find_element(By.NAME, "DOWNLOAD").click()
            # time.sleep(2)

            before = set(os.listdir(csv_save_dir))
            browser.find_element(By.NAME, "DOWNLOAD").click()
            time.sleep(2)  # ダウンロード完了まで待機
            after = set(os.listdir(csv_save_dir))
            new_files = after - before
            if new_files:
                downloaded_file = new_files.pop()
                # 任意のファイル名をここで指定
                # new_filename = f"{branch_code}_{account_number}_{FROM_DATE_OF_YEAR}{FROM_DATE_OF_MONTH:02d}{FROM_DATE_OF_DAY:02d}-{TO_DATE_OF_YEAR}{TO_DATE_OF_MONTH:02d}{TO_DATE_OF_DAY:02d}.csv"
                new_filename = f"{branch_code}-{account_number}_{FROM_DATE_OF_YEAR}{int(FROM_DATE_OF_MONTH):02d}{int(FROM_DATE_OF_DAY):02d}-{TO_DATE_OF_YEAR}{int(TO_DATE_OF_MONTH):02d}{int(TO_DATE_OF_DAY):02d}.csv"
                os.rename(
                    os.path.join(csv_save_dir, downloaded_file),
                    os.path.join(csv_save_dir, new_filename)
                )
                LOGGER.info(f"ダウンロードファイルをリネームしました: {new_filename}")
            else:
                try:
                    browser.back()
                    LOGGER.info(rf'@@@@@ ブラウザバック @@@@@')
                except Exception as e:
                    LOGGER.info(rf'@@@@@ 戻るなし @@@@@')
                    

        except Exception as e:
            LOGGER.info(rf'@@@@@ 明細なし @@@@@')
        finally:
            browser.find_element(By.LINK_TEXT, "口座選択").click()
            # browser.implicitly_wait(3000.0)

            LOGGER.info(f"@@@@@ 口座選択 @@@@@")
            continue

    browser.close()

    # out_file_prefix = "pdfList"

    # # 出力結果はinputと同じ場所に格納
    # # out_folder_path = extract_folder_path(pdf_save_dir)
    # out_folder_path = pdf_save_dir
    # # csvで保存 
    # save_to_csv(out_data, rf"{out_folder_path}\{out_file_prefix}.csv")
    # # xlsxで保存 
    # tmp_df = pd.DataFrame(out_data)
    # tmp_df.to_excel(rf"{out_folder_path}\{out_file_prefix}.xlsx", index = False, header=False)

    return

if __name__ == "__main__":
    LOGGER.info("starts")
    main()
    LOGGER.info("ends")
