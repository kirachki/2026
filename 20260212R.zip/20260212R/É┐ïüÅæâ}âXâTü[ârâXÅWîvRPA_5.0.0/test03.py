from typing import List, Dict

def f_split_month(yyyymmdd_from: str, yyyymmdd_to: str, split_num: int) -> List[Dict[str, int]]:
    """
    指定されたyyyymmdd_from～yyyymmdd_to（どちらも yyyy/mm/dd 形式）の期間をsplit_num分割し、
    各分割のfrom/toをyyyy,mm,ddで返却する。
    返却値: [{'from_yyyy': xxxx, 'from_mm': xx, 'from_dd': xx, 'to_yyyy': xxxx, 'to_mm': xx, 'to_dd': xx}, ...]
    """
    from datetime import datetime, timedelta

    # yyyy/mm/dd形式で受け取り、それを日付に変換して使用
    from_date = datetime.strptime(yyyymmdd_from, "%Y/%m/%d")
    to_date = datetime.strptime(yyyymmdd_to, "%Y/%m/%d")

    total_days = (to_date - from_date).days + 1  # 端点を含める

    result = []
    for i in range(split_num):
        start_offset = (total_days * i) // split_num
        end_offset = (total_days * (i + 1)) // split_num - 1

        split_from = from_date + timedelta(days=start_offset)
        split_to = from_date + timedelta(days=end_offset)

        result.append({
            'from_yyyy': split_from.year,
            'from_mm': split_from.month,
            'from_dd': split_from.day,
            'to_yyyy': split_to.year,
            'to_mm': split_to.month,
            'to_dd': split_to.day
        })
    return result

# 月を指定された数で分割します。分割なし1です。
def main():
    # 2026/01/01～2026/01/31を10分割（例）
    yyyymmdd_from = "2026/01/01"
    yyyymmdd_to = "2026/01/31"
    # split_num = 10
    split_num = 2
    result = f_split_month(yyyymmdd_from, yyyymmdd_to, split_num)
    # print(f"f_split_month('{yyyymmdd_from}', '{yyyymmdd_to}', {split_num}) の結果:")
    # print(f"{'No.':<3} {'from':<10} {'to':<10}")
    # print("-" * 30)
    for i, r in enumerate(result, 1):
        from_str = f"{r['from_yyyy']:04}/{r['from_mm']:02}/{r['from_dd']:02}"
        to_str = f"{r['to_yyyy']:04}/{r['to_mm']:02}/{r['to_dd']:02}"
        # print(f"{i:<3} {from_str:<10} {to_str:<10}")
        # print(f"{from_str} ~ {to_str}")

        start_date_list = from_str.split('/')
        end_date_list = to_str.split('/')

        print("@@@@@")
        print(f"{start_date_list[0]} {start_date_list[1]} {start_date_list[2]}")
        print(f"{end_date_list[0]} {end_date_list[1]} {end_date_list[2]}")  


if __name__ == "__main__":
    main()
