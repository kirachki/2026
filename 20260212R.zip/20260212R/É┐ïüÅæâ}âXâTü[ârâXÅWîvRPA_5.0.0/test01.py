from datetime import datetime

def format_to_slash_date(date_string):
    """
    'yyyy-mm-dd 00:00:00' 形式の文字列を 'yyyy/mm/dd' 形式に変換する
    """
    try:
        # 文字列をdatetimeオブジェクトに変換
        dt = datetime.strptime(date_string, '%Y-%m-%d %H:%M:%S')
        # 任意のフォーマットに変換して返す
        return dt.strftime('%Y/%m/%d')
    except ValueError as e:
        return f"エラー: フォーマットが正しくありません ({e})"

# ハイフンをスラッシュに変換します。それとyyyy/mm/dd形式に変換します。
def main():
    # テストデータ
    test_cases = [
        "2026-02-11 00:00:00",
        "2023-12-31 23:59:59",
        "2024-01-01 12:30:00",
        "invalid-date" # エラーハンドリング用
    ]
    
    print(f"{'入力文字列':<20} -> {'変換後'}")
    print("-" * 40)
    
    for case in test_cases:
        result = format_to_slash_date(case)
        print(f"{case:<20} -> {result}")


    result = format_to_slash_date("2026-02-11 00:00:00")
    print(f"2026-02-11 00:00:00 -> {result}")


if __name__ == "__main__":
    main()
    