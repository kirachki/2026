"""
ステップ1: MCPツール共通実装

FastAPI画面とMCPサーバーの両方から同じ関数を利用する。
"""
from __future__ import annotations

from datetime import datetime
import json
import os
from pathlib import Path
import subprocess
import sys

import db
import invoice_pdf


BASE_DIR = Path(__file__).resolve().parent
DEFAULT_PDF_OUTPUT_DIR = BASE_DIR / "outputs" / "invoices"


def get_current_time() -> str:
    """現在時刻を日本向けフォーマットで返す。"""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def read_text_file(file_path: str) -> str:
    """
    指定したテキストファイルを読む。
    セキュリティ上、プロジェクト配下の相対パスのみ許可する。
    """
    target = (file_path or "").strip()
    if not target:
        raise ValueError("ファイルパスを入力してください。")

    # 例: README_FastAPI_htmx.md / templates/fragments/hello.html
    p = Path(target)
    if p.is_absolute() or ".." in p.parts:
        raise ValueError("相対パスのみ指定できます。")

    full = (BASE_DIR / p).resolve()
    if BASE_DIR not in full.parents and full != BASE_DIR:
        raise ValueError("プロジェクト配下のファイルのみ読めます。")
    if not full.exists() or not full.is_file():
        raise ValueError("指定ファイルが存在しません。")

    text = full.read_text(encoding="utf-8")
    return text if text else "(空ファイル)"


def get_invoice_header_summary(invoice_no: str) -> dict:
    """
    請求番号で T1_請求書データ_ヘッダを検索し、主要5項目を返す。
    MCP では複数 out 引数ではなく、1つの構造化データ(dict)として返す。
    """
    uid = (invoice_no or "").strip()
    if not uid:
        raise ValueError("請求番号を入力してください。")

    row = db.fetch_invoice_for_maintenance(uid)
    if not row:
        return {
            "found": False,
            "請求書番号": uid,
            "宛名_取引先名": "",
            "宛名_担当部署": "",
            "宛名_担当者": "",
            "郵便番号": "",
            "住所": "",
            "message": "該当データが見つかりません。",
        }

    header = row.get("header") or {}
    return {
        "found": True,
        "請求書番号": uid,
        "宛名_取引先名": str(header.get("宛名_取引先名") or ""),
        "宛名_担当部署": str(header.get("宛名_担当部署") or ""),
        "宛名_担当者": str(header.get("宛名_担当者") or ""),
        "郵便番号": str(header.get("郵便番号") or ""),
        "住所": str(header.get("住所") or ""),
        "message": "取得成功",
    }


def _resolve_pdf_output(invoice_no: str, output_dir: str) -> tuple[str, Path]:
    inv = (invoice_no or "").strip()
    if not inv:
        raise ValueError("請求番号を入力してください。")

    target_dir_raw = (output_dir or "").strip()
    if target_dir_raw:
        p = Path(target_dir_raw)
        if p.is_absolute() or ".." in p.parts:
            raise ValueError("output_dir はプロジェクト配下の相対パスのみ指定できます。")
        target_dir = (BASE_DIR / p).resolve()
    else:
        target_dir = DEFAULT_PDF_OUTPUT_DIR.resolve()

    if BASE_DIR not in target_dir.parents and target_dir != BASE_DIR:
        raise ValueError("output_dir はプロジェクト配下のみ指定できます。")

    target_dir.mkdir(parents=True, exist_ok=True)
    return inv, target_dir


def _generate_invoice_pdf_file_direct(invoice_no: str, output_dir: str = "") -> dict:
    inv, target_dir = _resolve_pdf_output(invoice_no, output_dir)
    file_name = invoice_pdf.get_invoice_pdf_filename(inv) or f"{inv}.pdf"
    output_path = target_dir / file_name
    saved = invoice_pdf.save_invoice_pdf_to_path(inv, output_path)

    return {
        "ok": True,
        "invoice_no": inv,
        "file_path": str(saved),
        "file_name": saved.name,
        "size_bytes": int(saved.stat().st_size),
        "message": "PDFを生成しました。",
    }


def generate_invoice_pdf_file(invoice_no: str, output_dir: str = "") -> dict:
    """
    請求番号をもとに請求書PDFを生成し、サーバー上のファイルへ保存する。
    戻り値は MCP で扱いやすいメタ情報(dict)。
    """
    return _generate_invoice_pdf_file_direct(invoice_no, output_dir)


def generate_invoice_pdf_file_subprocess(invoice_no: str, output_dir: str = "") -> dict:
    """
    PDF生成を別Pythonプロセスで実行する（MCP経由時のハング回避用）。
    """
    inv, target_dir = _resolve_pdf_output(invoice_no, output_dir)
    code = (
        "import json,sys,mcp_tools;"
        "res=mcp_tools._generate_invoice_pdf_file_direct(sys.argv[1],sys.argv[2]);"
        "print(json.dumps(res,ensure_ascii=False))"
    )
    cp = subprocess.run(
        [sys.executable, "-c", code, inv, str(target_dir.relative_to(BASE_DIR))],
        cwd=str(BASE_DIR),
        capture_output=True,
        text=False,
        env={
            **os.environ,
            "PYTHONIOENCODING": "utf-8",
            "PYTHONUTF8": "1",
        },
        timeout=180,
        check=False,
    )
    stdout_text = (cp.stdout or b"").decode("utf-8", errors="replace").strip()
    stderr_text = (cp.stderr or b"").decode("utf-8", errors="replace").strip()
    if cp.returncode != 0:
        err = (stderr_text or stdout_text) or "PDF生成プロセスでエラーが発生しました。"
        raise RuntimeError(err)
    if not stdout_text:
        raise RuntimeError("PDF生成プロセスの応答が空です。")
    return json.loads(stdout_text)
