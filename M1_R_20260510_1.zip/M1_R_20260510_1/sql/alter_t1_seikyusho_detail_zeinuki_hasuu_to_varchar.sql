-- T1_請求書データ_明細.税抜金額端数処理区分: 数値型等 -> VARCHAR(255)
-- 変更後、既存行の値はすべて「切捨て」に統一する。
-- アプリ側（db._detail_cell_for_insert）は日本語（切り上げ／切捨て／四捨五入）を保存する。

ALTER TABLE `T1_請求書データ_明細`
  MODIFY COLUMN `税抜金額端数処理区分` VARCHAR(255) DEFAULT NULL;

UPDATE `T1_請求書データ_明細`
  SET `税抜金額端数処理区分` = '切捨て';
