-- メンション（@ユーザーID / @表示名）。T1_ChatMessage 削除時に CASCADE で消える。
-- 適用例: mysql -u ... dbname < sql/install_team_chat_mention.sql

CREATE TABLE IF NOT EXISTS `T1_ChatMention` (
  `message_id` BIGINT NOT NULL,
  `mentioned_userid` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`message_id`, `mentioned_userid`),
  KEY `idx_T1_ChatMention_user_msg` (`mentioned_userid`, `message_id`),
  CONSTRAINT `fk_T1_ChatMention_message` FOREIGN KEY (`message_id`) REFERENCES `T1_ChatMessage` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_T1_ChatMention_user` FOREIGN KEY (`mentioned_userid`) REFERENCES `T1_LoginUser` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
