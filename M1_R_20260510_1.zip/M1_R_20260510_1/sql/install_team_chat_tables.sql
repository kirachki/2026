-- Team chat tables. Requires T1_LoginUser. Run: mysql -u root -p sakila < sql/install_team_chat_tables.sql

CREATE TABLE IF NOT EXISTS `T1_ChatChannel` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(200) NOT NULL,
  `created_by_userid` VARCHAR(50) NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_T1_ChatChannel_updated` (`updated_at`),
  CONSTRAINT `fk_T1_ChatChannel_creator` FOREIGN KEY (`created_by_userid`) REFERENCES `T1_LoginUser` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `T1_ChatMember` (
  `channel_id` BIGINT NOT NULL,
  `userid` VARCHAR(50) NOT NULL,
  `joined_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`channel_id`, `userid`),
  KEY `idx_T1_ChatMember_userid` (`userid`),
  CONSTRAINT `fk_T1_ChatMember_channel` FOREIGN KEY (`channel_id`) REFERENCES `T1_ChatChannel` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_T1_ChatMember_user` FOREIGN KEY (`userid`) REFERENCES `T1_LoginUser` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `T1_ChatMessage` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `channel_id` BIGINT NOT NULL,
  `sender_userid` VARCHAR(50) NOT NULL,
  `body` TEXT NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_T1_ChatMessage_channel_id` (`channel_id`, `id`),
  CONSTRAINT `fk_T1_ChatMessage_channel` FOREIGN KEY (`channel_id`) REFERENCES `T1_ChatChannel` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_T1_ChatMessage_sender` FOREIGN KEY (`sender_userid`) REFERENCES `T1_LoginUser` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `T1_ChatMention` (
  `message_id` BIGINT NOT NULL,
  `mentioned_userid` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`message_id`, `mentioned_userid`),
  KEY `idx_T1_ChatMention_user_msg` (`mentioned_userid`, `message_id`),
  CONSTRAINT `fk_T1_ChatMention_message` FOREIGN KEY (`message_id`) REFERENCES `T1_ChatMessage` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_T1_ChatMention_user` FOREIGN KEY (`mentioned_userid`) REFERENCES `T1_LoginUser` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
