-- M_取引先マスタ.ID 採番用の疑似シーケンス（MySQL）
-- カレント（払い出し開始値）は 2001

CREATE TABLE IF NOT EXISTS `M_取引先マスタ_ID_SEQ` (
  `seq_name` VARCHAR(64) NOT NULL,
  `next_value` BIGINT NOT NULL,
  PRIMARY KEY (`seq_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO `M_取引先マスタ_ID_SEQ` (`seq_name`, `next_value`)
VALUES ('m_torihiki_master_id_seq', 2001);
