-- T1_請求書データ_ヘッダ.消費税端数: INT -> VARCHAR(255)
-- 変更後、既存行の値はすべて「切捨て」に統一する。
-- アプリ側（db._header_value_for_persist）は日本語（切り上げ／切捨て／四捨五入）を保存する。

ALTER TABLE `T1_請求書データ_ヘッダ`
  MODIFY COLUMN `消費税端数` VARCHAR(255) DEFAULT NULL;

UPDATE `T1_請求書データ_ヘッダ`
  SET `消費税端数` = '切捨て';
