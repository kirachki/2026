"""
MySQL データベース接続・クエリモジュール (PyMySQL)

テーブル・カラム定義の正はリポジトリ直下の create_table_update.sql（MySQL 実体から取得した DDL）。
ここでは列名を SQL に埋め込むだけで、型の完全なミスマッチはドライバと MySQL の変換に任せている。
部署・ロール（M_Department / M_Role / T_UserDepartment / T_UserRole）の権限確認は
`f_check_permissions` / `f_check_permissions2` を参照。
"""
import hashlib
import logging
import re
import unicodedata
from datetime import datetime, timedelta, date

import pymysql
from pymysql.cursors import DictCursor
from pymysql.err import IntegrityError, ProgrammingError

logger = logging.getLogger(__name__)

# _DB_CONFIG = {
#     "host": "10.1.100.30",
#     "user": "jinostest",
#     "password": "jinostest",
#     "database": "jinostest",
#     "charset": "utf8mb4",
#     "cursorclass": DictCursor,
# }
_DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "kuro0711",
    "database": "sakila",
    "charset": "utf8mb4",
    "cursorclass": DictCursor,
}



# 画面の検索パラメータ名 → テーブルのカラム名
_SEARCH_COLUMN_MAP = {
    "search_koza_meigi": "`口座名義(漢字)`",
    "search_hojin_mei":  "`法人名(漢字)`",
    "search_daihyo_sei": "CONCAT(`代表者姓(漢字)`, `代表者名(漢字)`)",
    "search_kanri_sei":  "CONCAT(`口座管理者姓(漢字)`, `口座管理者名(漢字)`)",
}

_SELECT_COLUMNS = """\
    `店番号`,
    `口座番号`,
    `MDAS-ID`,
    `口座名義(漢字)`,
    `法人名(漢字)`,
    `住所(漢字)`,
    CONCAT_WS('-', `電話番号(市外局番)`, `電話番号(市内局番)`, `電話番号(局番)`) AS `電話番号`,
    CONCAT(`代表者姓(漢字)`, `代表者名(漢字)`) AS `代表者名`,
    CONCAT(`口座管理者姓(漢字)`, `口座管理者名(漢字)`) AS `口座管理者`\
"""

# 明細部分の表示限界
DISPLAY_LIMIT = 999

# M_取引先マスタ.ID 採番用（MySQL 疑似シーケンス）
_TORIHIKI_ID_SEQ_TABLE = "M_取引先マスタ_ID_SEQ"
_TORIHIKI_ID_SEQ_NAME = "m_torihiki_master_id_seq"
_TORIHIKI_ID_SEQ_START = 2001

# 最終ログインから何日以上で強制パスワード変更するか
FORCE_PWD_CHANGE_DAYS = 180


def _get_connection():
    return pymysql.connect(**_DB_CONFIG)


def _next_m_torihikisaki_master_id(cur) -> int:
    """
    M_取引先マスタ.ID 用の次採番値を返す（2001 開始）。
    MySQL はシーケンスオブジェクト非対応のため、管理テーブルで疑似実装する。
    """
    cur.execute(
        f"CREATE TABLE IF NOT EXISTS `{_TORIHIKI_ID_SEQ_TABLE}` ("
        "`seq_name` VARCHAR(64) NOT NULL,"
        "`next_value` BIGINT NOT NULL,"
        "PRIMARY KEY (`seq_name`)"
        ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    )
    cur.execute(
        f"INSERT IGNORE INTO `{_TORIHIKI_ID_SEQ_TABLE}` (`seq_name`, `next_value`) VALUES (%s, %s)",
        (_TORIHIKI_ID_SEQ_NAME, _TORIHIKI_ID_SEQ_START),
    )
    cur.execute(
        f"UPDATE `{_TORIHIKI_ID_SEQ_TABLE}` "
        "SET `next_value` = LAST_INSERT_ID(`next_value` + 1) "
        "WHERE `seq_name`=%s",
        (_TORIHIKI_ID_SEQ_NAME,),
    )
    cur.execute("SELECT LAST_INSERT_ID() AS `next_value`")
    row = cur.fetchone() or {}
    try:
        # UPDATE 時に +1 された値が入るため、払い出し値は -1
        return int(row.get("next_value")) - 1
    except Exception as e:
        raise RuntimeError("取引先IDシーケンスの採番に失敗しました。") from e


def allocate_m_torihikisaki_master_id() -> int:
    """
    画面（新規追加）表示用に、M_取引先マスタ.ID 用シーケンスの次値を1回消費して返す。
    未保存のまま再表示するたびに番号は進む（未使用番号の欠番は許容する設計）。
    シーケンス名: _TORIHIKI_ID_SEQ_NAME（m_torihiki_master_id_seq）
    """
    conn = _get_connection()
    try:
        conn.autocommit(False)
        try:
            with conn.cursor() as cur:
                next_id = _next_m_torihikisaki_master_id(cur)
            conn.commit()
            return int(next_id)
        except Exception:
            conn.rollback()
            raise
    finally:
        conn.close()


_F_CHECK_PERMISSIONS_SQL = """
SELECT *
FROM (
  SELECT
    ur.userid,
    mr.role_id,
    mr.role_code,
    mr.role_name,
    '直接付与' AS source
  FROM `T_UserRole` ur
  JOIN `M_Role` mr ON mr.role_id = ur.role_id
  WHERE (ur.assigned_to IS NULL OR ur.assigned_to >= CURDATE())

  UNION

  SELECT
    ud.userid,
    mr.role_id,
    mr.role_code,
    mr.role_name,
    'チーム経由' AS source
  FROM `T_UserDepartment` ud
  JOIN `T_DepartmentRole` dr ON dr.dept_id = ud.dept_id
  JOIN `M_Role` mr ON mr.role_id = dr.role_id
  WHERE (ud.assigned_to IS NULL OR ud.assigned_to >= CURDATE())
    AND (dr.granted_to IS NULL OR dr.granted_to >= CURDATE())
) AS all_roles
WHERE userid = %s
ORDER BY userid, source, role_id, role_code, role_name
"""


def f_check_permissions(user_id: str, role_code: list[str]) -> bool:
    """
    ユーザに付与されているロール（直接付与・チーム経由）のうち、
    いずれかの role_code が第2引数のいずれかと一致すれば True。

    :param user_id: ログインID（T1_LoginUser.userid 等）
    :param role_code: 確認する M_Role.role_code のリスト（例: BILLING_EDIT_ALL）
    """
    uid = (user_id or "").strip()
    if not uid:
        return False
    wanted = {str(x).strip() for x in (role_code or []) if str(x).strip()}
    if not wanted:
        return False

    conn = _get_connection()
    rows: list = []
    try:
        with conn.cursor() as cur:
            cur.execute(_F_CHECK_PERMISSIONS_SQL, (uid,))
            rows = cur.fetchall() or []
    except Exception as e:
        logger.warning("f_check_permissions: %s", e)
        return False
    finally:
        conn.close()

    for row in rows:
        rc = row.get("role_code") if isinstance(row, dict) else None
        if rc is None:
            continue
        if str(rc).strip() in wanted:
            return True
    return False


_F_CHECK_PERMISSIONS2_SQL = """
SELECT *
FROM (
  SELECT
    ur.userid,
    lu.user_name,
    lv1.dept_id    AS division_id,
    lv2.dept_id    AS dept_id,
    lv3.dept_id    AS team_id,
    lv1.dept_name  AS division_name,
    lv2.dept_name  AS dept_name,
    lv3.dept_name  AS team_name,
    mr.role_id,
    mr.role_code,
    mr.role_name,
    '直接付与'   AS source
  FROM `T_UserRole`      ur
  JOIN  `T1_LoginUser`    lu  ON  lu.userid        = ur.userid
  JOIN  `M_Role`           mr  ON  mr.role_id       = ur.role_id
  LEFT JOIN `T_UserDepartment` ud  ON  ud.userid    = ur.userid
                                     AND ud.is_primary = 1
                                     AND (ud.assigned_to IS NULL OR ud.assigned_to >= CURDATE())
  LEFT JOIN `M_Department`  lv3 ON  lv3.dept_id    = ud.dept_id
  LEFT JOIN `M_Department`  lv2 ON  lv2.dept_id    = lv3.parent_dept_id
  LEFT JOIN `M_Department`  lv1 ON  lv1.dept_id    = lv2.parent_dept_id
  WHERE (ur.assigned_to IS NULL OR ur.assigned_to >= CURDATE())
  UNION
  SELECT
    ud.userid,
    lu.user_name,
    lv1.dept_id    AS division_id,
    lv2.dept_id    AS dept_id,
    lv3.dept_id    AS team_id,
    lv1.dept_name  AS division_name,
    lv2.dept_name  AS dept_name,
    lv3.dept_name  AS team_name,
    mr.role_id,
    mr.role_code,
    mr.role_name,
    'チーム経由' AS source
  FROM `T_UserDepartment`  ud
  JOIN  `T1_LoginUser`     lu  ON  lu.userid        = ud.userid
  JOIN  `T_DepartmentRole` dr  ON  dr.dept_id       = ud.dept_id
  JOIN  `M_Role`            mr  ON  mr.role_id       = dr.role_id
  LEFT JOIN `M_Department`  lv3 ON  lv3.dept_id     = ud.dept_id
  LEFT JOIN `M_Department`  lv2 ON  lv2.dept_id     = lv3.parent_dept_id
  LEFT JOIN `M_Department`  lv1 ON  lv1.dept_id     = lv2.parent_dept_id
  WHERE (ud.assigned_to IS NULL OR ud.assigned_to >= CURDATE())
    AND (dr.granted_to  IS NULL OR dr.granted_to  >= CURDATE())
) AS all_roles
WHERE user_name = %s
ORDER BY division_name, dept_name, team_name, userid, source, role_id
"""


def _fetch_all_roles_rows_by_user_name(user_name: str) -> list[dict]:
    """`<SQL1>` 相当。user_name（表示名）でロール・部署階層を取得。"""
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(_F_CHECK_PERMISSIONS2_SQL, ((user_name or "").strip(),))
            return list(cur.fetchall() or [])
    except Exception as e:
        logger.warning("_fetch_all_roles_rows_by_user_name: %s", e)
        return []
    finally:
        conn.close()


def _same_org_id(a: object, b: object) -> bool:
    """division/dept/team_id の比較（NULL は一致とみなさない）。"""
    if a is None or b is None:
        return False
    return str(a).strip() == str(b).strip()


def f_check_permissions2(
    user_name_current: str,
    role_code: list[str],
    user_name_owner: str,
    level: str,
) -> bool:
    """
    自部署の請求のみ更新可などのロールを持つユーザについて、
    データ所有者の部署階層と一致するかを LEVEL に応じて判定する。

    Step1: user_name_current で <SQL1> を実行し、role_code が第2引数のいずれかに一致する行を探す。
           無ければ False。あればその行の division_id / dept_id / team_id を my_* として使用。
    Step2: user_name_owner で同じ SQL を実行し、先頭行の division_id / dept_id / team_id を owner_* に使用。
    Step3: level が \"1\"/\"2\"/\"3\" のとき、division のみ / division+dept / 全部一致で True。

    :param user_name_current: 操作ユーザの表示名（日本語）
    :param role_code: 確認する role_code のリスト（例: BILLING_EDIT_OWN）
    :param user_name_owner: データ側ユーザの表示名（日本語）
    :param level: "1" / "2" / "3"（文字列）
    """
    current_name = (user_name_current or "").strip()
    owner_name = (user_name_owner or "").strip()
    wanted = {str(x).strip() for x in (role_code or []) if str(x).strip()}
    if not current_name or not owner_name or not wanted:
        return False

    rows_me = _fetch_all_roles_rows_by_user_name(current_name)
    row_match: dict | None = None
    for row in rows_me:
        if not isinstance(row, dict):
            continue
        rc = row.get("role_code")
        if rc is not None and str(rc).strip() in wanted:
            row_match = row
            break
    if row_match is None:
        return False

    my_division_id = row_match.get("division_id")
    my_dept_id = row_match.get("dept_id")
    my_team_id = row_match.get("team_id")

    rows_owner = _fetch_all_roles_rows_by_user_name(owner_name)
    if not rows_owner:
        return False
    row_o = rows_owner[0] if isinstance(rows_owner[0], dict) else {}
    owner_division_id = row_o.get("division_id")
    owner_dept_id = row_o.get("dept_id")
    owner_team_id = row_o.get("team_id")

    lv = (level or "").strip()

    if lv == "1":
        return _same_org_id(my_division_id, owner_division_id)

    if lv == "2":
        return _same_org_id(my_division_id, owner_division_id) and _same_org_id(
            my_dept_id, owner_dept_id
        )

    if lv == "3":
        return (
            _same_org_id(my_division_id, owner_division_id)
            and _same_org_id(my_dept_id, owner_dept_id)
            and _same_org_id(my_team_id, owner_team_id)
        )

    return False


_INVOICE_SEARCH_SELECT = """\
    `請求書番号`,
    `宛名_取引先名` AS `取引先名`,
    `件名`,
    `メモ備忘` AS `メモ備考`,
    `発行日`,
    `支払期限`\
"""


def _normalize_invoice_search_date_display_row(row: dict) -> None:
    """
    請求一覧検索の1行について 発行日・支払期限 を表示用 YYYY-MM-DD にそろえる。
    DATETIME・datetime・'2026-02-02 00:00:00' 形式の文字列などに対応。
    """
    for key in ("発行日", "支払期限"):
        if key not in row:
            continue
        v = row[key]
        if v is None:
            continue
        if isinstance(v, date):
            row[key] = v.strftime("%Y-%m-%d")
            continue
        s = str(v).strip()
        if len(s) >= 10 and s[4] == "-" and s[7] == "-":
            row[key] = s[:10]


# 請求一覧検索の ORDER BY（API キー → SQL）。ユーザー入力をそのまま連結しない。
INVOICE_SEARCH_SORT_COLUMN_SQL: dict[str, str] = {
    "invoice_no": "`請求書番号`",
    "customer_name": "`宛名_取引先名`",
    "subject": "`件名`",
    "memo": "`メモ備忘`",
    "issue_date": "`発行日`",
    "payment_deadline": "`支払期限`",
}

# sort_levels 未指定・空のときの既定
DEFAULT_INVOICE_SEARCH_ORDER_BY = "`発行日` DESC, `請求書番号` ASC"


def _build_invoice_search_order_by(
    sort_levels: list[tuple[str, str]] | None,
) -> str:
    """sort_levels: [(column_key, 'asc'|'desc'), ...] 最大3段想定。不正キーは無視。"""
    if not sort_levels:
        return DEFAULT_INVOICE_SEARCH_ORDER_BY
    parts: list[str] = []
    for col_key, direction in sort_levels:
        col_key = (col_key or "").strip()
        if col_key not in INVOICE_SEARCH_SORT_COLUMN_SQL:
            continue
        d = (direction or "asc").strip().lower()
        if d not in ("asc", "desc"):
            d = "asc"
        parts.append(f"{INVOICE_SEARCH_SORT_COLUMN_SQL[col_key]} {d.upper()}")
    if not parts:
        return DEFAULT_INVOICE_SEARCH_ORDER_BY
    return ", ".join(parts)


def search_invoices(
    search_invoice_no: str = "",
    search_customer_name: str = "",
    search_subject: str = "",
    search_memo: str = "",
    search_issue_date_from: str = "",
    search_issue_date_to: str = "",
    search_payment_deadline_from: str = "",
    search_payment_deadline_to: str = "",
    sort_levels: list[tuple[str, str]] | None = None,
) -> tuple[list[dict], int, bool]:
    """
    T1_請求書データ_ヘッダ を検索し (results, result_count, over_limit) を返す。
    over_limit=True の場合、結果は先頭 DISPLAY_LIMIT 件のみ。
    sort_levels: INVOICE_SEARCH_SORT_COLUMN_SQL のキーと asc/desc のタプル（最大3段程度を想定）。
    """
    params_map = {
        "search_invoice_no": (search_invoice_no or "").strip(),
        "search_customer_name": (search_customer_name or "").strip(),
        "search_subject": (search_subject or "").strip(),
        "search_memo": (search_memo or "").strip(),
        "search_issue_date_from": (search_issue_date_from or "").strip(),
        "search_issue_date_to": (search_issue_date_to or "").strip(),
        "search_payment_deadline_from": (search_payment_deadline_from or "").strip(),
        "search_payment_deadline_to": (search_payment_deadline_to or "").strip(),
    }

    where_parts: list[str] = []
    bind_values: list[str] = []

    if params_map["search_invoice_no"]:
        where_parts.append("`請求書番号` LIKE %s")
        bind_values.append(f"%{params_map['search_invoice_no']}%")

    if params_map["search_customer_name"]:
        # スキーマ上の取引先名カラムは `宛名_取引先名` です（画面は「取引先名」表示）
        where_parts.append("`宛名_取引先名` LIKE %s")
        bind_values.append(f"%{params_map['search_customer_name']}%")

    if params_map["search_subject"]:
        where_parts.append("`件名` LIKE %s")
        bind_values.append(f"%{params_map['search_subject']}%")

    if params_map["search_memo"]:
        where_parts.append("`メモ備忘` LIKE %s")
        bind_values.append(f"%{params_map['search_memo']}%")

    if params_map["search_issue_date_from"]:
        where_parts.append("`発行日` >= %s")
        bind_values.append(params_map["search_issue_date_from"])

    if params_map["search_issue_date_to"]:
        where_parts.append("`発行日` <= %s")
        bind_values.append(params_map["search_issue_date_to"])

    if params_map["search_payment_deadline_from"]:
        where_parts.append("`支払期限` >= %s")
        bind_values.append(params_map["search_payment_deadline_from"])

    if params_map["search_payment_deadline_to"]:
        where_parts.append("`支払期限` <= %s")
        bind_values.append(params_map["search_payment_deadline_to"])

    order_by = _build_invoice_search_order_by(sort_levels)
    sql = f"SELECT {_INVOICE_SEARCH_SELECT} FROM `T1_請求書データ_ヘッダ`"
    if where_parts:
        sql += " WHERE " + " AND ".join(where_parts)
    sql += f" ORDER BY {order_by}"
    sql += f" LIMIT {DISPLAY_LIMIT + 1}"

    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, bind_values)
            rows = cur.fetchall()
    finally:
        conn.close()

    over_limit = len(rows) > DISPLAY_LIMIT
    if over_limit:
        rows = rows[:DISPLAY_LIMIT]

    for r in rows:
        if isinstance(r, dict):
            _normalize_invoice_search_date_display_row(r)

    return rows, len(rows) if not over_limit else DISPLAY_LIMIT, over_limit


def fetch_invoice_details_for_list(invoice_no: str) -> list[dict]:
    """
    請求書番号で T1_請求書データ_明細 を取得（一覧の行展開用）。
    戻り値: 明細行の dict リスト（明細番号昇順）。請求書番号が空や不正なら []。
    """
    inv = (invoice_no or "").strip()
    if not inv or len(inv) > 64:
        return []

    cols = [
        "明細番号",
        "請求項目1",
        "請求項目2",
        "請求項目3",
        "単価",
        "数量",
        "税抜金額",
        "消費税",
        "税込金額",
        "消費税区分",
    ]
    select_list = ", ".join(f"`{c}`" for c in cols)
    sql = (
        f"SELECT {select_list} FROM `T1_請求書データ_明細` "
        "WHERE `請求書番号` = %s ORDER BY `明細番号`"
    )

    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, (inv,))
            rows = cur.fetchall()
    finally:
        conn.close()

    return [dict(r) for r in rows]


_LOGIN_USER_SEARCH_SELECT = """\
    `userid`,
    `user_name`,
    `admin_option`,
    `Enabled`,
    `LastLoginDateTime`,
    `created_at`,
    `updated_at`\
"""

# ユーザ一覧検索の ORDER BY（API キー → SQL）。ユーザー入力をそのまま連結しない。
LOGIN_USER_SEARCH_SORT_COLUMN_SQL: dict[str, str] = {
    "userid": "`userid`",
    "user_name": "`user_name`",
    "admin_option": "`admin_option`",
    "enabled": "`Enabled`",
    "last_login_datetime": "`LastLoginDateTime`",
    "created_at": "`created_at`",
    "updated_at": "`updated_at`",
}

DEFAULT_LOGIN_USER_SEARCH_ORDER_BY = "`userid` ASC"


def _build_login_user_search_order_by(
    sort_levels: list[tuple[str, str]] | None,
) -> str:
    """sort_levels: [(column_key, 'asc'|'desc'), ...] 最大3段想定。不正キーは無視。"""
    if not sort_levels:
        return DEFAULT_LOGIN_USER_SEARCH_ORDER_BY
    parts: list[str] = []
    for col_key, direction in sort_levels:
        col_key = (col_key or "").strip()
        if col_key not in LOGIN_USER_SEARCH_SORT_COLUMN_SQL:
            continue
        d = (direction or "asc").strip().lower()
        if d not in ("asc", "desc"):
            d = "asc"
        parts.append(f"{LOGIN_USER_SEARCH_SORT_COLUMN_SQL[col_key]} {d.upper()}")
    if not parts:
        return DEFAULT_LOGIN_USER_SEARCH_ORDER_BY
    return ", ".join(parts)


def search_login_users(
    userid: str = "",
    user_name: str = "",
    sort_levels: list[tuple[str, str]] | None = None,
) -> tuple[list[dict], int, bool]:
    """
    T1_LoginUser を検索し (results, result_count, over_limit) を返す。
    over_limit=True の場合、結果は先頭 DISPLAY_LIMIT 件のみ。
    sort_levels: LOGIN_USER_SEARCH_SORT_COLUMN_SQL のキーと asc/desc のタプル（最大3段程度を想定）。
    """
    uid = (userid or "").strip()
    uname = (user_name or "").strip()

    where_parts: list[str] = []
    bind_values: list[str] = []

    if uid:
        where_parts.append("`userid` LIKE %s")
        bind_values.append(f"%{uid}%")

    if uname:
        where_parts.append("`user_name` LIKE %s")
        bind_values.append(f"%{uname}%")

    order_by = _build_login_user_search_order_by(sort_levels)
    sql = f"SELECT {_LOGIN_USER_SEARCH_SELECT} FROM `T1_LoginUser`"
    if where_parts:
        sql += " WHERE " + " AND ".join(where_parts)
    sql += f" ORDER BY {order_by}"
    sql += f" LIMIT {DISPLAY_LIMIT + 1}"

    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, bind_values)
            rows = cur.fetchall()
    finally:
        conn.close()

    over_limit = len(rows) > DISPLAY_LIMIT
    if over_limit:
        rows = rows[:DISPLAY_LIMIT]

    return rows, len(rows) if not over_limit else DISPLAY_LIMIT, over_limit


def list_t_user_department_dept_ids_by_userids(userids: list[str]) -> dict[str, list[int]]:
    """
    各 userid について T_UserDepartment の dept_id を列挙（権限・組織設定のユーザ一覧用）。
    """
    if not userids:
        return {}
    seen: set[str] = set()
    unique: list[str] = []
    for raw in userids:
        u = (raw or "").strip()
        if u and u not in seen:
            seen.add(u)
            unique.append(u)
    if not unique:
        return {}
    placeholders = ",".join(["%s"] * len(unique))
    sql = (
        f"SELECT DISTINCT `userid`, `dept_id` FROM `T_UserDepartment` "
        f"WHERE `userid` IN ({placeholders})"
    )
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, unique)
            rows = cur.fetchall()
    finally:
        conn.close()
    out: dict[str, list[int]] = {}
    for r in rows:
        uid = r.get("userid")
        did = r.get("dept_id")
        if uid is None or did is None:
            continue
        key = str(uid)
        out.setdefault(key, []).append(int(did))
    return out


def org_settings_search_users(
    userid: str = "",
    user_name: str = "",
) -> tuple[list[dict], bool]:
    """
    権限・組織設定右ペイン用: T1_LoginUser を検索し、各ユーザに T_UserDepartment を付与。
    検索語が両方空のときは ([], False)。

    戻り: (users, over_limit)
    users 各要素: {"id": str, "name": str, "depts": [{"deptId": int}, ...]}
    """
    uid_q = (userid or "").strip()
    uname_q = (user_name or "").strip()
    if not uid_q and not uname_q:
        return [], False
    rows, _cnt, over = search_login_users(
        userid=uid_q,
        user_name=uname_q,
        sort_levels=None,
    )
    userids = [str(r["userid"]) for r in rows]
    dept_map = list_t_user_department_dept_ids_by_userids(userids)
    users: list[dict] = []
    for r in rows:
        u = str(r["userid"])
        display_name = (r.get("user_name") or "").strip() or u
        dlist = dept_map.get(u, [])
        users.append(
            {
                "id": u,
                "name": display_name,
                "depts": [{"deptId": d} for d in dlist],
            }
        )
    return users, over


def search_accounts(
    search_koza_meigi: str = "",
    search_hojin_mei: str = "",
    search_daihyo_sei: str = "",
    search_kanri_sei: str = "",
) -> tuple[list[dict], int, bool]:
    """
    T1_AccountAttribute を検索し (results, result_count, over_limit) を返す。
    over_limit=True の場合、結果は先頭 DISPLAY_LIMIT 件のみ。
    """
    params_map = {
        "search_koza_meigi": search_koza_meigi.strip(),
        "search_hojin_mei":  search_hojin_mei.strip(),
        "search_daihyo_sei": search_daihyo_sei.strip(),
        "search_kanri_sei":  search_kanri_sei.strip(),
    }

    where_parts: list[str] = []
    bind_values: list[str] = []
    for key, col_expr in _SEARCH_COLUMN_MAP.items():
        val = params_map.get(key, "")
        if val:
            where_parts.append(f"{col_expr} LIKE %s")
            bind_values.append(f"%{val}%")

    sql = f"SELECT {_SELECT_COLUMNS} FROM `T1_AccountAttribute`"
    if where_parts:
        sql += " WHERE " + " AND ".join(where_parts)
    sql += f" LIMIT {DISPLAY_LIMIT + 1}"

    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, bind_values)
            rows = cur.fetchall()
    finally:
        conn.close()

    over_limit = len(rows) > DISPLAY_LIMIT
    if over_limit:
        rows = rows[:DISPLAY_LIMIT]

    return rows, len(rows) if not over_limit else DISPLAY_LIMIT, over_limit


_MAINTENANCE_SELECT = """\
    `店番号`,
    `口座番号`,
    `AIS開設日`,
    `法人名(漢字)`,
    `法人コード`,
    `登録番号`,
    `設立日`,
    `口座名義(漢字)`,
    `口座名義(カナ)`,
    `住所(漢字)`,
    `電話番号(市外局番)`,
    `電話番号(市内局番)`,
    `電話番号(局番)`,
    `代表者姓(漢字)`,
    `代表者名(漢字)`,
    `代表者姓(カナ)`,
    `代表者名(カナ)`,
    `口座管理者姓(漢字)`,
    `口座管理者名(漢字)`,
    `Emailアドレス`,
    `ホームページアドレス`\
"""


def fetch_account_for_maintenance(tenban: int, koza: str) -> dict | None:
    """店番号 + 口座番号で T1_AccountAttribute を1件取得（メンテ画面用）。"""
    sql = f"SELECT {_MAINTENANCE_SELECT} FROM `T1_AccountAttribute` WHERE `店番号` = %s AND `口座番号` = %s LIMIT 1"
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, (tenban, koza.strip()))
            row = cur.fetchone()
    finally:
        conn.close()
    return row


# 請求メンテ画面上部スロット1行目に配置し、header_quads から除外するヘッダ項目（左から1〜4列目）
INVOICE_HEADER_SLOT_ROW1_FIELDS: tuple[str, ...] = (
    "発行日",
    "支払期限",
    "請求書番号",
    "削除フラグ",
)
# スロット2行目：取引先名・件名・取引先コード（表示のみ）・空（取引先コード・件名はクワッドから除外）
INVOICE_HEADER_SLOT_ROW2_FIELDS: tuple[str, ...] = (
    "宛名_取引先名",
    "件名",
    "取引先コード",
)
# 支払情報ブロック（内側：店番行＋挿入行のみ2行）
INVOICE_HEADER_PAYMENT_SECTION_ROWS: tuple[
    tuple[str | None, str | None, str | None, str | None], ...
] = (
    ("店番", "決済口座", "口座名義人", "決済方法"),
)
_INVOICE_HEADER_PAYMENT_SECTION_FIELD_NAMES: frozenset[str] = frozenset(
    c
    for row in INVOICE_HEADER_PAYMENT_SECTION_ROWS
    for c in row
    if c
)
# 支払情報内側テーブル・店番行の直下の挿入スロット1行（4列＝th+td×4）。None は未配置
INVOICE_HEADER_INSERT_ROW_COLUMNS: tuple[str | None, str | None, str | None, str | None] = (
    "郵便番号",
    "住所",
    None,
    None,
)
_INVOICE_HEADER_INSERT_ROW_FIELD_NAMES: frozenset[str] = frozenset(
    c for c in INVOICE_HEADER_INSERT_ROW_COLUMNS if c
)
# 支払情報ブロックの直下（見出し除く4行目）：先方担当者（画面ラベル）1行・4列（宛名_*）。DB 名は宛名_* を使用
INVOICE_HEADER_SLOT_ROW6_COLUMNS: tuple[str | None, str | None, str | None, str | None] = (
    "宛名_担当部署",
    "役職",
    "宛名_担当者",
    None,
)
_INVOICE_HEADER_SLOT_ROW6_FIELD_NAMES: frozenset[str] = frozenset(
    c for c in INVOICE_HEADER_SLOT_ROW6_COLUMNS if c
)
# 先方担当者ブロックの直下：自行担当者1行・4列（事業部・コメント_振込・敬称・自行営業担当者）
INVOICE_HEADER_SLOT_ROW_SELF_COLUMNS: tuple[str | None, str | None, str | None, str | None] = (
    "自行部署名",
    "コメント_振込",
    "敬称",
    "自行営業担当者",
)
_INVOICE_HEADER_SLOT_ROW_SELF_FIELD_NAMES: frozenset[str] = frozenset(
    c for c in INVOICE_HEADER_SLOT_ROW_SELF_COLUMNS if c
)
# 自行担当者行の直下：消費税端数・消費税率・請求金額（画面は合計金額）・空
# 消費税端数：画面は select の value 0/1。永続化は _header_value_for_persist で int（DB 列は varchar 等でも代入可）
INVOICE_HEADER_SLOT_ROW7_COLUMNS: tuple[str | None, str | None, str | None, str | None] = (
    "消費税端数",
    "消費税率",
    "請求金額",
    None,
)
_INVOICE_HEADER_SLOT_ROW7_FIELD_NAMES: frozenset[str] = frozenset(
    c for c in INVOICE_HEADER_SLOT_ROW7_COLUMNS if c
)
# 消費税等行の直下：備考欄とメモ備忘を同一行・横並び（各 th+td で列数半分＝均等2分割）
INVOICE_HEADER_SLOT_ROW8_COLUMNS: tuple[str | None, str | None, str | None, str | None] = (
    "備考欄",
    "メモ備忘",
    None,
    None,
)
_INVOICE_HEADER_SLOT_ROW8_FIELD_NAMES: frozenset[str] = frozenset(
    c for c in INVOICE_HEADER_SLOT_ROW8_COLUMNS if c
)
# クワッド先頭行の直上：専用行なし（コメント_振込・敬称は自行担当者行）。プレースホルダで EXCLUDE 集合の形だけ維持
INVOICE_HEADER_SLOT_ROW_PRE_QUAD_COMMENT_COLUMNS: tuple[
    str | None, str | None, str | None, str | None
] = (
    None,
    None,
    None,
    None,
)
_INVOICE_HEADER_SLOT_ROW_PRE_QUAD_COMMENT_FIELD_NAMES: frozenset[str] = frozenset(
    c for c in INVOICE_HEADER_SLOT_ROW_PRE_QUAD_COMMENT_COLUMNS if c
)
INVOICE_HEADER_QUAD_EXCLUDE: frozenset[str] = (
    frozenset((*INVOICE_HEADER_SLOT_ROW1_FIELDS, *INVOICE_HEADER_SLOT_ROW2_FIELDS))
    .union(_INVOICE_HEADER_PAYMENT_SECTION_FIELD_NAMES)
    .union(_INVOICE_HEADER_INSERT_ROW_FIELD_NAMES)
    .union(_INVOICE_HEADER_SLOT_ROW6_FIELD_NAMES)
    .union(_INVOICE_HEADER_SLOT_ROW_SELF_FIELD_NAMES)
    .union(_INVOICE_HEADER_SLOT_ROW7_FIELD_NAMES)
    .union(_INVOICE_HEADER_SLOT_ROW8_FIELD_NAMES)
    .union(_INVOICE_HEADER_SLOT_ROW_PRE_QUAD_COMMENT_FIELD_NAMES)
)

_INVOICE_HEADER_COLUMNS: list[str] = [
    "請求書番号",
    "郵便番号",
    "住所",
    "取引先コード",
    "宛名_取引先名",
    "宛名_担当部署",
    "宛名_担当者",
    "自行住所",
    "自行電話_FAX番号",
    "自行営業担当者",
    "自行部署名",
    "発行日",
    "決済方法",
    "営業担当者",
    "発行者",
    "消費税率",
    "消費税端数",
    "件名",
    "請求金額",
    "支払期限",
    "決済口座",
    "コメント_振込",
    "備考欄",
    "店番",
    "口座名義人",
    "役職",
    "敬称",
    "削除フラグ",
    "メモ備忘",
]

_INVOICE_DETAIL_COLUMNS: list[str] = [
    "請求書番号",
    "明細番号",
    "請求項目1",
    "請求項目2",
    "請求項目3",
    "単価",
    "数量",
    "消費税区分",
    "税抜金額",
    "税抜金額端数処理区分",
    "消費税",
    "税込金額",
    "プロジェクトコード",
    "科目コード",
    "中分類",
    "小分類",
]


def _invoice_header_select_expr(col: str) -> str:
    return f"h.`{col}` AS `header_{col}`"


def _invoice_detail_select_expr(col: str) -> str:
    return f"d.`{col}` AS `detail_{col}`"


def fetch_invoice_for_maintenance(invoice_no: str) -> dict | None:
    """
    請求書番号で T1_請求書データ_ヘッダ と T1_請求書データ_明細 を JOINして取得する。
    戻り値: {"header": {col: value}, "details": [{col: value}, ...]}
    """
    invoice_no = (invoice_no or "").strip()
    if not invoice_no:
        return None

    header_select = ", ".join(_invoice_header_select_expr(c) for c in _INVOICE_HEADER_COLUMNS)
    detail_select = ", ".join(_invoice_detail_select_expr(c) for c in _INVOICE_DETAIL_COLUMNS)
    sql = (
        "SELECT "
        f"{header_select}, {detail_select} "
        "FROM `T1_請求書データ_ヘッダ` h "
        "LEFT JOIN `T1_請求書データ_明細` d "
        "  ON h.`請求書番号` = d.`請求書番号` "
        "WHERE h.`請求書番号` = %s "
        "ORDER BY d.`明細番号`"
    )

    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, (invoice_no,))
            rows = cur.fetchall()
    finally:
        conn.close()

    if not rows:
        return None

    first = rows[0]
    header = {c: first.get(f"header_{c}") for c in _INVOICE_HEADER_COLUMNS}
    details: list[dict] = []
    for r in rows:
        # LEFT JOIN のため、明細0件の場合は detailカラムが全て NULL になり得る。
        # そのケースは「明細0行」になるようにスキップする。
        detail_no = r.get("detail_明細番号")
        if detail_no is None or str(detail_no).strip() == "":
            continue
        details.append({c: r.get(f"detail_{c}") for c in _INVOICE_DETAIL_COLUMNS})

    return {"header": header, "details": details}


def search_zip_master_suggestions(q_raw: str, *, limit: int = 15) -> list[dict[str, str]]:
    """
    zipMaster を zipcode の前方一致で検索（入力は数字以外を除去した接頭辞）。
    戻り値: [{"zipcode": str, "address1": str}, ...]（最大 limit 件）
    """
    # 全角数字・互換文字を半角へ（「２」だけだと LIKE が一致しない）
    normalized = unicodedata.normalize("NFKC", q_raw or "")
    digits = "".join(c for c in normalized if c.isdigit())
    if not digits:
        return []
    if len(digits) > 10:
        digits = digits[:10]
    lim = max(1, min(int(limit), 50))
    conn = None
    try:
        conn = _get_connection()
        with conn.cursor() as cur:
            cur.execute(
                "SELECT `zipcode`, `address1` FROM `zipMaster` "
                "WHERE `zipcode` LIKE %s ORDER BY `zipcode` ASC LIMIT %s",
                (digits + "%", lim),
            )
            rows = cur.fetchall() or []
    except Exception as e:
        logger.warning("search_zip_master_suggestions: %s", e)
        return []
    finally:
        if conn is not None:
            conn.close()
    out: list[dict[str, str]] = []
    for r in rows:
        out.append(
            {
                "zipcode": str(r.get("zipcode") or ""),
                "address1": str(r.get("address1") or ""),
            }
        )
    return out


_TORIHIKISAKI_MASTER_COLUMNS: tuple[str, ...] = (
    "ID",
    "取引先コード",
    "請求先",
    "郵便番号",
    "住所",
    "電話",
    "FAX",
    "消費税率",
    "税端数処理",
    "自社フラグ",
    "メモ備忘",
)

# 取引先一覧検索の ORDER BY（API キー → SQL）
TORIHIKI_SEARCH_SORT_COLUMN_SQL: dict[str, str] = {
    "id": "`ID`",
    "code": "`取引先コード`",
    "name": "`請求先`",
    "zip": "`郵便番号`",
    "addr": "`住所`",
    "tel": "`電話`",
    "fax": "`FAX`",
    "tax": "`消費税率`",
    "taxr": "`税端数処理`",
    "jisha": "`自社フラグ`",
    "memo": "`メモ備忘`",
}

DEFAULT_TORIHIKI_SEARCH_ORDER_BY = "`請求先` ASC, `ID` ASC"


def _build_torihiki_search_order_by(
    sort_levels: list[tuple[str, str]] | None,
) -> str:
    if not sort_levels:
        return DEFAULT_TORIHIKI_SEARCH_ORDER_BY
    parts: list[str] = []
    for col_key, direction in sort_levels:
        col_key = (col_key or "").strip()
        if col_key not in TORIHIKI_SEARCH_SORT_COLUMN_SQL:
            continue
        d = (direction or "asc").strip().lower()
        if d not in ("asc", "desc"):
            d = "asc"
        parts.append(f"{TORIHIKI_SEARCH_SORT_COLUMN_SQL[col_key]} {d.upper()}")
    if not parts:
        return DEFAULT_TORIHIKI_SEARCH_ORDER_BY
    return ", ".join(parts)


def _like_pattern_contains_mysql(q: str) -> str:
    """LIKE 用: % _ \\ をエスケープし、部分一致パターン %q% を返す（ESCAPE '\\\\' 前提）。"""
    esc = (
        unicodedata.normalize("NFKC", q or "")
        .replace("\\", "\\\\")
        .replace("%", "\\%")
        .replace("_", "\\_")
    )
    return f"%{esc}%"


def search_m_torihikisaki_master(
    q_raw: str = "",
    *,
    filters: dict[str, str] | None = None,
    sort_levels: list[tuple[str, str]] | None = None,
    limit: int = 200,
) -> tuple[list[dict[str, str]], int, bool]:
    """
    M_取引先マスタを検索する。
    q が空のときは先頭から最大 limit 件。非空のときは 請求先 のみを対象に検索する。
    検索語は NFKC で正規化し、請求先に対して前後ワイルドカード LIKE（%q%）で照合する。
    LIKE は % _ をエスケープ。並び: 請求先 ASC, ID ASC。
    戻り値: (行 dict リスト, 返却件数, over_limit)
    """
    q_raw_trim = str(q_raw or "").strip()
    q_nfkc = unicodedata.normalize("NFKC", q_raw_trim)
    lim = max(1, min(int(limit), DISPLAY_LIMIT))
    cols_sql = ", ".join(f"`{c}`" for c in _TORIHIKISAKI_MASTER_COLUMNS)
    order_by_sql = _build_torihiki_search_order_by(sort_levels)
    f = {k: str(v or "").strip() for k, v in (filters or {}).items()}
    has_advanced = any(v for v in f.values())
    conn = None
    try:
        conn = _get_connection()
        with conn.cursor() as cur:
            if has_advanced:
                clauses: list[str] = []
                params: list[object] = []

                def _add_contains(col_name: str, raw_val: str):
                    raw_trim = str(raw_val or "").strip()
                    if not raw_trim:
                        return
                    nfkc = unicodedata.normalize("NFKC", raw_trim)
                    pats: list[str] = []
                    for cand in (raw_trim, nfkc):
                        if not cand:
                            continue
                        pat = _like_pattern_contains_mysql(cand)
                        if pat not in pats:
                            pats.append(pat)
                    if not pats:
                        return
                    sub = " OR ".join([f"`{col_name}` LIKE %s ESCAPE '\\\\'"] * len(pats))
                    clauses.append(f"({sub})")
                    params.extend(pats)

                _add_contains("取引先コード", f.get("code") or "")
                _add_contains("請求先", f.get("name") or "")
                _add_contains("郵便番号", f.get("zip") or "")
                _add_contains("住所", f.get("addr") or "")
                _add_contains("電話", f.get("tel") or "")
                _add_contains("FAX", f.get("fax") or "")
                _add_contains("消費税率", f.get("tax") or "")
                _add_contains("メモ備忘", f.get("memo") or "")

                taxr = str(f.get("taxr") or "").strip()
                if taxr:
                    clauses.append("`税端数処理` = %s")
                    params.append(taxr)
                jisha = str(f.get("jisha") or "").strip()
                if jisha in ("0", "1"):
                    clauses.append("`自社フラグ` = %s")
                    params.append(jisha)

                if clauses:
                    where_sql = " AND ".join(clauses)
                    cur.execute(
                        f"SELECT {cols_sql} FROM `M_取引先マスタ` "
                        f"WHERE {where_sql} "
                        f"ORDER BY {order_by_sql} LIMIT %s",
                        (*params, lim + 1),
                    )
                else:
                    cur.execute(
                        f"SELECT {cols_sql} FROM `M_取引先マスタ` "
                        f"ORDER BY {order_by_sql} LIMIT %s",
                        (lim + 1,),
                    )
            elif not q_raw_trim:
                cur.execute(
                    f"SELECT {cols_sql} FROM `M_取引先マスタ` "
                    f"ORDER BY {order_by_sql} LIMIT %s",
                    (lim + 1,),
                )
            else:
                # 実入力とNFKC正規化入力の両方で LIKE（%q%）照合し、表記ゆれの取りこぼしを抑える。
                pats: list[str] = []
                for cand in (q_raw_trim, q_nfkc):
                    if not cand:
                        continue
                    p = _like_pattern_contains_mysql(cand)
                    if p not in pats:
                        pats.append(p)
                if not pats:
                    pats = [_like_pattern_contains_mysql(q_raw_trim)]
                where_like = " OR ".join(["`請求先` LIKE %s ESCAPE '\\\\'"] * len(pats))
                cur.execute(
                    f"SELECT {cols_sql} FROM `M_取引先マスタ` "
                    f"WHERE ({where_like}) "
                    f"ORDER BY {order_by_sql} LIMIT %s",
                    (*pats, lim + 1),
                )
            rows = cur.fetchall() or []
    except Exception as e:
        logger.warning("search_m_torihikisaki_master: %s", e)
        return [], 0, False
    finally:
        if conn is not None:
            conn.close()

    over_limit = len(rows) > lim
    if over_limit:
        rows = rows[:lim]
    out: list[dict[str, str]] = []
    for r in rows:
        out.append(
            {
                k: ("" if r.get(k) is None else str(r.get(k)))
                for k in _TORIHIKISAKI_MASTER_COLUMNS
            }
        )
    return out, len(out), over_limit


def search_m_torihikisaki_master_with_koza_count(
    q_raw: str = "",
    *,
    filters: dict[str, str] | None = None,
    sort_levels: list[tuple[str, str]] | None = None,
    limit: int = 200,
) -> tuple[list[dict[str, str | int]], int, bool]:
    """
    M_取引先マスタの検索結果に、M_口座マスタ の件数（ID一致）を付与して返す。
    戻り値の各行:
      {
        id, code, name, zip, addr, tel, fax, tax, taxr, jisha, memo, bank_count
      }
    """
    base_rows, result_count, over_limit = search_m_torihikisaki_master(
        q_raw=q_raw,
        filters=filters,
        sort_levels=sort_levels,
        limit=limit,
    )
    if not base_rows:
        return [], result_count, over_limit

    ids = [str(r.get("ID") or "").strip() for r in base_rows]
    ids = [x for x in ids if x]
    koza_count_by_id: dict[str, int] = {}

    if ids:
        conn = None
        try:
            conn = _get_connection()
            with conn.cursor() as cur:
                placeholders = ", ".join(["%s"] * len(ids))
                cur.execute(
                    "SELECT `ID`, COUNT(*) AS `cnt` "
                    "FROM `M_口座マスタ` "
                    f"WHERE `ID` IN ({placeholders}) "
                    "GROUP BY `ID`",
                    tuple(ids),
                )
                for row in (cur.fetchall() or []):
                    key = str(row.get("ID") or "").strip()
                    if not key:
                        continue
                    try:
                        koza_count_by_id[key] = int(row.get("cnt") or 0)
                    except Exception:
                        koza_count_by_id[key] = 0
        except Exception as e:
            logger.warning("search_m_torihikisaki_master_with_koza_count: %s", e)
        finally:
            if conn is not None:
                conn.close()

    out: list[dict[str, str | int]] = []
    for r in base_rows:
        rid = str(r.get("ID") or "").strip()
        out.append(
            {
                "id": rid,
                "code": str(r.get("取引先コード") or ""),
                "name": str(r.get("請求先") or ""),
                "zip": str(r.get("郵便番号") or ""),
                "addr": str(r.get("住所") or ""),
                "tel": str(r.get("電話") or ""),
                "fax": str(r.get("FAX") or ""),
                "tax": str(r.get("消費税率") or ""),
                "taxr": str(r.get("税端数処理") or ""),
                "jisha": str(r.get("自社フラグ") or ""),
                "memo": str(r.get("メモ備忘") or ""),
                "bank_count": int(koza_count_by_id.get(rid, 0)),
            }
        )
    return out, result_count, over_limit


def get_m_torihikisaki_master_with_koza_count_by_id(
    master_id: str,
) -> dict[str, str | int] | None:
    """
    M_取引先マスタを ID で1件取得し、M_口座マスタ件数を付与して返す。
    見つからない場合は None。
    """
    sid = str(master_id or "").strip()
    if not sid:
        return None
    conn = None
    try:
        conn = _get_connection()
        with conn.cursor() as cur:
            cols_sql = ", ".join(f"`{c}`" for c in _TORIHIKISAKI_MASTER_COLUMNS)
            cur.execute(
                f"SELECT {cols_sql} FROM `M_取引先マスタ` WHERE `ID`=%s LIMIT 1",
                (sid,),
            )
            row = cur.fetchone()
            if not row:
                return None
            cur.execute(
                "SELECT COUNT(*) AS `cnt` FROM `M_口座マスタ` WHERE `ID`=%s",
                (sid,),
            )
            cnt_row = cur.fetchone() or {}
            try:
                bank_count = int(cnt_row.get("cnt") or 0)
            except Exception:
                bank_count = 0
    except Exception as e:
        logger.warning("get_m_torihikisaki_master_with_koza_count_by_id: %s", e)
        return None
    finally:
        if conn is not None:
            conn.close()
    return {
        "id": sid,
        "code": str(row.get("取引先コード") or ""),
        "name": str(row.get("請求先") or ""),
        "zip": str(row.get("郵便番号") or ""),
        "addr": str(row.get("住所") or ""),
        "tel": str(row.get("電話") or ""),
        "fax": str(row.get("FAX") or ""),
        "tax": str(row.get("消費税率") or ""),
        "taxr": str(row.get("税端数処理") or ""),
        "jisha": str(row.get("自社フラグ") or ""),
        "memo": str(row.get("メモ備忘") or ""),
        "bank_count": bank_count,
    }


def delete_m_torihikisaki_master_by_id(master_id: int) -> tuple[bool, str]:
    """
    M_取引先マスタ を主キー ID で1件物理削除する。
    戻り値: (成功, メッセージ)。0件削除のときは失敗とする。
    """
    try:
        pk = int(master_id)
    except (TypeError, ValueError):
        return False, "IDが不正です。"
    if pk <= 0:
        return False, "IDが不正です。"

    conn = _get_connection()
    try:
        conn.autocommit(False)
        try:
            with conn.cursor() as cur:
                cur.execute("DELETE FROM `M_取引先マスタ` WHERE `ID`=%s", (pk,))
                deleted = cur.rowcount if hasattr(cur, "rowcount") else 0
            if not deleted:
                conn.rollback()
                return False, "該当する取引先マスタが見つかりません。"
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        return True, "取引先マスタを削除しました。"
    except Exception as e:
        logger.exception("delete_m_torihikisaki_master_by_id: %s", e)
        return False, str(e)
    finally:
        conn.close()


def save_torihikisaki_master_with_koza(
    master_id: int | None,
    torihiki: dict[str, str],
    koza_rows: list[dict[str, str]],
) -> tuple[bool, str, int | None]:
    """
    取引先マスタ 1 件と口座マスタ複数件を同時保存する（トランザクション）。
    - master_id が None: 新規用にシーケンス採番して M_取引先マスタ を INSERT
    - master_id が数値: 行が無ければ INSERT（画面表示時に allocate 済みの採番 ID）、
      あれば M_取引先マスタ を更新
    - 口座マスタは対象 ID の既存行を全削除してから再登録
    戻り値: (成功, メッセージ, 保存後ID)
    """
    code = str((torihiki or {}).get("code") or "").strip()
    name = str((torihiki or {}).get("name") or "").strip()
    zip_code = str((torihiki or {}).get("zip") or "").strip()
    addr = str((torihiki or {}).get("addr") or "").strip()
    tel = str((torihiki or {}).get("tel") or "").strip()
    fax = str((torihiki or {}).get("fax") or "").strip()
    tax = str((torihiki or {}).get("tax") or "").strip()
    taxr = str((torihiki or {}).get("taxr") or "").strip() or "切捨て"
    jisha = str((torihiki or {}).get("jisha") or "").strip()
    memo = str((torihiki or {}).get("memo") or "").strip()

    if not name:
        return False, "請求先は必須です。", None
    if not tax:
        return False, "消費税率は必須です。", None
    if taxr not in ("切捨て", "切り上げ", "四捨五入"):
        return False, "税端数処理が不正です。", None
    if jisha not in ("0", "1"):
        jisha = "0"

    parsed_koza: list[tuple[str, str, str]] = []
    for row in (koza_rows or []):
        tenban = str((row or {}).get("tenban") or "").strip()
        koza_no = str((row or {}).get("koza") or "").strip()
        meigi = str((row or {}).get("meigi") or "").strip()
        if not tenban and not koza_no and not meigi:
            continue
        if not tenban or not koza_no:
            return False, "口座情報は店番・口座番号を入力してください。", None
        parsed_koza.append((tenban, koza_no, meigi))

    sorted_parsed_koza = sorted(parsed_koza)

    conn = _get_connection()
    try:
        conn.autocommit(False)
        try:
            with conn.cursor() as cur:
                target_id: int
                did_insert = False
                torihiki_changed = True
                koza_changed = True
                if master_id is None:
                    target_id = _next_m_torihikisaki_master_id(cur)
                    did_insert = True
                    cur.execute(
                        "INSERT INTO `M_取引先マスタ` "
                        "(`ID`, `取引先コード`, `請求先`, `郵便番号`, `住所`, `電話`, `FAX`, `消費税率`, `税端数処理`, `自社フラグ`, `メモ備忘`) "
                        "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                        (
                            target_id,
                            code,
                            name,
                            zip_code,
                            addr,
                            tel,
                            fax,
                            tax,
                            taxr,
                            jisha,
                            memo,
                        ),
                    )
                else:
                    try:
                        target_id = int(master_id)
                    except (TypeError, ValueError):
                        conn.rollback()
                        return False, "IDが不正です。", None
                    if target_id <= 0:
                        conn.rollback()
                        return False, "IDが不正です。", None
                    cur.execute(
                        "SELECT `取引先コード`, `請求先`, `郵便番号`, `住所`, `電話`, `FAX`, `消費税率`, `税端数処理`, `自社フラグ`, `メモ備忘` "
                        "FROM `M_取引先マスタ` WHERE `ID`=%s LIMIT 1",
                        (target_id,),
                    )
                    existing = cur.fetchone()
                    if not existing:
                        # 画面表示時に採番済みのIDで初回登録
                        did_insert = True
                        torihiki_changed = True
                        koza_changed = True
                        cur.execute(
                            "INSERT INTO `M_取引先マスタ` "
                            "(`ID`, `取引先コード`, `請求先`, `郵便番号`, `住所`, `電話`, `FAX`, `消費税率`, `税端数処理`, `自社フラグ`, `メモ備忘`) "
                            "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                            (
                                target_id,
                                code,
                                name,
                                zip_code,
                                addr,
                                tel,
                                fax,
                                tax,
                                taxr,
                                jisha,
                                memo,
                            ),
                        )
                    else:
                        did_insert = False
                        before_torihiki = (
                            str(existing.get("取引先コード") or "").strip(),
                            str(existing.get("請求先") or "").strip(),
                            str(existing.get("郵便番号") or "").strip(),
                            str(existing.get("住所") or "").strip(),
                            str(existing.get("電話") or "").strip(),
                            str(existing.get("FAX") or "").strip(),
                            str(existing.get("消費税率") or "").strip(),
                            str(existing.get("税端数処理") or "").strip(),
                            str(existing.get("自社フラグ") or "0").strip(),
                            str(existing.get("メモ備忘") or "").strip(),
                        )
                        after_torihiki = (
                            code,
                            name,
                            zip_code,
                            addr,
                            tel,
                            fax,
                            tax,
                            taxr,
                            jisha,
                            memo,
                        )
                        torihiki_changed = before_torihiki != after_torihiki
                        cur.execute(
                            "UPDATE `M_取引先マスタ` "
                            "SET `取引先コード`=%s, `請求先`=%s, `郵便番号`=%s, `住所`=%s, `電話`=%s, `FAX`=%s, `消費税率`=%s, `税端数処理`=%s, `自社フラグ`=%s, `メモ備忘`=%s "
                            "WHERE `ID`=%s",
                            (code, name, zip_code, addr, tel, fax, tax, taxr, jisha, memo, target_id),
                        )

                cur.execute(
                    "SELECT `店番`, `口座番号`, `口座名義人` FROM `M_口座マスタ` WHERE `ID`=%s",
                    (target_id,),
                )
                existing_koza_rows = cur.fetchall() or []
                before_koza = sorted(
                    (
                        str((row or {}).get("店番") or "").strip(),
                        str((row or {}).get("口座番号") or "").strip(),
                        str((row or {}).get("口座名義人") or "").strip(),
                    )
                    for row in existing_koza_rows
                )
                koza_changed = before_koza != sorted_parsed_koza
                cur.execute("DELETE FROM `M_口座マスタ` WHERE `ID`=%s", (target_id,))
                for tenban, koza_no, meigi in parsed_koza:
                    cur.execute(
                        "INSERT INTO `M_口座マスタ` (`ID`, `店番`, `口座番号`, `口座名義人`) VALUES (%s,%s,%s,%s)",
                        (target_id, tenban, koza_no, meigi),
                    )
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        if did_insert:
            return True, "取引先を登録しました。", target_id
        if torihiki_changed or koza_changed:
            return True, "取引先を更新しました。", target_id
        return True, "変更はありませんでした。", target_id
    except Exception as e:
        logger.exception("save_torihikisaki_master_with_koza: %s", e)
        return False, str(e), None
    finally:
        conn.close()


def delete_torihikisaki_master_with_koza(master_id: int) -> tuple[bool, str]:
    """
    取引先マスタ1件と紐づく口座マスタを同一トランザクションで削除する。

    master_id は M_取引先マスタ.ID かつ、取引先 HTMX 詳細の id-badge / 非表示 f-id / URL
    selected_id など画面で扱う ID と同じ主キーである。当スキームでは M_口座マスタ も
    同一 `ID` 列で紐づくため、先に M_口座マスタ を当該 ID で削除し、続けて
    M_取引先マスタ を削除する。
    """
    try:
        pk = int(master_id)
    except (TypeError, ValueError):
        return False, "IDが不正です。"
    if pk <= 0:
        return False, "IDが不正です。"

    conn = _get_connection()
    try:
        conn.autocommit(False)
        try:
            with conn.cursor() as cur:
                cur.execute("DELETE FROM `M_口座マスタ` WHERE `ID`=%s", (pk,))
                cur.execute("DELETE FROM `M_取引先マスタ` WHERE `ID`=%s", (pk,))
                deleted = cur.rowcount if hasattr(cur, "rowcount") else 0
            if not deleted:
                conn.rollback()
                return False, "該当する取引先マスタが見つかりません。"
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        return True, "取引先を削除しました。"
    except Exception as e:
        logger.exception("delete_torihikisaki_master_with_koza: %s", e)
        return False, str(e)
    finally:
        conn.close()


_KOZA_MASTER_COLUMNS: tuple[str, ...] = (
    "ID",
    "店番",
    "口座番号",
    "口座名義人",
)


def list_m_koza_master_by_torihiki_id(torihiki_id: str) -> list[dict[str, str]]:
    """
    M_口座マスタを取引先マスタの ID（M_口座マスタ.ID）で検索して返す。
    並び: 店番 ASC, 口座番号 ASC。最大 DISPLAY_LIMIT 件。
    """
    tid = (torihiki_id or "").strip()
    if not tid:
        return []
    lim = max(1, int(DISPLAY_LIMIT))
    cols_sql = ", ".join(f"`{c}`" for c in _KOZA_MASTER_COLUMNS)
    conn = None
    try:
        conn = _get_connection()
        with conn.cursor() as cur:
            cur.execute(
                f"SELECT {cols_sql} FROM `M_口座マスタ` "
                "WHERE `ID`=%s "
                "ORDER BY `店番` ASC, `口座番号` ASC "
                "LIMIT %s",
                (tid, lim),
            )
            rows = cur.fetchall() or []
    except Exception as e:
        logger.warning("list_m_koza_master_by_torihiki_id: %s", e)
        return []
    finally:
        if conn is not None:
            conn.close()
    out: list[dict[str, str]] = []
    for r in rows:
        out.append(
            {
                k: ("" if r.get(k) is None else str(r.get(k)))
                for k in _KOZA_MASTER_COLUMNS
            }
        )
    return out


def search_m_koza_master(
    meigi: str = "",
    tenban: str = "",
    torihikisaki_name: str = "",
    *,
    limit: int = 200,
) -> tuple[list[dict[str, str]], int, bool]:
    """
    M_口座マスタを検索する。
    条件は AND で結合:
    - tenban 非空: `店番` LIKE %tenban%
    - 口座名義人の絞り込みは次のどちらか一方のみ（同一列への二重 LIKE を AND しない）:
      - meigi 非空: `口座名義人` LIKE %meigi%（検索欄を優先）
      - meigi が空で torihikisaki_name 非空: `口座名義人` LIKE %torihikisaki_name%
        （画面の取引先名＝宛名_取引先名）
    店番・口座名義人いずれの条件も無いときは先頭から最大 limit 件。
    """
    meigi_s = (meigi or "").strip()
    tenban_s = (tenban or "").strip()
    tori_s = (torihikisaki_name or "").strip()
    lim = max(1, min(int(limit), DISPLAY_LIMIT))
    cols_sql = ", ".join(f"`{c}`" for c in _KOZA_MASTER_COLUMNS)
    conds: list[str] = []
    params: list = []
    if tenban_s:
        conds.append("`店番` LIKE %s")
        params.append(f"%{tenban_s}%")
    if meigi_s:
        conds.append("`口座名義人` LIKE %s")
        params.append(f"%{meigi_s}%")
    elif tori_s:
        conds.append("`口座名義人` LIKE %s")
        params.append(f"%{tori_s}%")
    conn = None
    try:
        conn = _get_connection()
        with conn.cursor() as cur:
            if not conds:
                cur.execute(
                    f"SELECT {cols_sql} FROM `M_口座マスタ` "
                    "ORDER BY `店番` ASC, `口座番号` ASC LIMIT %s",
                    (lim + 1,),
                )
            else:
                where_sql = " AND ".join(conds)
                cur.execute(
                    f"SELECT {cols_sql} FROM `M_口座マスタ` "
                    f"WHERE {where_sql} "
                    "ORDER BY `店番` ASC, `口座番号` ASC LIMIT %s",
                    (*params, lim + 1),
                )
            rows = cur.fetchall() or []
    except Exception as e:
        logger.warning("search_m_koza_master: %s", e)
        return [], 0, False
    finally:
        if conn is not None:
            conn.close()

    over_limit = len(rows) > lim
    if over_limit:
        rows = rows[:lim]
    out: list[dict[str, str]] = []
    for r in rows:
        out.append(
            {
                k: ("" if r.get(k) is None else str(r.get(k)))
                for k in _KOZA_MASTER_COLUMNS
            }
        )
    return out, len(out), over_limit


def delete_m_koza_master_by_id(master_id: int) -> tuple[bool, str]:
    """
    M_口座マスタ を主キー ID で1件物理削除する。
    戻り値: (成功, メッセージ)。0件削除のときは失敗とする。
    """
    try:
        pk = int(master_id)
    except (TypeError, ValueError):
        return False, "IDが不正です。"
    if pk <= 0:
        return False, "IDが不正です。"

    conn = _get_connection()
    try:
        conn.autocommit(False)
        try:
            with conn.cursor() as cur:
                cur.execute("DELETE FROM `M_口座マスタ` WHERE `ID`=%s", (pk,))
                deleted = cur.rowcount if hasattr(cur, "rowcount") else 0
            if not deleted:
                conn.rollback()
                return False, "該当する口座マスタが見つかりません。"
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        return True, "口座マスタを削除しました。"
    except Exception as e:
        logger.exception("delete_m_koza_master_by_id: %s", e)
        return False, str(e)
    finally:
        conn.close()


_INVOICE_HEADER_REQUIRED: tuple[tuple[str, str], ...] = (
    ("郵便番号", "郵便番号"),
    ("住所", "住所"),
    ("取引先名", "宛名_取引先名"),
    # ("担当部署", "宛名_担当部署"),  # 任意入力
    # ("担当者", "宛名_担当者"),  # 任意入力
    ("決済方法", "決済方法"),
    ("消費税率", "消費税率"),
    ("件名", "件名"),
    ("支払期限", "支払期限"),
    ("決済口座", "決済口座"),
    ("店番", "店番"),
    ("口座名義人", "口座名義人"),
)


def validate_invoice_header_for_save(
    header: dict, *, update_torihikisaki_master: bool = False
) -> list[str]:
    """
    請求書ヘッダの保存前チェック。
    update_torihikisaki_master が True のとき、取引先マスタ更新用に
    請求先（宛名_取引先名）・郵便番号・住所が空でないことも検証する（文言は専用）。
    戻り値: エラーメッセージのリスト（空なら OK）。
    """
    errs: list[str] = []

    def g(name: str) -> str:
        v = header.get(name)
        if v is None:
            return ""
        return str(v).strip()

    if update_torihikisaki_master:
        if not g("宛名_取引先名"):
            errs.append(
                "請求書ヘッダ：取引先マスタを更新する場合、請求先は必須です。"
            )
        if not g("郵便番号"):
            errs.append(
                "請求書ヘッダ：取引先マスタを更新する場合、郵便番号は必須です。"
            )
        if not g("住所"):
            errs.append(
                "請求書ヘッダ：取引先マスタを更新する場合、住所は必須です。"
            )

    _skip_generic_required: frozenset[str] = (
        frozenset(("郵便番号", "住所", "宛名_取引先名"))
        if update_torihikisaki_master
        else frozenset()
    )

    inv = g("請求書番号")
    if inv:
        import re

        if not re.fullmatch(r"\d{2}(0[1-9]|1[0-2])\d{2}-[A-Z]\d{3,4}", inv):
            errs.append(
                "請求書ヘッダ：請求書番号は YYMM99-A999（または A9999）形式で入力してください。"
            )

    for label, key in _INVOICE_HEADER_REQUIRED:
        if key in _skip_generic_required:
            continue
        if not g(key):
            errs.append(f"請求書ヘッダ：{label}は必須です。")

    if g("郵便番号"):
        znorm = unicodedata.normalize("NFKC", g("郵便番号"))
        zip_digits = "".join(c for c in znorm if c.isdigit())
        if len(zip_digits) < 5:
            errs.append("請求書ヘッダ：郵便番号は数字5桁以上で入力してください。")

    km = g("決済方法")
    if km and km not in ("振込", "引落"):
        errs.append("請求書ヘッダ：決済方法は「振込」または「引落」を選択してください。")

    zt = g("消費税端数")
    if zt and zt not in ("0", "1", "2", "切り上げ", "切捨て", "四捨五入"):
        errs.append(
            "請求書ヘッダ：消費税端数は「切り上げ」「切捨て」または「四捨五入」を選択してください。"
        )

    def maxlen_if_nonempty(label: str, key: str, n: int) -> None:
        s = g(key)
        if s and len(s) > n:
            errs.append(f"請求書ヘッダ：{label}は{n}文字以内で入力してください。")

    # 取引先名・件名・メモ備忘は同一の扱い（スキーマの VARCHAR 長に合わせる）
    maxlen_if_nonempty("取引先名", "宛名_取引先名", 255)
    maxlen_if_nonempty("件名", "件名", 255)
    maxlen_if_nonempty("メモ備忘", "メモ備忘", 500)
    maxlen_if_nonempty("備考欄", "備考欄", 500)

    return errs


def validate_invoice_detail_rows_for_save(detail_rows: list[dict]) -> list[str]:
    """
    請求書明細の保存前チェック。
    detail_rows: 各行に excluded (bool) とカラム名のキーを含む。
    """
    from decimal import Decimal, InvalidOperation

    errs: list[str] = []

    n_active = sum(1 for row in detail_rows if not row.get("excluded"))
    if n_active == 0:
        errs.append(
            "請求書明細：登録対象の明細が1件以上必要です。（行先頭のチェックが付いている行は保存されません）"
        )

    def gv(row: dict, k: str) -> str:
        v = row.get(k)
        if v is None:
            return ""
        return str(v).strip()

    for i, row in enumerate(detail_rows, start=1):
        if row.get("excluded"):
            continue

        if not gv(row, "単価"):
            errs.append(f"請求書明細：第{i}行目の単価は必須です。")
        else:
            try:
                Decimal(str(gv(row, "単価")).replace(",", "").strip())
            except (InvalidOperation, ValueError):
                errs.append(f"請求書明細：第{i}行目の単価は数値で入力してください。")

        qty_raw = row.get("数量")
        qty_norm = _normalize_detail_quantity_string(qty_raw)
        if not qty_norm:
            errs.append(f"請求書明細：第{i}行目の数量は必須です。")
        elif _parse_detail_quantity_int(qty_raw) is None:
            errs.append(f"請求書明細：第{i}行目の数量は整数で入力してください。")

        tax_k = gv(row, "消費税区分")
        if not tax_k:
            errs.append(f"請求書明細：第{i}行目の消費税区分を選択してください。")
        elif tax_k not in ("内税", "外税", "非課税", "不課税"):
            errs.append(
                f"請求書明細：第{i}行目の消費税区分はドロップダウンから選択してください。"
            )

        fk = gv(row, "税抜金額端数処理区分")
        # 未選択時は保存時に既定値「切捨て」を補完する。
        if fk and fk not in ("0", "1", "2", "切り上げ", "切捨て", "四捨五入"):
            errs.append(
                f"請求書明細：第{i}行目の税抜金額端数処理区分は「切り上げ」「切捨て」または「四捨五入」を選択してください。"
            )

        if (
            not gv(row, "請求項目1")
            and not gv(row, "請求項目2")
            and not gv(row, "請求項目3")
        ):
            errs.append(
                f"請求書明細：第{i}行目の請求項目1縲鰀3のいずれかを入力してください。"
            )

    return errs


def _parse_decimal_loose(s: str):
    from decimal import Decimal, InvalidOperation

    try:
        return Decimal(str(s).replace(",", "").strip())
    except (InvalidOperation, ValueError):
        return None


def _normalize_detail_quantity_string(raw) -> str:
    """明細の数量（カンマ・全角カンマ・空白除去）。画面の 1,234 / １，０００ 等を int 用に正規化。"""
    if raw is None:
        return ""
    s = unicodedata.normalize("NFKC", str(raw))
    s = s.replace(",", "").replace("\uff0c", "")
    s = "".join(s.split())
    return s


def _parse_detail_quantity_int(raw) -> int | None:
    """数量を整数化。空・不正は None。"""
    s = _normalize_detail_quantity_string(raw)
    if not s:
        return None
    try:
        return int(s)
    except ValueError:
        return None


def _apply_detail_tax_excluded_amount(row: dict) -> None:
    """単価×数量を税抜金額にセット（検証済み行向け）。
    現状 save_invoice_maintenance からは呼ばれていない（呼び出しはコメントアウト）。"""
    from decimal import Decimal

    d = _parse_decimal_loose(str(row.get("単価") or ""))
    q = _parse_detail_quantity_int(row.get("数量"))
    if d is None or q is None:
        return
    row["_税抜金額_decimal"] = d * Decimal(q)


def _header_value_for_persist(col: str, raw) -> object:
    """ヘッダ INSERT/UPDATE 用に値を変換（請求書番号キー以外のカラム）。"""
    from datetime import datetime
    from decimal import Decimal, InvalidOperation

    if raw is None:
        s = ""
    else:
        s = str(raw).strip()
    if col == "発行日":
        if not s:
            return None
        try:
            return datetime.strptime(s[:10], "%Y-%m-%d").date()
        except ValueError:
            return None
    if col == "消費税端数":
        # 未選択時は既定値「切捨て」で保存する。
        if not s:
            return "切捨て"
        if s == "1":
            return "切り上げ"
        if s == "0":
            return "切捨て"
        if s == "2":
            return "四捨五入"
        if s in ("切り上げ", "切捨て", "四捨五入"):
            return s
        return None
    if col == "請求金額":
        # 合計金額は画面表示専用。画面入力値は DB へ保存しない。
        return None
    if col == "郵便番号":
        if not s:
            return None
        zd = "".join(c for c in unicodedata.normalize("NFKC", s) if c.isdigit())
        return zd if zd else None
    if col == "削除フラグ":
        # DB が BIT(1) のため、保存時は常に 0/1 の数値へ正規化する。
        if isinstance(raw, (bytes, bytearray, memoryview)):
            b = bytes(raw)
            return 1 if any(x != 0 for x in b) else 0
        if isinstance(raw, bool):
            return 1 if raw else 0
        if isinstance(raw, (int, float)):
            return 1 if int(raw) != 0 else 0
        s_lower = s.lower()
        return 1 if s_lower in ("1", "true", "yes", "on", "y") else 0
    return s if s != "" else None


def _torihikisaki_master_tax_hasuu_label(header: dict) -> str | None:
    """
    画面の消費税端数（select の value 0/1/2）を、M_取引先マスタ.税端数処理 用の表示文字に変換。
    DB には数値ではなく「切り上げ」「切捨て」「四捨五入」のいずれかを保存する。
    """
    raw = header.get("消費税端数")
    s = "" if raw is None else str(raw).strip()
    if s == "1":
        return "切り上げ"
    if s == "0":
        return "切捨て"
    if s == "2":
        return "四捨五入"
    if s in ("切り上げ", "切捨て", "四捨五入"):
        return s
    return None


def _zip_digits_nfkc_compare(raw) -> str:
    """郵便番号の比較用（NFKC 後の数字のみ）。永続化値と DB 表示の表記差を吸収する。"""
    if raw is None:
        return ""
    return "".join(c for c in unicodedata.normalize("NFKC", str(raw)) if c.isdigit())


def _upsert_m_torihikisaki_master_from_header(cur, header: dict) -> None:
    """
    請求ヘッダの値で M_取引先マスタ を更新または新規登録（チェック ON 保存時）。

    既存行の特定: 取引先コードがあればそれで先頭1件、なければ 請求先＝画面の宛名_取引先名 で先頭1件。

    - 請求先・郵便番号・住所のいずれかが既存行と異なる → 新規 INSERT（画面のコード・宛名・郵便・住所・税率・税端数）。
    - 3項目とも一致 → 当該行の 消費税率・税端数処理 のみ UPDATE（画面の消費税率・消費税端数から変換した税端数処理）。
    税端数処理には消費税端数の文字（切り上げ／切捨て／四捨五入）を格納する。

    既存行が無い場合は従来どおり INSERT（電話・FAX・メモ等は空／自社フラグ0）。
    """
    seikyu_saki = str(header.get("宛名_取引先名") or "").strip()
    if not seikyu_saki:
        raise ValueError("取引先マスタを更新するには取引先名（宛名_取引先名）が必要です。")

    code = str(header.get("取引先コード") or "").strip()
    zip_v = _header_value_for_persist("郵便番号", header.get("郵便番号"))
    addr = str(header.get("住所") or "").strip()
    tax_rate = str(header.get("消費税率") or "").strip()
    tax_zatsu_label = _torihikisaki_master_tax_hasuu_label(header)

    def _insert_new_row() -> None:
        cur.execute(
            "INSERT INTO `M_取引先マスタ` ("
            "`取引先コード`, `請求先`, `郵便番号`, `住所`, `電話`, `FAX`, "
            "`消費税率`, `税端数処理`, `自社フラグ`, `メモ備忘`"
            ") VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
            (
                code or None,
                seikyu_saki,
                zip_v,
                addr or None,
                "",
                "",
                tax_rate or None,
                tax_zatsu_label,
                0,
                "",
            ),
        )

    one = None
    if code:
        cur.execute(
            "SELECT `ID`, `請求先`, `郵便番号`, `住所` FROM `M_取引先マスタ` "
            "WHERE `取引先コード`=%s ORDER BY `ID` ASC LIMIT 1",
            (code,),
        )
        one = cur.fetchone()
    if not one:
        cur.execute(
            "SELECT `ID`, `請求先`, `郵便番号`, `住所` FROM `M_取引先マスタ` "
            "WHERE `請求先`=%s ORDER BY `ID` ASC LIMIT 1",
            (seikyu_saki,),
        )
        one = cur.fetchone()

    if not one:
        _insert_new_row()
        return

    pk = one.get("ID")
    db_seikyu = str(one.get("請求先") or "").strip()
    db_zip_raw = one.get("郵便番号")
    db_addr = str(one.get("住所") or "").strip()

    screen_zip_norm = _zip_digits_nfkc_compare(header.get("郵便番号"))
    db_zip_norm = _zip_digits_nfkc_compare(db_zip_raw)

    triple_changed = (
        db_seikyu != seikyu_saki
        or db_zip_norm != screen_zip_norm
        or db_addr != addr
    )

    if triple_changed:
        _insert_new_row()
    else:
        cur.execute(
            "UPDATE `M_取引先マスタ` SET `消費税率`=%s, `税端数処理`=%s WHERE `ID`=%s",
            (tax_rate or None, tax_zatsu_label, pk),
        )


def _upsert_m_koza_master_from_header(
    cur,
    header: dict,
    *,
    previous_header_koza: tuple[str, str, str] | None = None,
) -> tuple[str, int | None]:
    """
    請求ヘッダの値で M_口座マスタ を更新/新規登録（チェック ON 保存時）。

    仕様:
    - 判定キー: 店番 / 口座番号 / 口座名義人（画面の3項目）
    - 変更有無は見ない。
    - M_口座マスタに3項目完全一致行が存在しない場合のみ INSERT。
    - 存在する場合は no-op。
    戻り値: (status, id)
      - status: "inserted" または "unchanged"
      - id: 既存一致ID または 新規挿入ID（取得できない場合 None）
    """
    tenban = str(header.get("店番") or "").strip()
    koza_no = str(header.get("決済口座") or "").strip()
    koza_meigi = str(header.get("口座名義人") or "").strip()
    if not tenban:
        raise ValueError("口座マスタを更新するには店番が必要です。")
    if not koza_no:
        raise ValueError("口座マスタを更新するには口座番号（決済口座）が必要です。")
    if not koza_meigi:
        raise ValueError("口座マスタを更新するには口座名義人が必要です。")

    # 仕様変更: 変更差分ではなく、口座マスタ上の存在有無で INSERT 判定する。
    cur.execute(
        "SELECT `ID` FROM `M_口座マスタ` "
        "WHERE `店番`=%s AND `口座番号`=%s AND `口座名義人`=%s "
        "ORDER BY `ID` ASC LIMIT 1",
        (tenban, koza_no, koza_meigi),
    )
    one = cur.fetchone()
    if one:
        if isinstance(one, dict):
            return "unchanged", (int(one.get("ID")) if one.get("ID") is not None else None)
        return "unchanged", (int(one[0]) if len(one) > 0 and one[0] is not None else None)

    cur.execute(
        "INSERT INTO `M_口座マスタ` (`店番`, `口座番号`, `口座名義人`) "
        "VALUES (%s, %s, %s)",
        (tenban, koza_no, koza_meigi),
    )
    new_id = cur.lastrowid if hasattr(cur, "lastrowid") else None
    return "inserted", (int(new_id) if new_id else None)


def _header_insert_tuple(invoice_no: str, header: dict) -> tuple:
    """T1_請求書データ_ヘッダ INSERT 用タプル（_INVOICE_HEADER_COLUMNS 順）。"""
    uid = (invoice_no or "").strip()
    return tuple(
        uid if c == "請求書番号" else _header_value_for_persist(c, header.get(c))
        for c in _INVOICE_HEADER_COLUMNS
    )


def _detail_cell_for_insert(col: str, row: dict, invoice_no: str, line_no: int):
    """INSERT 用の1セル値。"""
    from decimal import Decimal, InvalidOperation

    if col == "請求書番号":
        return invoice_no
    if col == "明細番号":
        return str(line_no)
    if col == "税抜金額":
        v = row.get("_税抜金額_decimal")
        if v is not None:
            return v
        return _parse_decimal_loose(str(row.get("税抜金額") or "")) or Decimal("0")
    if col == "数量":
        q = _parse_detail_quantity_int(row.get("数量"))
        return q
    if col == "単価":
        s = str(row.get(col) or "").strip()
        if not s:
            return None
        try:
            return Decimal(s.replace(",", ""))
        except (InvalidOperation, ValueError):
            return None
    if col == "税抜金額端数処理区分":
        s = str(row.get(col) or "").strip()
        if not s:
            # 未選択時は既定値「切捨て」で保存する。
            return "切捨て"
        if s == "1":
            return "切り上げ"
        if s == "0":
            return "切捨て"
        if s == "2":
            return "四捨五入"
        if s in ("切り上げ", "切捨て", "四捨五入"):
            return s
        return None
    if col == "税込金額":
        s = str(row.get(col) or "").strip()
        if not s:
            return None
        try:
            return Decimal(s.replace(",", ""))
        except (InvalidOperation, ValueError):
            return None
    if col == "消費税":
        s = str(row.get(col) or "").strip()
        if not s:
            return None
        try:
            return Decimal(s.replace(",", ""))
        except (InvalidOperation, ValueError):
            return None
    v = row.get(col)
    if v is None:
        return None
    s = str(v).strip()
    return s if s != "" else None


_MSG_COPY_INVOICE_NO_EXISTS = (
    "指定された請求番号はすでに存在しています。コピーの場合は新規の請求番号を設定してください。"
)


def save_invoice_maintenance(
    invoice_no: str,
    header: dict,
    detail_rows: list[dict],
    *,
    copy_save: bool = False,
    update_torihikisaki_master: bool = False,
    update_koza_master: bool = False,
) -> tuple[bool, str]:
    """
    請求ヘッダ: 請求書番号が T1_請求書データ_ヘッダ に存在すれば UPDATE、なければ INSERT。
    明細: 全削除後に未チェック行のみ再INSERT。
    copy_save が True のときは新規コピー保存のみ許可し、請求書番号が既存ならエラーとする。
    update_torihikisaki_master が True のとき、同一トランザクション内で M_取引先マスタ を
    更新または新規登録（請求先・郵便番号・住所の変更有無で分岐。詳細は _upsert_m_torihikisaki_master_from_header）。
    update_koza_master が True のとき、同一トランザクション内で M_口座マスタ を
    判定キー（店番・口座番号・口座名義人）で重複回避しつつ更新/新規登録する。
    戻り値: (成功, メッセージ) 失敗時は False と DB/例外メッセージ。
    """
    uid = (invoice_no or "").strip()
    if not uid:
        return False, "請求書番号がありません。"

    # （無効化）DB登録前に単価×数量で税抜金額を補完する処理。再開する場合は以下の for を戻す。
    # for row in detail_rows:
    #     if row.get("excluded"):
    #         continue
    #     _apply_detail_tax_excluded_amount(row)

    set_parts: list[str] = []
    set_values: list = []
    for col in _INVOICE_HEADER_COLUMNS:
        if col == "請求書番号":
            continue
        if col == "請求金額":
            # 合計金額は画面表示専用。画面入力値では DB 更新しない。
            continue
        set_parts.append(f"`{col}`=%s")
        set_values.append(_header_value_for_persist(col, header.get(col)))

    update_sql = (
        "UPDATE `T1_請求書データ_ヘッダ` SET "
        + ", ".join(set_parts)
        + " WHERE `請求書番号`=%s"
    )
    set_values.append(uid)

    insert_header_sql = (
        "INSERT INTO `T1_請求書データ_ヘッダ` ("
        + ", ".join(f"`{c}`" for c in _INVOICE_HEADER_COLUMNS)
        + ") VALUES ("
        + ", ".join(["%s"] * len(_INVOICE_HEADER_COLUMNS))
        + ")"
    )
    insert_header_params = list(_header_insert_tuple(uid, header))

    header_exists_sql = (
        "SELECT 1 FROM `T1_請求書データ_ヘッダ` WHERE `請求書番号`=%s LIMIT 1"
    )

    delete_sql = "DELETE FROM `T1_請求書データ_明細` WHERE `請求書番号`=%s"

    cols = _INVOICE_DETAIL_COLUMNS
    placeholders = ", ".join(["%s"] * len(cols))
    insert_sql = (
        "INSERT INTO `T1_請求書データ_明細` ("
        + ", ".join(f"`{c}`" for c in cols)
        + f") VALUES ({placeholders})"
    )

    conn = _get_connection()
    try:
        conn.autocommit(False)
        try:
            koza_upsert_status: str | None = None
            koza_upsert_id: int | None = None
            with conn.cursor() as cur:
                cur.execute(header_exists_sql, (uid,))
                header_exists = cur.fetchone() is not None
                if copy_save and header_exists:
                    conn.rollback()
                    return False, _MSG_COPY_INVOICE_NO_EXISTS
                if header_exists:
                    cur.execute(update_sql, set_values)
                else:
                    cur.execute(insert_header_sql, insert_header_params)
                cur.execute(delete_sql, (uid,))
                line_no = 1
                for row in detail_rows:
                    if row.get("excluded"):
                        continue
                    params = [
                        _detail_cell_for_insert(c, row, uid, line_no) for c in cols
                    ]
                    cur.execute(insert_sql, params)
                    line_no += 1
                if update_torihikisaki_master:
                    _upsert_m_torihikisaki_master_from_header(cur, header)
                if update_koza_master:
                    koza_upsert_status, koza_upsert_id = _upsert_m_koza_master_from_header(
                        cur, header, previous_header_koza=None
                    )
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        if update_torihikisaki_master and update_koza_master:
            if koza_upsert_status == "inserted":
                return True, f"請求データを保存し、取引先マスタを更新し、口座マスタを登録しました。（口座ID: {koza_upsert_id or '取得不可'}）"
            return True, f"請求データを保存し、取引先マスタを更新しました（口座マスタは変更なし・既存ID: {koza_upsert_id or '不明'}）。"
        if update_torihikisaki_master:
            return True, "請求データを保存し、取引先マスタを更新しました。"
        if update_koza_master:
            if koza_upsert_status == "inserted":
                return True, f"請求データを保存し、口座マスタを登録しました。（口座ID: {koza_upsert_id or '取得不可'}）"
            return True, f"請求データを保存しました（口座マスタは変更なし・既存ID: {koza_upsert_id or '不明'}）。"
        return True, "請求データを保存しました。"
    except Exception as e:
        logger.exception("save_invoice_maintenance: %s", e)
        return False, str(e)
    finally:
        conn.close()


def _password_sha256_hex(plain: str) -> str:
    """MySQL SHA2(plain, 256) と同じ 64 文字 hex（小文字）。"""
    return hashlib.sha256((plain or "").encode("utf-8")).hexdigest()


def verify_login_user(userid: str, plain_password: str) -> tuple[bool, str, str]:
    """
    T1_LoginUser を照合する。
    戻り値: (成功, メッセージ, 成功時は DB 上の userid／失敗時は空文字)
    セッションには第3戻り値を格納し、照合・外部キーと表示を一致させる。
    """
    uid = (userid or "").strip()
    if not uid:
        return False, "ユーザーIDを入力してください。", ""

    if not (plain_password or "").strip():
        return False, "パスワードを入力してください。", ""

    pwd_hex = _password_sha256_hex(plain_password or "")
    sql = (
        "SELECT `userid`, `pwd`, `Enabled` FROM `T1_LoginUser` WHERE `userid` = %s LIMIT 1"
    )

    try:
        conn = _get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute(sql, (uid,))
                row = cur.fetchone()
        finally:
            conn.close()
    except Exception as e:
        logger.exception("verify_login_user DB error: %s", e)
        return (
            False,
            "ログイン処理中にエラーが発生しました。しばらくしてから再度お試しください。",
            "",
        )

    if not row:
        return False, "ユーザーIDまたはパスワードが正しくありません。", ""

    stored = (row.get("pwd") or "").strip()
    if stored.lower() != pwd_hex.lower():
        return False, "ユーザーIDまたはパスワードが正しくありません。", ""

    enabled = row.get("Enabled")
    if enabled is None or int(enabled) != 1:
        return False, "このアカウントは利用できません（無効）。", ""

    canon = (row.get("userid") or "").strip()
    return True, "", (canon if canon else uid)


def get_canonical_login_userid(userid: str) -> str:
    """
    セッション等の userid を T1_LoginUser 行の値に揃える（大文字小文字・照合順の差を吸収）。
    行が無いときは strip した引数をそのまま返す。
    """
    uid = (userid or "").strip()
    if not uid:
        return ""
    sql = "SELECT `userid` FROM `T1_LoginUser` WHERE `userid` = %s LIMIT 1"
    try:
        conn = _get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute(sql, (uid,))
                row = cur.fetchone()
        finally:
            conn.close()
    except Exception as e:
        logger.warning("get_canonical_login_userid: %s", e)
        return uid
    if not row:
        return uid
    return (row.get("userid") or "").strip() or uid


def is_same_login_user_password(userid: str, plain_password: str) -> bool:
    """
    入力された plain_password が、DBに保存されている現行パスワード（pwd）と同じか。
    同じなら True。
    """
    uid = (userid or "").strip()
    if not uid:
        return False
    pwd_hex = _password_sha256_hex(plain_password or "")
    sql = "SELECT `pwd` FROM `T1_LoginUser` WHERE `userid` = %s LIMIT 1"
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, (uid,))
            row = cur.fetchone()
    finally:
        conn.close()

    if not row:
        return False
    stored_raw = row.get("pwd")
    if stored_raw is None:
        return False

    # pwd は SHA2 の hex（想定）だが、環境によって bytes で返ることがあるため吸収する
    if isinstance(stored_raw, (bytes, bytearray)):
        try:
            stored_raw = stored_raw.decode("utf-8", errors="ignore")
        except Exception:
            stored_raw = str(stored_raw)

    stored = str(stored_raw).strip()
    if not stored:
        return False
    return stored.lower() == pwd_hex.lower()


def set_login_user_last_login_datetime_days_ago(userid: str, days_ago: int) -> bool:
    """T1_LoginUser.LastLoginDateTime を `days_ago` 日前に更新する。更新件数>0で True。"""
    uid = (userid or "").strip()
    if not uid:
        return False
    try:
        days_int = int(days_ago)
    except Exception:
        return False

    target_dt = datetime.now() - timedelta(days=days_int)

    sql = "UPDATE `T1_LoginUser` SET `LastLoginDateTime`=%s WHERE `userid`=%s"
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, (target_dt, uid))
            updated = int(cur.rowcount or 0)
        conn.commit()
        return updated > 0
    finally:
        conn.close()


def get_login_user_last_login_datetime(userid: str):
    """T1_LoginUser.LastLoginDateTime を取得（未設定なら None）。"""
    uid = (userid or "").strip()
    if not uid:
        return None
    sql = "SELECT `LastLoginDateTime` FROM `T1_LoginUser` WHERE `userid`=%s LIMIT 1"
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, (uid,))
            row = cur.fetchone()
    finally:
        conn.close()
    if not row:
        return None
    raw = row.get("LastLoginDateTime")
    if raw is None:
        return None

    # MySQL 側の「ブランク」が NULL ではなく、空文字 / 0000-00-00 等で入っているケースを吸収
    if isinstance(raw, (bytes, bytearray)):
        try:
            raw = raw.decode("utf-8", errors="ignore")
        except Exception:
            raw = str(raw)

    if isinstance(raw, str):
        s = raw.strip()
        if not s:
            return None
        if s.startswith("0000"):
            return None

    # datetime.date / datetime.datetime の場合
    try:
        if getattr(raw, "year", None) == 0:
            return None
    except Exception:
        pass

    return raw


def should_force_password_change(userid: str) -> bool:
    """
    初回ログイン（LastLoginDateTime がブランク）または、
    最終ログインから FORCE_PWD_CHANGE_DAYS 日以上経過している場合 True。
    """
    last_dt = get_login_user_last_login_datetime(userid)
    if last_dt is None:
        return True

    # pymysql は通常 datetime オブジェクトを返すが、念のため型を吸収する
    last: datetime
    if isinstance(last_dt, datetime):
        last = last_dt
    elif isinstance(last_dt, date):
        last = datetime.combine(last_dt, datetime.min.time())
    else:
        try:
            last = datetime.fromisoformat(str(last_dt))
        except Exception:
            # 解析不能は安全側に倒す（強制変更）
            return True

    threshold = datetime.now() - timedelta(days=FORCE_PWD_CHANGE_DAYS)
    return last <= threshold


def get_force_password_change_reason(userid: str) -> str | None:
    """
    強制変更の理由を返す。
      - 'initial' : LastLoginDateTime がブランク（初回）
      - 'expired' : 最終ログインから FORCE_PWD_CHANGE_DAYS 日以上経過（期限切れ）
      - None      : 強制変更不要
    """
    last_dt = get_login_user_last_login_datetime(userid)
    if last_dt is None:
        return "initial"

    # pymysql は通常 datetime オブジェクトを返すが、念のため型を吸収する
    if isinstance(last_dt, datetime):
        last = last_dt
    elif isinstance(last_dt, date):
        last = datetime.combine(last_dt, datetime.min.time())
    else:
        try:
            last = datetime.fromisoformat(str(last_dt))
        except Exception:
            return "expired"

    threshold = datetime.now() - timedelta(days=FORCE_PWD_CHANGE_DAYS)
    if last <= threshold:
        return "expired"
    return None


def set_login_user_password_and_last_login_datetime(userid: str, plain_password: str) -> None:
    """パスワードを更新し、LastLoginDateTime を NOW() にする。"""
    uid = (userid or "").strip()
    if not uid:
        return
    pwd_hex = _password_sha256_hex(plain_password or "")
    sql = (
        "UPDATE `T1_LoginUser` "
        "SET `pwd`=%s, `LastLoginDateTime`=NOW() "
        "WHERE `userid`=%s"
    )
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, (pwd_hex, uid))
        conn.commit()
    finally:
        conn.close()


def get_login_user_display_name(userid: str) -> str:
    """
    ログインIDに対応する表示名（T1_LoginUser.user_name）。
    未設定・取得失敗時は userid を返す。
    """
    uid = (userid or "").strip()
    if not uid:
        return ""
    sql = "SELECT `user_name` FROM `T1_LoginUser` WHERE `userid` = %s LIMIT 1"
    try:
        conn = _get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute(sql, (uid,))
                row = cur.fetchone()
        finally:
            conn.close()
    except Exception as e:
        logger.warning("get_login_user_display_name: %s", e)
        return uid
    if not row:
        return uid
    name = (row.get("user_name") or "").strip()
    return name if name else uid


def get_shift_sso_profile(userid: str) -> dict | None:
    """
    シフトSSO用のユーザ情報を返す。
    戻り値: {"user_id","user_name","role","team_id"} / 取得不可時 None
    role マッピング: admin_option=1 -> admin, 2 -> manager, それ以外 -> staff
    team_id: sh_staff.name = T1_LoginUser.user_name で特定（複数時は最小 team_id を採用）
    """
    uid = (userid or "").strip()
    if not uid:
        return None
    sql_user = (
        "SELECT `userid`, `user_name`, `admin_option` "
        "FROM `T1_LoginUser` "
        "WHERE `userid` = %s AND `Enabled` = 1 "
        "LIMIT 1"
    )
    sql_team = "SELECT MIN(`team_id`) AS `team_id` FROM `sh_staff` WHERE `name` = %s"
    try:
        conn = _get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute(sql_user, (uid,))
                user = cur.fetchone()
        finally:
            conn.close()
    except Exception as e:
        logger.warning("get_shift_sso_profile (user): %s", e)
        return None
    if not user:
        return None

    team_row: dict = {}
    try:
        conn = _get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute(sql_team, ((user.get("user_name") or "").strip(),))
                team_row = cur.fetchone() or {}
        finally:
            conn.close()
    except Exception as e:
        # sh_staff が未作成・未接続でも SSO 自体は継続できるようにする。
        logger.warning("get_shift_sso_profile (team fallback): %s", e)
    try:
        admin_opt = int(user.get("admin_option") or 0)
    except Exception:
        admin_opt = 0
    role = "staff"
    if admin_opt == 1:
        role = "admin"
    elif admin_opt == 2:
        role = "manager"
    team_id = team_row.get("team_id")
    try:
        team_id = int(team_id) if team_id is not None else 1
    except Exception:
        team_id = 1
    return {
        "user_id": str(user.get("userid") or "").strip(),
        "user_name": str(user.get("user_name") or "").strip(),
        "role": role,
        "team_id": team_id,
    }


def get_login_user_department_profile(userid: str) -> dict[str, str] | None:
    """
    ログインユーザの主所属（Lv1〜Lv3）と表示名を取得する。
    戻り値: {"userid","user_name","lv1_name","lv2_name","lv3_name"}（未該当なら None）。
    """
    uid = (userid or "").strip()
    if not uid:
        return None
    sql = (
        "SELECT "
        "  lu.`userid`, "
        "  lu.`user_name` AS `user_name`, "
        "  lv1.`dept_name` AS `lv1_name`, "
        "  lv2.`dept_name` AS `lv2_name`, "
        "  lv3.`dept_name` AS `lv3_name` "
        "FROM `T1_LoginUser` lu "
        "LEFT JOIN `T_UserDepartment` ud "
        "  ON ud.`userid` = lu.`userid` "
        " AND ud.`is_primary` = 1 "
        " AND (ud.`assigned_to` IS NULL OR ud.`assigned_to` >= CURDATE()) "
        "LEFT JOIN `M_Department` lv3 "
        "  ON lv3.`dept_id` = ud.`dept_id` "
        "LEFT JOIN `M_Department` lv2 "
        "  ON lv2.`dept_id` = lv3.`parent_dept_id` "
        "LEFT JOIN `M_Department` lv1 "
        "  ON lv1.`dept_id` = lv2.`parent_dept_id` "
        "WHERE lu.`Enabled` = 1 "
        "  AND lu.`userid` = %s "
        "ORDER BY lv1.`dept_name`, lv2.`dept_name`, lv3.`dept_name` "
        "LIMIT 1"
    )
    try:
        conn = _get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute(sql, (uid,))
                row = cur.fetchone()
        finally:
            conn.close()
    except Exception as e:
        logger.warning("get_login_user_department_profile: %s", e)
        return None
    if not row:
        return None
    return {
        "userid": str(row.get("userid") or "").strip(),
        "user_name": str(row.get("user_name") or "").strip(),
        "lv1_name": str(row.get("lv1_name") or "").strip(),
        "lv2_name": str(row.get("lv2_name") or "").strip(),
        "lv3_name": str(row.get("lv3_name") or "").strip(),
    }


def _m_department_depth(
    dept_id: int,
    by_id: dict[int, dict],
    memo: dict[int, int],
    visiting: set[int],
) -> int:
    """親チェーンの長さから深さ（ルート=1）を返す。循環参照は打ち切る。"""
    if dept_id in memo:
        return memo[dept_id]
    if dept_id in visiting:
        memo[dept_id] = 1
        return 1
    visiting.add(dept_id)
    row = by_id.get(dept_id)
    if not row:
        memo[dept_id] = 1
        visiting.discard(dept_id)
        return 1
    p = row.get("parent_dept_id")
    if p is None:
        memo[dept_id] = 1
        visiting.discard(dept_id)
        return 1
    pid = int(p)
    d = 1 + _m_department_depth(pid, by_id, memo, visiting)
    memo[dept_id] = d
    visiting.discard(dept_id)
    return d


def list_m_department_org_settings_rows() -> list[dict]:
    """
    権限・組織設定の左ペイン用。`M_Department` の有効行を親子関係つきフラット配列で返す。

    各要素はフロントの state.depts 互換:
      id: dept_id, code: dept_code, name: dept_name,
      parent: parent_dept_id（ルートは None）,
      lv: ルートからの深さ（1始まり。バッジは UI で 3 に丸める）,
      sortOrder: sort_order
    """
    sql = (
        "SELECT `dept_id`, `dept_code`, `dept_name`, `parent_dept_id`, `sort_order` "
        "FROM `M_Department` WHERE `Enabled` = 1 "
        "ORDER BY (`parent_dept_id` IS NOT NULL), `parent_dept_id`, `sort_order`, `dept_code`"
    )
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql)
            raw = cur.fetchall()
    finally:
        conn.close()

    if not raw:
        return []

    by_id: dict[int, dict] = {}
    for r in raw:
        did = int(r["dept_id"])
        by_id[did] = r

    memo: dict[int, int] = {}
    out: list[dict] = []
    for r in raw:
        did = int(r["dept_id"])
        p = r.get("parent_dept_id")
        visiting: set[int] = set()
        lv = _m_department_depth(did, by_id, memo, visiting)
        out.append(
            {
                "id": did,
                "code": str(r.get("dept_code") or "").strip(),
                "name": str(r.get("dept_name") or "").strip(),
                "parent": int(p) if p is not None else None,
                "lv": lv,
                "sortOrder": int(r.get("sort_order") or 0),
            }
        )
    return out


def list_m_roles_for_org_settings() -> list[dict]:
    """
    M_Role の有効行を返す（フロントの state.roles 互換: id / code / name）。
    """
    sql = (
        "SELECT `role_id`, `role_code`, `role_name` FROM `M_Role` "
        "WHERE `Enabled` = 1 ORDER BY `role_code`"
    )
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql)
            raw = cur.fetchall()
    finally:
        conn.close()
    out: list[dict] = []
    for r in raw or []:
        out.append(
            {
                "id": int(r["role_id"]),
                "code": str(r.get("role_code") or "").strip(),
                "name": str(r.get("role_name") or "").strip(),
            }
        )
    return out


def list_active_t_department_role_pairs() -> list[dict]:
    """
    T_DepartmentRole のうち現在有効な付与（granted_to が無期限または未来）。
    戻り値は {deptId, roleId}（JS 側 state.deptRoles と同形）。
    """
    sql = (
        "SELECT `dept_id`, `role_id` FROM `T_DepartmentRole` "
        "WHERE `granted_to` IS NULL OR `granted_to` >= CURDATE()"
    )
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql)
            raw = cur.fetchall()
    finally:
        conn.close()
    out: list[dict] = []
    for r in raw or []:
        out.append(
            {
                "deptId": int(r["dept_id"]),
                "roleId": int(r["role_id"]),
            }
        )
    return out


def set_t_department_role(dept_id: int, role_id: int, grant: bool) -> bool:
    """
    T_DepartmentRole にロール付与を反映する。
    grant=True: INSERT（granted_from=CURRENT_DATE, granted_to=NULL）。
                UNIQUE 衝突時は granted_to を NULL に戻して有効化。
    grant=False: DELETE。
    """
    did = int(dept_id)
    rid = int(role_id)
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            if grant:
                cur.execute(
                    "INSERT INTO `T_DepartmentRole` "
                    "(`dept_id`, `role_id`, `granted_from`, `granted_to`) "
                    "VALUES (%s, %s, CURDATE(), NULL) "
                    "ON DUPLICATE KEY UPDATE "
                    "`granted_to` = NULL, `updated_at` = CURRENT_TIMESTAMP",
                    (did, rid),
                )
            else:
                cur.execute(
                    "DELETE FROM `T_DepartmentRole` "
                    "WHERE `dept_id` = %s AND `role_id` = %s",
                    (did, rid),
                )
        conn.commit()
        return True
    except Exception as e:
        logger.warning("set_t_department_role: %s", e)
        try:
            conn.rollback()
        except Exception:
            pass
        return False
    finally:
        conn.close()


def get_m_department_org_settings_row(dept_id: int) -> dict | None:
    """1件を org 設定画面用 dict（id/code/name/parent/lv/sortOrder）で返す。"""
    did = int(dept_id)
    rows = list_m_department_org_settings_rows()
    for r in rows:
        if int(r.get("id") or 0) == did:
            return r
    return None


def insert_m_department(
    dept_code: str,
    dept_name: str,
    parent_dept_id: int | None,
    sort_order: int = 10,
) -> tuple[int | None, str | None]:
    """
    M_Department に1行 INSERT。成功時は新しい dept_id、失敗時は (None, メッセージ)。
    """
    code = (dept_code or "").strip()
    name = (dept_name or "").strip()
    if not code:
        return None, "部署コードを入力してください。"
    if not name:
        return None, "部署名を入力してください。"
    if len(code) > 20:
        return None, "部署コードは20文字以内です。"
    if len(name) > 100:
        return None, "部署名は100文字以内です。"

    pid = int(parent_dept_id) if parent_dept_id is not None else None

    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            if pid is not None:
                cur.execute(
                    "SELECT `dept_id` FROM `M_Department` WHERE `dept_id`=%s LIMIT 1",
                    (pid,),
                )
                if not cur.fetchone():
                    return None, "親部署が見つかりません。"
            cur.execute(
                "INSERT INTO `M_Department` "
                "(`dept_code`,`dept_name`,`parent_dept_id`,`sort_order`,`Enabled`) "
                "VALUES (%s,%s,%s,%s,1)",
                (code, name, pid, int(sort_order)),
            )
            new_id = int(cur.lastrowid)
        conn.commit()
        return new_id, None
    except IntegrityError as e:
        try:
            conn.rollback()
        except Exception:
            pass
        raw = ""
        try:
            raw = str(e.args[1]) if getattr(e, "args", None) else str(e)
        except Exception:
            raw = str(e)
        low = raw.lower()
        if "duplicate" in low or "uq_m_department_code" in low:
            return None, "この部署コードは既に登録されています。"
        logger.warning("insert_m_department IntegrityError: %s", raw)
        return None, "部署の登録に失敗しました。"
    except Exception as e:
        logger.warning("insert_m_department: %s", e)
        try:
            conn.rollback()
        except Exception:
            pass
        return None, "部署の登録に失敗しました。"
    finally:
        conn.close()


def update_m_department(
    dept_id: int,
    dept_code: str,
    dept_name: str,
) -> tuple[bool, str | None]:
    """部署コード・部署名のみ更新。"""
    code = (dept_code or "").strip()
    name = (dept_name or "").strip()
    if not code:
        return False, "部署コードを入力してください。"
    if not name:
        return False, "部署名を入力してください。"
    if len(code) > 20:
        return False, "部署コードは20文字以内です。"
    if len(name) > 100:
        return False, "部署名は100文字以内です。"

    did = int(dept_id)
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE `M_Department` SET `dept_code`=%s, `dept_name`=%s WHERE `dept_id`=%s AND `Enabled`=1",
                (code, name, did),
            )
            if cur.rowcount == 0:
                conn.rollback()
                return False, "部署が見つからないか、無効です。"
        conn.commit()
        return True, None
    except IntegrityError as e:
        try:
            conn.rollback()
        except Exception:
            pass
        raw = str(e.args[1]) if getattr(e, "args", None) else str(e)
        low = raw.lower()
        if "duplicate" in low:
            return False, "この部署コードは既に登録されています。"
        logger.warning("update_m_department IntegrityError: %s", raw)
        return False, "部署の更新に失敗しました。"
    except Exception as e:
        logger.warning("update_m_department: %s", e)
        try:
            conn.rollback()
        except Exception:
            pass
        return False, "部署の更新に失敗しました。"
    finally:
        conn.close()


def delete_m_department(dept_id: int) -> tuple[bool, str | None]:
    """
    部署を削除。子部署・T_DepartmentRole は先に除去。T_UserDepartment 参照時は失敗。
    """
    did = int(dept_id)
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT COUNT(*) AS c FROM `M_Department` WHERE `parent_dept_id`=%s",
                (did,),
            )
            row = cur.fetchone()
            if row and int(row.get("c") or 0) > 0:
                return False, "配下の部署があるため削除できません。"
            cur.execute(
                "DELETE FROM `T_DepartmentRole` WHERE `dept_id`=%s",
                (did,),
            )
            cur.execute("DELETE FROM `M_Department` WHERE `dept_id`=%s", (did,))
            if cur.rowcount == 0:
                conn.rollback()
                return False, "対象の部署が見つかりません。"
        conn.commit()
        return True, None
    except IntegrityError as e:
        try:
            conn.rollback()
        except Exception:
            pass
        logger.warning("delete_m_department IntegrityError: %s", e)
        return (
            False,
            "この部署はユーザ所属など他データで参照されているため削除できません。",
        )
    except Exception as e:
        logger.warning("delete_m_department: %s", e)
        try:
            conn.rollback()
        except Exception:
            pass
        return False, "部署の削除に失敗しました。"
    finally:
        conn.close()


def update_last_login_datetime(userid: str) -> None:
    """成功ログイン後に LastLoginDateTime を更新する。"""
    uid = (userid or "").strip()
    if not uid:
        return
    sql = "UPDATE `T1_LoginUser` SET `LastLoginDateTime` = NOW() WHERE `userid` = %s"
    try:
        conn = _get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute(sql, (uid,))
            conn.commit()
        finally:
            conn.close()
    except Exception as e:
        logger.warning("update_last_login_datetime failed: %s", e)


def is_login_user_admin(userid: str) -> bool:
    """ログインIDが T1_LoginUser で admin_option=1（管理者）か。"""
    uid = (userid or "").strip()
    if not uid:
        return False
    sql = "SELECT `admin_option` FROM `T1_LoginUser` WHERE `userid`=%s LIMIT 1"
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, (uid,))
            row = cur.fetchone()
    finally:
        conn.close()
    if not row:
        return False
    return int(row.get("admin_option") or 0) == 1


def fetch_login_user_for_maintenance(userid: str) -> dict | None:
    """userid で T1_LoginUser を1件取得（メンテ画面用）。"""
    uid = (userid or "").strip()
    if not uid:
        return None
    sql = (
        "SELECT `userid`, `user_name`, `admin_option`, `Enabled`, "
        "`LastLoginDateTime`, `created_at`, `updated_at` "
        "FROM `T1_LoginUser` WHERE `userid`=%s LIMIT 1"
    )
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, (uid,))
            row = cur.fetchone()
    finally:
        conn.close()
    return row


def validate_login_user_maintenance_for_save(
    userid: str,
    user_name: str,
    admin_option: str,
    enabled: str,
    pwd: str,
    pwd_confirm: str,
    *,
    is_new: bool,
    pwd_change: bool,
) -> list[str]:
    errs: list[str] = []
    uid = (userid or "").strip()
    uname = (user_name or "").strip()
    admin = (admin_option or "").strip()
    en = (enabled or "").strip()

    if not uid:
        errs.append("ログインIDは必須です。")
    elif len(uid) >= 20:
        errs.append("ログインIDは20桁未満で入力してください。")

    if not uname:
        errs.append("表示名は必須です。")

    if admin not in ("0", "1"):
        errs.append("管理者区分を選択してください。")

    if en not in ("0", "1"):
        errs.append("有効区分を選択してください。")

    if is_new or pwd_change:
        p1 = pwd or ""
        p2 = pwd_confirm or ""
        if not p1.strip():
            errs.append("パスワードは必須です。")
        if p1 != p2:
            errs.append("パスワードと確認用パスワードが一致しません。")

    return errs


def save_login_user_maintenance(
    original_userid: str,
    userid: str,
    user_name: str,
    admin_option: str,
    enabled: str,
    pwd: str,
    *,
    is_new: bool,
    pwd_change: bool,
) -> tuple[bool, str]:
    """
    ログインIDとパスワード（平文）が同一のときはユーザ初期化とみなし、
    更新かつパスワード変更時のみ LastLoginDateTime を NULL にする。
    新規登録時は常に LastLoginDateTime を NULL で登録する。
    """
    uid_old = (original_userid or "").strip()
    uid_new = (userid or "").strip()
    pwd_plain = (pwd or "").strip()
    uname = (user_name or "").strip()
    admin = int((admin_option or "0").strip() or "0")
    en = int((enabled or "1").strip() or "1")
    # 初期化: ログインIDとパスワードが同じ値（新規は UI 上も常に一致）
    is_password_init = pwd_plain == uid_new and bool(uid_new)

    conn = _get_connection()
    try:
        conn.autocommit(False)
        try:
            with conn.cursor() as cur:
                if is_new:
                    cur.execute(
                        "SELECT 1 FROM `T1_LoginUser` WHERE `userid`=%s LIMIT 1",
                        (uid_new,),
                    )
                    if cur.fetchone() is not None:
                        conn.rollback()
                        return False, "指定されたログインIDはすでに存在しています。"
                    cur.execute(
                        "INSERT INTO `T1_LoginUser` (`userid`, `pwd`, `user_name`, `admin_option`, `Enabled`, `LastLoginDateTime`) "
                        "VALUES (%s, %s, %s, %s, %s, NULL)",
                        (uid_new, _password_sha256_hex(pwd_plain), uname, admin, en),
                    )
                else:
                    if not uid_old:
                        conn.rollback()
                        return False, "更新対象ユーザーが特定できません。"
                    cur.execute(
                        "SELECT 1 FROM `T1_LoginUser` WHERE `userid`=%s LIMIT 1",
                        (uid_old,),
                    )
                    if cur.fetchone() is None:
                        conn.rollback()
                        return False, "更新対象ユーザーが見つかりません。"

                    if uid_new != uid_old:
                        cur.execute(
                            "SELECT 1 FROM `T1_LoginUser` WHERE `userid`=%s LIMIT 1",
                            (uid_new,),
                        )
                        if cur.fetchone() is not None:
                            conn.rollback()
                            return False, "変更先のログインIDはすでに存在しています。"

                    if pwd_change:
                        if is_password_init:
                            cur.execute(
                                "UPDATE `T1_LoginUser` SET `userid`=%s, `pwd`=%s, `user_name`=%s, `admin_option`=%s, `Enabled`=%s, "
                                "`LastLoginDateTime`=NULL WHERE `userid`=%s",
                                (
                                    uid_new,
                                    _password_sha256_hex(pwd_plain),
                                    uname,
                                    admin,
                                    en,
                                    uid_old,
                                ),
                            )
                        else:
                            cur.execute(
                                "UPDATE `T1_LoginUser` SET `userid`=%s, `pwd`=%s, `user_name`=%s, `admin_option`=%s, `Enabled`=%s "
                                "WHERE `userid`=%s",
                                (
                                    uid_new,
                                    _password_sha256_hex(pwd_plain),
                                    uname,
                                    admin,
                                    en,
                                    uid_old,
                                ),
                            )
                    else:
                        cur.execute(
                            "UPDATE `T1_LoginUser` SET `userid`=%s, `user_name`=%s, `admin_option`=%s, `Enabled`=%s "
                            "WHERE `userid`=%s",
                            (uid_new, uname, admin, en, uid_old),
                        )
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        if not is_new and pwd_change and is_password_init:
            return True, "ユーザー情報を保存しました。最終ログイン日時を初期化しました。"
        return True, "ユーザー情報を保存しました。"
    except Exception as e:
        logger.exception("save_login_user_maintenance: %s", e)
        return False, str(e)
    finally:
        conn.close()


def _check_login_user_delete_allowed(cur, actor: str, uid: str) -> tuple[bool, str]:
    """actor / uid は strip 済み。削除実行前の権限・対象存在チェックのみ。"""
    cur.execute(
        "SELECT `admin_option` FROM `T1_LoginUser` WHERE `userid`=%s LIMIT 1",
        (actor,),
    )
    actor_row = cur.fetchone()
    if actor_row is None:
        return False, "操作ユーザーが見つかりません。"
    if int(actor_row.get("admin_option") or 0) != 1:
        return False, "ユーザーの削除は管理者のみが実行できます。"

    cur.execute(
        "SELECT 1 FROM `T1_LoginUser` WHERE `userid`=%s LIMIT 1",
        (uid,),
    )
    if cur.fetchone() is None:
        return False, "削除対象ユーザーが見つかりません。"
    return True, ""


def validate_login_user_delete(actor_userid: str, target_userid: str) -> tuple[bool, str]:
    """
    削除前チェックのみ（DELETE は行わない）。
    クライアントで確認ダイアログの前に権限エラー等を返すために使う。
    """
    actor = (actor_userid or "").strip()
    uid = (target_userid or "").strip()
    if not actor:
        return False, "ログイン情報が取得できません。"
    if not uid:
        return False, "削除対象のユーザーIDが指定されていません。"

    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            return _check_login_user_delete_allowed(cur, actor, uid)
    except Exception as e:
        logger.exception("validate_login_user_delete: %s", e)
        return False, str(e)
    finally:
        conn.close()


# --- チームチャット（T1_ChatChannel / T1_ChatMember / T1_ChatMessage） ---

CHAT_TITLE_MAX = 200
CHAT_BODY_MAX = 32000
CHAT_MESSAGES_PAGE = 500
CHAT_AROUND_HALF = 200
CHAT_SEARCH_MAX_RESULTS = 50
CHAT_SEARCH_MIN_LEN = 2
CHAT_SEARCH_SNIPPET_LEN = 200
CHAT_ERR_MESSAGE_NOT_FOUND = "メッセージが見つかりません。"

# 本文中の @トークン（空白・@ まで）
MENTION_TOKEN_RE = re.compile(r"@([^\s@]+)")


def _chat_resolve_mention_userids(
    cur, channel_id: int, body: str
) -> list[str]:
    """チャンネルメンバーに限定し、@userid または @表示名（完全一致）に対応する userid を返す。"""
    tokens = MENTION_TOKEN_RE.findall(body or "")
    if not tokens:
        return []
    cur.execute(
        "SELECT m.`userid`, COALESCE(NULLIF(TRIM(u.`user_name`), ''), u.`userid`) AS `disp` "
        "FROM `T1_ChatMember` m "
        "INNER JOIN `T1_LoginUser` u ON u.`userid` = m.`userid` "
        "WHERE m.`channel_id`=%s",
        (int(channel_id),),
    )
    rows = cur.fetchall() or []
    by_user_cf: dict[str, str] = {}
    by_disp: dict[str, str] = {}
    for r in rows:
        uid = str(_chat_row_val(r, "userid", "userid") or "").strip()
        disp = str(_chat_row_val(r, "disp", "disp") or "").strip()
        if uid:
            by_user_cf[uid.casefold()] = uid
            if disp:
                by_disp[disp] = uid
    out: list[str] = []
    seen: set[str] = set()
    for raw in tokens:
        tok = (raw or "").strip()
        if not tok:
            continue
        resolved = by_user_cf.get(tok.casefold()) or by_disp.get(tok)
        if resolved and resolved not in seen:
            seen.add(resolved)
            out.append(resolved)
    return out


def _chat_insert_mentions_for_message(
    cur, channel_id: int, message_id: int, body: str
) -> list[str]:
    """T1_ChatMention にINSERT。テーブル無し時は空リストを返す。"""
    try:
        mention_ids = _chat_resolve_mention_userids(cur, channel_id, body)
        for mu in mention_ids:
            cur.execute(
                "INSERT IGNORE INTO `T1_ChatMention` (`message_id`, `mentioned_userid`) "
                "VALUES (%s, %s)",
                (int(message_id), mu),
            )
        return mention_ids
    except ProgrammingError:
        logger.warning(
            "T1_ChatMention が未作成です。sql/install_team_chat_mention.sql を適用してください。"
        )
        return []


def _chat_latest_mention_max_by_channel(viewer_userid: str) -> dict[int, int]:
    """閲覧者宛メンションを含む各チャンネルでの最新 message_id（一覧バッジ用・1クエリ）。"""
    uid = (viewer_userid or "").strip()
    if not uid:
        return {}
    sql = (
        "SELECT m.`channel_id`, MAX(m.`id`) AS `max_id` "
        "FROM `T1_ChatMention` cm "
        "INNER JOIN `T1_ChatMessage` m ON m.`id` = cm.`message_id` "
        "WHERE cm.`mentioned_userid` = %s "
        "GROUP BY m.`channel_id`"
    )
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            try:
                cur.execute(sql, (uid,))
                rows = cur.fetchall() or []
            except ProgrammingError:
                return {}
    finally:
        conn.close()
    out: dict[int, int] = {}
    for r in rows:
        cid = _chat_row_val(r, "channel_id", "channel_id")
        mid = _chat_row_val(r, "max_id", "max_id")
        try:
            out[int(cid)] = int(mid)
        except (TypeError, ValueError):
            continue
    return out


def _chat_fetch_mentions_bulk(message_ids: list[int]) -> dict[int, list[str]]:
    """message_id -> [mentioned_userid, ...]"""
    ids = sorted({int(x) for x in message_ids if x is not None})
    if not ids:
        return {}
    placeholders = ",".join(["%s"] * len(ids))
    sql = (
        f"SELECT `message_id`, `mentioned_userid` FROM `T1_ChatMention` "
        f"WHERE `message_id` IN ({placeholders}) ORDER BY `mentioned_userid`"
    )
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            try:
                cur.execute(sql, ids)
                rows = cur.fetchall() or []
            except ProgrammingError:
                return {}
    finally:
        conn.close()
    bu: dict[int, list[str]] = {}
    for r in rows:
        mid = _chat_row_val(r, "message_id", "message_id")
        mu = str(_chat_row_val(r, "mentioned_userid", "mentioned_userid") or "").strip()
        if not mid or not mu:
            continue
        try:
            ik = int(mid)
        except (TypeError, ValueError):
            continue
        bu.setdefault(ik, []).append(mu)
    return bu


def _chat_attach_mentions_to_messages(messages: list[dict]) -> None:
    if not messages:
        return
    ids = [int(m["id"]) for m in messages if m.get("id") is not None]
    bulk = _chat_fetch_mentions_bulk(ids)
    for m in messages:
        mid = int(m["id"])
        m["mentions"] = bulk.get(mid, [])


def _chat_row_val(row: dict, *names: str):
    """DictCursor の列名の大文字小文字差を吸収して値を取得。"""
    if not row:
        return None
    for n in names:
        if n in row:
            return row.get(n)
    lower_index = {str(k).lower(): k for k in row}
    for n in names:
        orig = lower_index.get(n.lower())
        if orig is not None:
            return row.get(orig)
    return None


def _mysql_truthy_flag(v) -> bool:
    """MySQL の (cond) AS flag が返す 1/0・BIT・バイト列を bool にする。"""
    if v is None:
        return False
    if isinstance(v, bool):
        return v
    if isinstance(v, (bytes, bytearray)):
        if len(v) == 0:
            return False
        if len(v) == 1:
            return v[0] != 0
        return any(b != 0 for b in v)
    try:
        return int(v) != 0
    except (TypeError, ValueError):
        return bool(v)


def _chat_same_participant(viewer_userid: str, sender_userid: str) -> bool:
    """閲覧者と送信者が同一ログインユーザか（大文字小文字・前後空白の差を吸収）。"""
    v = (viewer_userid or "").strip()
    s = (sender_userid or "").strip()
    if not v or not s:
        return False
    if v == s:
        return True
    try:
        if v.casefold() == s.casefold():
            return True
    except Exception:
        if v.lower() == s.lower():
            return True
    return False


def _chat_dt_str(v) -> str:
    if v is None:
        return ""
    if isinstance(v, datetime):
        return v.strftime("%Y-%m-%d %H:%M:%S")
    if isinstance(v, date):
        return v.strftime("%Y-%m-%d")
    return str(v).strip()


def chat_list_pick_users(exclude_userid: str) -> list[dict]:
    """有効ユーザ一覧（メンバー選択用）。自分と管理者（admin_option=1）を除く。"""
    ex = (exclude_userid or "").strip()
    sql = (
        "SELECT `userid`, `user_name` FROM `T1_LoginUser` "
        "WHERE `Enabled` = 1 AND `userid` <> %s AND `admin_option` <> 1 "
        "ORDER BY COALESCE(NULLIF(TRIM(`user_name`), ''), `userid`), `userid`"
    )
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, (ex,))
            rows = cur.fetchall() or []
    finally:
        conn.close()
    return rows


def chat_is_channel_member(channel_id: int, userid: str) -> bool:
    uid = (userid or "").strip()
    if not uid or channel_id <= 0:
        return False
    sql = (
        "SELECT 1 FROM `T1_ChatMember` "
        "WHERE `channel_id`=%s AND `userid`=%s LIMIT 1"
    )
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, (channel_id, uid))
            return cur.fetchone() is not None
    finally:
        conn.close()


def chat_list_channels(userid: str) -> list[dict]:
    """参加チャンネル一覧（新しい更新順）。"""
    uid = (userid or "").strip()
    if not uid:
        return []
    sql = (
        "SELECT c.`id`, c.`title`, c.`created_at`, c.`updated_at`, c.`created_by_userid` "
        "FROM `T1_ChatChannel` c "
        "INNER JOIN `T1_ChatMember` m ON m.`channel_id` = c.`id` AND m.`userid` = %s "
        "ORDER BY COALESCE(c.`updated_at`, c.`created_at`) DESC, c.`id` DESC"
    )
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, (uid,))
            rows = cur.fetchall() or []
    finally:
        conn.close()
    mention_max: dict[int, int] = {}
    try:
        mention_max = _chat_latest_mention_max_by_channel(uid)
    except Exception:
        logger.debug("chat_list_channels: mention map skipped", exc_info=True)
    out = []
    for r in rows:
        cid = int(r["id"])
        item = {
            "id": cid,
            "title": (r.get("title") or "").strip(),
            "created_at": _chat_dt_str(r.get("created_at")),
            "updated_at": _chat_dt_str(r.get("updated_at")),
            "created_by_userid": (r.get("created_by_userid") or "").strip(),
        }
        mid_ment = mention_max.get(cid)
        if mid_ment is not None:
            item["latest_mention_message_id"] = int(mid_ment)
        else:
            item["latest_mention_message_id"] = None
        out.append(item)
    return out


def chat_get_channel_for_member(channel_id: int, userid: str) -> dict | None:
    uid = (userid or "").strip()
    if not uid or channel_id <= 0:
        return None
    sql = (
        "SELECT c.`id`, c.`title`, c.`created_at`, c.`updated_at`, c.`created_by_userid` "
        "FROM `T1_ChatChannel` c "
        "INNER JOIN `T1_ChatMember` m ON m.`channel_id` = c.`id` AND m.`userid` = %s "
        "WHERE c.`id` = %s LIMIT 1"
    )
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, (uid, channel_id))
            r = cur.fetchone()
    finally:
        conn.close()
    if not r:
        return None
    return {
        "id": int(r["id"]),
        "title": (r.get("title") or "").strip(),
        "created_at": _chat_dt_str(r.get("created_at")),
        "updated_at": _chat_dt_str(r.get("updated_at")),
        "created_by_userid": (r.get("created_by_userid") or "").strip(),
    }


def chat_list_members(channel_id: int, userid: str) -> tuple[list[dict] | None, str]:
    """チャンネルメンバー一覧。閲覧者が参加していない場合は None。"""
    if not chat_is_channel_member(channel_id, userid):
        return None, "チャンネルに参加していません。"
    sql = (
        "SELECT m.`userid`, m.`joined_at`, u.`user_name`, c.`created_by_userid` "
        "FROM `T1_ChatMember` m "
        "INNER JOIN `T1_LoginUser` u ON u.`userid` = m.`userid` "
        "INNER JOIN `T1_ChatChannel` c ON c.`id` = m.`channel_id` "
        "WHERE m.`channel_id`=%s "
        "ORDER BY COALESCE(NULLIF(TRIM(u.`user_name`), ''), u.`userid`), u.`userid`"
    )
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, (channel_id,))
            rows = cur.fetchall() or []
    finally:
        conn.close()
    out = []
    for r in rows:
        un = (r.get("user_name") or "").strip()
        uid = (r.get("userid") or "").strip()
        creator = (r.get("created_by_userid") or "").strip()
        out.append(
            {
                "userid": uid,
                "user_name": un if un else uid,
                "joined_at": _chat_dt_str(r.get("joined_at")),
                "is_creator": bool(uid and creator and uid == creator),
            }
        )
    return out, ""


def chat_create_channel(
    creator_userid: str, title: str, member_userids: list[str]
) -> tuple[int | None, str]:
    """
    チャンネル作成。creator は必ずメンバーに含める。
    member_userids は T1_LoginUser で有効な ID のみ。
    """
    creator = (creator_userid or "").strip()
    t = (title or "").strip()
    if not creator:
        return None, "ログイン情報が取得できません。"
    if not t:
        return None, "チャットタイトルを入力してください。"
    if len(t) > CHAT_TITLE_MAX:
        return None, f"タイトルは{CHAT_TITLE_MAX}文字以内で入力してください。"

    raw_ids = [str(x).strip() for x in (member_userids or []) if str(x).strip()]
    member_set = {creator}
    for x in raw_ids:
        if x != creator:
            member_set.add(x)

    conn = _get_connection()
    try:
        conn.autocommit(False)
        try:
            with conn.cursor() as cur:
                placeholders = ",".join(["%s"] * len(member_set))
                cur.execute(
                    f"SELECT `userid` FROM `T1_LoginUser` "
                    f"WHERE `Enabled`=1 AND `userid` IN ({placeholders})",
                    tuple(member_set),
                )
                ok_rows = {str(row["userid"]) for row in (cur.fetchall() or [])}
                if creator not in ok_rows:
                    conn.rollback()
                    return None, "作成者のアカウントが無効です。"
                missing = member_set - ok_rows
                if missing:
                    conn.rollback()
                    return None, f"存在しないか無効なユーザーが含まれています: {', '.join(sorted(missing))}"

                cur.execute(
                    "INSERT INTO `T1_ChatChannel` (`title`, `created_by_userid`) VALUES (%s, %s)",
                    (t, creator),
                )
                cid = int(cur.lastrowid)
                for uid in sorted(member_set):
                    cur.execute(
                        "INSERT INTO `T1_ChatMember` (`channel_id`, `userid`) VALUES (%s, %s)",
                        (cid, uid),
                    )
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        return cid, ""
    except Exception as e:
        logger.exception("chat_create_channel: %s", e)
        return None, str(e)
    finally:
        conn.close()


def chat_delete_channel(channel_id: int, actor_userid: str) -> tuple[bool, str]:
    """
    チャンネル削除。登録者（T1_ChatChannel.created_by_userid）のみ実行可。
    メンバー・メッセージは FK の ON DELETE CASCADE で連鎖削除。
    """
    uid = (actor_userid or "").strip()
    if not uid or channel_id <= 0:
        return False, "不正なリクエストです。"
    conn = _get_connection()
    try:
        conn.autocommit(False)
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT `created_by_userid` FROM `T1_ChatChannel` WHERE `id`=%s LIMIT 1",
                    (channel_id,),
                )
                row = cur.fetchone()
                if not row:
                    conn.rollback()
                    return False, "チャットが見つかりません。"
                creator = str(row.get("created_by_userid") or "").strip()
                if not _chat_same_participant(uid, creator):
                    conn.rollback()
                    return False, "このチャットを削除できるのは登録者（作成者）だけです。"
                cur.execute("DELETE FROM `T1_ChatChannel` WHERE `id`=%s", (channel_id,))
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        return True, ""
    except Exception as e:
        logger.exception("chat_delete_channel: %s", e)
        return False, str(e)
    finally:
        conn.close()


def chat_add_members(
    channel_id: int, actor_userid: str, new_userids: list[str]
) -> tuple[bool, str]:
    if not chat_is_channel_member(channel_id, actor_userid):
        return False, "チャンネルに参加していません。"
    ids = sorted({str(x).strip() for x in (new_userids or []) if str(x).strip()})
    if not ids:
        return False, "追加するユーザーを選択してください。"
    conn = _get_connection()
    try:
        conn.autocommit(False)
        try:
            with conn.cursor() as cur:
                placeholders = ",".join(["%s"] * len(ids))
                cur.execute(
                    f"SELECT `userid` FROM `T1_LoginUser` "
                    f"WHERE `Enabled`=1 AND `userid` IN ({placeholders})",
                    tuple(ids),
                )
                ok = {str(row["userid"]) for row in (cur.fetchall() or [])}
                missing = set(ids) - ok
                if missing:
                    conn.rollback()
                    return False, f"存在しないか無効なユーザー: {', '.join(sorted(missing))}"
                for uid in ids:
                    cur.execute(
                        "INSERT IGNORE INTO `T1_ChatMember` (`channel_id`, `userid`) VALUES (%s, %s)",
                        (channel_id, uid),
                    )
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        return True, "メンバーを追加しました。"
    except Exception as e:
        logger.exception("chat_add_members: %s", e)
        return False, str(e)
    finally:
        conn.close()


def _chat_join_rows_to_messages(rows: list, viewer_userid: str) -> list[dict]:
    """T1_ChatMessage + LoginUser JOIN の行を API 用メッセージ dict に変換する。"""
    vu = (viewer_userid or "").strip()
    out = []
    for r in rows:
        raw_snd = _chat_row_val(r, "msg_sender_userid", "sender_userid")
        snd = str(raw_snd if raw_snd is not None else "").strip()
        raw_id = _chat_row_val(r, "msg_id", "id")
        raw_ch = _chat_row_val(r, "msg_channel_id", "channel_id")
        raw_body = _chat_row_val(r, "msg_body", "body")
        raw_ca = _chat_row_val(r, "msg_created_at", "created_at")
        is_self = _chat_same_participant(vu, snd)
        disp = _chat_row_val(r, "sender_display_name", "SENDER_DISPLAY_NAME")
        out.append(
            {
                "id": int(raw_id),
                "channel_id": int(raw_ch),
                "sender_userid": snd,
                "sender_display_name": str(disp if disp is not None else "").strip(),
                "body": raw_body if raw_body is not None else "",
                "created_at": _chat_dt_str(raw_ca),
                "is_from_viewer": bool(is_self),
            }
        )
    return out


def _chat_like_pattern_contains(q: str) -> str:
    """LIKE 用。MySQL の ESCAPE '|' と組み合わせて % と _ をリテラル扱いする。"""
    parts: list[str] = []
    for c in q:
        if c == "|":
            parts.append("||")
        elif c == "%":
            parts.append("|%")
        elif c == "_":
            parts.append("|_")
        else:
            parts.append(c)
    return "%" + "".join(parts) + "%"


def _chat_search_snippet(body: object, max_len: int = CHAT_SEARCH_SNIPPET_LEN) -> str:
    b = body if isinstance(body, str) else str(body or "")
    b = b.replace("\r\n", "\n").strip()
    if len(b) <= max_len:
        return b
    return b[: max_len - 1] + "…"


def chat_get_messages(
    channel_id: int, userid: str, after_id: int = 0, limit: int | None = None
) -> tuple[list[dict] | None, str]:
    if not chat_is_channel_member(channel_id, userid):
        return None, "チャンネルに参加していません。"
    lim = int(limit) if limit is not None else CHAT_MESSAGES_PAGE
    if lim < 1:
        lim = 1
    if lim > CHAT_MESSAGES_PAGE:
        lim = CHAT_MESSAGES_PAGE
    aid = max(0, int(after_id or 0))
    vu = (userid or "").strip()
    # 本人判定は常に Python で sender と閲覧者を比較（ドライバが flag 列を文字列等で返すと _mysql_truthy_flag が誤真になり得る）
    sql = (
        "SELECT m.`id` AS `msg_id`, m.`channel_id` AS `msg_channel_id`, "
        "m.`sender_userid` AS `msg_sender_userid`, m.`body` AS `msg_body`, "
        "m.`created_at` AS `msg_created_at`, "
        "COALESCE(NULLIF(TRIM(u.`user_name`), ''), u.`userid`) AS `sender_display_name` "
        "FROM `T1_ChatMessage` m "
        "INNER JOIN `T1_LoginUser` u ON u.`userid` = m.`sender_userid` "
        "WHERE m.`channel_id`=%s AND m.`id` > %s "
        "ORDER BY m.`id` ASC LIMIT %s"
    )
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, (channel_id, aid, lim))
            rows = cur.fetchall() or []
    finally:
        conn.close()
    msgs = _chat_join_rows_to_messages(rows, vu)
    _chat_attach_mentions_to_messages(msgs)
    return msgs, ""


def chat_get_messages_around(
    channel_id: int,
    userid: str,
    center_msg_id: int,
    half: int | None = None,
) -> tuple[list[dict] | None, str]:
    """
    指定メッセージを中心に前後をまとめて取得（検索結果ジャンプ用）。
    center を含む「それより古い」側は最大 half+1 件、新しい側は最大 half 件。
    """
    if not chat_is_channel_member(channel_id, userid):
        return None, "チャンネルに参加していません。"
    cid = int(channel_id)
    mid = int(center_msg_id)
    if mid < 1:
        return None, CHAT_ERR_MESSAGE_NOT_FOUND
    h = int(half) if half is not None else CHAT_AROUND_HALF
    if h < 1:
        h = 1
    if h > 250:
        h = 250
    vu = (userid or "").strip()

    base_sql = (
        "SELECT m.`id` AS `msg_id`, m.`channel_id` AS `msg_channel_id`, "
        "m.`sender_userid` AS `msg_sender_userid`, m.`body` AS `msg_body`, "
        "m.`created_at` AS `msg_created_at`, "
        "COALESCE(NULLIF(TRIM(u.`user_name`), ''), u.`userid`) AS `sender_display_name` "
        "FROM `T1_ChatMessage` m "
        "INNER JOIN `T1_LoginUser` u ON u.`userid` = m.`sender_userid` "
    )

    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT 1 FROM `T1_ChatMessage` WHERE `channel_id`=%s AND `id`=%s LIMIT 1",
                (cid, mid),
            )
            if not cur.fetchone():
                return None, CHAT_ERR_MESSAGE_NOT_FOUND
            cur.execute(
                base_sql + "WHERE m.`channel_id`=%s AND m.`id`<=%s "
                "ORDER BY m.`id` DESC LIMIT %s",
                (cid, mid, h + 1),
            )
            older_first = cur.fetchall() or []
            cur.execute(
                base_sql + "WHERE m.`channel_id`=%s AND m.`id`>%s "
                "ORDER BY m.`id` ASC LIMIT %s",
                (cid, mid, h),
            )
            newer = cur.fetchall() or []
    finally:
        conn.close()

    older_first.reverse()
    merged = older_first + newer
    msgs_ar = _chat_join_rows_to_messages(merged, vu)
    _chat_attach_mentions_to_messages(msgs_ar)
    return msgs_ar, ""


def chat_search_messages(
    userid: str, q: str, limit: int | None = None
) -> tuple[list[dict] | None, str]:
    """
    参加チャンネルに限定して本文を部分一致検索（LIKE）。
    先頭から limit 件（新しい id 順）。
    """
    uid = (userid or "").strip()
    raw = (q or "").strip()
    if not uid:
        return None, "ログイン情報が取得できません。"
    if len(raw) < CHAT_SEARCH_MIN_LEN:
        return None, f"検索語は{CHAT_SEARCH_MIN_LEN}文字以上入力してください。"
    lim = int(limit) if limit is not None else 30
    if lim < 1:
        lim = 1
    if lim > CHAT_SEARCH_MAX_RESULTS:
        lim = CHAT_SEARCH_MAX_RESULTS

    pattern = _chat_like_pattern_contains(raw)
    sql = (
        "SELECT m.`id` AS `msg_id`, m.`channel_id` AS `msg_channel_id`, "
        "m.`body` AS `msg_body`, m.`created_at` AS `msg_created_at`, "
        "ch.`title` AS `channel_title`, "
        "COALESCE(NULLIF(TRIM(u.`user_name`), ''), u.`userid`) AS `sender_display_name` "
        "FROM `T1_ChatMessage` m "
        "INNER JOIN `T1_ChatMember` mem ON mem.`channel_id` = m.`channel_id` "
        "AND mem.`userid` = %s "
        "INNER JOIN `T1_ChatChannel` ch ON ch.`id` = m.`channel_id` "
        "INNER JOIN `T1_LoginUser` u ON u.`userid` = m.`sender_userid` "
        "WHERE m.`body` LIKE %s ESCAPE '|' "
        "ORDER BY m.`id` DESC LIMIT %s"
    )
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, (uid, pattern, lim))
            rows = cur.fetchall() or []
    except Exception as e:
        logger.exception("chat_search_messages: %s", e)
        return None, str(e)
    finally:
        conn.close()

    out = []
    for r in rows:
        raw_id = _chat_row_val(r, "msg_id", "id")
        raw_ch = _chat_row_val(r, "msg_channel_id", "channel_id")
        raw_body = _chat_row_val(r, "msg_body", "body")
        raw_ca = _chat_row_val(r, "msg_created_at", "created_at")
        title = _chat_row_val(r, "channel_title", "title")
        disp = _chat_row_val(r, "sender_display_name", "SENDER_DISPLAY_NAME")
        body_s = raw_body if raw_body is not None else ""
        out.append(
            {
                "message_id": int(raw_id),
                "channel_id": int(raw_ch),
                "channel_title": str(title if title is not None else "").strip(),
                "snippet": _chat_search_snippet(body_s),
                "created_at": _chat_dt_str(raw_ca),
                "sender_display_name": str(disp if disp is not None else "").strip(),
            }
        )
    return out, ""


def chat_post_message(channel_id: int, userid: str, body: str) -> tuple[dict | None, str]:
    uid = (userid or "").strip()
    b = body if isinstance(body, str) else str(body or "")
    b = b.strip()
    if not uid:
        return None, "ログイン情報が取得できません。"
    if not b:
        return None, "メッセージを入力してください。"
    if len(b) > CHAT_BODY_MAX:
        return None, f"メッセージは{CHAT_BODY_MAX}文字以内で入力してください。"
    if not chat_is_channel_member(channel_id, uid):
        return None, "チャンネルに参加していません。"

    r = None
    mention_saved: list[str] = []
    conn = _get_connection()
    try:
        conn.autocommit(False)
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "INSERT INTO `T1_ChatMessage` (`channel_id`, `sender_userid`, `body`) "
                    "VALUES (%s, %s, %s)",
                    (channel_id, uid, b),
                )
                mid = int(cur.lastrowid)
                cur.execute(
                    "UPDATE `T1_ChatChannel` SET `updated_at` = NOW() WHERE `id`=%s",
                    (channel_id,),
                )
                try:
                    mention_saved = _chat_insert_mentions_for_message(
                        cur, channel_id, mid, b
                    )
                except Exception:
                    logger.exception("chat_post_message mention insert failed")
                    mention_saved = []
                cur.execute(
                    "SELECT m.`id` AS `msg_id`, m.`channel_id` AS `msg_channel_id`, "
                    "m.`sender_userid` AS `msg_sender_userid`, m.`body` AS `msg_body`, "
                    "m.`created_at` AS `msg_created_at`, "
                    "COALESCE(NULLIF(TRIM(u.`user_name`), ''), u.`userid`) AS `sender_display_name` "
                    "FROM `T1_ChatMessage` m "
                    "INNER JOIN `T1_LoginUser` u ON u.`userid` = m.`sender_userid` "
                    "WHERE m.`id`=%s LIMIT 1",
                    (mid,),
                )
                r = cur.fetchone()
            conn.commit()
        except Exception:
            conn.rollback()
            raise
    except Exception as e:
        logger.exception("chat_post_message: %s", e)
        return None, str(e)
    finally:
        conn.close()

    if not r:
        return None, "メッセージの保存に失敗しました。"
    raw_snd = _chat_row_val(r, "msg_sender_userid", "sender_userid")
    snd = str(raw_snd if raw_snd is not None else "").strip()
    raw_id = _chat_row_val(r, "msg_id", "id")
    raw_ch = _chat_row_val(r, "msg_channel_id", "channel_id")
    raw_body = _chat_row_val(r, "msg_body", "body")
    raw_ca = _chat_row_val(r, "msg_created_at", "created_at")
    is_self = _chat_same_participant(uid, snd)
    disp = _chat_row_val(r, "sender_display_name", "SENDER_DISPLAY_NAME")
    return (
        {
            "id": int(raw_id),
            "channel_id": int(raw_ch),
            "sender_userid": snd,
            "sender_display_name": str(disp if disp is not None else "").strip(),
            "body": raw_body if raw_body is not None else "",
            "created_at": _chat_dt_str(raw_ca),
            "is_from_viewer": bool(is_self),
            "mentions": list(mention_saved),
        },
        "",
    )


def delete_login_user_by_userid(actor_userid: str, target_userid: str) -> tuple[bool, str]:
    """
    ログイン中ユーザー（actor）が管理者のときのみ、target を削除する。
    ルール:
      - actor が未設定・DBに存在しない・admin_option!=1 のときはエラー
      - 対象が存在しない場合はエラー
    """
    actor = (actor_userid or "").strip()
    uid = (target_userid or "").strip()
    if not actor:
        return False, "ログイン情報が取得できません。"
    if not uid:
        return False, "削除対象のユーザーIDが指定されていません。"

    conn = _get_connection()
    try:
        conn.autocommit(False)
        try:
            with conn.cursor() as cur:
                ok, msg = _check_login_user_delete_allowed(cur, actor, uid)
                if not ok:
                    conn.rollback()
                    return False, msg

                cur.execute("DELETE FROM `T1_LoginUser` WHERE `userid`=%s", (uid,))
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        return True, "ユーザーを削除しました。"
    except Exception as e:
        logger.exception("delete_login_user_by_userid: %s", e)
        return False, str(e)
    finally:
        conn.close()
