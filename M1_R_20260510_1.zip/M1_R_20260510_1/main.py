"""
FastAPI + htmx サンプル（TOP: 取引先一覧）
"""
import asyncio
import logging
import os
import json
import re
import unicodedata
from contextlib import asynccontextmanager
from html import escape
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import quote, urlencode

import anyio
from jose import jwt
from fastapi import FastAPI, Form, HTTPException, Query, Request
from fastapi.responses import (
    FileResponse,
    HTMLResponse,
    JSONResponse,
    RedirectResponse,
    Response,
    StreamingResponse,
)
from pydantic import BaseModel, Field
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware

import app_config
import auth_middleware
import chat_hub
import db
import mcp_client
import mcp_tools

logger = logging.getLogger(__name__)
# Uvicorn 単体起動時、ルートが WARNING のままだと本モジュールの INFO（[diag]）が表示されない。
if not logger.handlers:
    _h = logging.StreamHandler()
    _h.setLevel(logging.INFO)
    _h.setFormatter(logging.Formatter("%(levelname)s:%(name)s:%(message)s"))
    logger.addHandler(_h)
logger.setLevel(logging.INFO)
logger.propagate = False

# セッション署名鍵（本番では必ず環境変数 CRM_SESSION_SECRET を設定）
SESSION_SECRET = os.environ.get(
    "CRM_SESSION_SECRET",
    "dev-only-change-me-set-CRM_SESSION_SECRET",
)

# ログイン成功後、?next= 未指定・フォーム next 空のときの遷移先
DEFAULT_AFTER_LOGIN_PATH = "/top/chat"
SHIFT_JWT_ALGORITHM = "HS256"


def _build_shift_sso_token(profile: dict, *, period_id: int | None = None) -> str:
    """
    シフト管理側SSO用 JWT を発行する。
    """
    now = datetime.now(timezone.utc)
    payload: dict = {
        "sub": profile.get("user_id") or "",
        "user_id": profile.get("user_id") or "",
        "user_name": profile.get("user_name") or "",
        "role": profile.get("role") or "staff",
        "team_id": profile.get("team_id"),
        "iss": app_config.SHIFT_JWT_ISSUER,
        "aud": app_config.SHIFT_JWT_AUDIENCE,
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(minutes=5)).timestamp()),
    }
    if period_id is not None:
        payload["period_id"] = period_id
    return jwt.encode(payload, app_config.SHIFT_JWT_SECRET, algorithm=SHIFT_JWT_ALGORITHM)


def _shift_sso_auto_post_html(*, post_url: str, token: str) -> str:
    """
    同一タブで POST /auth/sso するための自動送信HTML。
    """
    safe_url = escape(post_url, quote=True)
    safe_token = escape(token, quote=True)
    return (
        "<!doctype html><html lang='ja'><head><meta charset='utf-8'>"
        "<title>シフト管理へ移動中...</title></head><body>"
        "<form id='shift-sso-form' method='post' target='_self' action='"
        + safe_url
        + "'>"
        "<input type='hidden' name='token' value='"
        + safe_token
        + "'>"
        "</form>"
        "<script>(function(){"
        "var f=document.getElementById('shift-sso-form');if(f)f.submit();"
        "})();</script>"
        "<noscript><p>シフト管理を開くには下のボタンを押してください。</p>"
        "<button type='submit' form='shift-sso-form'>開く</button></noscript>"
        "</body></html>"
    )


@asynccontextmanager
async def _app_lifespan(_app: FastAPI):
    logger.info("CRM app settings: chat_only=%s", app_config.CHAT_ONLY)
    await chat_hub.startup()
    yield
    await chat_hub.shutdown()


app = FastAPI(title="FastAPI + htmx CRM", lifespan=_app_lifespan)

# 外側から: Session → 要ログイン → ルート（未ログインは /login へ）
app.add_middleware(auth_middleware.RequireLoginMiddleware)
# max_age=None: ブラウザを閉じるとセッション Cookie が消える（新しいブラウザ／プライベートは未ログイン）
app.add_middleware(
    SessionMiddleware,
    secret_key=SESSION_SECRET,
    max_age=None,
    same_site="lax",
    https_only=False,
)

BASE_DIR = Path(__file__).resolve().parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))
templates.env.filters["urlquote"] = lambda u: quote(str(u or ""), safe="")


@app.middleware("http")
async def _chat_only_redirect(request: Request, call_next):
    """
    chat_only モード時: TOP およびフラグメントはチャット以外へアクセスさせない（GET のみ）。
    API・静的ファイル・ログイン関連は対象外。
    """
    if not app_config.CHAT_ONLY:
        return await call_next(request)
    if request.method != "GET":
        return await call_next(request)
    path = request.url.path
    if (
        path.startswith("/api/")
        or path.startswith("/files/")
        or path.startswith("/ref3/")
        or path in (
            "/login",
            "/login/force-change",
            "/logout",
            "/logout/complete",
            "/favicon.ico",
            "/docs",
            "/openapi.json",
            "/redoc",
        )
        or path.startswith("/docs/")
    ):
        return await call_next(request)
    if path.startswith("/fragment/") and path.rstrip("/") != "/fragment/chat":
        return RedirectResponse(url="/fragment/chat", status_code=302)
    if path == "/top" or path == "/top/":
        return RedirectResponse(url="/top/chat", status_code=302)
    if path.startswith("/top/") and not path.startswith("/top/chat"):
        return RedirectResponse(url="/top/chat", status_code=302)
    return await call_next(request)


@app.middleware("http")
async def _no_store_personal_html(request: Request, call_next):
    """個人用 HTML を共有キャッシュ・ディスクキャッシュで誤って配信されないようにする。"""
    response = await call_next(request)
    ct = (response.headers.get("content-type") or "").lower()
    if "text/html" not in ct:
        return response
    p = request.url.path
    if not (
        p.startswith("/top")
        or p.startswith("/fragment/")
        or p.startswith("/login-user/")
        or p.startswith("/logout")
        or p in ("/login", "/login/force-change")
    ):
        return response
    response.headers["Cache-Control"] = "private, no-store, must-revalidate"
    response.headers["Pragma"] = "no-cache"
    existing = response.headers.get("vary")
    if existing:
        parts = [x.strip().lower() for x in existing.split(",")]
        if "cookie" not in parts:
            response.headers["vary"] = f"{existing}, Cookie"
    else:
        response.headers["vary"] = "Cookie"
    # 別ブラウザ検証用: Network タブで「この HTML がどのセッションか」を即確認（本番では無効のまま推奨）
    if os.environ.get("CRM_DEBUG_SESSION_HEADER", "").strip().lower() in (
        "1",
        "true",
        "yes",
        "on",
    ):
        try:
            raw_uid = (request.session.get("user_id") or "").strip()
        except Exception:
            raw_uid = ""
        if raw_uid:
            response.headers["X-CRM-Debug-Session-Userid"] = raw_uid
    return response


def safe_next_path(path: str) -> str | None:
    """
    ログイン後のリダイレクト先。同一アプリ内の相対パスのみ許可（オープンリダイレクト防止）。
    """
    if not path or not isinstance(path, str):
        return None
    path = path.strip()
    if not path.startswith("/") or path.startswith("//"):
        return None
    if path.startswith("/login"):
        return None
    if len(path) > 512 or "\n" in path or "\r" in path:
        return None
    return path


def _cell_to_str(v) -> str:
    if v is None:
        return ""
    if isinstance(v, (bytes, bytearray, memoryview)):
        b = bytes(v)
        return "1" if any(x != 0 for x in b) else "0"
    if isinstance(v, (date, datetime)):
        return v.strftime("%Y-%m-%d")
    s = str(v).strip()
    if len(s) >= 10 and s[:4].isdigit() and s[4:5] == "-" and s.startswith("0000"):
        return ""
    return s


def _cell_to_datetime_str(v) -> str:
    if v is None:
        return ""
    if isinstance(v, datetime):
        return v.strftime("%Y-%m-%d %H:%M:%S")
    if isinstance(v, date):
        return v.strftime("%Y-%m-%d")
    return _cell_to_str(v)


def _display_yyyy_mm_dd(s: str) -> str:
    """支払期限など VARCHAR 日付を一覧・画面表示用 YYYY-MM-DD に寄せる。"""
    s = (s or "").strip()
    if not s:
        return ""
    if (
        len(s) == 10
        and s[4:5] == "-"
        and s[7:8] == "-"
        and s[:4].isdigit()
        and s[5:7].isdigit()
        and s[8:10].isdigit()
    ):
        return s
    digits = "".join(c for c in s if c.isdigit())
    if len(digits) >= 8:
        d8 = digits[:8]
        if d8.isdigit():
            return f"{d8[:4]}-{d8[4:6]}-{d8[6:8]}"
    return s


_INVOICE_TREE_SORT_LABELS: dict[str, str] = {
    "invoice_no": "請求書番号",
    "customer_name": "取引先名",
    "subject": "件名",
    "memo": "メモ備忘",
    "issue_date": "発行日",
    "payment_deadline": "支払期限",
}


def _parse_invoice_tree_sort_params(
    sort0_col: str = "",
    sort0_dir: str = "",
    sort1_col: str = "",
    sort1_dir: str = "",
    sort2_col: str = "",
    sort2_dir: str = "",
) -> tuple[list[tuple[str, str]], str]:
    """請求一覧の並べ替えクエリを検証し、(sort_levels, 表示用文言) を返す。"""
    allowed = db.INVOICE_SEARCH_SORT_COLUMN_SQL
    raw = [
        (sort0_col, sort0_dir),
        (sort1_col, sort1_dir),
        (sort2_col, sort2_dir),
    ]
    levels: list[tuple[str, str]] = []
    for col, dir_ in raw:
        c = (col or "").strip()
        if not c or c not in allowed:
            continue
        d = (dir_ or "asc").strip().lower()
        if d not in ("asc", "desc"):
            d = "asc"
        levels.append((c, d))
    if not levels:
        summary = "発行日（降順）→ 請求書番号（昇順）"
        return [], summary
    parts: list[str] = []
    for c, d in levels:
        dir_label = "昇順" if d == "asc" else "降順"
        label = _INVOICE_TREE_SORT_LABELS.get(c, c)
        parts.append(f"{label}（{dir_label}）")
    summary = " → ".join(parts)
    return levels, summary


_LOGIN_USER_SORT_LABELS: dict[str, str] = {
    "userid": "ユーザーID",
    "user_name": "表示名",
    "admin_option": "管理者区分",
    "enabled": "有効",
    "last_login_datetime": "最終ログイン",
    "created_at": "作成日時",
    "updated_at": "更新日時",
}


def _parse_login_user_sort_params(
    sort0_col: str = "",
    sort0_dir: str = "",
    sort1_col: str = "",
    sort1_dir: str = "",
    sort2_col: str = "",
    sort2_dir: str = "",
) -> tuple[list[tuple[str, str]], str]:
    """ユーザ一覧の並べ替えクエリを検証し、(sort_levels, 表示用文言) を返す。"""
    allowed = db.LOGIN_USER_SEARCH_SORT_COLUMN_SQL
    raw = [
        (sort0_col, sort0_dir),
        (sort1_col, sort1_dir),
        (sort2_col, sort2_dir),
    ]
    levels: list[tuple[str, str]] = []
    for col, dir_ in raw:
        c = (col or "").strip()
        if not c or c not in allowed:
            continue
        d = (dir_ or "asc").strip().lower()
        if d not in ("asc", "desc"):
            d = "asc"
        levels.append((c, d))
    if not levels:
        summary = "ユーザーID（昇順）"
        return [], summary
    parts: list[str] = []
    for c, d in levels:
        dir_label = "昇順" if d == "asc" else "降順"
        label = _LOGIN_USER_SORT_LABELS.get(c, c)
        parts.append(f"{label}（{dir_label}）")
    summary = " → ".join(parts)
    return levels, summary


_TORIHIKI_SORT_LABELS: dict[str, str] = {
    "id": "ID",
    "code": "取引先コード",
    "name": "請求先",
    "zip": "郵便番号",
    "addr": "住所",
    "tel": "電話",
    "fax": "FAX",
    "tax": "消費税率",
    "taxr": "税端数処理",
    "jisha": "自社フラグ",
    "memo": "メモ備忘",
}


def _parse_torihiki_sort_params(
    sort0_col: str = "",
    sort0_dir: str = "",
    sort1_col: str = "",
    sort1_dir: str = "",
    sort2_col: str = "",
    sort2_dir: str = "",
) -> tuple[list[tuple[str, str]], str]:
    allowed = db.TORIHIKI_SEARCH_SORT_COLUMN_SQL
    raw = [
        (sort0_col, sort0_dir),
        (sort1_col, sort1_dir),
        (sort2_col, sort2_dir),
    ]
    levels: list[tuple[str, str]] = []
    for col, dir_ in raw:
        c = (col or "").strip()
        if not c or c not in allowed:
            continue
        d = (dir_ or "asc").strip().lower()
        if d not in ("asc", "desc"):
            d = "asc"
        levels.append((c, d))
    if not levels:
        return [], "請求先（昇順）→ ID（昇順）"
    parts: list[str] = []
    for c, d in levels:
        parts.append(f"{_TORIHIKI_SORT_LABELS.get(c, c)}（{'昇順' if d == 'asc' else '降順'}）")
    return levels, " → ".join(parts)


def _mount_first_existing(mount_path: str, name: str, candidates: list[Path]) -> None:
    """最初に存在するディレクトリを StaticFiles でマウントする。"""
    for d in candidates:
        if d.is_dir():
            app.mount(mount_path, StaticFiles(directory=str(d)), name=name)
            return


# TOP・一覧用: /files/（リポジトリ内 static/files を最優先）
_mount_first_existing(
    "/files",
    "files",
    [
        BASE_DIR / "static" / "files",
        BASE_DIR / "SamplesCRM" / "2" / "取引先一覧 - All Gather CRM V3_files",
    ],
)

# メンテ画面用: /ref3/（一覧と別セット。未マウントだとフォームだけ無スタイルになる）
_mount_first_existing(
    "/ref3",
    "ref3",
    [
        BASE_DIR / "static" / "ref3",
        BASE_DIR / "SamplesCRM" / "3" / "木田工務店 - 取引先 - All Gather CRM V3_files",
    ],
)


@app.get("/favicon.ico", include_in_schema=False)
async def favicon():
    """
    ブラウザが自動で GET する。ルートが無いと 404 になるため 204 で応答する。
    （ログイン画面などで favicon 404 が出るのはこれが原因）
    """
    return Response(status_code=204)


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    """Hello サンプルページ"""
    return templates.TemplateResponse(
        request=request, name="index.html", context={"request": request}
    )


@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    """ログイン画面（常に表示。ログイン済みでも URL で開ける）。"""
    nxt = request.query_params.get("next") or ""
    next_field = safe_next_path(nxt) or ""
    return templates.TemplateResponse(
        request=request,
        name="login.html",
        context={
            "request": request,
            "login_error": None,
            "userid_value": "",
            "next_field": next_field,
            "force_change": False,
            "force_change_reason": "",
        },
    )


@app.post("/login", response_class=HTMLResponse)
async def login_submit(request: Request):
    """ログイン処理。成功時は next があればそこへ、なければ DEFAULT_AFTER_LOGIN_PATH へ。"""
    form = await request.form()
    userid = (form.get("userid") or "").strip()
    pwd = form.get("pwd") or ""
    next_raw = (form.get("next") or "").strip()

    ok, err_msg, canon_userid = db.verify_login_user(userid, pwd)
    if ok:
        dest = safe_next_path(next_raw) or DEFAULT_AFTER_LOGIN_PATH
        # 初回ログインまたは最終ログインから一定期間経過なら強制パスワード変更へ
        reason = db.get_force_password_change_reason(canon_userid)
        if reason:
            request.session["force_change_userid"] = canon_userid
            request.session["force_change_next"] = dest
            request.session["force_change_reason"] = reason
            return templates.TemplateResponse(
                request=request,
                name="login.html",
                context={
                    "request": request,
                    "login_error": None,
                    "userid_value": canon_userid,
                    "next_field": dest,
                    "force_change": True,
                    "force_change_reason": reason,
                },
            )

        request.session["user_id"] = canon_userid
        db.update_last_login_datetime(canon_userid)
        return RedirectResponse(url=dest, status_code=303)

    next_field = safe_next_path(next_raw) or ""
    return templates.TemplateResponse(
        request=request,
        name="login.html",
        context={
            "request": request,
            "login_error": err_msg,
            "userid_value": userid,
            "next_field": next_field,
            "force_change": False,
            "force_change_reason": "",
        },
    )


@app.post("/login/force-change", response_class=HTMLResponse)
async def login_force_change_submit(request: Request):
    """初回ログイン強制パスワード変更（LastLoginDateTime がブランクのユーザ向け）。"""
    force_userid = (request.session.get("force_change_userid") or "").strip()
    force_next = (request.session.get("force_change_next") or "").strip()
    force_reason = (request.session.get("force_change_reason") or "").strip()

    form = await request.form()
    new_pwd = form.get("new_pwd") or ""
    new_pwd_confirm = form.get("new_pwd_confirm") or ""

    if not force_userid:
        # 期限切れ/不正アクセス
        return RedirectResponse(url="/login", status_code=303)

    errs: list[str] = []
    if not new_pwd.strip():
        errs.append("新しいパスワードを入力してください。")
    if new_pwd != new_pwd_confirm:
        errs.append("パスワード（確認用）が一致しません。")
    if not errs and db.is_same_login_user_password(force_userid, new_pwd):
        errs.append("新しいパスワードが初期パスワードと同じです。別の値にしてください。")

    if errs:
        return templates.TemplateResponse(
            request=request,
            name="login.html",
            context={
                "request": request,
                "login_error": "\n".join(errs),
                "userid_value": force_userid,
                "next_field": force_next,
                "force_change": True,
                "force_change_reason": force_reason or "expired",
            },
            status_code=400,
        )

    try:
        db.set_login_user_password_and_last_login_datetime(force_userid, new_pwd)
    except Exception as exc:
        return templates.TemplateResponse(
            request=request,
            name="login.html",
            context={
                "request": request,
                "login_error": f"パスワード設定に失敗しました: {exc}",
                "userid_value": force_userid,
                "next_field": force_next,
                "force_change": True,
                "force_change_reason": force_reason or "expired",
            },
            status_code=500,
        )
    request.session["user_id"] = db.get_canonical_login_userid(force_userid) or force_userid
    try:
        if "force_change_userid" in request.session:
            del request.session["force_change_userid"]
        if "force_change_next" in request.session:
            del request.session["force_change_next"]
        if "force_change_reason" in request.session:
            del request.session["force_change_reason"]
    except Exception:
        pass

    dest = safe_next_path(force_next) or DEFAULT_AFTER_LOGIN_PATH
    return RedirectResponse(url=dest, status_code=303)


@app.get("/logout")
async def logout(request: Request):
    """セッションを破棄し、ログアウト完了画面へリダイレクト。"""
    try:
        request.session.clear()
    except Exception:
        for _k in list(request.session.keys()):
            del request.session[_k]
    return RedirectResponse(url="/logout/complete", status_code=303)


@app.get("/logout/complete", response_class=HTMLResponse)
async def logout_complete(request: Request):
    """ログアウト完了（セッションは既に空）。洗練された完了画面からログインへ誘導。"""
    return templates.TemplateResponse(
        request=request,
        name="logout_complete.html",
        context={"request": request},
    )


@app.get("/shift-app-link", response_class=HTMLResponse)
async def shift_app_link(request: Request, period_id: int | None = Query(default=None)):
    """
    シフト管理システムへ SSO 連携するための中継。
    JWT を生成し、POST (target=_self) で shift 側 /auth/sso へ送る。
    """
    if not app_config.SHIFT_JWT_SECRET:
        raise HTTPException(
            status_code=500,
            detail="SHIFT_JWT_SECRET が未設定です（CRM_SHIFT_JWT_SECRET などを設定してください）。",
        )
    uid = (request.session.get("user_id") or "").strip()
    if not uid:
        raise HTTPException(status_code=401, detail="ログインが必要です。")
    profile = db.get_shift_sso_profile(uid)
    if not profile:
        raise HTTPException(
            status_code=403,
            detail="シフト連携用のユーザ情報が取得できませんでした。",
        )
    token = _build_shift_sso_token(profile, period_id=period_id)
    html = _shift_sso_auto_post_html(
        post_url=app_config.SHIFT_SSO_POST_URL,
        token=token,
    )
    return HTMLResponse(content=html)


def _browser_title_for_top_subpath(subpath: str | None) -> str:
    """TOP シェルのブラウザタブ用タイトル（/top の直下セグメントで判定）。"""
    if not subpath or not str(subpath).strip():
        return "顧客一覧"
    first = str(subpath).strip().strip("/").split("/")[0].lower()
    if first == "invoice-data-tree-test":
        return "請求一覧"
    if first == "invoice-data":
        return "請求一覧（古い）"
    if first == "login-users":
        return "ユーザ一覧"
    if first == "permission-org-settings":
        return "組織・権限設定"
    if first == "mcp-test1":
        return "MCPテスト１"
    if first == "mcp-test2":
        return "MCPテスト２"
    if first == "mcp-test3":
        return "MCPテスト３"
    if first == "mcp-test4":
        return "MCPテスト４"
    if first == "excel-test":
        return "エクセルテスト"
    if first == "facility-reserve":
        return "シフト管理"
    if first == "shift-scheduler":
        return "シフト管理"
    if first == "image-test":
        return "画像認識テスト"
    if first == "chat":
        return "Chat"
    if first == "hello":
        return "Hello サンプル"
    if first == "torihiki-htmx-mock":
        return "取引先 / 口座"
    if first == "torihiki-htmx-mock_detail":
        return "取引先 / 口座 詳細"
    return "顧客一覧"


def _initial_fragment_for_top_subpath(subpath: str | None) -> str:
    """TOPシェル初期表示フラグメントを /top/{subpath} から決定する。"""
    if not subpath or not str(subpath).strip():
        return "fragments/torihikisaki_list.html"
    first = str(subpath).strip().strip("/").split("/")[0].lower()
    if first == "invoice-data-tree-test":
        return "fragments/invoice_data_tree_test_list.html"
    if first == "invoice-data":
        return "fragments/invoice_data_list.html"
    if first == "login-users":
        return "fragments/login_user_list.html"
    if first == "permission-org-settings":
        return "fragments/permission_org_settings.html"
    if first == "mcp-test1":
        return "fragments/mcp_test1.html"
    if first == "mcp-test2":
        return "fragments/mcp_test2.html"
    if first == "mcp-test3":
        return "fragments/mcp_test3.html"
    if first == "mcp-test4":
        return "fragments/mcp_test4.html"
    if first == "excel-test":
        return "fragments/excel_test.html"
    if first == "facility-reserve":
        return "fragments/facility_reserve.html"
    if first == "shift-scheduler":
        return "content/shift_scheduler/shift_scheduler_ui.html"
    if first == "image-test":
        return "fragments/image_test_reserve.html"
    if first == "chat":
        return "fragments/chat.html"
    if first == "hello":
        return "fragments/hello.html"
    if first == "torihiki-htmx-mock":
        return "fragments/torihiki_htmx_mock.html"
    if first == "torihiki-htmx-mock_detail":
        return "fragments/torihiki_htmx_mock_detail.html"
    return "fragments/torihikisaki_list.html"


def _department_bootstrap_json() -> str:
    """権限・組織設定フラグメント内の JSON（script タグ用）。"""
    # readOnly=False: オリジナルモック同様の各レベル「追加」UI（部署の永続化は別途）
    bootstrap: dict = {
        "source": "db",
        "readOnly": False,
        "depts": [],
        "nextId": 1,
        "roles": [],
        "department_roles": [],
    }
    try:
        rows = db.list_m_department_org_settings_rows()
        bootstrap["depts"] = rows
        if rows:
            bootstrap["nextId"] = max(r["id"] for r in rows) + 1
    except Exception:
        logger.exception("M_Department bootstrap load failed")
        bootstrap["dbError"] = True
    try:
        bootstrap["roles"] = db.list_m_roles_for_org_settings()
    except Exception:
        logger.exception("M_Role bootstrap load failed")
    try:
        bootstrap["department_roles"] = db.list_active_t_department_role_pairs()
    except Exception:
        logger.exception("T_DepartmentRole bootstrap load failed")
    return json.dumps(bootstrap, ensure_ascii=False).replace("</", "<\\/")


def _top_context(request: Request, *, subpath: str | None = None) -> dict:
    """TOP シェル用テンプレートコンテキスト（ログインユーザー表示名を含む）。"""
    uid = (request.session.get("user_id") or "").strip()
    me_uid = (db.get_canonical_login_userid(uid) or uid) if uid else ""
    disp_name = db.get_login_user_display_name(me_uid) if me_uid else ""
    if app_config.CHAT_ONLY:
        return {
            "request": request,
            "login_user_name": disp_name,
            "browser_title": "Chat",
            "initial_fragment": "fragments/chat.html",
            "login_user_list_flash": None,
            "chat_me_userid": me_uid,
            "chat_me_name": disp_name,
            "chat_only": True,
        }
    first = (
        str(subpath or "").strip().strip("/").split("/")[0].lower() if subpath else ""
    )
    ctx = {
        "request": request,
        "login_user_name": disp_name,
        "browser_title": _browser_title_for_top_subpath(subpath),
        "initial_fragment": _initial_fragment_for_top_subpath(subpath),
        "login_user_list_flash": None,
        "chat_me_userid": me_uid,
        "chat_me_name": disp_name,
        "chat_only": False,
        "shift_management_url": app_config.SHIFT_MANAGEMENT_URL,
        "schedule_url": app_config.SCHEDULE_URL,
    }
    if first == "login-users":
        flash = request.session.pop("login_user_list_flash", None)
        if isinstance(flash, dict) and (flash.get("text") or "").strip():
            ctx["login_user_list_flash"] = flash
    if first == "permission-org-settings":
        ctx["department_bootstrap_json"] = _department_bootstrap_json()
    if first in ("torihiki-htmx-mock", "torihiki-htmx-mock_detail"):
        filters = {
            "code": str(request.query_params.get("f_code") or "").strip(),
            "name": str(request.query_params.get("f_name") or "").strip(),
            "zip": str(request.query_params.get("f_zip") or "").strip(),
            "addr": str(request.query_params.get("f_addr") or "").strip(),
            "tel": str(request.query_params.get("f_tel") or "").strip(),
            "fax": str(request.query_params.get("f_fax") or "").strip(),
            "tax": str(request.query_params.get("f_tax") or "").strip(),
            "taxr": str(request.query_params.get("f_taxr") or "").strip(),
            "jisha": str(request.query_params.get("f_jisha") or "").strip(),
            "memo": str(request.query_params.get("f_memo") or "").strip(),
        }
        has_filter_condition = any(v for v in filters.values())
        sort0_col = str(request.query_params.get("sort0_col") or "").strip()
        sort0_dir = str(request.query_params.get("sort0_dir") or "").strip()
        sort1_col = str(request.query_params.get("sort1_col") or "").strip()
        sort1_dir = str(request.query_params.get("sort1_dir") or "").strip()
        sort2_col = str(request.query_params.get("sort2_col") or "").strip()
        sort2_dir = str(request.query_params.get("sort2_dir") or "").strip()
        panel_open_raw = str(request.query_params.get("panel_open") or "").strip().lower()
        torihiki_panel_open = panel_open_raw in ("1", "true", "yes", "on")
        sort_levels, sort_summary = _parse_torihiki_sort_params(
            sort0_col, sort0_dir, sort1_col, sort1_dir, sort2_col, sort2_dir
        )
        sid = str(request.query_params.get("selected_id") or "").strip()
        searched = str(request.query_params.get("searched") or "")
        new_raw = str(request.query_params.get("new") or "")
        is_detail = first == "torihiki-htmx-mock_detail"
        is_new = new_raw.strip().lower() in ("1", "true", "yes", "on")
        if new_raw.strip().lower() in ("1", "true", "yes", "on") and sid:
            sid = ""
        has_searched = searched.strip().lower() in ("1", "true", "yes", "on")
        if has_filter_condition:
            has_searched = True
        if sid:
            has_searched = True
        # /top/..._detail は直接リロード時に selected_id が無くてもフォーム描画へ進むため検索を有効化
        if is_detail:
            has_searched = True
        rows: list[dict[str, object]] = []
        result_count = 0
        over_limit = False
        if has_searched:
            rows, result_count, over_limit = db.search_m_torihikisaki_master_with_koza_count(
                q_raw="",
                filters=filters,
                sort_levels=sort_levels if sort_levels else None,
                limit=db.DISPLAY_LIMIT,
            )
        selected_row = None
        if sid:
            selected_row = next((r for r in rows if str(r.get("id") or "") == sid), None)
            if selected_row is None:
                selected_row = db.get_m_torihikisaki_master_with_koza_count_by_id(sid)
        koza_rows: list[dict[str, str]] = (
            db.list_m_koza_master_by_torihiki_id(str(selected_row.get("id") or sid))
            if (sid and selected_row)
            else []
        )
        if is_detail and sid and not selected_row:
            # URLにIDがあっても実データが無い場合は更新モードにしない
            sid = ""
            is_new = True
        torihiki_new_allocated_id = ""
        if is_detail and is_new and not selected_row:
            torihiki_new_allocated_id = str(db.allocate_m_torihikisaki_master_id())
        query_items = []
        for key in ("code", "name", "zip", "addr", "tel", "fax", "tax", "taxr", "jisha", "memo"):
            val = str(filters.get(key) or "").strip()
            if not val:
                continue
            query_items.append((f"f_{key}", val))
        if sort0_col:
            query_items.append(("sort0_col", sort0_col))
        if sort0_dir:
            query_items.append(("sort0_dir", sort0_dir))
        if sort1_col:
            query_items.append(("sort1_col", sort1_col))
        if sort1_dir:
            query_items.append(("sort1_dir", sort1_dir))
        if sort2_col:
            query_items.append(("sort2_col", sort2_col))
        if sort2_dir:
            query_items.append(("sort2_dir", sort2_dir))
        if torihiki_panel_open:
            query_items.append(("panel_open", "1"))
        torihiki_query_string = urlencode(query_items)
        ctx.update(
            {
                "torihiki_rows": rows,
                "torihiki_result_count": result_count,
                "torihiki_over_limit": over_limit,
                "torihiki_query": "",
                "torihiki_filters": filters,
                "torihiki_query_string": torihiki_query_string,
                "torihiki_sort_levels": sort_levels,
                "torihiki_sort_summary": sort_summary,
                "torihiki_panel_open": torihiki_panel_open,
                "torihiki_has_searched": has_searched,
                "torihiki_selected_id": sid,
                "torihiki_selected_row": selected_row,
                "torihiki_koza_rows": koza_rows,
                "torihiki_view": "detail" if is_detail else "list",
                "torihiki_is_new": is_new,
                "torihiki_new_allocated_id": torihiki_new_allocated_id,
            }
        )
    logger.info(
        "[diag] top_context subpath=%r path=%r session_user_id=%r me_uid=%r "
        "login_user_name=%r",
        subpath,
        request.url.path,
        uid,
        me_uid,
        ctx.get("login_user_name") or "",
    )
    return ctx


@app.get("/top", response_class=HTMLResponse)
async def top(request: Request):
    """TOPメニュー（取引先一覧レイアウト）"""
    return templates.TemplateResponse(
        request=request, name="top.html", context=_top_context(request, subpath=None)
    )


@app.get("/top/torihiki-htmx-mock_detail", response_class=HTMLResponse)
async def top_torihiki_htmx_mock_detail(request: Request):
    """
    取引先/口座 詳細画面の直アクセス。
    selected_id も new も無い場合は一覧へ戻す。
    """
    sid = str(request.query_params.get("selected_id") or "").strip()
    new_raw = str(request.query_params.get("new") or "").strip().lower()
    is_new = new_raw in ("1", "true", "yes", "on")
    if not sid and not is_new:
        filters = {
            "f_code": str(request.query_params.get("f_code") or "").strip(),
            "f_name": str(request.query_params.get("f_name") or "").strip(),
            "f_zip": str(request.query_params.get("f_zip") or "").strip(),
            "f_addr": str(request.query_params.get("f_addr") or "").strip(),
            "f_tel": str(request.query_params.get("f_tel") or "").strip(),
            "f_fax": str(request.query_params.get("f_fax") or "").strip(),
            "f_tax": str(request.query_params.get("f_tax") or "").strip(),
            "f_taxr": str(request.query_params.get("f_taxr") or "").strip(),
            "f_jisha": str(request.query_params.get("f_jisha") or "").strip(),
            "f_memo": str(request.query_params.get("f_memo") or "").strip(),
            "sort0_col": str(request.query_params.get("sort0_col") or "").strip(),
            "sort0_dir": str(request.query_params.get("sort0_dir") or "").strip(),
            "sort1_col": str(request.query_params.get("sort1_col") or "").strip(),
            "sort1_dir": str(request.query_params.get("sort1_dir") or "").strip(),
            "sort2_col": str(request.query_params.get("sort2_col") or "").strip(),
            "sort2_dir": str(request.query_params.get("sort2_dir") or "").strip(),
            "panel_open": str(request.query_params.get("panel_open") or "").strip(),
        }
        dest = "/top/torihiki-htmx-mock"
        query_items = [(k, v) for k, v in filters.items() if v]
        if query_items:
            query_items.insert(0, ("searched", "1"))
            dest += f"?{urlencode(query_items)}"
        return RedirectResponse(url=dest, status_code=303)
    return templates.TemplateResponse(
        request=request,
        name="top.html",
        context=_top_context(request, subpath="torihiki-htmx-mock_detail"),
    )


@app.get("/top/{subpath:path}", response_class=HTMLResponse)
async def top_with_path(request: Request, subpath: str):
    """
    TOP シェル（/top/torihikisaki 等の直リンク・ブックマーク用）。
    htmx の hx-push-url と同じ URL をサーバーでも返す。
    """
    first = str(subpath or "").strip().strip("/").split("/")[0].lower()
    if first == "torihiki-htmx-mock_detail":
        sid = str(request.query_params.get("selected_id") or "").strip()
        new_raw = str(request.query_params.get("new") or "").strip().lower()
        is_new = new_raw in ("1", "true", "yes", "on")
        if not sid and not is_new:
            filters = {
                "f_code": str(request.query_params.get("f_code") or "").strip(),
                "f_name": str(request.query_params.get("f_name") or "").strip(),
                "f_zip": str(request.query_params.get("f_zip") or "").strip(),
                "f_addr": str(request.query_params.get("f_addr") or "").strip(),
                "f_tel": str(request.query_params.get("f_tel") or "").strip(),
                "f_fax": str(request.query_params.get("f_fax") or "").strip(),
                "f_tax": str(request.query_params.get("f_tax") or "").strip(),
                "f_taxr": str(request.query_params.get("f_taxr") or "").strip(),
                "f_jisha": str(request.query_params.get("f_jisha") or "").strip(),
                "f_memo": str(request.query_params.get("f_memo") or "").strip(),
                "sort0_col": str(request.query_params.get("sort0_col") or "").strip(),
                "sort0_dir": str(request.query_params.get("sort0_dir") or "").strip(),
                "sort1_col": str(request.query_params.get("sort1_col") or "").strip(),
                "sort1_dir": str(request.query_params.get("sort1_dir") or "").strip(),
                "sort2_col": str(request.query_params.get("sort2_col") or "").strip(),
                "sort2_dir": str(request.query_params.get("sort2_dir") or "").strip(),
                "panel_open": str(request.query_params.get("panel_open") or "").strip(),
            }
            dest = "/top/torihiki-htmx-mock"
            query_items = [(k, v) for k, v in filters.items() if v]
            if query_items:
                query_items.insert(0, ("searched", "1"))
                dest += f"?{urlencode(query_items)}"
            return RedirectResponse(url=dest, status_code=303)
    return templates.TemplateResponse(
        request=request, name="top.html", context=_top_context(request, subpath=subpath)
    )


@app.get("/fragment/dashboard", response_class=HTMLResponse)
async def fragment_dashboard(request: Request):
    """htmx: ダッシュボードフラグメント"""
    return templates.TemplateResponse(
        request=request,
        name="fragments/dashboard.html",
        context={"request": request},
    )


@app.get("/fragment/torihikisaki", response_class=HTMLResponse)
async def fragment_torihikisaki(request: Request):
    """htmx: 取引先一覧フラグメント"""
    return templates.TemplateResponse(
        request=request,
        name="fragments/torihikisaki_list.html",
        context={"request": request},
    )


@app.get("/fragment/torihiki-htmx-mock", response_class=HTMLResponse)
async def fragment_torihiki_htmx_mock(
    request: Request, selected_id: str = "", searched: str = ""
):
    """htmx: 取引先 / 口座 同時メンテモック（一覧）。"""
    selected_row = None
    sid = (selected_id or "").strip()
    filters = {
        "code": str(request.query_params.get("f_code") or "").strip(),
        "name": str(request.query_params.get("f_name") or "").strip(),
        "zip": str(request.query_params.get("f_zip") or "").strip(),
        "addr": str(request.query_params.get("f_addr") or "").strip(),
        "tel": str(request.query_params.get("f_tel") or "").strip(),
        "fax": str(request.query_params.get("f_fax") or "").strip(),
        "tax": str(request.query_params.get("f_tax") or "").strip(),
        "taxr": str(request.query_params.get("f_taxr") or "").strip(),
        "jisha": str(request.query_params.get("f_jisha") or "").strip(),
        "memo": str(request.query_params.get("f_memo") or "").strip(),
    }
    sort0_col = str(request.query_params.get("sort0_col") or "").strip()
    sort0_dir = str(request.query_params.get("sort0_dir") or "").strip()
    sort1_col = str(request.query_params.get("sort1_col") or "").strip()
    sort1_dir = str(request.query_params.get("sort1_dir") or "").strip()
    sort2_col = str(request.query_params.get("sort2_col") or "").strip()
    sort2_dir = str(request.query_params.get("sort2_dir") or "").strip()
    panel_open_raw = str(request.query_params.get("panel_open") or "").strip().lower()
    torihiki_panel_open = panel_open_raw in ("1", "true", "yes", "on")
    sort_levels, sort_summary = _parse_torihiki_sort_params(
        sort0_col, sort0_dir, sort1_col, sort1_dir, sort2_col, sort2_dir
    )
    has_filter_condition = any(v for v in filters.values())
    has_searched = str(searched or "").strip().lower() in ("1", "true", "yes", "on")
    if has_filter_condition:
        has_searched = True
    if sid:
        has_searched = True
    rows: list[dict[str, object]] = []
    result_count = 0
    over_limit = False
    if has_searched:
        rows, result_count, over_limit = db.search_m_torihikisaki_master_with_koza_count(
            q_raw="",
            filters=filters,
            sort_levels=sort_levels if sort_levels else None,
            limit=db.DISPLAY_LIMIT,
        )
    if sid:
        selected_row = next((r for r in rows if str(r.get("id") or "") == sid), None)
    koza_rows: list[dict[str, str]] = (
        db.list_m_koza_master_by_torihiki_id(sid) if sid else []
    )
    query_items = []
    for key in ("code", "name", "zip", "addr", "tel", "fax", "tax", "taxr", "jisha", "memo"):
        val = str(filters.get(key) or "").strip()
        if not val:
            continue
        query_items.append((f"f_{key}", val))
    if sort0_col:
        query_items.append(("sort0_col", sort0_col))
    if sort0_dir:
        query_items.append(("sort0_dir", sort0_dir))
    if sort1_col:
        query_items.append(("sort1_col", sort1_col))
    if sort1_dir:
        query_items.append(("sort1_dir", sort1_dir))
    if sort2_col:
        query_items.append(("sort2_col", sort2_col))
    if sort2_dir:
        query_items.append(("sort2_dir", sort2_dir))
    if torihiki_panel_open:
        query_items.append(("panel_open", "1"))
    torihiki_query_string = urlencode(query_items)
    return templates.TemplateResponse(
        request=request,
        name="fragments/torihiki_htmx_mock.html",
        context={
            "request": request,
            "torihiki_rows": rows,
            "torihiki_result_count": result_count,
            "torihiki_over_limit": over_limit,
            "torihiki_query": "",
            "torihiki_filters": filters,
            "torihiki_query_string": torihiki_query_string,
            "torihiki_sort_levels": sort_levels,
            "torihiki_sort_summary": sort_summary,
            "torihiki_panel_open": torihiki_panel_open,
            "torihiki_has_searched": has_searched,
            "torihiki_selected_id": sid,
            "torihiki_selected_row": selected_row,
            "torihiki_koza_rows": koza_rows,
            "torihiki_view": "list",
            "torihiki_is_new": False,
            "torihiki_new_allocated_id": "",
        },
    )


@app.get("/fragment/torihiki-htmx-mock/detail", response_class=HTMLResponse)
async def fragment_torihiki_htmx_mock_detail(
    request: Request, selected_id: str = "", new: str = ""
):
    """htmx: 取引先 / 口座 同時メンテモック（詳細フォーム）。"""
    sid = (selected_id or "").strip()
    filters = {
        "code": str(request.query_params.get("f_code") or "").strip(),
        "name": str(request.query_params.get("f_name") or "").strip(),
        "zip": str(request.query_params.get("f_zip") or "").strip(),
        "addr": str(request.query_params.get("f_addr") or "").strip(),
        "tel": str(request.query_params.get("f_tel") or "").strip(),
        "fax": str(request.query_params.get("f_fax") or "").strip(),
        "tax": str(request.query_params.get("f_tax") or "").strip(),
        "taxr": str(request.query_params.get("f_taxr") or "").strip(),
        "jisha": str(request.query_params.get("f_jisha") or "").strip(),
        "memo": str(request.query_params.get("f_memo") or "").strip(),
    }
    sort0_col = str(request.query_params.get("sort0_col") or "").strip()
    sort0_dir = str(request.query_params.get("sort0_dir") or "").strip()
    sort1_col = str(request.query_params.get("sort1_col") or "").strip()
    sort1_dir = str(request.query_params.get("sort1_dir") or "").strip()
    sort2_col = str(request.query_params.get("sort2_col") or "").strip()
    sort2_dir = str(request.query_params.get("sort2_dir") or "").strip()
    panel_open_raw = str(request.query_params.get("panel_open") or "").strip().lower()
    torihiki_panel_open = panel_open_raw in ("1", "true", "yes", "on")
    sort_levels, sort_summary = _parse_torihiki_sort_params(
        sort0_col, sort0_dir, sort1_col, sort1_dir, sort2_col, sort2_dir
    )
    is_new = str(new or "").strip().lower() in ("1", "true", "yes", "on")
    # selected_id が無い詳細表示は更新対象を特定できないため、新規モードとして扱う
    if not sid and not is_new:
        is_new = True
    # 新規追加（new=1）のとき selected_id があると既存行が載り誤上書きするため無視
    if str(new or "").strip().lower() in ("1", "true", "yes", "on") and sid:
        sid = ""
    rows, result_count, over_limit = db.search_m_torihikisaki_master_with_koza_count(
        q_raw="",
        filters=filters,
        sort_levels=sort_levels if sort_levels else None,
        limit=db.DISPLAY_LIMIT,
    )
    selected_row = None
    if sid:
        selected_row = next((r for r in rows if str(r.get("id") or "") == sid), None)
        if selected_row is None:
            selected_row = db.get_m_torihikisaki_master_with_koza_count_by_id(sid)
    koza_rows: list[dict[str, str]] = (
        db.list_m_koza_master_by_torihiki_id(str(selected_row.get("id") or sid))
        if (sid and selected_row)
        else []
    )
    if sid and not selected_row:
        sid = ""
        is_new = True
    torihiki_new_allocated_id = ""
    if is_new and not selected_row:
        torihiki_new_allocated_id = str(db.allocate_m_torihikisaki_master_id())
    query_items = []
    for key in ("code", "name", "zip", "addr", "tel", "fax", "tax", "taxr", "jisha", "memo"):
        val = str(filters.get(key) or "").strip()
        if not val:
            continue
        query_items.append((f"f_{key}", val))
    if sort0_col:
        query_items.append(("sort0_col", sort0_col))
    if sort0_dir:
        query_items.append(("sort0_dir", sort0_dir))
    if sort1_col:
        query_items.append(("sort1_col", sort1_col))
    if sort1_dir:
        query_items.append(("sort1_dir", sort1_dir))
    if sort2_col:
        query_items.append(("sort2_col", sort2_col))
    if sort2_dir:
        query_items.append(("sort2_dir", sort2_dir))
    if torihiki_panel_open:
        query_items.append(("panel_open", "1"))
    torihiki_query_string = urlencode(query_items)
    return templates.TemplateResponse(
        request=request,
        name="fragments/torihiki_htmx_mock_detail.html",
        context={
            "request": request,
            "torihiki_rows": rows,
            "torihiki_result_count": result_count,
            "torihiki_over_limit": over_limit,
            "torihiki_query": "",
            "torihiki_filters": filters,
            "torihiki_query_string": torihiki_query_string,
            "torihiki_sort_levels": sort_levels,
            "torihiki_sort_summary": sort_summary,
            "torihiki_panel_open": torihiki_panel_open,
            "torihiki_has_searched": True,
            "torihiki_selected_id": sid,
            "torihiki_selected_row": selected_row,
            "torihiki_koza_rows": koza_rows,
            "torihiki_view": "detail",
            "torihiki_is_new": is_new,
            "torihiki_new_allocated_id": torihiki_new_allocated_id,
        },
    )


@app.get("/fragment/torihiki-htmx-mock_detail", response_class=HTMLResponse)
async def fragment_torihiki_htmx_mock_detail_alias(
    request: Request, selected_id: str = "", new: str = ""
):
    """htmx: 取引先 / 口座 同時メンテモック（詳細フォーム、_detail ルート）。"""
    return await fragment_torihiki_htmx_mock_detail(
        request=request, selected_id=selected_id, new=new
    )


@app.post("/api/torihiki-htmx-mock/save", response_class=JSONResponse)
async def api_torihiki_htmx_mock_save(request: Request):
    """
    取引先/口座 同時メンテ（モック画面）の保存 API。
    """
    try:
        body = await request.json()
    except Exception:
        return JSONResponse(
            content={"ok": False, "message": "リクエスト形式が不正です。"},
            status_code=400,
        )

    raw_id = str((body or {}).get("id") or "").strip()
    save_mode = str((body or {}).get("save_mode") or "").strip().lower()
    master_id: int | None = None
    if raw_id:
        try:
            master_id = int(raw_id)
        except ValueError:
            return JSONResponse(
                content={"ok": False, "message": "IDが不正です。"},
                status_code=400,
            )
    if save_mode in ("create", "new", "insert"):
        # 有効な ID が付いていれば新規扱いに落とさず更新（誤二重登録防止）
        if master_id is None or master_id <= 0:
            master_id = None
    elif save_mode in ("update", "edit"):
        # 変更モードは ID 必須（誤って新規にならないようにする）
        if master_id is None:
            return JSONResponse(
                content={"ok": False, "message": "更新モードでは対象IDが必須です。"},
                status_code=400,
            )

    torihiki = (body or {}).get("torihiki") or {}
    koza_rows = (body or {}).get("banks") or []
    if not isinstance(torihiki, dict):
        torihiki = {}
    if not isinstance(koza_rows, list):
        koza_rows = []

    ok, msg, saved_id = db.save_torihikisaki_master_with_koza(
        master_id, torihiki, koza_rows
    )
    if not ok:
        return JSONResponse(content={"ok": False, "message": msg}, status_code=400)
    return JSONResponse(
        content={"ok": True, "message": msg, "id": str(saved_id or "")}, status_code=200
    )


@app.post("/api/torihiki-htmx-mock/delete", response_class=JSONResponse)
async def api_torihiki_htmx_mock_delete(request: Request):
    """
    取引先/口座 同時メンテ（モック画面）の削除 API。
    リクエスト body の id は、詳細の id-badge（取引先マスタ行の主キー）と同じ数値で、
    紐づく M_口座マスタ も M_口座マスタ.ID で削除される。
    """
    try:
        body = await request.json()
    except Exception:
        return JSONResponse(
            content={"ok": False, "message": "リクエスト形式が不正です。"},
            status_code=400,
        )

    raw_id = str((body or {}).get("id") or "").strip()
    if not raw_id:
        return JSONResponse(
            content={"ok": False, "message": "削除対象IDがありません。"},
            status_code=400,
        )
    try:
        master_id = int(raw_id)
    except ValueError:
        return JSONResponse(
            content={"ok": False, "message": "IDが不正です。"},
            status_code=400,
        )

    ok, msg = db.delete_torihikisaki_master_with_koza(master_id)
    if not ok:
        return JSONResponse(content={"ok": False, "message": msg}, status_code=400)
    return JSONResponse(content={"ok": True, "message": msg}, status_code=200)


@app.get("/fragment/invoice-data", response_class=HTMLResponse)
async def fragment_invoice_data(request: Request):
    """htmx: 請求データ一覧フラグメント（顧客一覧のSaveAs版）"""
    return templates.TemplateResponse(
        request=request,
        name="fragments/invoice_data_list.html",
        context={"request": request},
    )


@app.get("/fragment/invoice-data-tree-test", response_class=HTMLResponse)
async def fragment_invoice_data_tree_test(request: Request):
    """htmx: 請求一覧（旧フラット版のコピー・同一検索ロジック）。"""
    return templates.TemplateResponse(
        request=request,
        name="fragments/invoice_data_tree_test_list.html",
        context={"request": request},
    )


@app.get("/fragment/login-users", response_class=HTMLResponse)
async def fragment_login_users(request: Request):
    """htmx: ユーザ一覧フラグメント"""
    flash = request.session.pop("login_user_list_flash", None)
    ctx: dict = {"request": request, "login_user_list_flash": None}
    if isinstance(flash, dict) and (flash.get("text") or "").strip():
        ctx["login_user_list_flash"] = flash
    return templates.TemplateResponse(
        request=request,
        name="fragments/login_user_list.html",
        context=ctx,
    )


@app.get("/fragment/permission-org-settings", response_class=HTMLResponse)
def fragment_permission_org_settings(request: Request):
    """htmx: 権限・組織設定フラグメント（M_Department 一覧・モックのユーザ所属など）"""
    return templates.TemplateResponse(
        request=request,
        name="fragments/permission_org_settings.html",
        context={
            "request": request,
            "department_bootstrap_json": _department_bootstrap_json(),
        },
    )


@app.get("/fragment/login-users/search", response_class=HTMLResponse)
def fragment_login_users_search(
    request: Request,
    userid: str = "",
    user_name: str = "",
    sort0_col: str = "",
    sort0_dir: str = "",
    sort1_col: str = "",
    sort1_dir: str = "",
    sort2_col: str = "",
    sort2_dir: str = "",
    _reset: bool = False,
):
    """htmx: ユーザ一覧検索結果フラグメント（同期: DBアクセスのため def）"""
    if _reset:
        return templates.TemplateResponse(
            request=request,
            name="fragments/login_user_results.html",
            context={"request": request, "mode": "initial"},
        )

    sort_levels, sort_summary = _parse_login_user_sort_params(
        sort0_col,
        sort0_dir,
        sort1_col,
        sort1_dir,
        sort2_col,
        sort2_dir,
    )

    results, result_count, over_limit = db.search_login_users(
        userid=userid,
        user_name=user_name,
        sort_levels=sort_levels if sort_levels else None,
    )
    for row in results:
        row["admin_option_label"] = "管理者" if int(row.get("admin_option") or 0) == 1 else "一般"
        row["Enabled_label"] = "有効" if int(row.get("Enabled") or 0) == 1 else "無効"
        row["LastLoginDateTime"] = _cell_to_datetime_str(row.get("LastLoginDateTime"))
        row["created_at"] = _cell_to_datetime_str(row.get("created_at"))
        row["updated_at"] = _cell_to_datetime_str(row.get("updated_at"))

    return templates.TemplateResponse(
        request=request,
        name="fragments/login_user_results.html",
        context={
            "request": request,
            "mode": "results",
            "results": results,
            "result_count": result_count,
            "over_limit": over_limit,
            "display_limit": db.DISPLAY_LIMIT,
            "sort_summary": sort_summary,
        },
    )


@app.get("/fragment/invoice-data/search", response_class=HTMLResponse)
def fragment_invoice_data_search(
    request: Request,
    search_invoice_no: str = "",
    search_customer_name: str = "",
    search_subject: str = "",
    search_memo: str = "",
    search_issue_date_from: str = "",
    search_issue_date_to: str = "",
    search_payment_deadline_from: str = "",
    search_payment_deadline_to: str = "",
    _reset: bool = False,
):
    """htmx: 請求書データ検索結果フラグメント（同期: DBアクセスのため def）"""
    if _reset:
        return templates.TemplateResponse(
            request=request,
            name="fragments/invoice_data_results.html",
            context={"request": request, "mode": "initial"},
        )

    has_condition = any(
        v.strip()
        for v in [
            search_invoice_no,
            search_customer_name,
            search_subject,
            search_memo,
            search_issue_date_from,
            search_issue_date_to,
            search_payment_deadline_from,
            search_payment_deadline_to,
        ]
    )
    if not has_condition:
        return templates.TemplateResponse(
            request=request,
            name="fragments/invoice_data_results.html",
            context={"request": request, "mode": "no_condition"},
        )

    results, result_count, over_limit = db.search_invoices(
        search_invoice_no=search_invoice_no,
        search_customer_name=search_customer_name,
        search_subject=search_subject,
        search_memo=search_memo,
        search_issue_date_from=search_issue_date_from,
        search_issue_date_to=search_issue_date_to,
        search_payment_deadline_from=search_payment_deadline_from,
        search_payment_deadline_to=search_payment_deadline_to,
    )

    for row in results:
        row["支払期限"] = _display_yyyy_mm_dd(_cell_to_str(row.get("支払期限")))

    return templates.TemplateResponse(
        request=request,
        name="fragments/invoice_data_results.html",
        context={
            "request": request,
            "mode": "results",
            "results": results,
            "result_count": result_count,
            "over_limit": over_limit,
            "display_limit": db.DISPLAY_LIMIT,
        },
    )


@app.get("/fragment/invoice-data-tree-test/search", response_class=HTMLResponse)
def fragment_invoice_data_tree_test_search(
    request: Request,
    search_invoice_no: str = "",
    search_customer_name: str = "",
    search_subject: str = "",
    search_memo: str = "",
    search_issue_date_from: str = "",
    search_issue_date_to: str = "",
    search_payment_deadline_from: str = "",
    search_payment_deadline_to: str = "",
    sort0_col: str = "",
    sort0_dir: str = "",
    sort1_col: str = "",
    sort1_dir: str = "",
    sort2_col: str = "",
    sort2_dir: str = "",
    _reset: bool = False,
):
    """htmx: 請求一覧の検索（請求一覧（古い）と同一 DB 検索）。"""
    if _reset:
        return templates.TemplateResponse(
            request=request,
            name="fragments/invoice_data_tree_test_results.html",
            context={"request": request, "mode": "initial"},
        )

    has_condition = any(
        v.strip()
        for v in [
            search_invoice_no,
            search_customer_name,
            search_subject,
            search_memo,
            search_issue_date_from,
            search_issue_date_to,
            search_payment_deadline_from,
            search_payment_deadline_to,
        ]
    )
    if not has_condition:
        return templates.TemplateResponse(
            request=request,
            name="fragments/invoice_data_tree_test_results.html",
            context={"request": request, "mode": "no_condition"},
        )

    sort_levels, sort_summary = _parse_invoice_tree_sort_params(
        sort0_col,
        sort0_dir,
        sort1_col,
        sort1_dir,
        sort2_col,
        sort2_dir,
    )

    results, result_count, over_limit = db.search_invoices(
        search_invoice_no=search_invoice_no,
        search_customer_name=search_customer_name,
        search_subject=search_subject,
        search_memo=search_memo,
        search_issue_date_from=search_issue_date_from,
        search_issue_date_to=search_issue_date_to,
        search_payment_deadline_from=search_payment_deadline_from,
        search_payment_deadline_to=search_payment_deadline_to,
        sort_levels=sort_levels if sort_levels else None,
    )

    for row in results:
        row["支払期限"] = _display_yyyy_mm_dd(_cell_to_str(row.get("支払期限")))

    return templates.TemplateResponse(
        request=request,
        name="fragments/invoice_data_tree_test_results.html",
        context={
            "request": request,
            "mode": "results",
            "results": results,
            "result_count": result_count,
            "over_limit": over_limit,
            "display_limit": db.DISPLAY_LIMIT,
            "sort_summary": sort_summary,
        },
    )


@app.get("/fragment/invoice-data-tree-test/details", response_class=HTMLResponse)
def fragment_invoice_data_tree_test_details(
    request: Request,
    invoice_no: str = "",
):
    """請求一覧: 1件の請求明細（行展開用フラグメント）。"""
    inv = (invoice_no or "").strip()
    if not inv:
        return templates.TemplateResponse(
            request=request,
            name="fragments/invoice_data_tree_test_details.html",
            context={
                "request": request,
                "details": [],
                "error_message": "請求書番号が指定されていません。",
            },
        )

    details = db.fetch_invoice_details_for_list(inv)
    return templates.TemplateResponse(
        request=request,
        name="fragments/invoice_data_tree_test_details.html",
        context={
            "request": request,
            "details": details,
            "error_message": None,
        },
    )


@app.get("/fragment/torihikisaki/search", response_class=HTMLResponse)
def fragment_torihikisaki_search(
    request: Request,
    search_koza_meigi: str = "",
    search_hojin_mei: str = "",
    search_daihyo_sei: str = "",
    search_kanri_sei: str = "",
    _reset: bool = False,
):
    """htmx: 取引先検索結果フラグメント（同期: DBアクセスのため def）"""
    if _reset:
        return templates.TemplateResponse(
            request=request,
            name="fragments/torihikisaki_results.html",
            context={"request": request, "mode": "initial"},
        )

    has_condition = any(
        v.strip()
        for v in [search_koza_meigi, search_hojin_mei,
                   search_daihyo_sei, search_kanri_sei]
    )
    if not has_condition:
        return templates.TemplateResponse(
            request=request,
            name="fragments/torihikisaki_results.html",
            context={"request": request, "mode": "no_condition"},
        )

    results, result_count, over_limit = db.search_accounts(
        search_koza_meigi=search_koza_meigi,
        search_hojin_mei=search_hojin_mei,
        search_daihyo_sei=search_daihyo_sei,
        search_kanri_sei=search_kanri_sei,
    )

    return templates.TemplateResponse(
        request=request,
        name="fragments/torihikisaki_results.html",
        context={
            "request": request,
            "mode": "results",
            "results": results,
            "result_count": result_count,
            "over_limit": over_limit,
            "display_limit": db.DISPLAY_LIMIT,
        },
    )


@app.get("/account/maintenance", response_class=HTMLResponse)
def account_maintenance(request: Request, tenban: int, koza: str):
    """取引先メンテナンス（新規タブ用フルページ）。T1_AccountAttribute を店番号+口座番号で特定。"""
    row = db.fetch_account_for_maintenance(tenban, koza)
    if not row:
        return HTMLResponse(
            content=(
                "<!DOCTYPE html><html><head><meta charset='utf-8'><title>404</title></head>"
                "<body><p>該当する取引先が見つかりません。</p></body></html>"
            ),
            status_code=404,
        )

    form = {k: _cell_to_str(v) for k, v in row.items()}
    z = form.get("電話番号(市外局番)", "")
    s = form.get("電話番号(市内局番)", "")
    kk = form.get("電話番号(局番)", "")
    phone_parts = [p for p in [z, s, kk] if p]
    phone_combined = "-".join(phone_parts)
    rep_kanji = (form.get("代表者姓(漢字)", "") or "") + (form.get("代表者名(漢字)", "") or "")
    rep_kana = (form.get("代表者姓(カナ)", "") or "") + (form.get("代表者名(カナ)", "") or "")
    mgr_full = (form.get("口座管理者姓(漢字)", "") or "") + (form.get("口座管理者名(漢字)", "") or "")
    title = form.get("法人名(漢字)", "") or "取引先メンテナンス"

    return templates.TemplateResponse(
        request=request,
        name="account_maintenance.html",
        context={
            "request": request,
            "form": form,
            "phone_combined": phone_combined,
            "rep_kanji": rep_kanji,
            "rep_kana": rep_kana,
            "mgr_full": mgr_full,
            "page_title": title,
        },
    )


def _render_invoice_maintenance_page(
    request: Request,
    invoice_no: str,
    mode: str,
    *,
    maintenance_page_base: str,
    maintenance_title_prefix: str,
):
    """請求書メンテ HTML を返す。maintenance_page_base は保存後リダイレクト先の GET パス（末尾スラッシュなし）。"""
    raw_uid = (request.session.get("user_id") or "").strip()
    canon_uid = db.get_canonical_login_userid(raw_uid) or raw_uid if raw_uid else ""
    has_billing_edit_all = (
        db.f_check_permissions(canon_uid, ["BILLING_EDIT_ALL"]) if canon_uid else False
    )

    row = db.fetch_invoice_for_maintenance(invoice_no)
    if not row:
        return HTMLResponse(
            content=(
                "<!DOCTYPE html><html><head><meta charset='utf-8'><title>404</title></head>"
                "<body><p>該当する請求データが見つかりません。</p></body></html>"
            ),
            status_code=404,
        )

    header = row["header"]
    details = row["details"]

    header_form = {k: _cell_to_str(v) for k, v in header.items()}
    detail_rows = [{k: _cell_to_str(v) for k, v in d.items()} for d in details]

    maintenance_mode = "copy" if (mode or "").strip().lower() == "copy" else "update"

    # コピーモード: Save As では承認状態を引き継がない（最終承認者・日時は空、承認OKはオフ固定）
    if maintenance_mode == "copy":
        header_form["自行住所"] = ""
        header_form["自行電話_FAX番号"] = ""
        header_form["最終承認OK"] = ""

    title = header_form.get("宛名_取引先名") or header_form.get("請求書番号") or "請求データメンテナンス"

    _hdr_cols_full = getattr(db, "_INVOICE_HEADER_COLUMNS")
    _quad_exclude = getattr(db, "INVOICE_HEADER_QUAD_EXCLUDE")
    _cols_for_quads = [c for c in _hdr_cols_full if c not in _quad_exclude]
    # クワッド先頭行：最終更新者・最終更新日時・自行住所・自行電話 の表示順（DB 列名順）
    _quad_first_row_order = (
        "発行者",
        "営業担当者",
        "自行住所",
        "自行電話_FAX番号",
    )
    _quad_front = [c for c in _quad_first_row_order if c in _cols_for_quads]
    _quad_rest = [c for c in _cols_for_quads if c not in _quad_front]
    _cols_for_quads = _quad_front + _quad_rest
    # スロット1・2 + 支払情報(1tr) + 先方担当者(1tr) + 自行担当者(1tr・事業部/コメント_振込/敬称/自行営業) + 税・金額(1tr) + 備考・メモ(1tr)
    _layout_slot_row_count = 7
    _quad_row_no_base = _layout_slot_row_count + 1
    _header_quads = [
        {
            # スロット行の次の行から quad（r は row_no に合わせる）
            "row_no": (i // 4) + _quad_row_no_base,
            "col1": _cols_for_quads[i],
            "col2": _cols_for_quads[i + 1] if (i + 1) < len(_cols_for_quads) else None,
            "col3": _cols_for_quads[i + 2] if (i + 2) < len(_cols_for_quads) else None,
            "col4": _cols_for_quads[i + 3] if (i + 3) < len(_cols_for_quads) else None,
        }
        for i in range(0, len(_cols_for_quads), 4)
    ]
    _header_slot_row2_columns = [
        *list(getattr(db, "INVOICE_HEADER_SLOT_ROW2_FIELDS")),
        None,
    ]
    _header_payment_section_rows = list(getattr(db, "INVOICE_HEADER_PAYMENT_SECTION_ROWS"))
    _header_insert_row_columns = list(getattr(db, "INVOICE_HEADER_INSERT_ROW_COLUMNS"))
    _header_slot_row6_columns = list(getattr(db, "INVOICE_HEADER_SLOT_ROW6_COLUMNS"))
    _header_slot_row_self_columns = list(getattr(db, "INVOICE_HEADER_SLOT_ROW_SELF_COLUMNS"))
    _header_slot_row7_columns = list(getattr(db, "INVOICE_HEADER_SLOT_ROW7_COLUMNS"))
    _details_section_row_class = _layout_slot_row_count + (
        (len(_cols_for_quads) + 3) // 4
    ) + 2

    return templates.TemplateResponse(
        request=request,
        name="invoice_maintenance.html",
        context={
            "request": request,
            "header_form": header_form,
            "invoice_torihikisaki_name": header_form.get("宛名_取引先名") or "",
            "invoice_koza_search_meigi": header_form.get("口座名義人") or "",
            "detail_rows": detail_rows,
            "header_columns": _hdr_cols_full,
            "detail_columns": getattr(db, "_INVOICE_DETAIL_COLUMNS"),
            "header_slot_row1_columns": list(getattr(db, "INVOICE_HEADER_SLOT_ROW1_FIELDS")),
            "header_slot_row2_columns": _header_slot_row2_columns,
            "header_payment_section_rows": _header_payment_section_rows,
            "header_insert_row_columns": _header_insert_row_columns,
            "header_slot_row6_columns": _header_slot_row6_columns,
            "header_slot_row_self_columns": _header_slot_row_self_columns,
            "header_slot_row7_columns": _header_slot_row7_columns,
            "header_quads": _header_quads,
            "details_section_row_class": _details_section_row_class,
            "page_title": title,
            "invoice_maintenance_mode": maintenance_mode,
            "invoice_maintenance_page_base": maintenance_page_base,
            "maintenance_title_prefix": maintenance_title_prefix,
            "invoice_has_billing_edit_all": has_billing_edit_all,
        },
    )


@app.get("/invoice/maintenance", response_class=HTMLResponse)
def invoice_maintenance(request: Request, invoice_no: str, mode: str = ""):
    """請求書メンテナンス（新規タブ用フルページ）。T1_請求書データ_ヘッダ + 明細を請求書番号でJOIN。
    mode=copy: コピー元の請求書番号でデータを読み込み、SaveAs 用（請求書番号は画面上で変更可）。
    """
    return _render_invoice_maintenance_page(
        request,
        invoice_no,
        mode,
        maintenance_page_base="/invoice/maintenance",
        maintenance_title_prefix="",
    )


@app.get("/invoice/maintenance-new", response_class=HTMLResponse)
def invoice_maintenance_new(request: Request, invoice_no: str, mode: str = ""):
    """請求書メンテ（請求一覧などから開く別画面）。表示・保存後遷移は /invoice/maintenance-new を基準にする。"""
    return _render_invoice_maintenance_page(
        request,
        invoice_no,
        mode,
        maintenance_page_base="/invoice/maintenance-new",
        maintenance_title_prefix="",
    )


@app.get("/api/zipmaster/suggest")
def api_zipmaster_suggest(q: str = ""):
    """郵便番号入力のサジェスト（zipMaster.zipcode 前方一致、最大15件）。"""
    items = db.search_zip_master_suggestions(q, limit=15)
    return JSONResponse(content={"items": items})


@app.get("/api/torihikisaki-master/search")
def api_torihikisaki_master_search(q: str = ""):
    """取引先マスタ（M_取引先マスタ）検索。請求メンテの取引先選択モーダル用 JSON。"""
    items, count, over_limit = db.search_m_torihikisaki_master(
        q, limit=db.DISPLAY_LIMIT
    )
    return JSONResponse(
        content={"items": items, "count": count, "over_limit": over_limit},
        headers={
            "Cache-Control": "no-store, no-cache, must-revalidate",
            "Pragma": "no-cache",
        },
    )


@app.post("/api/torihikisaki-master/delete")
async def api_torihikisaki_master_delete(request: Request):
    """取引先マスタ（M_取引先マスタ）1件を ID で物理削除。請求メンテの取引先選択モーダル用。"""
    try:
        body = await request.json()
    except Exception:
        return JSONResponse(
            status_code=400,
            content={"ok": False, "errors": ["リクエスト本文が不正です。"]},
        )

    raw_uid = (request.session.get("user_id") or "").strip()
    if not raw_uid:
        return JSONResponse(
            content={"ok": False, "errors": ["ログイン情報が取得できません。"]},
        )
    canon_uid = db.get_canonical_login_userid(raw_uid) or raw_uid
    if not db.f_check_permissions(canon_uid, list(_INVOICE_MAINTENANCE_SAVE_EDIT_ROLES)):
        return JSONResponse(
            content={"ok": False, "errors": [_INV_SAVE_ERR_NO_EDIT_ROLE]},
        )

    raw_id = body.get("id")
    try:
        pk = int(raw_id)
    except (TypeError, ValueError):
        return JSONResponse(content={"ok": False, "errors": ["IDが不正です。"]})

    ok, msg = db.delete_m_torihikisaki_master_by_id(pk)
    if ok:
        return JSONResponse(content={"ok": True, "message": msg})
    return JSONResponse(content={"ok": False, "errors": [msg]})


class KozaMasterSearchIn(BaseModel):
    """請求メンテ・口座マスタ検索（JSON POST で日本語・長文も確実に渡す）。"""

    meigi: str = ""
    tenban: str = ""
    torihikisaki_name: str = ""


@app.post("/api/koza-master/search")
def api_koza_master_search(body: KozaMasterSearchIn):
    """口座マスタ（M_口座マスタ）検索。請求メンテの店番選択モーダル用 JSON。"""
    items, count, over_limit = db.search_m_koza_master(
        meigi=body.meigi,
        tenban=body.tenban,
        torihikisaki_name=body.torihikisaki_name,
        limit=200,
    )
    return JSONResponse(
        content={"items": items, "count": count, "over_limit": over_limit}
    )


class OrgSettingsDepartmentRoleIn(BaseModel):
    """T_DepartmentRole の付与・解除（granted_to は無期限のみ＝NULL）。"""

    dept_id: int = Field(..., ge=1)
    role_id: int = Field(..., ge=1)
    grant: bool


@app.post("/api/org-settings/department-role")
def api_org_settings_department_role(body: OrgSettingsDepartmentRoleIn):
    """部署×ロールを登録・削除する。認可は当面なし（誰でも呼べる）。"""
    if not db.set_t_department_role(body.dept_id, body.role_id, body.grant):
        return JSONResponse(
            status_code=500,
            content={"ok": False, "error": "保存に失敗しました。"},
        )
    return JSONResponse(content={"ok": True})


class OrgSettingsDepartmentCreateIn(BaseModel):
    """M_Department 新規（部門／部署／チーム追加）。"""

    dept_code: str = Field("", max_length=20)
    dept_name: str = Field("", max_length=100)
    parent_dept_id: int | None = None


class OrgSettingsDepartmentUpdateIn(BaseModel):
    """M_Department 名称・コード更新。"""

    dept_code: str = Field("", max_length=20)
    dept_name: str = Field("", max_length=100)


@app.post("/api/org-settings/department")
def api_org_settings_department_create(body: OrgSettingsDepartmentCreateIn):
    """部署マスタへ新規登録。"""
    new_id, err = db.insert_m_department(
        body.dept_code,
        body.dept_name,
        body.parent_dept_id,
    )
    if err:
        return JSONResponse(
            status_code=400,
            content={"ok": False, "error": err},
        )
    if new_id is None:
        return JSONResponse(
            status_code=500,
            content={"ok": False, "error": "登録に失敗しました。"},
        )
    row = db.get_m_department_org_settings_row(new_id)
    if not row:
        return JSONResponse(
            status_code=500,
            content={"ok": False, "error": "登録後の取得に失敗しました。"},
        )
    return JSONResponse(content={"ok": True, "dept": row})


@app.put("/api/org-settings/department/{dept_id:int}")
def api_org_settings_department_update(dept_id: int, body: OrgSettingsDepartmentUpdateIn):
    """部署コード・部署名を更新。"""
    ok, err = db.update_m_department(dept_id, body.dept_code, body.dept_name)
    if not ok:
        return JSONResponse(
            status_code=400,
            content={"ok": False, "error": err or "更新に失敗しました。"},
        )
    row = db.get_m_department_org_settings_row(dept_id)
    if row:
        return JSONResponse(content={"ok": True, "dept": row})
    return JSONResponse(content={"ok": True})


@app.delete("/api/org-settings/department/{dept_id:int}")
def api_org_settings_department_delete(dept_id: int):
    """部署を削除（先に子部署・T_DepartmentRole を除去）。ユーザ所属があると失敗。"""
    ok, err = db.delete_m_department(dept_id)
    if not ok:
        return JSONResponse(
            status_code=400,
            content={"ok": False, "error": err or "削除に失敗しました。"},
        )
    return JSONResponse(content={"ok": True})


@app.get("/api/org-settings/login-users")
def api_org_settings_login_users(userid: str = "", user_name: str = ""):
    """
    権限・組織設定: ユーザID・ユーザ名（部分一致）で T1_LoginUser を検索し、
    各ユーザの T_UserDepartment を付与して返す。当面認可なし。
    """
    try:
        users, over_limit = db.org_settings_search_users(
            userid=userid,
            user_name=user_name,
        )
        return JSONResponse(
            content={"ok": True, "users": users, "over_limit": over_limit},
        )
    except Exception:
        logger.exception("org_settings_search_users failed")
        return JSONResponse(
            status_code=500,
            content={"ok": False, "error": "ユーザ検索に失敗しました。"},
        )


# 請求メンテ・更新保存時に f_check_permissions で確認するロールコード（コピー保存時は未使用）
_INVOICE_MAINTENANCE_SAVE_EDIT_ROLES: tuple[str, ...] = (
    "BILLING_EDIT_ALL",
    "BILLING_EDIT_OWN",
)

# /invoice/maintenance/save の権限エラー表示用（どの関数で止まったか判別できるよう文言を分ける）
_INV_SAVE_ERR_NO_EDIT_ROLE = (
    "【db.f_check_permissions】"
    "ログインユーザに BILLING_EDIT_ALL または BILLING_EDIT_OWN が付与されているか確認しましたが、"
    "どちらもありません。"
    "（請求データ全件編集／担当請求の編集ロールが必要です）"
)
_INV_SAVE_ERR_OWN_NEEDS_TANTO = (
    "【db.f_check_permissions2 は実行していません】"
    "直前に db.f_check_permissions(BILLING_EDIT_ALL のみ) で全件編集権がない経路であり、"
    "続けて同一事業部判定に進むためには請求ヘッダの自行営業担当者（担当）が必須ですが未設定です。"
)
_INV_SAVE_ERR_OWN_ORG_MISMATCH = (
    "【db.f_check_permissions2】"
    "ロール BILLING_EDIT_OWN のユーザについて、操作者と請求の担当者（自行営業担当者）が"
    "同一事業部（level 1）かを確認しましたが一致しません。"
)

# 将来要件変更で外しやすいよう、請求書番号のスポット請求チェックはフラグで独立管理する。
_ENABLE_INV_NO_SPOT_RULE_FOR_NON_ALL = True
_INV_NO_SPOT_RULE_MSG = '請求書番号の5～6桁目はスポット請求を意味する"02"をセットしてください。'
_INV_NO_FORMAT_RE = re.compile(r"^\d{2}(0[1-9]|1[0-2])\d{2}-[A-Z]\d{3,4}$")


@app.post("/api/koza-master/delete")
async def api_koza_master_delete(request: Request):
    """口座マスタ（M_口座マスタ）1件を ID で物理削除。請求メンテの口座選択モーダル用。"""
    try:
        body = await request.json()
    except Exception:
        return JSONResponse(
            status_code=400,
            content={"ok": False, "errors": ["リクエスト本文が不正です。"]},
        )

    raw_uid = (request.session.get("user_id") or "").strip()
    if not raw_uid:
        return JSONResponse(
            content={"ok": False, "errors": ["ログイン情報が取得できません。"]},
        )
    canon_uid = db.get_canonical_login_userid(raw_uid) or raw_uid
    if not db.f_check_permissions(canon_uid, list(_INVOICE_MAINTENANCE_SAVE_EDIT_ROLES)):
        return JSONResponse(
            content={"ok": False, "errors": [_INV_SAVE_ERR_NO_EDIT_ROLE]},
        )

    raw_id = body.get("id")
    try:
        pk = int(raw_id)
    except (TypeError, ValueError):
        return JSONResponse(content={"ok": False, "errors": ["IDが不正です。"]})

    ok, msg = db.delete_m_koza_master_by_id(pk)
    if ok:
        return JSONResponse(content={"ok": True, "message": msg})
    return JSONResponse(content={"ok": False, "errors": [msg]})


def _validate_invoice_no_spot_rule_for_non_all(invoice_no_value: object) -> str | None:
    """BILLING_EDIT_ALL が無い経路でのみ使う独立ルール。
    請求書番号フォーマットが一致し、かつ 5-6 桁目が "01" の場合はエラーを返す。
    """
    if not _ENABLE_INV_NO_SPOT_RULE_FOR_NON_ALL:
        return None
    inv = str(invoice_no_value or "").strip()
    if not inv:
        return None
    if not _INV_NO_FORMAT_RE.fullmatch(inv):
        return None
    if inv[4:6] == "01":
        return _INV_NO_SPOT_RULE_MSG
    return None


@app.post("/invoice/maintenance/save")
async def invoice_maintenance_save(request: Request):
    """請求データメンテ画面の保存（検証→補完→DB更新）。"""
    try:
        body = await request.json()
    except Exception:
        return JSONResponse(
            status_code=400,
            content={"ok": False, "errors": ["リクエスト本文が不正です。"]},
        )

    invoice_no = (body.get("invoice_no") or "").strip()
    header = body.get("header") or {}
    detail_rows = body.get("detail_rows") or []
    if not isinstance(header, dict):
        header = {}
    if not isinstance(detail_rows, list):
        detail_rows = []

    raw_uid = (request.session.get("user_id") or "").strip()
    if not raw_uid:
        return JSONResponse(
            content={
                "ok": False,
                "errors": ["ログイン情報が取得できません。"],
            }
        )
    canon_uid = db.get_canonical_login_userid(raw_uid) or raw_uid
    save_mode = (body.get("save_mode") or "").strip().lower()
    copy_save = save_mode == "copy"

    # コピー保存は新規登録扱いのため権限チェックは行わない（更新保存のみ f_check_permissions）
    if not copy_save and not db.f_check_permissions(
        canon_uid, list(_INVOICE_MAINTENANCE_SAVE_EDIT_ROLES)
    ):
        return JSONResponse(
            content={
                "ok": False,
                "errors": [_INV_SAVE_ERR_NO_EDIT_ROLE],
            }
        )

    def _parse_ymd_or_none(raw: object) -> date | None:
        s = str(raw or "").strip()
        if not s:
            return None
        s10 = s[:10]
        try:
            return datetime.strptime(s10, "%Y-%m-%d").date()
        except ValueError:
            return None

    issue_date = _parse_ymd_or_none(header.get("発行日"))
    payment_deadline = _parse_ymd_or_none(header.get("支払期限"))
    if issue_date is not None and payment_deadline is not None:
        if payment_deadline <= issue_date:
            return JSONResponse(
                content={
                    "ok": False,
                    "errors": ["支払期限は発行日よりも未来の日付を入力してください。"],
                }
            )

    # copy_save かつ BILLING_EDIT_ALL が無い経路向けの請求書番号ルール（将来撤去しやすい独立関数）。
    has_billing_edit_all = db.f_check_permissions(canon_uid, ["BILLING_EDIT_ALL"])
    if copy_save and not has_billing_edit_all:
        invoice_no_for_rule = (header.get("請求書番号") or invoice_no or "").strip()
        spot_rule_err = _validate_invoice_no_spot_rule_for_non_all(invoice_no_for_rule)
        if spot_rule_err:
            return JSONResponse(content={"ok": False, "errors": [spot_rule_err]})

    update_torihikisaki_master = bool(body.get("update_torihikisaki_master"))
    update_koza_master = bool(body.get("update_koza_master"))

    err_h = db.validate_invoice_header_for_save(
        header, update_torihikisaki_master=update_torihikisaki_master
    )
    if err_h:
        return JSONResponse(content={"ok": False, "errors": err_h})

    err_d = db.validate_invoice_detail_rows_for_save(detail_rows)
    if err_d:
        return JSONResponse(content={"ok": False, "errors": err_d})

    profile = db.get_login_user_department_profile(canon_uid)

    # コピー保存時のみ: セッション user_id から所属情報をヘッダへ反映
    if copy_save:
        if not profile:
            return JSONResponse(
                content={
                    "ok": False,
                    "errors": ["ログインユーザの所属情報を取得できません。"],
                }
            )
        header["自行部署名"] = profile.get("lv1_name") or ""
        header["コメント_振込"] = profile.get("lv2_name") or ""
        header["敬称"] = profile.get("lv3_name") or ""
        header["自行営業担当者"] = profile.get("user_name") or canon_uid

    # ログインユーザの表示名（最終更新者・最終承認者に使う値と同一）
    if profile:
        issuer_display = str(profile.get("user_name") or canon_uid).strip()
    else:
        issuer_display = str(db.get_login_user_display_name(canon_uid) or canon_uid).strip()

    # BILLING_EDIT_ALL が無い場合のみ: OWN 保存は担当者（自行営業担当者）と同一事業部（level 1）
    # コピー保存時はスキップ（新規登録扱い）
    if not copy_save and not has_billing_edit_all:
        owner_for_perm = unicodedata.normalize(
            "NFKC", str(header.get("自行営業担当者") or "").strip()
        )
        issuer_for_perm = unicodedata.normalize("NFKC", issuer_display)
        if not owner_for_perm:
            return JSONResponse(
                content={
                    "ok": False,
                    "errors": [_INV_SAVE_ERR_OWN_NEEDS_TANTO],
                }
            )
        if not db.f_check_permissions2(
            issuer_for_perm,
            ["BILLING_EDIT_OWN"],
            owner_for_perm,
            "1",
        ):
            return JSONResponse(
                content={
                    "ok": False,
                    "errors": [_INV_SAVE_ERR_OWN_ORG_MISMATCH],
                }
            )

    def _norm_invoice_person_name(v: object) -> str:
        return unicodedata.normalize("NFKC", str(v or "").strip())

    def _is_final_approval_requested(raw: object) -> bool:
        if isinstance(raw, bool):
            return raw
        if raw is None:
            return False
        if isinstance(raw, (int, float)):
            return int(raw) == 1
        s = str(raw).strip().lower()
        return s in ("1", "true", "yes", "on", "y")

    approval_requested = _is_final_approval_requested(header.get("最終承認OK"))

    if approval_requested:
        existing_inv = db.fetch_invoice_for_maintenance(invoice_no)
        # 自行担当者ブロック「担当者」＝ DB 列 自行営業担当者。ログインユーザ表示名と同一なら本人承認として不可
        if existing_inv and existing_inv.get("header"):
            self_block_tanto_raw = existing_inv["header"].get("自行営業担当者")
        else:
            self_block_tanto_raw = header.get("自行営業担当者")
        if _norm_invoice_person_name(self_block_tanto_raw) == _norm_invoice_person_name(
            issuer_display
        ):
            return JSONResponse(
                content={
                    "ok": False,
                    "errors": [
                        "最終承認は、自行担当者の担当者本人では行えません。"
                    ],
                }
            )
        header["自行住所"] = issuer_display
        header["自行電話_FAX番号"] = datetime.now().strftime("%Y/%m/%d %H:%M:%S")
    else:
        # 最終更新者（発行者）：自行担当「担当者」と同じ user_name 解決。所属プロファイル無しの更新保存では LoginUser 表示名
        if profile:
            header["発行者"] = profile.get("user_name") or canon_uid
        else:
            header["発行者"] = db.get_login_user_display_name(canon_uid) or canon_uid

        # タイムスタンプ（画面ラベル）＝ DB 列「営業担当者」：保存時にサーバ時刻を文字列でセット
        header["営業担当者"] = datetime.now().strftime("%Y/%m/%d %H:%M:%S")

    # 最終承認OKは画面専用（DB 列なし）。保存リクエストの分岐にだけ使い、永続化から外す
    header.pop("最終承認OK", None)

    ok, msg = db.save_invoice_maintenance(
        invoice_no,
        header,
        detail_rows,
        copy_save=copy_save,
        update_torihikisaki_master=update_torihikisaki_master,
        update_koza_master=update_koza_master,
    )
    if ok:
        return JSONResponse(content={"ok": True, "message": msg})
    return JSONResponse(content={"ok": False, "errors": [msg]})


@app.post("/login-user/maintenance/can-create")
async def login_user_maintenance_can_create(request: Request):
    """新規ユーザ登録画面へ進めるか（管理者のみ）。一覧のメッセージエリア用に JSON で返す。"""
    actor = (request.session.get("user_id") or "").strip()
    if not actor:
        return JSONResponse(
            content={"ok": False, "errors": ["ログイン情報が取得できません。"]},
        )
    if not db.is_login_user_admin(actor):
        return JSONResponse(
            content={
                "ok": False,
                "errors": ["ユーザーの新規登録は管理者のみが行えます。"],
            },
        )
    return JSONResponse(content={"ok": True})


@app.get("/login-user/maintenance", response_class=HTMLResponse)
def login_user_maintenance(request: Request, userid: str = ""):
    """ログインユーザメンテナンス（フルページ）。"""
    uid = (userid or "").strip()
    is_new = uid == ""
    if is_new:
        actor = (request.session.get("user_id") or "").strip()
        if not db.is_login_user_admin(actor):
            request.session["login_user_list_flash"] = {
                "kind": "error",
                "text": "ユーザーの新規登録は管理者のみが行えます。",
            }
            return RedirectResponse(url="/top/login-users", status_code=302)
        form = {
            "userid": "",
            "user_name": "",
            "admin_option": "0",
            "Enabled": "1",
            "LastLoginDateTime": "",
            "created_at": "",
            "updated_at": "",
        }
        page_title = "ログインユーザメンテナンス"
    else:
        row = db.fetch_login_user_for_maintenance(uid)
        if not row:
            return HTMLResponse(
                content=(
                    "<!DOCTYPE html><html><head><meta charset='utf-8'><title>404</title></head>"
                    "<body><p>該当するユーザーが見つかりません。</p></body></html>"
                ),
                status_code=404,
            )
        form = {
            "userid": _cell_to_str(row.get("userid")),
            "user_name": _cell_to_str(row.get("user_name")),
            "admin_option": _cell_to_str(row.get("admin_option") if row.get("admin_option") is not None else 0),
            "Enabled": _cell_to_str(row.get("Enabled") if row.get("Enabled") is not None else 1),
            "LastLoginDateTime": _cell_to_datetime_str(row.get("LastLoginDateTime")),
            "created_at": _cell_to_datetime_str(row.get("created_at")),
            "updated_at": _cell_to_datetime_str(row.get("updated_at")),
        }
        page_title = form.get("userid") or "ログインユーザメンテナンス"

    return templates.TemplateResponse(
        request=request,
        name="login_user_maintenance.html",
        context={
            "request": request,
            "form": form,
            "page_title": page_title,
            "is_new": is_new,
            "original_userid": uid,
        },
    )


@app.post("/login-user/maintenance/save")
async def login_user_maintenance_save(request: Request):
    """ログインユーザメンテ画面の保存。"""
    try:
        body = await request.json()
    except Exception:
        return JSONResponse(
            status_code=400,
            content={"ok": False, "errors": ["リクエスト本文が不正です。"]},
        )

    original_userid = (body.get("original_userid") or "").strip()
    userid = (body.get("userid") or "").strip()
    user_name = (body.get("user_name") or "").strip()
    admin_option = (body.get("admin_option") or "").strip()
    enabled = (body.get("Enabled") or "").strip()
    pwd = body.get("pwd") or ""
    pwd_confirm = body.get("pwd_confirm") or ""
    is_new = bool(body.get("is_new"))
    pwd_change = bool(body.get("pwd_change"))

    actor = (request.session.get("user_id") or "").strip()
    if is_new and not db.is_login_user_admin(actor):
        return JSONResponse(
            content={
                "ok": False,
                "errors": ["ユーザーの新規登録は管理者のみが行えます。"],
            }
        )

    errs = db.validate_login_user_maintenance_for_save(
        userid=userid,
        user_name=user_name,
        admin_option=admin_option,
        enabled=enabled,
        pwd=pwd,
        pwd_confirm=pwd_confirm,
        is_new=is_new,
        pwd_change=pwd_change,
    )
    if errs:
        return JSONResponse(content={"ok": False, "errors": errs})

    ok, msg = db.save_login_user_maintenance(
        original_userid=original_userid,
        userid=userid,
        user_name=user_name,
        admin_option=admin_option,
        enabled=enabled,
        pwd=pwd,
        is_new=is_new,
        pwd_change=pwd_change,
    )
    if ok:
        return JSONResponse(content={"ok": True, "message": msg, "userid": userid})
    return JSONResponse(content={"ok": False, "errors": [msg]})


@app.post("/login-user/delete/validate")
async def login_user_delete_validate(request: Request):
    """削除前チェックのみ（確認ダイアログより前に呼ぶ）。DELETE は行わない。"""
    try:
        body = await request.json()
    except Exception:
        return JSONResponse(
            status_code=400,
            content={"ok": False, "errors": ["リクエスト本文が不正です。"]},
        )

    actor = (request.session.get("user_id") or "").strip()
    userid = (body.get("userid") or "").strip()
    if not userid:
        return JSONResponse(content={"ok": False, "errors": ["削除対象のユーザーIDがありません。"]})

    ok, msg = db.validate_login_user_delete(actor, userid)
    if ok:
        return JSONResponse(content={"ok": True})
    return JSONResponse(content={"ok": False, "errors": [msg]})


@app.post("/login-user/delete")
async def login_user_delete(request: Request):
    """ユーザー削除（ログイン中ユーザーが管理者のときのみ可）。"""
    try:
        body = await request.json()
    except Exception:
        return JSONResponse(
            status_code=400,
            content={"ok": False, "errors": ["リクエスト本文が不正です。"]},
        )

    actor = (request.session.get("user_id") or "").strip()
    userid = (body.get("userid") or "").strip()
    if not userid:
        return JSONResponse(content={"ok": False, "errors": ["削除対象のユーザーIDがありません。"]})

    ok, msg = db.delete_login_user_by_userid(actor, userid)
    if ok:
        return JSONResponse(content={"ok": True, "message": msg})
    return JSONResponse(content={"ok": False, "errors": [msg]})


@app.get("/invoice/pdf/{invoice_no}")
def get_invoice_pdf(invoice_no: str):
    """
    請求書番号単位で PDF を返す（請求書一括作成・他機能から再利用）。
    """
    import invoice_pdf as invoice_pdf_mod
    from urllib.parse import quote

    row = db.fetch_invoice_for_maintenance(invoice_no)
    if not row:
        raise HTTPException(
            status_code=404, detail="該当する請求データが見つかりません。"
        )
    data = invoice_pdf_mod.build_invoice_pdf_bytes_from_row(row)
    fn = invoice_pdf_mod.get_invoice_pdf_filename_from_row(row, invoice_no)
    fn_encoded = quote(fn, safe="")
    return Response(
        content=data,
        media_type="application/pdf",
        headers={
            "Content-Disposition": (
                'attachment; filename="invoice.pdf"; '
                f"filename*=UTF-8''{fn_encoded}"
            )
        },
    )


@app.get("/fragment/hello", response_class=HTMLResponse)
async def fragment_hello(request: Request):
    """htmx: Hello サンプルフラグメント（メインフレーム用）"""
    return templates.TemplateResponse(
        request=request,
        name="fragments/hello.html",
        context={"request": request},
    )


@app.get("/fragment/mcp-test1", response_class=HTMLResponse)
async def fragment_mcp_test1(request: Request):
    """htmx: MCPテスト1（ステップ1）フラグメント"""
    return templates.TemplateResponse(
        request=request,
        name="fragments/mcp_test1.html",
        context={"request": request},
    )


@app.get("/fragment/mcp-test2", response_class=HTMLResponse)
async def fragment_mcp_test2(request: Request):
    """htmx: MCPテスト2（請求ヘッダ検索）フラグメント"""
    return templates.TemplateResponse(
        request=request,
        name="fragments/mcp_test2.html",
        context={"request": request},
    )


@app.get("/fragment/mcp-test3", response_class=HTMLResponse)
async def fragment_mcp_test3(request: Request):
    """htmx: MCPテスト3（Web→MCP経由）フラグメント"""
    return templates.TemplateResponse(
        request=request,
        name="fragments/mcp_test3.html",
        context={"request": request},
    )


@app.get("/fragment/mcp-test4", response_class=HTMLResponse)
async def fragment_mcp_test4(request: Request):
    """htmx: MCPテスト4（請求書PDF生成）フラグメント"""
    return templates.TemplateResponse(
        request=request,
        name="fragments/mcp_test4.html",
        context={"request": request},
    )


@app.get("/fragment/excel-test", response_class=HTMLResponse)
async def fragment_excel_test(request: Request):
    """htmx: エクセルテストフラグメント（メインフレーム用）"""
    return templates.TemplateResponse(
        request=request,
        name="fragments/excel_test.html",
        context={"request": request},
    )


@app.get("/fragment/facility-reserve", response_class=HTMLResponse)
async def fragment_facility_reserve(request: Request):
    """htmx: シフト管理（メインフレーム用）"""
    return templates.TemplateResponse(
        request=request,
        name="fragments/facility_reserve.html",
        context={"request": request},
    )


@app.get("/fragment/shift-scheduler", response_class=HTMLResponse)
async def fragment_shift_scheduler(request: Request):
    """htmx: 勤務シフト最適化モック（メインフレーム用）"""
    return templates.TemplateResponse(
        request=request,
        name="content/shift_scheduler/shift_scheduler_ui.html",
        context={"request": request},
    )


@app.get("/shift-scheduler-mock")
async def shift_scheduler_mock_standalone():
    """オリジナル HTML を Jinja なしでそのまま返す（TOP 内 iframe 用）。"""
    p = (
        BASE_DIR
        / "templates"
        / "content"
        / "shift_scheduler"
        / "shift_scheduler_ui_standalone.html"
    )
    if not p.is_file():
        raise HTTPException(status_code=404, detail="shift mock file missing")
    return FileResponse(p, media_type="text/html; charset=utf-8")


_FACILITY_RESERVE_LABELS: dict[str, str] = {
    "meeting-a": "会議室A",
    "meeting-b": "会議室B",
    "reception": "応接室",
    "hall": "多目的ホール",
}

_FACILITY_TIME_SLOT_LABELS: dict[str, str] = {
    "09-10": "09:00 ～ 10:00",
    "10-11": "10:00 ～ 11:00",
    "11-12": "11:00 ～ 12:00",
    "1130-1230": "11:30 ～ 12:30",
    "13-14": "13:00 ～ 14:00",
    "14-15": "14:00 ～ 15:00",
    "1630-1730": "16:30 ～ 17:30",
    "17-18": "17:00 ～ 18:00",
    "15-16": "15:00 ～ 16:00",
    "19-20": "19:00 ～ 20:00",
}

# Availability デモ: 週の月曜 2026-04-06（M6〜Su12）のマトリクス（行=時間帯、列=月〜日）
_FACILITY_AVAIL_SLOTS: list[tuple[str, str]] = [
    ("9:00 AM", "09-10"),
    ("11:30 AM", "1130-1230"),
    ("2:00 PM", "14-15"),
    ("4:30 PM", "1630-1730"),
    ("5:00 PM", "17-18"),
    ("7:00 PM", "19-20"),
]

_FACILITY_AVAIL_DEMO_GRID: list[list[str]] = [
    ["block", "open", "closed", "closed", "closed", "block", "block"],
    ["block", "open", "open", "open", "open", "block", "block"],
    ["block", "open", "closed", "open", "closed", "block", "block"],
    ["block", "closed", "closed", "open", "closed", "block", "block"],
    ["block", "closed", "closed", "closed", "open", "block", "block"],
    ["block", "closed", "closed", "closed", "open", "block", "block"],
]

_FACILITY_AVAIL_DEMO_MONDAY = date(2026, 4, 6)


def _facility_availability_context(week_offset: int) -> dict:
    """週次空きグリッド用コンテキスト（week_offset=0 のみデモデータ、それ以外は全ブロック）。"""
    monday = _FACILITY_AVAIL_DEMO_MONDAY + timedelta(weeks=week_offset)
    dow_short = ["M", "Tu", "We", "Th", "Fr", "Sa", "Su"]
    days: list[dict] = []
    for i in range(7):
        d = monday + timedelta(days=i)
        days.append(
            {
                "iso": d.isoformat(),
                "dow": dow_short[i],
                "dom": d.day,
                "is_sat": i == 5,
                "is_sun": i == 6,
            }
        )
    if week_offset == 0:
        grid = _FACILITY_AVAIL_DEMO_GRID
    else:
        grid = [["block"] * 7 for _ in range(len(_FACILITY_AVAIL_SLOTS))]

    rows: list[dict] = []
    for r, (lbl, skey) in enumerate(_FACILITY_AVAIL_SLOTS):
        cells: list[dict] = []
        for c in range(7):
            cells.append(
                {
                    "state": grid[r][c],
                    "date_iso": days[c]["iso"],
                    "slot_key": skey,
                }
            )
        rows.append({"label": lbl, "slot_key": skey, "cells": cells})

    month_label = monday.strftime("%b")
    return {
        "week_offset": week_offset,
        "month_label": month_label,
        "days": days,
        "rows": rows,
    }


@app.get("/fragment/facility-reserve/availability", response_class=HTMLResponse)
async def fragment_facility_reserve_availability(
    request: Request, week_offset: int = 0
):
    """htmx: シフト管理の週次 Availability グリッド（部分 HTML）。"""
    try:
        wo = int(week_offset)
    except (TypeError, ValueError):
        wo = 0
    wo = max(-52, min(52, wo))
    ctx = _facility_availability_context(wo)
    return templates.TemplateResponse(
        request=request,
        name="fragments/facility_reserve_availability.html",
        context={"request": request, **ctx},
    )


_FACILITY_AVAIL_SLOT_KEYS = frozenset(s for _, s in _FACILITY_AVAIL_SLOTS)


@app.get("/fragment/facility-reserve/pick", response_class=HTMLResponse)
async def fragment_facility_reserve_pick(
    request: Request,
    date: str = "",
    slot: str = "",
):
    """htmx: 空きセル選択 → フォームへ日付・時間帯を反映（デモ）。"""
    d = (date or "").strip()
    sk = (slot or "").strip()
    if not d or not sk or sk not in _FACILITY_AVAIL_SLOT_KEYS:
        return HTMLResponse(
            content='<div class="alert alert-warning" style="margin-bottom:0;">日付または時間帯が不正です。</div>'
        )
    try:
        datetime.strptime(d, "%Y-%m-%d")
    except ValueError:
        return HTMLResponse(
            content='<div class="alert alert-warning" style="margin-bottom:0;">日付の形式が不正です。</div>'
        )
    slot_label = _FACILITY_TIME_SLOT_LABELS.get(sk, sk)
    safe_d = escape(d)
    safe_lbl = escape(slot_label)
    d_js = json.dumps(d)
    sk_js = json.dumps(sk)
    return HTMLResponse(
        content=(
            '<div class="alert alert-info" style="margin-bottom:0;">'
            f"<strong>枠を選択しました</strong><br>日付: {safe_d}<br>時間: {safe_lbl}"
            "<br><span class=\"text-muted small\">下のフォームの利用日・時間帯にも反映しました。</span>"
            "</div>"
            "<script>"
            "(function(){"
            "var f=document.getElementById('facility-reserve-form');"
            "if(!f)return;"
            "var di=f.querySelector('[name=reserve_date]');"
            "var si=f.querySelector('[name=time_slot]');"
            f"if(di)di.value={d_js};"
            f"if(si)si.value={sk_js};"
            "})();"
            "</script>"
        )
    )


@app.post("/fragment/facility-reserve/submit", response_class=HTMLResponse)
async def fragment_facility_reserve_submit(
    request: Request,
    facility_id: str = Form(""),
    reserve_date: str = Form(""),
    time_slot: str = Form(""),
    attendees: str = Form("1"),
    note: str = Form(""),
):
    """htmx: シフト管理の送信結果（部分 HTML）。"""
    fid = (facility_id or "").strip()
    rdate = (reserve_date or "").strip()
    tslot = (time_slot or "").strip()
    att_raw = (attendees or "").strip()
    note_s = (note or "").strip()

    if not fid or not rdate or not tslot or not att_raw:
        return HTMLResponse(
            content=(
                '<div class="alert alert-warning" style="margin-bottom:0;">'
                "<strong>入力不足</strong><br>施設・利用日・時間帯・人数は必須です。"
                "</div>"
            )
        )
    att = att_raw

    fac_name = _FACILITY_RESERVE_LABELS.get(fid, fid)
    slot_label = _FACILITY_TIME_SLOT_LABELS.get(tslot, tslot)
    safe_fac = escape(fac_name)
    safe_date = escape(rdate)
    safe_slot = escape(slot_label)
    safe_att = escape(att)
    safe_note = escape(note_s) if note_s else "（なし）"

    return HTMLResponse(
        content=(
            '<div class="alert alert-success" style="margin-bottom:0;">'
            "<strong>予約内容（デモ・非保存）</strong><br>"
            f"施設: {safe_fac}<br>"
            f"利用日: {safe_date}<br>"
            f"時間帯: {safe_slot}<br>"
            f"人数: {safe_att}<br>"
            f"備考: {safe_note}"
            "</div>"
        )
    )


# --- 画像認識テスト（参照画像の STARBUCKS RESERVE 風 UI・週次 Availability） ---
_IMAGE_TEST_AVAIL_SLOTS: list[tuple[str, str]] = [
    ("9:00 AM", "09-10"),
    ("11:30 AM", "1130-1230"),
    ("2:00 PM", "14-15"),
    ("5:00 PM", "17-18"),
    ("7:00 PM", "19-20"),
]

# 参照画像のマトリクス（行=上から時間、列=月〜日）
_IMAGE_TEST_AVAIL_GRID: list[list[str]] = [
    ["block", "open", "closed", "closed", "closed", "block", "block"],
    ["block", "open", "open", "open", "open", "block", "block"],
    ["block", "open", "closed", "open", "closed", "block", "block"],
    ["block", "closed", "closed", "closed", "open", "block", "block"],
    ["block", "closed", "closed", "closed", "open", "block", "block"],
]

_IMAGE_TEST_AVAIL_MONDAY = date(2026, 4, 6)

_IMAGE_TEST_SLOT_TO_TIME_PREF: dict[str, str] = {
    "09-10": "0900",
    "1130-1230": "1130",
    "14-15": "1400",
    "17-18": "1700",
    "19-20": "1900",
}

_IMAGE_TEST_SLOT_KEYS = frozenset(s for _, s in _IMAGE_TEST_AVAIL_SLOTS)


def _image_test_availability_context(
    week_offset: int,
    adults: str = "1",
    reserve_date: str = "",
    time_pref: str = "",
    children: str = "0",
    baby: str = "",
) -> dict:
    """週次グリッド（week_offset=0 のみ参照画像どおり、他週は全て −）。"""
    monday = _IMAGE_TEST_AVAIL_MONDAY + timedelta(weeks=week_offset)
    dow_short = ["M", "Tu", "W", "Th", "F", "Sa", "Su"]
    days: list[dict] = []
    for i in range(7):
        d = monday + timedelta(days=i)
        days.append(
            {
                "iso": d.isoformat(),
                "dow": dow_short[i],
                "dom": d.day,
                "is_sat": i == 5,
                "is_sun": i == 6,
            }
        )
    if week_offset == 0:
        grid = _IMAGE_TEST_AVAIL_GRID
    else:
        grid = [["block"] * 7 for _ in range(len(_IMAGE_TEST_AVAIL_SLOTS))]

    rows: list[dict] = []
    for r, (lbl, skey) in enumerate(_IMAGE_TEST_AVAIL_SLOTS):
        cells: list[dict] = []
        for c in range(7):
            cells.append(
                {
                    "state": grid[r][c],
                    "date_iso": days[c]["iso"],
                    "slot_key": skey,
                }
            )
        rows.append({"label": lbl, "slot_key": skey, "cells": cells})

    month_label = monday.strftime("%b")
    baby_disp = (baby or "").strip() or "—"
    rd = (reserve_date or "").strip() or "—"
    tp = (time_pref or "").strip() or "—"
    parts = (
        f"大人{(adults or '1').strip()} / お子様{(children or '0').strip()} "
        f"/ 乳児{baby_disp} / 日付{rd} / 希望時間{tp}"
    )
    return {
        "week_offset": week_offset,
        "month_label": month_label,
        "days": days,
        "rows": rows,
        "filter_summary": parts,
    }


@app.get("/fragment/image-test", response_class=HTMLResponse)
async def fragment_image_test(request: Request):
    """htmx: 画像認識テスト（メインフレーム用）"""
    return templates.TemplateResponse(
        request=request,
        name="fragments/image_test_reserve.html",
        context={"request": request},
    )


@app.get("/fragment/image-test/availability", response_class=HTMLResponse)
async def fragment_image_test_availability(
    request: Request,
    week_offset: int = 0,
    adults: str = "1",
    reserve_date: str = "",
    time_pref: str = "1630",
    children: str = "0",
    baby: str = "",
):
    """htmx: 画像認識テストの週次 Availability（部分 HTML）。"""
    try:
        wo = int(week_offset)
    except (TypeError, ValueError):
        wo = 0
    wo = max(-52, min(52, wo))
    ctx = _image_test_availability_context(
        wo,
        adults=adults,
        reserve_date=reserve_date,
        time_pref=time_pref,
        children=children,
        baby=baby,
    )
    return templates.TemplateResponse(
        request=request,
        name="fragments/image_test_availability.html",
        context={"request": request, **ctx},
    )


@app.get("/fragment/image-test/pick", response_class=HTMLResponse)
async def fragment_image_test_pick(
    request: Request,
    date: str = "",
    slot: str = "",
):
    """htmx: 空きセル選択 → 日付・希望時間をフォームに反映（デモ）。"""
    d = (date or "").strip()
    sk = (slot or "").strip()
    if not d or not sk or sk not in _IMAGE_TEST_SLOT_KEYS:
        return HTMLResponse(
            content='<div class="alert alert-warning" style="margin-bottom:0;">日付または時間帯が不正です。</div>'
        )
    try:
        datetime.strptime(d, "%Y-%m-%d")
    except ValueError:
        return HTMLResponse(
            content='<div class="alert alert-warning" style="margin-bottom:0;">日付の形式が不正です。</div>'
        )
    tp = _IMAGE_TEST_SLOT_TO_TIME_PREF.get(sk, "")
    slot_label = _FACILITY_TIME_SLOT_LABELS.get(sk, sk)
    safe_d = escape(d)
    safe_lbl = escape(slot_label)
    d_js = json.dumps(d)
    tp_js = json.dumps(tp)
    return HTMLResponse(
        content=(
            '<div class="alert alert-info" style="margin-bottom:0;">'
            f"<strong>枠を選択しました</strong><br>日付: {safe_d}<br>時間: {safe_lbl}"
            "<br><span class=\"text-muted small\">上の日付・希望時間にも反映しました。</span>"
            "</div>"
            "<script>"
            "(function(){"
            "var f=document.getElementById('image-test-booking-form');"
            "if(!f)return;"
            "var di=f.querySelector('[name=reserve_date]');"
            "var ti=f.querySelector('[name=time_pref]');"
            f"if(di)di.value={d_js};"
            f"if(ti)ti.value={tp_js};"
            "})();"
            "</script>"
        )
    )


@app.get("/fragment/chat", response_class=HTMLResponse)
async def fragment_chat(request: Request):
    """htmx: Chat フラグメント（メインフレーム用）"""
    uid = (request.session.get("user_id") or "").strip()
    me_uid = (db.get_canonical_login_userid(uid) or uid) if uid else ""
    chat_me_name = db.get_login_user_display_name(me_uid) if me_uid else ""
    logger.info(
        "[diag] fragment_chat path=%r session_user_id=%r me_uid=%r chat_me_name=%r",
        request.url.path,
        uid,
        me_uid,
        chat_me_name,
    )
    return templates.TemplateResponse(
        request=request,
        name="fragments/chat.html",
        context={
            "request": request,
            "chat_me_userid": me_uid,
            "chat_me_name": chat_me_name,
        },
    )


class _ChatCreateIn(BaseModel):
    title: str = ""
    member_userids: list[str] = Field(default_factory=list)


class _ChatMessageIn(BaseModel):
    body: str = ""


class _ChatAddMembersIn(BaseModel):
    userids: list[str] = Field(default_factory=list)


def _session_userid(request: Request) -> str:
    return (request.session.get("user_id") or "").strip()


def _chat_session_userid(request: Request) -> str:
    """
    チャット API 用のログイン ID。
    T1_LoginUser に格納されている userid と同一表記に正規化し、投稿者表示と DB のずれを防ぐ。
    """
    uid = _session_userid(request)
    if not uid:
        return ""
    return db.get_canonical_login_userid(uid) or uid


@app.get("/api/chat/me")
async def api_chat_me(request: Request):
    """カレントユーザ（サーバのセッション＋DB 正規化）。チャット UI の本人判定用。"""
    uid = _chat_session_userid(request)
    if not uid:
        raise HTTPException(status_code=401, detail="ログインが必要です。")
    name = await anyio.to_thread.run_sync(db.get_login_user_display_name, uid)
    return JSONResponse(content={"userid": uid, "display_name": name})


@app.get("/api/chat/pick-users")
async def api_chat_pick_users(request: Request):
    """有効ユーザ一覧（メンバー選択・自分・管理者除外）。"""
    uid = _chat_session_userid(request)
    if not uid:
        raise HTTPException(status_code=401, detail="ログインが必要です。")
    rows = await anyio.to_thread.run_sync(db.chat_list_pick_users, uid)
    return JSONResponse(
        content={
            "users": [
                {
                    "userid": (r.get("userid") or "").strip(),
                    "user_name": (r.get("user_name") or "").strip()
                    or (r.get("userid") or "").strip(),
                }
                for r in rows
            ]
        }
    )


@app.get("/api/chat/search")
async def api_chat_search(
    request: Request,
    q: str = "",
    limit: int = 30,
):
    """参加チャンネル横断でメッセージ本文を検索する。"""
    uid = _chat_session_userid(request)
    if not uid:
        raise HTTPException(status_code=401, detail="ログインが必要です。")
    lim = max(1, min(int(limit), 50))
    results, err = await anyio.to_thread.run_sync(db.chat_search_messages, uid, q, lim)
    if results is None:
        raise HTTPException(status_code=400, detail=err or "検索に失敗しました。")
    return JSONResponse(content={"results": results})


@app.get("/api/chat/channels")
async def api_chat_channels(request: Request):
    uid = _chat_session_userid(request)
    if not uid:
        raise HTTPException(status_code=401, detail="ログインが必要です。")
    channels = await anyio.to_thread.run_sync(db.chat_list_channels, uid)
    return JSONResponse(content={"channels": channels})


@app.post("/api/chat/channels")
async def api_chat_channels_create(request: Request, payload: _ChatCreateIn):
    uid = _chat_session_userid(request)
    if not uid:
        raise HTTPException(status_code=401, detail="ログインが必要です。")
    cid, err = await anyio.to_thread.run_sync(
        db.chat_create_channel,
        uid,
        payload.title,
        payload.member_userids,
    )
    if cid is None:
        raise HTTPException(status_code=400, detail=err or "作成に失敗しました。")
    return JSONResponse(content={"id": cid})


@app.delete("/api/chat/channels/{channel_id:int}")
async def api_chat_channel_delete(request: Request, channel_id: int):
    uid = _chat_session_userid(request)
    if not uid:
        raise HTTPException(status_code=401, detail="ログインが必要です。")
    ok, err = await anyio.to_thread.run_sync(db.chat_delete_channel, channel_id, uid)
    if not ok:
        raise HTTPException(status_code=400, detail=err or "削除に失敗しました。")
    await chat_hub.publish(
        channel_id,
        {"type": "channel_deleted", "channel_id": channel_id},
    )
    return JSONResponse(content={"ok": True})


@app.get("/api/chat/channels/{channel_id:int}")
async def api_chat_channel_get(request: Request, channel_id: int):
    uid = _chat_session_userid(request)
    if not uid:
        raise HTTPException(status_code=401, detail="ログインが必要です。")
    ch = await anyio.to_thread.run_sync(db.chat_get_channel_for_member, channel_id, uid)
    if not ch:
        raise HTTPException(status_code=404, detail="チャンネルが見つかりません。")
    return JSONResponse(content={"channel": ch})


@app.get("/api/chat/channels/{channel_id:int}/members")
async def api_chat_channel_members(request: Request, channel_id: int):
    uid = _chat_session_userid(request)
    if not uid:
        raise HTTPException(status_code=401, detail="ログインが必要です。")
    members, err = await anyio.to_thread.run_sync(db.chat_list_members, channel_id, uid)
    if members is None:
        raise HTTPException(status_code=404, detail=err or "チャンネルが見つかりません。")
    return JSONResponse(content={"members": members})


@app.get("/api/chat/channels/{channel_id:int}/messages")
async def api_chat_channel_messages(
    request: Request,
    channel_id: int,
    after_id: int = 0,
    around_message_id: int | None = Query(default=None),
):
    uid = _chat_session_userid(request)
    if not uid:
        raise HTTPException(status_code=401, detail="ログインが必要です。")
    aid = around_message_id
    if aid is not None and int(aid) > 0:
        msgs, err = await anyio.to_thread.run_sync(
            db.chat_get_messages_around,
            channel_id,
            uid,
            int(aid),
            None,
        )
        # 指定 ID が削除済み等のときは通常の先頭ページで開く（検索ヒットのスタレ対策）
        if msgs is None and err == db.CHAT_ERR_MESSAGE_NOT_FOUND:
            msgs, err = await anyio.to_thread.run_sync(
                db.chat_get_messages, channel_id, uid, 0, None
            )
    else:
        msgs, err = await anyio.to_thread.run_sync(
            db.chat_get_messages, channel_id, uid, after_id, None
        )
    if msgs is None:
        raise HTTPException(status_code=404, detail=err or "チャンネルが見つかりません。")
    return JSONResponse(
        content={"messages": msgs, "viewer_userid": uid}
    )


@app.post("/api/chat/channels/{channel_id:int}/messages")
async def api_chat_channel_post_message(
    request: Request, channel_id: int, payload: _ChatMessageIn
):
    uid = _chat_session_userid(request)
    if not uid:
        raise HTTPException(status_code=401, detail="ログインが必要です。")
    msg, err = await anyio.to_thread.run_sync(
        db.chat_post_message, channel_id, uid, payload.body
    )
    if msg is None:
        raise HTTPException(status_code=400, detail=err or "送信に失敗しました。")
    # SSE は全購読者で同一ペイロードのため is_from_viewer は載せない（他ユーザーが誤って「自分」表示になる）
    msg_broadcast = {k: v for k, v in msg.items() if k != "is_from_viewer"}
    await chat_hub.publish(
        channel_id,
        {"type": "chat_message", "message": msg_broadcast},
    )
    return JSONResponse(content={"message": msg})


@app.post("/api/chat/channels/{channel_id:int}/members")
async def api_chat_channel_add_members(
    request: Request, channel_id: int, payload: _ChatAddMembersIn
):
    uid = _chat_session_userid(request)
    if not uid:
        raise HTTPException(status_code=401, detail="ログインが必要です。")
    ok, err = await anyio.to_thread.run_sync(
        db.chat_add_members, channel_id, uid, payload.userids
    )
    if not ok:
        raise HTTPException(status_code=400, detail=err or "追加に失敗しました。")
    await chat_hub.publish(
        channel_id,
        {"type": "members_updated", "channel_id": channel_id},
    )
    return JSONResponse(content={"ok": True})


@app.get("/api/chat/channels/{channel_id:int}/events")
async def api_chat_channel_sse(request: Request, channel_id: int):
    """SSE: 同一チャンネルの新着（メッセージ・メンバー更新など）。"""
    uid = _chat_session_userid(request)
    if not uid:
        raise HTTPException(status_code=401, detail="ログインが必要です。")

    is_member = await anyio.to_thread.run_sync(
        db.chat_is_channel_member, channel_id, uid
    )
    if not is_member:
        raise HTTPException(status_code=404, detail="チャンネルが見つかりません。")

    queue = await chat_hub.subscribe(channel_id)

    async def event_gen():
        # 長い wait でブロックすると Ctrl+C 時に uvicorn が接続待ちで固まるため、短いチャンクで待機する
        _chunk_sec = 2.0
        _keepalive_sec = 25.0
        _idle_accum = 0.0
        try:
            hello = json.dumps({"channel_id": channel_id}, ensure_ascii=False)
            yield f"event: ready\ndata: {hello}\n\n"
            while True:
                if await request.is_disconnected():
                    break
                try:
                    data = await asyncio.wait_for(queue.get(), timeout=_chunk_sec)
                    _idle_accum = 0.0
                except asyncio.TimeoutError:
                    _idle_accum += _chunk_sec
                    if _idle_accum >= _keepalive_sec:
                        yield ": keepalive\n\n"
                        _idle_accum = 0.0
                    continue
                if data == chat_hub.SSE_SHUTDOWN_SENTINEL:
                    break
                yield f"event: chat\ndata: {data}\n\n"
        finally:
            await chat_hub.unsubscribe(channel_id, queue)

    return StreamingResponse(
        event_gen(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@app.get("/mcp-test/current-time", response_class=HTMLResponse)
async def mcp_test_current_time():
    """MCPツール: 現在時刻"""
    now_str = mcp_tools.get_current_time()
    return HTMLResponse(
        f"<div class='alert alert-info'>現在時刻: <strong>{escape(now_str)}</strong></div>"
    )


@app.get("/mcp-test/read-text-file", response_class=HTMLResponse)
async def mcp_test_read_text_file(path: str = ""):
    """MCPツール: テキストファイル読み取り"""
    try:
        content = mcp_tools.read_text_file(path)
    except ValueError as exc:
        return HTMLResponse(
            f"<div class='alert alert-danger'>{escape(str(exc))}</div>", status_code=400
        )

    preview = content
    if len(preview) > 4000:
        preview = preview[:4000] + "\n\n... (先頭4000文字のみ表示)"

    return HTMLResponse(
        "<div class='alert alert-success'>読み取り成功</div>"
        f"<div><strong>対象:</strong> {escape(path)}</div>"
        f"<pre style='white-space: pre-wrap; margin-top: 0.5rem;'>{escape(preview)}</pre>"
    )


@app.get("/mcp-test/invoice-header-summary", response_class=HTMLResponse)
async def mcp_test_invoice_header_summary(invoice_no: str = ""):
    """MCPツール: 請求ヘッダ主要項目取得"""
    try:
        data = mcp_tools.get_invoice_header_summary(invoice_no)
    except ValueError as exc:
        return HTMLResponse(
            f"<div class='alert alert-danger'>{escape(str(exc))}</div>", status_code=400
        )

    if not data.get("found"):
        return HTMLResponse(
            "<div class='alert alert-warning'>"
            f"{escape(str(data.get('message') or '該当データが見つかりません。'))}"
            "</div>"
        )

    return HTMLResponse(
        "<div class='alert alert-success'>請求ヘッダ取得成功</div>"
        "<table class='table table-bordered table-striped'>"
        "<tbody>"
        f"<tr><th style='width:220px;'>請求書番号</th><td>{escape(str(data.get('請求書番号') or ''))}</td></tr>"
        f"<tr><th>宛名_取引先名</th><td>{escape(str(data.get('宛名_取引先名') or ''))}</td></tr>"
        f"<tr><th>宛名_担当部署</th><td>{escape(str(data.get('宛名_担当部署') or ''))}</td></tr>"
        f"<tr><th>宛名_担当者</th><td>{escape(str(data.get('宛名_担当者') or ''))}</td></tr>"
        f"<tr><th>郵便番号</th><td>{escape(str(data.get('郵便番号') or ''))}</td></tr>"
        f"<tr><th>住所</th><td>{escape(str(data.get('住所') or ''))}</td></tr>"
        "</tbody>"
        "</table>"
    )


@app.get("/mcp-test3/current-time", response_class=HTMLResponse)
async def mcp_test3_current_time():
    """MCPツールをMCPクライアント経由で呼ぶ: 現在時刻"""
    try:
        now_str = await mcp_client.call_mcp_tool_text_async("current_time", {})
    except Exception as exc:
        return HTMLResponse(
            f"<div class='alert alert-danger'>MCP呼び出し失敗: {escape(str(exc))}</div>",
            status_code=500,
        )
    return HTMLResponse(
        f"<div class='alert alert-info'>現在時刻(MCP経由): <strong>{escape(now_str)}</strong></div>"
    )


@app.get("/mcp-test3/read-text-file", response_class=HTMLResponse)
async def mcp_test3_read_text_file(path: str = ""):
    """MCPツールをMCPクライアント経由で呼ぶ: テキスト読取"""
    try:
        content = await mcp_client.call_mcp_tool_text_async("read_text", {"path": path})
    except Exception as exc:
        return HTMLResponse(
            f"<div class='alert alert-danger'>MCP呼び出し失敗: {escape(str(exc))}</div>",
            status_code=500,
        )
    preview = content
    if len(preview) > 4000:
        preview = preview[:4000] + "\n\n... (先頭4000文字のみ表示)"
    return HTMLResponse(
        "<div class='alert alert-success'>読み取り成功(MCP経由)</div>"
        f"<div><strong>対象:</strong> {escape(path)}</div>"
        f"<pre style='white-space: pre-wrap; margin-top: 0.5rem;'>{escape(preview)}</pre>"
    )


@app.get("/mcp-test3/invoice-header-summary", response_class=HTMLResponse)
async def mcp_test3_invoice_header_summary(invoice_no: str = ""):
    """MCPツールをMCPクライアント経由で呼ぶ: 請求ヘッダ主要項目取得"""
    try:
        payload = await mcp_client.call_mcp_tool_text_async(
            "invoice_header_summary", {"invoice_no": invoice_no}
        )
        data = json.loads(payload or "{}")
    except json.JSONDecodeError:
        return HTMLResponse(
            "<div class='alert alert-danger'>MCP応答のJSON解析に失敗しました。</div>",
            status_code=500,
        )
    except Exception as exc:
        return HTMLResponse(
            f"<div class='alert alert-danger'>MCP呼び出し失敗: {escape(str(exc))}</div>",
            status_code=500,
        )

    if not data.get("found"):
        return HTMLResponse(
            "<div class='alert alert-warning'>"
            f"{escape(str(data.get('message') or '該当データが見つかりません。'))}"
            "</div>"
        )

    return HTMLResponse(
        "<div class='alert alert-success'>請求ヘッダ取得成功(MCP経由)</div>"
        "<table class='table table-bordered table-striped'>"
        "<tbody>"
        f"<tr><th style='width:220px;'>請求書番号</th><td>{escape(str(data.get('請求書番号') or ''))}</td></tr>"
        f"<tr><th>宛名_取引先名</th><td>{escape(str(data.get('宛名_取引先名') or ''))}</td></tr>"
        f"<tr><th>宛名_担当部署</th><td>{escape(str(data.get('宛名_担当部署') or ''))}</td></tr>"
        f"<tr><th>宛名_担当者</th><td>{escape(str(data.get('宛名_担当者') or ''))}</td></tr>"
        f"<tr><th>郵便番号</th><td>{escape(str(data.get('郵便番号') or ''))}</td></tr>"
        f"<tr><th>住所</th><td>{escape(str(data.get('住所') or ''))}</td></tr>"
        "</tbody>"
        "</table>"
    )


@app.get("/mcp-test4/generate-invoice-pdf", response_class=HTMLResponse)
async def mcp_test4_generate_invoice_pdf(invoice_no: str = "", output_dir: str = ""):
    """MCPツールをMCPクライアント経由で呼ぶ: 請求書PDF生成（保存型）"""
    data = None
    used_fallback = False
    try:
        with anyio.fail_after(20):
            payload = await mcp_client.call_mcp_tool_text_async(
                "generate_invoice_pdf",
                {"invoice_no": invoice_no, "output_dir": output_dir},
            )
            data = json.loads(payload or "{}")
    except TimeoutError:
        # 現環境では PDF 生成だけ MCP 応答待ちで停止するケースがあるためフォールバック。
        used_fallback = True
        try:
            data = await anyio.to_thread.run_sync(
                mcp_tools.generate_invoice_pdf_file_subprocess, invoice_no, output_dir
            )
        except Exception as exc:
            return HTMLResponse(
                f"<div class='alert alert-danger'>PDF生成失敗: {escape(str(exc))}</div>",
                status_code=500,
            )
    except json.JSONDecodeError:
        return HTMLResponse(
            "<div class='alert alert-danger'>MCP応答のJSON解析に失敗しました。</div>",
            status_code=500,
        )
    except Exception as exc:
        return HTMLResponse(
            f"<div class='alert alert-danger'>MCP呼び出し失敗: {escape(str(exc))}</div>",
            status_code=500,
        )

    if not data.get("ok", False):
        return HTMLResponse(
            "<div class='alert alert-warning'>"
            f"{escape(str(data.get('message') or 'PDF生成に失敗しました。'))}"
            "</div>"
        )

    success_title = "PDF生成に成功しました(MCP経由)"
    if used_fallback:
        success_title = "PDF生成に成功しました(フォールバック経由)"
    return HTMLResponse(
        f"<div class='alert alert-success'>{escape(success_title)}</div>"
        "<table class='table table-bordered table-striped'>"
        "<tbody>"
        f"<tr><th style='width:220px;'>請求番号</th><td>{escape(str(data.get('invoice_no') or ''))}</td></tr>"
        f"<tr><th>ファイル名</th><td>{escape(str(data.get('file_name') or ''))}</td></tr>"
        f"<tr><th>保存先パス</th><td>{escape(str(data.get('file_path') or ''))}</td></tr>"
        f"<tr><th>サイズ(bytes)</th><td>{escape(str(data.get('size_bytes') or ''))}</td></tr>"
        f"<tr><th>メッセージ</th><td>{escape(str(data.get('message') or ''))}</td></tr>"
        "</tbody>"
        "</table>"
    )


@app.get("/hello", response_class=HTMLResponse)
async def hello(name: str = ""):
    """htmx: 画面入力の name を XXX に反映"""
    display_name = name.strip() or "ゲスト"
    return HTMLResponse(
        f"<p id='greeting' class='greeting'>Hello {display_name}さん from FastAPI + htmx!</p>"
    )
