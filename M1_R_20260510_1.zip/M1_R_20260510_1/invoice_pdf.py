"""
請求書 PDF 生成（ReportLab）。
他モジュールから再利用する場合は build_invoice_pdf_bytes / save_invoice_pdf_to_path を利用。
"""
from __future__ import annotations

import io
import logging
import math
import os
import re
import unicodedata
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation
from pathlib import Path

import db

logger = logging.getLogger(__name__)

# 1ページあたりの明細行数（MAX）
DETAIL_ROWS_PER_PAGE = 10

# 送付先「住所」1行目の最大幅（この文字列の描画幅を stringWidth で求め、折り返しの上限にする）
INVOICE_PDF_ADDRESS_LINE1_WIDTH_SAMPLE = (
    "東京都千代田区丸の内1-11-1 パシフィックセンチュリープレイス丸の内"
)

# フッター「下記の口座…」文言の少し上の3行罫線（従来の '-' 連続の置換。解析①: 細長い塗り矩形の連続）
# sample.pdf の幅方向 約168 セグメントを参考
_VECTOR_DASH_H_SEGMENTS = 168
_VECTOR_DASH_SEGMENT_W_PT = 1.35
_VECTOR_DASH_HEIGHT_PT = 0.14

# sample.pdf と同系の TrueType（Windows: meiryo.ttc 内の Meiryo UI / Meiryo UI Bold）
_INVOICE_PDF_FONT_REGULAR = "InvoicePdfMeiryoUI"
_INVOICE_PDF_FONT_BOLD = "InvoicePdfMeiryoUIBold"
_MEIRYO_UI_TTC_SUBFONT_INDEX = 2


def _register_fallback_cjk_font() -> str:
    """Meiryo UI が使えない環境向け: ReportLab 日本語 CID（失敗時 Helvetica）。"""
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.cidfonts import UnicodeCIDFont

    for name in ("HeiseiKakuGo-W5", "HeiseiMin-W3", "MS-Gothic"):
        try:
            pdfmetrics.registerFont(UnicodeCIDFont(name))
            return name
        except Exception:
            continue
    return "Helvetica"


def _register_invoice_pdf_fonts() -> tuple[str, str]:
    """
    PDFs/sample.pdf と同じファミリー（Meiryo UI / Meiryo UI Bold）を登録する。
    Windows の meiryo.ttc・meiryob.ttc のサブフォント index 2 を使用。
    失敗時は通常・太字とも同一のフォールバックフォントを返す。
    """
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont

    reg = _INVOICE_PDF_FONT_REGULAR
    bold = _INVOICE_PDF_FONT_BOLD
    if reg in pdfmetrics.getRegisteredFontNames() and bold in pdfmetrics.getRegisteredFontNames():
        return reg, bold

    windir = Path(os.environ.get("WINDIR", r"C:\Windows"))
    meiryo_ttc = windir / "Fonts" / "meiryo.ttc"
    meiryob_ttc = windir / "Fonts" / "meiryob.ttc"

    try:
        if meiryo_ttc.is_file() and meiryob_ttc.is_file():
            pdfmetrics.registerFont(
                TTFont(
                    reg,
                    str(meiryo_ttc),
                    subfontIndex=_MEIRYO_UI_TTC_SUBFONT_INDEX,
                )
            )
            pdfmetrics.registerFont(
                TTFont(
                    bold,
                    str(meiryob_ttc),
                    subfontIndex=_MEIRYO_UI_TTC_SUBFONT_INDEX,
                )
            )
            return reg, bold
    except Exception as e:
        logger.warning("Meiryo UI の登録に失敗しました。フォールバックを使います: %s", e)

    fb = _register_fallback_cjk_font()
    return fb, fb


def _read_invoice_hanko_side_text_lines() -> list[str]:
    """static/files/invoice_hanko_side_text.txt からハンコ左横の印字用行を読む（UTF-8）。無い・読めない場合は空。"""
    text_path = Path(__file__).resolve().parent / "static" / "files" / "invoice_hanko_side_text.txt"
    if not text_path.is_file():
        logger.debug("請求書ハンコ横テキストがありません: %s", text_path)
        return []
    try:
        raw = text_path.read_text(encoding="utf-8")
    except Exception as e:
        logger.warning("請求書ハンコ横テキストを読み込めません: %s", e)
        return []
    lines = [ln.rstrip("\r\n") for ln in raw.splitlines()]
    while lines and lines[-1] == "":
        lines.pop()
    return lines


def _draw_vector_dash_line_filled_rects(
    canvas_obj,
    x_left: float,
    y_bottom: float,
    width: float,
    *,
    fill_color,
    n_segments: int = _VECTOR_DASH_H_SEGMENTS,
    segment_width_pt: float = _VECTOR_DASH_SEGMENT_W_PT,
    segment_height_pt: float = _VECTOR_DASH_HEIGHT_PT,
) -> None:
    """横一列の破線を、細長い塗り矩形を並べて描く（sample.pdf 解析①）。"""
    if width <= 0 or n_segments <= 0:
        return
    pitch = width / float(n_segments)
    sw = min(segment_width_pt, max(0.4, pitch * 0.88))
    canvas_obj.saveState()
    canvas_obj.setFillColor(fill_color)
    for i in range(n_segments):
        x = x_left + i * pitch
        canvas_obj.rect(x, y_bottom, sw, segment_height_pt, stroke=0, fill=1)
    canvas_obj.restoreState()


def _draw_invoice_hanko_top_right(
    canvas_obj,
    page_w: float,
    page_h: float,
    margin_x: float,
    font: str,
    font_bold: str,
    line_h: float,
) -> None:
    """請求書1枚目の右上にハンコ画像（static/files/invoice_hanko.png）と、その左側のテキストを描画する。"""
    from reportlab.lib.utils import ImageReader
    from reportlab.pdfbase import pdfmetrics

    side_lines = _read_invoice_hanko_side_text_lines()

    path = Path(__file__).resolve().parent / "static" / "files" / "invoice_hanko.png"
    if not path.is_file():
        logger.debug("請求書ハンコ画像がありません: %s", path)
        return
    try:
        ir = ImageReader(str(path))
        iw, ih = ir.getSize()
    except Exception as e:
        logger.warning("請求書ハンコ画像を読み込めません: %s", e)
        return
    if iw <= 0 or ih <= 0:
        return
    max_h_pt = 87.0  # 基準 58pt の 1.5 倍
    stamp_h = max_h_pt
    stamp_w = stamp_h * (float(iw) / float(ih))
    x = page_w - margin_x - stamp_w
    top_inset = 32.0
    y = page_h - top_inset - stamp_h

    # 宛先と同じ行送り。1 行目のみ他行より大きめ（+3pt = 13pt。従来 +1pt からさらに +2pt）。全体左寄せ（ハンコ左端から gap を空けたブロック内）
    gap = 13.45  # sample.pdf の「左印字開始位置」へ合わせるため（解析結果）
    fs_addr = 10
    fs_first = fs_addr + 3
    leading = line_h
    max_text_w = 0.0
    for i, line in enumerate(side_lines):
        if not line:
            continue
        fs_use = fs_first if i == 0 else fs_addr
        fn_use = font_bold if i == 0 else font
        max_text_w = max(max_text_w, pdfmetrics.stringWidth(line, fn_use, fs_use))
    text_left_x = x - gap - max_text_w if max_text_w > 0 else x - gap
    # 開始行を宛先1行目相当から 1 行分下げる（前回比 1 行上）
    y_baseline_top = y + stamp_h - 3 - leading
    for i, line in enumerate(side_lines):
        yy = y_baseline_top - i * leading
        if line:
            fs_use = fs_first if i == 0 else fs_addr
            canvas_obj.setFont(font_bold if i == 0 else font, fs_use)
            canvas_obj.drawString(text_left_x, yy, line)

    canvas_obj.drawImage(ir, x, y, width=stamp_w, height=stamp_h, mask="auto")


def _fmt_issue_date_jp(v) -> str:
    """PDF 用に日付を「yyyy年MM月dd日」形式（月日は2桁）で返す。発行日・支払期限など共通。"""
    if v is None:
        return ""
    if hasattr(v, "strftime"):
        return v.strftime("%Y年%m月%d日")
    s = str(v).strip()
    m = re.match(r"^(\d{4})[-/](\d{1,2})[-/](\d{1,2})", s)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        return f"{y}年{mo:02d}月{d:02d}日"
    m2 = re.match(r"^(\d{4})(\d{2})(\d{2})", s)
    if m2:
        return f"{m2.group(1)}年{m2.group(2)}月{m2.group(3)}日"
    return s


def _cell_str(v) -> str:
    if v is None:
        return ""
    return str(v).strip()


def _digits_postal_code_7(v) -> str:
    """
    ヘッダの郵便番号値から最大7桁の数字列を返す。
    「1234567.0」等を数字だけ拾うと8桁になるため、数値として整数化してから桁を取る。
    """
    if v is None:
        return ""
    if isinstance(v, Decimal):
        try:
            if v == v.to_integral_value():
                v = int(v)
            else:
                s = "".join(c for c in str(v) if c.isdigit())
                return s[:7] if len(s) > 7 else s
        except (InvalidOperation, ValueError, OverflowError):
            v = str(v)
    if isinstance(v, bool):
        return ""
    if isinstance(v, int):
        s = str(abs(v))
        return s[:7] if len(s) > 7 else s
    if isinstance(v, float):
        try:
            if math.isfinite(v) and v == int(v) and v >= 0:
                s = str(int(v))
                return s[:7] if len(s) > 7 else s
        except (ValueError, OverflowError):
            pass
    s = unicodedata.normalize("NFKC", _cell_str(v))
    if not s:
        return ""
    s2 = re.sub(r"[\s\u3000\-ー－―（）()〒]", "", s)
    if re.fullmatch(r"\d+\.\d+", s2):
        try:
            f = float(s2)
            if math.isfinite(f) and f == int(f) and f >= 0:
                s2 = str(int(f))
        except ValueError:
            pass
    digits = "".join(c for c in s2 if c.isdigit())
    if len(digits) > 7:
        digits = digits[:7]
    return digits


def _pdf_fill_width_with_char(ch: str, font_name: str, font_size: float, max_width_pt: float) -> str:
    """1文字を横に繰り返し、max_width_pt を埋める（ページ幅いっぱいの罫線風テキスト用）。"""
    from reportlab.pdfbase import pdfmetrics

    if max_width_pt <= 0:
        return ""
    c0 = (ch or "_")[:1] or "_"
    sw = pdfmetrics.stringWidth(c0, font_name, font_size)
    if sw <= 0:
        return c0 * 80
    n = int(max_width_pt / sw)
    return c0 * max(1, n)


def _fmt_detail_tax_cell(d: dict, header: dict) -> str:
    """
    明細1行の消費税列表示。
    当行の消費税区分が非課税・不課税のときは「ー」（セル内中央寄せは TableStyle で指定）。
    それ以外はヘッダ税率から「課税N%」。
    """
    k = str(d.get("消費税区分") or "").strip()
    if k in ("非課税", "不課税"):
        return "\u30fc"  # ー（長音記号）
    return _fmt_detail_tax_rate_label(header)


def _fmt_detail_tax_rate_label(header: dict) -> str:
    """
    請求ヘッダの税率に 100 を掛け、「課税N%」形式で返す。
    主に `消費税率`（DB）。空のとき `消費税` を参照。値は小数税率（例 0.1 → 課税10%）を想定。
    """
    raw = header.get("消費税率")
    if raw is None or (isinstance(raw, str) and not str(raw).strip()):
        raw = header.get("消費税")
    if raw is None:
        return ""
    s = str(raw).strip().replace(",", "")
    if not s:
        return ""
    try:
        x = float(s)
    except ValueError:
        return ""
    pct = int(round(x * 100))
    return f"課税{pct}%"


def _parse_invoice_amount_sum(v) -> float:
    """税抜金額などを合計用に float 化。空・不正は 0。"""
    if v is None:
        return 0.0
    s = str(v).strip().replace(",", "").replace("¥", "").replace("￥", "")
    if not s:
        return 0.0
    try:
        return float(s)
    except ValueError:
        return 0.0


def _fmt_pdf_detail_unit_price(v) -> str:
    """明細・単価：整数部は3桁区切りカンマ、小数点以下は常に3桁（0埋め）。"""
    raw = _cell_str(v)
    if not raw:
        return ""
    s = raw.replace(",", "").replace("¥", "").replace("￥", "")
    try:
        q = Decimal(s).quantize(Decimal("0.001"), rounding=ROUND_HALF_UP)
    except InvalidOperation:
        return raw
    sign = "-" if q < 0 else ""
    q = abs(q)
    ip = int(q)
    rem = (q - Decimal(ip)).quantize(Decimal("0.001"), rounding=ROUND_HALF_UP)
    frac_int = int((rem * 1000).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    frac_s = f"{frac_int:03d}"
    return sign + f"{ip:,}.{frac_s}"


def _fmt_pdf_detail_quantity(v) -> str:
    """明細・数量：整数部はカンマ区切り。小数があるときのみ小数部を表示（末尾0省略）。"""
    raw = _cell_str(v)
    if not raw:
        return ""
    s = raw.replace(",", "").replace("¥", "").replace("￥", "")
    try:
        d = Decimal(s)
    except InvalidOperation:
        return raw
    sign = "-" if d < 0 else ""
    da = abs(d)
    if da == da.to_integral_value(rounding=ROUND_HALF_UP):
        return sign + f"{int(da):,}"
    ip = int(da)
    rem = da - Decimal(ip)
    rem_s = format(rem, "f")
    dec_part = rem_s.split(".", 1)[1].rstrip("0")
    return sign + f"{ip:,}.{dec_part}"


def _fmt_pdf_detail_tax_excluded_amount(v) -> str:
    """明細・税抜金額：整数のみ（四捨五入）、カンマ区切り。小数点以下は表示しない。"""
    raw = _cell_str(v)
    if not raw:
        return ""
    s = raw.replace(",", "").replace("¥", "").replace("￥", "")
    try:
        q = Decimal(s).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    except InvalidOperation:
        return raw
    sign = "-" if q < 0 else ""
    return sign + f"{int(abs(q)):,}"


def _header_consumption_tax_rate_float(header: dict) -> float:
    """ヘッダの消費税率（小数。例 0.1 = 10%）。取得できなければ 0.0。"""
    raw = header.get("消費税率")
    if raw is None or (isinstance(raw, str) and not str(raw).strip()):
        raw = header.get("消費税")
    if raw is None:
        return 0.0
    s = str(raw).strip().replace(",", "")
    if not s:
        return 0.0
    try:
        return float(s)
    except ValueError:
        return 0.0


def _invoice_footer_tax_kbn_from_first_detail(details: list[dict]) -> str:
    """明細1行目の消費税区分（なしは空文字。未設定は外税扱いに回す）。"""
    if not details:
        return ""
    raw = details[0].get("消費税区分")
    if raw is None:
        return ""
    return str(raw).strip()


def _compute_invoice_pdf_footer_tax_grand(
    subtotal: float,
    rate: float,
    tax_kbn: str,
) -> tuple[int, float]:
    """
    フッター消費税額と御請求金額用の合計。端数は最終税額を floor（1e-9 は float 誤差用）。
    - 外税・未設定・上記以外: 税 = floor(税抜合計×税率)、請求 = 税抜 + 税
    - 内税: 税抜金額合計を税込とみなし 税 = floor(合計×税率/(1+税率))、請求 = 税込合計
    - 非課税・不課税: 税 = 0、請求 = 税抜合計
    """
    if tax_kbn in ("非課税", "不課税"):
        return 0, subtotal
    if tax_kbn == "内税":
        if rate <= 0 or subtotal <= 0:
            return 0, subtotal
        tax_amt = math.floor(subtotal * rate / (1.0 + rate) + 1e-9)
        return tax_amt, subtotal
    tax_amt = math.floor(subtotal * rate + 1e-9)
    return tax_amt, subtotal + tax_amt


def _invoice_footer_tax_pct_int(header: dict) -> int:
    """明細フッター表の税率表示用パーセント整数（ヘッダ小数税率×100、四捨五入）。"""
    return int(round(_header_consumption_tax_rate_float(header) * 100))


def _fmt_invoice_footer_subtotal_row_label(header: dict, tax_kbn_first_detail: str = "") -> str:
    """
    明細合計ブロックの税抜合計行ラベル。
    明細1行目の消費税区分が非課税・不課税のときは括弧内をそれぞれ固定文言、それ以外は合計（ヘッダ税率×100%）。
    """
    k = (tax_kbn_first_detail or "").strip()
    if k == "非課税":
        return "合計（非課税）"
    if k == "不課税":
        return "合計（不課税）"
    return f"合計（{_invoice_footer_tax_pct_int(header)}%）"


def _fmt_invoice_footer_tax_row_label(header: dict, tax_kbn_first_detail: str = "") -> str:
    """
    明細合計ブロックの消費税行ラベル。
    明細1行目の消費税区分が非課税・不課税のときは括弧内をそれぞれ固定文言、それ以外は消費税（ヘッダ税率×100%）。
    """
    k = (tax_kbn_first_detail or "").strip()
    if k == "非課税":
        return "消費税（非課税）"
    if k == "不課税":
        return "消費税（不課税）"
    return f"消費税（{_invoice_footer_tax_pct_int(header)}%）"


def _fmt_pdf_amount_integer_commas(x: float) -> str:
    """PDF 明細フッター等用の整数＋カンマ表記。"""
    return f"{int(round(x)):,}"


def _sanitize_pdf_filename_segment(s: str, max_len: int = 150) -> str:
    """Windows 等で問題になりやすい文字を置換し、長さを制限する。"""
    s = (s or "").strip()
    s = re.sub(r'[\\/:*?"<>|\r\n\t]', "_", s)
    s = s.strip(" .")
    if len(s) > max_len:
        s = s[:max_len]
    return s


def get_invoice_pdf_filename_from_row(row: dict, invoice_no: str = "") -> str:
    """
    保存用 PDF ファイル名。
    形式: 請求書番号_{宛名_取引先名の値}.pdf
    （宛名_取引先名が空のときは「名称なし」）
    """
    h = row["header"]
    inv_raw = _cell_str(h.get("請求書番号")) or (invoice_no or "").strip()
    meigi = _cell_str(h.get("宛名_取引先名")) or "名称なし"
    part_inv = _sanitize_pdf_filename_segment(inv_raw, max_len=40)
    part_meigi = _sanitize_pdf_filename_segment(meigi, max_len=150)
    return f"{part_inv}_{part_meigi}.pdf"


def get_invoice_pdf_filename(invoice_no: str) -> str | None:
    """DB から取得してファイル名を返す（データが無い場合は None）。"""
    inv = (invoice_no or "").strip()
    if not inv:
        return None
    row = db.fetch_invoice_for_maintenance(inv)
    if not row:
        return None
    return get_invoice_pdf_filename_from_row(row, invoice_no)


def _fmt_postal_code_jp(v) -> str:
    """郵便番号を PDF 用に「〒999-9999」形式で表示する（7桁にできない場合は数字のみ）。"""
    digits = _digits_postal_code_7(v)
    if len(digits) == 7:
        return f"\u3012{digits[:3]}-{digits[3:]}"
    return digits


def _wrap_pdf_text_to_lines(
    text: str,
    font_name: str,
    font_size: float,
    max_width: float,
    max_lines: int,
    *,
    first_line_max_width: float | None = None,
) -> list[str]:
    """
    幅 max_width に収まるよう折り返し、ちょうど max_lines 要素のリストを返す（不足は空文字で埋める）。
    収めきれない場合は最終行を「…」付きで省略する。

    first_line_max_width を指定した場合、先頭行のみその幅（と max_width の小さい方）を上限に分割し、
    2行目以降は従来どおり max_width を使う（送付先住所で1行目をサンプル文字列幅に合わせる用途）。
    """
    from reportlab.pdfbase import pdfmetrics

    def sw(s: str) -> float:
        if not s:
            return 0.0
        return pdfmetrics.stringWidth(s, font_name, font_size)

    raw = (text or "").replace("\r\n", "\n").replace("\r", "\n")
    paras = [p.strip() for p in raw.split("\n")]
    lines_out: list[str] = []
    p_idx = 0
    rest = ""

    def take_next_paragraph() -> bool:
        nonlocal p_idx, rest
        while p_idx < len(paras):
            p = paras[p_idx]
            p_idx += 1
            if p:
                rest = p
                return True
        return False

    use_first_cap = first_line_max_width is not None
    overflow = False
    while len(lines_out) < max_lines:
        if not rest:
            if not take_next_paragraph():
                break
        cap = max_width
        if use_first_cap and len(lines_out) == 0:
            cap = min(float(first_line_max_width), max_width)
        if sw(rest) <= cap:
            lines_out.append(rest)
            rest = ""
            continue
        lo, hi = 1, len(rest)
        best = 1
        while lo <= hi:
            mid = (lo + hi) // 2
            if sw(rest[:mid]) <= cap:
                best = mid
                lo = mid + 1
            else:
                hi = mid - 1
        lines_out.append(rest[:best])
        rest = rest[best:].lstrip()

    if rest or p_idx < len(paras):
        overflow = True

    while len(lines_out) < max_lines:
        lines_out.append("")
    lines_out = lines_out[:max_lines]

    if overflow:
        ell = "…"
        nlast = lines_out[-1]
        last_cap = max_width
        if use_first_cap and max_lines == 1:
            last_cap = min(float(first_line_max_width), max_width)
        while nlast and sw(nlast + ell) > last_cap:
            nlast = nlast[:-1]
        lines_out[-1] = nlast + ell

    return lines_out


def build_invoice_pdf_bytes_from_row(row: dict) -> bytes:
    """
    fetch 済みの請求データ dict（header / details）から PDF バイト列を生成する。
    """
    from xml.sax.saxutils import escape

    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER, TA_LEFT
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.pdfgen import canvas
    from reportlab.platypus import Paragraph, Table, TableStyle

    header = row["header"]
    details = row["details"] or []

    font, font_bold = _register_invoice_pdf_fonts()
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    w, h = A4

    margin_x = 40
    line_h = 14

    # 請求書・御請求金額直下の罫線（「━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━」相当の ━ 繰り返し）
    _INVOICE_RULE_BAR = "\u2501"
    _INVOICE_RULE_REPEAT_COUNT = 30

    # 明細テーブル列幅（pt・5列）：請求内訳は算出後に14/15へ、差分を金額列へ。数量・単価は従来式、消費税は2/3幅
    _avail_tbl = w - 2 * margin_x
    _w_detail_base = 118 * 2
    _rest = max(0.0, _avail_tbl - _w_detail_base)
    _w_mid = _rest / 4.0
    _w_tax = _w_mid * (2.0 / 3.0)
    _w_detail = _w_detail_base + (_w_mid - _w_tax)
    _w_qty = _w_mid * (8.0 / 9.0) * (8.0 / 9.0)
    _w_unit = _w_mid * (10.0 / 9.0) + (_w_mid * (8.0 / 9.0) * (1.0 / 9.0))
    _w_detail_to_amount = _w_detail / 15.0
    _w_detail = _w_detail * (14.0 / 15.0)
    _w_amount = _w_mid + _w_detail_to_amount
    detail_col_widths = [_w_detail, _w_unit, _w_qty, _w_amount, _w_tax]

    # 明細ヘッダ行の背景（淡いグレー）
    _DETAIL_HEADER_BG = colors.HexColor("#e8e8e8")
    _GRID_COLOR = colors.HexColor("#666666")
    _DETAIL_GRID_INNER_W = 0.5
    _DETAIL_GRID_OUTER_W = 1.5  # 明細表の外枠・太線区画（1段太い）
    # 罫線を「透明」に見せる用。PDF では下層の線の上に透明ストロークを重ねても消えないため、地色で上書きする。
    _DETAIL_TABLE_LINE_HIDE = colors.white

    # 明細を 10 行ずつ分割（0件でも1チャンク）
    chunks: list[list[dict]] = []
    if not details:
        chunks = [[]]
    else:
        for i in range(0, len(details), DETAIL_ROWS_PER_PAGE):
            chunks.append(details[i : i + DETAIL_ROWS_PER_PAGE])

    def draw_section2(y: float) -> float:
        """セクション2：送付先（見出しなし。住所・宛名はラベルなし・各2行分を確保）"""
        y -= line_h
        fs = 10
        fs_postal_addr = fs - 2  # 郵便番号・住所のみ 2pt 小さく
        max_text_w = w - 2 * margin_x
        # 送付先ブロックの折り返し幅（全体・1行目サンプル幅とも現行の 2/3）
        _s2 = 2.0 / 3.0
        section2_wrap_w = max_text_w * _s2
        c.setFont(font, fs_postal_addr)
        from reportlab.pdfbase import pdfmetrics

        addr_line1_max_w = (
            pdfmetrics.stringWidth(
                INVOICE_PDF_ADDRESS_LINE1_WIDTH_SAMPLE, font, fs_postal_addr
            )
            * _s2
        )

        y += line_h  # 郵便番号のみ1行分上へ（住所以下の縦位置は維持）
        c.drawString(margin_x, y, _fmt_postal_code_jp(header.get("郵便番号")))
        y -= line_h * 2

        y += line_h  # 住所を1行分上へ（宛名以降の縦位置はループ後に戻す）
        for part in _wrap_pdf_text_to_lines(
            _cell_str(header.get("住所")),
            font,
            fs_postal_addr,
            section2_wrap_w,
            2,
            first_line_max_width=addr_line1_max_w,
        ):
            c.drawString(margin_x, y, part)
            y -= line_h
        y -= line_h

        fs_meigi = fs + 2
        fs_meigi_gocho = max(1.0, fs_meigi - 3)  # 「御中」は取引先名より 3pt 小さく・通常フォント
        _busho = _cell_str(header.get("宛名_担当部署"))
        _tanto = _cell_str(header.get("宛名_担当者"))
        append_gocho_to_meigi = not _busho and not _tanto
        _meigi_only = _cell_str(header.get("宛名_取引先名"))
        # 住所と同じサンプル幅で 1 行目を制限（太字・宛名用フォントサイズで stringWidth）
        meigi_line1_max_w = (
            pdfmetrics.stringWidth(
                INVOICE_PDF_ADDRESS_LINE1_WIDTH_SAMPLE, font_bold, fs_meigi
            )
            * _s2
        )

        if append_gocho_to_meigi:
            gocho_w = pdfmetrics.stringWidth("　御中", font, fs_meigi_gocho)
            wrap_w_meigi = max(0.0, section2_wrap_w - gocho_w)
            meigi_line1_eff = min(meigi_line1_max_w, wrap_w_meigi)
            meigi_parts = _wrap_pdf_text_to_lines(
                _meigi_only,
                font_bold,
                fs_meigi,
                wrap_w_meigi,
                2,
                first_line_max_width=meigi_line1_eff,
            )

            def _meigi_last_nonempty_line_index(parts: list[str]) -> int:
                if len(parts) >= 2 and parts[1].strip():
                    return 1
                if parts and parts[0].strip():
                    return 0
                return -1

            last_li = _meigi_last_nonempty_line_index(meigi_parts)
            if last_li < 0:
                c.setFont(font, fs_meigi_gocho)
                c.drawString(margin_x, y, "　御中")
                y -= line_h
            else:
                for i, part in enumerate(meigi_parts):
                    if i < last_li:
                        c.setFont(font_bold, fs_meigi)
                        c.drawString(margin_x, y, part)
                        y -= line_h
                    elif i == last_li:
                        c.setFont(font_bold, fs_meigi)
                        c.drawString(margin_x, y, part)
                        xa = margin_x + pdfmetrics.stringWidth(part, font_bold, fs_meigi)
                        c.setFont(font, fs_meigi_gocho)
                        c.drawString(xa, y, "　御中")
                        y -= line_h
                    else:
                        continue
        else:
            meigi_line1_eff = min(meigi_line1_max_w, section2_wrap_w)
            for part in _wrap_pdf_text_to_lines(
                _meigi_only,
                font_bold,
                fs_meigi,
                section2_wrap_w,
                2,
                first_line_max_width=meigi_line1_eff,
            ):
                c.setFont(font_bold, fs_meigi)
                c.drawString(margin_x, y, part)
                y -= line_h

        y -= line_h
        c.setFont(font, fs)
        if _tanto:
            c.drawString(margin_x, y, _busho)
            y -= line_h
            c.drawString(margin_x, y, _tanto + "　様")
        else:
            c.drawString(margin_x, y, _busho + ("　御中" if _busho else ""))
            y -= line_h
            c.drawString(margin_x, y, "")
        y -= line_h

        _zairyu = "請求書在中"
        pad = 5
        fs_zairyu = fs + 3
        _shift5 = 5 * pdfmetrics.stringWidth("\u3000", font_bold, fs_zairyu)
        _zw = pdfmetrics.stringWidth(_zairyu, font_bold, fs_zairyu)
        box_w = _zw + 2 * pad
        box_h = fs_zairyu + 2 * pad
        box_bottom = y - box_h
        box_left = margin_x + _shift5
        c.setStrokeColor(colors.black)
        c.setLineWidth(1)
        c.rect(box_left, box_bottom, box_w, box_h, stroke=1, fill=0)
        c.setFont(font_bold, fs_zairyu)
        c.drawString(box_left + pad, box_bottom + pad + 2, _zairyu)

        return box_bottom - line_h * 0.8

    def draw_section3(y: float) -> float:
        """セクション3：請求書ヘッダ情報（先頭に請求書タイトル・区切り線・挨拶文）"""
        from reportlab.pdfbase import pdfmetrics

        max_text_w = w - 2 * margin_x

        # 請求書在中の下〜請求書ラベルまでの縦余白（1行分削減済み）
        y -= line_h * 2

        inv_no = _cell_str(header.get("請求書番号"))
        fs_meta = 10
        fs_box = fs_meta - 1
        _hdr_rule_w = pdfmetrics.stringWidth(
            _INVOICE_RULE_BAR * _INVOICE_RULE_REPEAT_COUNT, font, fs_meta
        )
        _y_sei_baseline = y - line_h
        _fs_sei_title = 12
        c.setFont(font_bold, _fs_sei_title)
        c.drawString(margin_x, _y_sei_baseline, "請求書")
        _date_jp = _fmt_issue_date_jp(header.get("発行日"))
        _pad_box = 5
        _row_h = line_h + 6
        _lab_w = max(
            pdfmetrics.stringWidth("請求番号", font, fs_box),
            pdfmetrics.stringWidth("発行日", font, fs_box),
        ) + 2 * _pad_box
        _val_w_raw = max(
            pdfmetrics.stringWidth(inv_no, font, fs_box),
            pdfmetrics.stringWidth(_date_jp, font, fs_box),
        ) + 2 * _pad_box
        _val_w = _val_w_raw * 1.2
        _box_w = _lab_w + _val_w
        _box_h = 2 * _row_h
        _y_top_row_baseline = y - 2
        _box_bottom = _y_top_row_baseline - _row_h - _pad_box - 2
        _box_left = w - margin_x - _box_w
        _x_split = _box_left + _lab_w
        _y_split = _box_bottom + _row_h
        c.setStrokeColor(colors.black)
        c.setLineWidth(1)
        c.rect(_box_left, _box_bottom, _box_w, _box_h, stroke=1, fill=0)
        c.line(_x_split, _box_bottom, _x_split, _box_bottom + _box_h)
        c.line(_box_left, _y_split, _box_left + _box_w, _y_split)
        _bl_top = _box_bottom + _row_h + _pad_box + 2
        _bl_bot = _box_bottom + _pad_box + 2
        c.setFont(font, fs_box)
        c.drawString(_box_left + _pad_box, _bl_top, "請求番号")
        c.drawString(_x_split + _pad_box, _bl_top, inv_no)
        c.drawString(_box_left + _pad_box, _bl_bot, "発行日")
        c.drawString(_x_split + _pad_box, _bl_bot, _date_jp)

        _sei_cell_line_y = _y_sei_baseline - 5
        c.setStrokeColor(colors.black)
        c.setLineWidth(1)
        c.line(margin_x, _sei_cell_line_y, margin_x + _hdr_rule_w, _sei_cell_line_y)

        y = _sei_cell_line_y - line_h * 0.9
        c.setFont(font, fs_meta)
        c.drawString(margin_x, y, "下記の通りご請求申し上げます。")
        y -= line_h * 1.15

        fs_k = 10
        c.setFont(font, fs_k)

        def _sw(s: str) -> float:
            return pdfmetrics.stringWidth(s, font, fs_k)

        _lab_w = max(_sw("件名"), _sw("支払期限"))
        _gap = _sw("\u3000") * 2
        x_value_col = margin_x + _lab_w + _gap

        c.drawString(margin_x, y, "件名")
        c.drawString(x_value_col, y, _cell_str(header.get("件名")))
        y -= line_h
        c.drawString(margin_x, y, "支払期限")
        c.drawString(x_value_col, y, _fmt_issue_date_jp(header.get("支払期限")))
        # 支払期限行の次の行位置へ移動 + その直下に空行を1行分挿入（計 line_h×2）
        y -= line_h * 2
        return y - line_h * 1.5

    _detail_hdr_style = ParagraphStyle(
        name="invDetailHdr",
        fontName=font,
        alignment=TA_CENTER,
        leading=10,
        spaceBefore=0,
        spaceAfter=0,
    )

    def _detail_hdr_cell(en: str, ja: str) -> Paragraph:
        return Paragraph(
            f'<font size="5">{escape(en)}</font><br/>'
            f'<font size="9">{escape(ja)}</font>',
            _detail_hdr_style,
        )

    def _detail_header_row() -> list:
        return [
            _detail_hdr_cell("Detail estimate", "請求内訳"),
            _detail_hdr_cell("Unit price", "単価"),
            _detail_hdr_cell("Quantity", "数量"),
            _detail_hdr_cell("Amount", "金額"),
            _detail_hdr_cell("Tax", "消費税"),
        ]

    _detail_item_style = ParagraphStyle(
        name="invDetailItem",
        fontName=font,
        fontSize=6,
        leading=8,
        alignment=TA_LEFT,
        spaceBefore=0,
        spaceAfter=0,
    )

    def _detail_breakdown_cell(d: dict) -> Paragraph:
        """請求項目1 改行 請求項目2 + 半角スペース + 請求項目3"""
        i1 = _cell_str(d.get("請求項目1"))[:500]
        i2 = _cell_str(d.get("請求項目2"))[:300]
        i3 = _cell_str(d.get("請求項目3"))[:300]
        line2 = f"{i2} {i3}".strip()
        if i1 and line2:
            xml = f"{escape(i1)}<br/>{escape(line2)}"
        elif i1:
            xml = escape(i1)
        else:
            xml = escape(line2)
        return Paragraph(xml, _detail_item_style)

    def _detail_body_rows(chunk: list[dict]) -> list[list]:
        rows: list[list] = []
        for d in chunk:
            rows.append(
                [
                    _detail_breakdown_cell(d),
                    _fmt_pdf_detail_unit_price(d.get("単価")),
                    _fmt_pdf_detail_quantity(d.get("数量")),
                    _fmt_pdf_detail_tax_excluded_amount(d.get("税抜金額")),
                    _fmt_detail_tax_cell(d, header),
                ]
            )
        return rows

    def draw_detail_block(
        y_top: float,
        chunk: list[dict],
        *,
        show_footer: bool,
        show_okyu_header: bool,
    ) -> float:
        """1ページ目: 御請求金額＋下線→御請求内容→明細。続ページ: 御請求内容以降のみ。"""
        from reportlab.pdfbase import pdfmetrics

        y = y_top

        subtotal = 0.0
        tax_amt = 0
        grand = 0.0
        kbn = ""
        # 1ページ目ヘッダの「… 也」は全明細合計。表末の合計3行は最終ページのみ。
        if show_footer or show_okyu_header:
            subtotal = sum(_parse_invoice_amount_sum(d.get("税抜金額")) for d in details)
            rate = _header_consumption_tax_rate_float(header)
            kbn = _invoice_footer_tax_kbn_from_first_detail(details)
            tax_amt, grand = _compute_invoice_pdf_footer_tax_grand(subtotal, rate, kbn)

        if show_okyu_header:
            # 同一行の「御請求金額」ラベルと金額＋「也」
            _fs_okyu_row = 12
            _hdr_rule_w = pdfmetrics.stringWidth(
                _INVOICE_RULE_BAR * _INVOICE_RULE_REPEAT_COUNT, font, 10
            )
            _y_okyu_baseline = y
            lbl_okyu = "御請求金額"
            amt_head = _fmt_pdf_amount_integer_commas(grand) + "\u3000" + "也"
            sw_lbl = pdfmetrics.stringWidth(lbl_okyu, font_bold, _fs_okyu_row)
            sw_amt = pdfmetrics.stringWidth(amt_head, font_bold, _fs_okyu_row)
            x_rule_right = margin_x + _hdr_rule_w
            _also_shift_pt = 2.0
            x_amt_head = x_rule_right - sw_amt - _also_shift_pt
            _min_amt_x = margin_x + sw_lbl + pdfmetrics.stringWidth("\u3000", font_bold, _fs_okyu_row)
            if x_amt_head < _min_amt_x:
                x_amt_head = _min_amt_x
            c.setFont(font_bold, _fs_okyu_row)
            c.drawString(margin_x, y, lbl_okyu)
            c.drawString(x_amt_head, y, amt_head)

            _okyu_cell_line_y = _y_okyu_baseline - 5
            c.setStrokeColor(colors.black)
            c.setLineWidth(1)
            c.line(margin_x, _okyu_cell_line_y, margin_x + _hdr_rule_w, _okyu_cell_line_y)

            y = _okyu_cell_line_y - line_h * 0.9

        y -= line_h
        # 「御請求内容」「(JPY)」同一行: 従来 11pt 通常 → 3pt 小さく（太字は未使用のまま）
        fs_detail_title = 8
        _jpy_lbl = "(JPY)"
        c.setFont(font, fs_detail_title)
        sw_jpy = pdfmetrics.stringWidth(_jpy_lbl, font, fs_detail_title)
        _jpy_left_shift_pt = 8.0  # 右寄せ位置から少し左へ
        c.drawString(margin_x, y, "御請求内容")
        c.drawString(w - margin_x - sw_jpy - _jpy_left_shift_pt, y, _jpy_lbl)
        y_below_title = y - 4

        data = [_detail_header_row()] + _detail_body_rows(chunk)
        if show_footer:
            data.extend(
                [
                    ["", _fmt_invoice_footer_subtotal_row_label(header, kbn), "", _fmt_pdf_amount_integer_commas(subtotal), ""],
                    ["", _fmt_invoice_footer_tax_row_label(header, kbn), "", _fmt_pdf_amount_integer_commas(tax_amt), ""],
                    ["", "御請求金額", "", _fmt_pdf_amount_integer_commas(grand), ""],
                ]
            )

        tbl = Table(data, colWidths=detail_col_widths, repeatRows=1)
        style_cmds: list = [
            ("FONTNAME", (0, 1), (-1, -1), font),
            ("FONTSIZE", (0, 1), (-1, -1), 8),
            ("FONTSIZE", (0, 1), (0, -1), 6),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("LEFTPADDING", (0, 0), (-1, -1), 5),
            ("RIGHTPADDING", (0, 0), (-1, -1), 5),
            ("TOPPADDING", (0, 0), (-1, -1), 5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            # ヘッダ行の背景（淡いグレー）
            ("BACKGROUND", (0, 0), (-1, 0), _DETAIL_HEADER_BG),
            # 罫線：内側は従来どおり、外枠だけ太線
            ("INNERGRID", (0, 0), (-1, -1), _DETAIL_GRID_INNER_W, _GRID_COLOR),
            ("BOX", (0, 0), (-1, -1), _DETAIL_GRID_OUTER_W, _GRID_COLOR),
            ("LINEBELOW", (0, 0), (-1, 0), _DETAIL_GRID_OUTER_W, _GRID_COLOR),
        ]
        if len(data) > 1:
            style_cmds.append(("ALIGN", (0, 1), (0, -1), "LEFT"))
            style_cmds.append(("ALIGN", (1, 1), (4, -1), "RIGHT"))
            # 明細部のみ：単価・数量・金額はベース8ptと同じ（以前より2pt大きく）、消費税列は1pt小さく
            if len(chunk) > 0:
                style_cmds.append(("FONTSIZE", (1, 1), (3, len(chunk)), 8))
                style_cmds.append(("FONTSIZE", (4, 1), (4, len(chunk)), 7))
            # 非課税・不課税行の消費税列（ー）は右寄せ一括指定の後に中央へ上書き
            for bi, d in enumerate(chunk):
                k = str(d.get("消費税区分") or "").strip()
                if k in ("非課税", "不課税"):
                    style_cmds.append(("ALIGN", (4, 1 + bi), (4, 1 + bi), "CENTER"))
        style_cmds.append(("ALIGN", (1, 0), (4, 0), "CENTER"))

        if show_footer:
            n = len(data)
            for i in range(3):
                r = n - 3 + i
                # 単価・数量列を結合してラベル表示（右寄せ）
                style_cmds.append(("SPAN", (1, r), (2, r)))
                style_cmds.append(("FONTNAME", (1, r), (2, r), font))
                style_cmds.append(("ALIGN", (1, r), (2, r), "RIGHT"))
                # 金額列・消費税列を結合し、数値は右寄せ
                style_cmds.append(("SPAN", (3, r), (4, r)))
                style_cmds.append(("ALIGN", (3, r), (4, r), "RIGHT"))
                style_cmds.append(("FONTNAME", (3, r), (4, r), font))
                # フッター3行：請求内訳列（0列）の左罫線・下辺を地色で上書き（グリッドの線を消す）
                _hide_w = 2
                style_cmds.append(
                    ("LINEBEFORE", (0, r), (0, r), _hide_w, _DETAIL_TABLE_LINE_HIDE)
                )
                style_cmds.append(
                    ("LINEBELOW", (0, r), (0, r), _hide_w, _DETAIL_TABLE_LINE_HIDE)
                )
            # 御請求金額行のみ 1pt 大きく太字（上のループより後に指定して上書き）
            r_okyu = n - 1
            style_cmds.append(("FONTNAME", (1, r_okyu), (2, r_okyu), font_bold))
            style_cmds.append(("FONTNAME", (3, r_okyu), (4, r_okyu), font_bold))
            style_cmds.append(("FONTSIZE", (1, r_okyu), (4, r_okyu), 9))
            # 合計行の直上（明細末行の下辺）を外枠と同じ太さ
            r_footer0 = n - 3
            if r_footer0 > 0:
                style_cmds.append(
                    (
                        "LINEBELOW",
                        (0, r_footer0 - 1),
                        (-1, r_footer0 - 1),
                        _DETAIL_GRID_OUTER_W,
                        _GRID_COLOR,
                    )
                )

        # 表の最下行の下辺（御請求金額行）：請求内訳列0は不可視、1〜4列のみ太線
        # 列0 の地色が太すぎると列0|列1 の縦線下端が欠けるため、太さは外枠の約1.3倍に抑える
        _bottom_hide_w = max(2.0, _DETAIL_GRID_OUTER_W * 1.3)
        if show_footer:
            style_cmds.append(
                ("LINEBELOW", (1, -1), (4, -1), _DETAIL_GRID_OUTER_W, _GRID_COLOR)
            )
            style_cmds.append(
                ("LINEBELOW", (0, -1), (0, -1), _bottom_hide_w, _DETAIL_TABLE_LINE_HIDE)
            )
        else:
            style_cmds.append(
                ("LINEBELOW", (0, -1), (-1, -1), _DETAIL_GRID_OUTER_W, _GRID_COLOR)
            )

        tbl.setStyle(TableStyle(style_cmds))

        avail_w = w - 2 * margin_x
        tw, th = tbl.wrap(avail_w, h)
        _y_tbl_bottom = y_below_title - th
        tbl.drawOn(c, margin_x, _y_tbl_bottom)
        # 単価列の左（請求内訳|単価の境）をヘッダ〜表下端まで外枠と同じ太さで一本描く
        _x_unit_left = margin_x + detail_col_widths[0]
        c.saveState()
        c.setStrokeColor(_GRID_COLOR)
        c.setLineWidth(_DETAIL_GRID_OUTER_W)
        c.setLineCap(1)
        c.line(_x_unit_left, _y_tbl_bottom, _x_unit_left, y_below_title)
        if show_footer:
            # 御請求金額行：列0 の LINEBELOW(地色) が境界の縦線・下端の取り合いを欠かすため角を補う
            _m = 1.75
            c.line(_x_unit_left, _y_tbl_bottom, _x_unit_left + _m, _y_tbl_bottom)
            c.line(_x_unit_left, _y_tbl_bottom, _x_unit_left, _y_tbl_bottom + _m)
        c.restoreState()
        return _y_tbl_bottom - 12

    # ページフッター（各改ページごと・用紙下端からの固定位置）
    _PAGE_FOOTER_FS = 9
    _PAGE_FOOTER_LEADING = 22.0  # 行間を従来の約2倍（旧 11pt 相当）
    _PAGE_FOOTER_BANK_LEADING = 16.0
    _PAGE_FOOTER_ULINE_LEADING = 11.0
    _PAGE_FOOTER_TRANSFER_FS = _PAGE_FOOTER_FS - 2
    _PAGE_FOOTER_TRANSFER_LEADING = 11.0
    _PAGE_FOOTER_BASELINE_BOTTOM = 38.0 + 2 * line_h
    _PAGE_FOOTER_TRANSFER_NOTICE = (
        "下記の口座までお振込をお願い致します。お振込時の手数料につきましては"
        "お客様ご負担とさせていただいております。予めご了承ください。"
    )
    # 下から積むため「下記の口座…」行の直下は口座枠の上辺（rect）。旧 +2pt だと罫線と密着しやすい。
    _PAGE_FOOTER_CLEARANCE_NOTICE_ABOVE_BANK_RULE_PT = 8.0

    def draw_page_footer() -> None:
        from reportlab.pdfbase import pdfmetrics

        fw = w - 2 * margin_x
        fs = _PAGE_FOOTER_FS
        lead = _PAGE_FOOTER_LEADING
        lead_bank = _PAGE_FOOTER_BANK_LEADING
        y = _PAGE_FOOTER_BASELINE_BOTTOM
        c.setFillColor(colors.black)
        _fw_space = "\u3000"

        _bank_lbl_prefix = "　　"  # 先頭の全角スペース2（各行同じ左位置）
        _bank_lbl_bodies = ("支店名", "口座番号", "名義人")
        fs_bank = fs + 1  # 従来より1pt小さい（fs+2→fs+1）
        _sw = lambda s: pdfmetrics.stringWidth(s, font, fs_bank)
        colon = "："
        # 左揃え：接頭辞→本文は同一X。コロンは最長本文幅で縦に揃え、値列はその右で揃え
        x_bank_text = margin_x + 4.0
        x_body0 = x_bank_text + _sw(_bank_lbl_prefix)
        body_col_w = max(_sw(b) for b in _bank_lbl_bodies)
        x_colon = x_body0 + body_col_w
        x_bank_value = x_colon + _sw(colon + _fw_space)
        v_shiten = _cell_str(header.get("店番"))
        v_koza = _cell_str(header.get("決済口座"))
        v_meigi = _cell_str(header.get("口座名義人"))
        remark_footer_text = _cell_str(header.get("備考欄"))

        def draw_bank_row(body: str, value: str) -> None:
            nonlocal y
            c.setFont(font, fs_bank)
            c.drawString(x_bank_text, y, _bank_lbl_prefix)
            c.drawString(x_body0, y, body)
            c.drawString(x_colon, y, colon)
            c.drawString(x_bank_value, y, value)
            y += lead_bank

        # 下から：名義人 → 口座番号 → 支店名 → 振込案内（支店名の直上）→ 破線罫線4行 → 備考欄（各破線上端と行ベースラインを対応・幅折り返し最大4行・ベクター矩形・解析①）
        # 口座枠エリアを 1 行分下げる（ページ下方向＝y を減らす）。上の振込案内と枠が被らないよう枠上端より上へ y を進める。
        y -= lead
        _y_bank_block_base = y
        _bank_box_pad_top = 3.0
        _bank_box_pad_bottom = 10.0
        _bank_box_h = 3 * lead_bank + _bank_box_pad_top + _bank_box_pad_bottom
        _bank_rect_bottom = _y_bank_block_base - _bank_box_pad_bottom
        c.saveState()
        c.setStrokeColor(colors.black)
        c.setLineWidth(0.5)
        c.rect(
            margin_x,
            _bank_rect_bottom,
            fw,
            _bank_box_h,
            stroke=1,
            fill=0,
        )
        c.restoreState()
        draw_bank_row("名義人", v_meigi)
        draw_bank_row("口座番号", v_koza)
        draw_bank_row("支店名", v_shiten)
        _bank_box_top = _bank_rect_bottom + _bank_box_h
        _c_notice_bank = _PAGE_FOOTER_CLEARANCE_NOTICE_ABOVE_BANK_RULE_PT
        if y < _bank_box_top + _c_notice_bank:
            y = _bank_box_top + _c_notice_bank
        fs_notice = _PAGE_FOOTER_TRANSFER_FS
        lead_notice = _PAGE_FOOTER_TRANSFER_LEADING
        c.setFont(font, fs_notice)
        for ln in _wrap_pdf_text_to_lines(
            _PAGE_FOOTER_TRANSFER_NOTICE, font, fs_notice, fw, 12
        ):
            if not ln:
                continue
            c.drawString(margin_x, y, ln)
            y += lead_notice
        lead_uline = _PAGE_FOOTER_ULINE_LEADING
        y_dash_bottom_0 = y
        for _ in range(4):
            _draw_vector_dash_line_filled_rects(
                c, margin_x, y, fw, fill_color=colors.black
            )
            y += lead_uline
        # 備考欄：幅で折り返し最大4行。各行のベースラインを破線 k=0…3 の上端に 1 対 1 で対応
        # y は下が小さく上が大きい。k=0 が最下段・k=3 が最上段。先頭行（折り返し1行目）を k=3、2行目を k=2…と上から順に対応。
        # 画面・DBは1フィールドのまま。
        # 破線上端より上へオフセット。大きいほど文字が上がる（備考と破線の間にわずかな余白を取る）
        _remark_above_dash_pt = 2.2
        _remark_footer_max_lines = 4
        fs_remark_footer = max(1.0, fs - 2.0)
        c.setFont(font, fs_remark_footer)
        _remark_lines = _wrap_pdf_text_to_lines(
            remark_footer_text,
            font,
            fs_remark_footer,
            fw,
            _remark_footer_max_lines,
        )
        _lines_non_empty = [ln for ln in _remark_lines if ln]
        for _j, _ln in enumerate(_lines_non_empty):
            # 先頭行を最上段（k=3）、次行を一段下（k を 1 ずつ減らす）。旧式 _j+4-_n は 2 行目が上に出るため使わない。
            _dash_k = 3 - _j
            if _dash_k < 0:
                _dash_k = 0
            elif _dash_k > 3:
                _dash_k = 3
            _y_dash_bottom_k = y_dash_bottom_0 + _dash_k * lead_uline
            _y_dash_top_k = _y_dash_bottom_k + _VECTOR_DASH_HEIGHT_PT
            _y_ln = _y_dash_top_k + _remark_above_dash_pt
            c.drawString(margin_x, _y_ln, _ln)

    _num_chunk_pages = len(chunks)
    for page_idx, chunk in enumerate(chunks):
        if page_idx > 0:
            c.showPage()
        y = h - 50

        if page_idx == 0:
            y = draw_section2(y)
            y = draw_section3(y)
            _draw_invoice_hanko_top_right(c, w, h, margin_x, font, font_bold, line_h)
        draw_detail_block(
            y,
            chunk,
            show_footer=(page_idx == _num_chunk_pages - 1),
            show_okyu_header=(page_idx == 0),
        )
        draw_page_footer()

    c.save()
    return buf.getvalue()


def build_invoice_pdf_bytes(invoice_no: str) -> bytes | None:
    """
    請求書番号単位で PDF バイト列を生成する。
    データは DB（T1_請求書データ_ヘッダ / 明細）から取得。
    """
    inv = (invoice_no or "").strip()
    if not inv:
        return None
    row = db.fetch_invoice_for_maintenance(inv)
    if not row:
        return None
    return build_invoice_pdf_bytes_from_row(row)


def save_invoice_pdf_to_path(invoice_no: str, output_path: str | Path) -> Path:
    """
    請求書 PDF を指定パスに保存する（サーバー側バッチ等で再利用）。
    """
    p = Path(output_path)
    data = build_invoice_pdf_bytes(invoice_no)
    if not data:
        raise ValueError(f"請求データが見つかりません: {invoice_no}")
    p.write_bytes(data)
    return p.resolve()
