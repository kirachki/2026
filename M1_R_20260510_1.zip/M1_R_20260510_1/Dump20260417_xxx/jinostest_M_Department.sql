CREATE DATABASE  IF NOT EXISTS `jinostest` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `jinostest`;
-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: 10.1.100.30    Database: jinostest
-- ------------------------------------------------------
-- Server version	5.6.51

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `M_Department`
--

LOCK TABLES `M_Department` WRITE;
/*!40000 ALTER TABLE `M_Department` DISABLE KEYS */;
INSERT INTO `M_Department` VALUES (12,'Corp_sales_dev','法人営業本部',NULL,10,1,'2026-04-14 17:12:09',NULL),(13,'Sales_Planning_Manag','営業企画管理部',12,10,1,'2026-04-14 17:12:31',NULL),(14,'Planning_Team','企画管理チーム',13,10,1,'2026-04-14 17:12:50','2026-04-14 17:19:17'),(15,'Support_1_Team','法人営業サポート第1チーム',13,10,1,'2026-04-14 17:13:09','2026-04-14 17:14:11'),(16,'Support_2_Team','法人営業サポート第2チーム',13,10,1,'2026-04-14 17:13:39','2026-04-14 17:14:11'),(17,'Person_sales_dev','個人営業本部',NULL,10,1,'2026-04-14 17:33:24',NULL),(18,'Ad_Sales_Plan','広告営業企画推進部',17,10,1,'2026-04-14 17:33:24',NULL),(20,'P_Planning_Team','企画チーム',18,10,1,'2026-04-14 17:34:40',NULL),(21,'kin_inp_Plan','金融商品企画推進部',17,10,1,'2026-04-15 13:05:50','2026-04-15 13:24:38'),(22,'P_kin_Plan_Team','企画チーム',21,10,1,'2026-04-15 13:05:58',NULL),(23,'Mark_dev','マーケティング本部',NULL,10,1,'2026-04-15 13:43:09',NULL),(24,'M_acct_markting','アカウントマーケティング部',23,10,1,'2026-04-15 13:43:57',NULL),(25,'M_Engment_markting','エンゲージメントマーケティング部',23,10,1,'2026-04-15 13:44:37',NULL),(26,'M_acct_markting_dmy','',24,10,1,'2026-04-15 13:54:22',NULL);
/*!40000 ALTER TABLE `M_Department` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-17 16:07:29
