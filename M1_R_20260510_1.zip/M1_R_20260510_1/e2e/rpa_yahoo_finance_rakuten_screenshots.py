"""
Yahoo!ファイナンス RPA: 銘柄検索 → 株価ページ表示 → スクリーンショット保存。

1. 「楽天銀行」で検索し、東証の楽天銀行（5838）の株価ページを開いて PNG 保存
2. 「楽天グループ」で検索し、東証の楽天グループ（4755）の株価ページを開いて PNG 保存

※ 検索結果のうち、href が /quote/5838.T および /quote/4755.T の銘柄リンクをクリックします
  （米国 OTC の RKUNY 等はスキップされます）。

利用規約・自動アクセスに関する制限は各サイトの規約を確認してください。

ブラウザ・ヘッドレス: e2e/playwright_settings.json（詳細は e2e/README.md）

環境変数（任意）:
  PLAYWRIGHT_SETTINGS_PATH
  PLAYWRIGHT_HEADLESS
  PLAYWRIGHT_BROWSER
"""
from __future__ import annotations

import re
import sys
from pathlib import Path
from urllib.parse import quote

from playwright.sync_api import sync_playwright

_REPO_ROOT = Path(__file__).resolve().parent.parent
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from e2e.playwright_launch_config import launch_browser, load_playwright_options

YAHOO_FINANCE = "https://finance.yahoo.co.jp"

# 検索語 → クリックする東証銘柄コード（.T）
TARGETS: tuple[tuple[str, str, str], ...] = (
    ("楽天銀行", "5838.T", "yahoo_finance_rakuten_bank_5838.png"),
    ("楽天グループ", "4755.T", "yahoo_finance_rakuten_group_4755.png"),
)

OUT_DIR = Path(__file__).resolve().parent / "output"


def _safe_browser_close(browser) -> None:
    try:
        browser.close()
    except BaseException:
        pass


def _search_url(query: str) -> str:
    return f"{YAHOO_FINANCE}/search/?query={quote(query)}"


def _click_quote_link(page, symbol: str) -> None:
    """検索結果ページから /quote/{symbol} へのリンクをクリック（東証を優先）。"""
    path = f"/quote/{symbol}"
    # 相対パス（一般的）
    loc = page.locator(f'a[href="{path}"]')
    if loc.count() == 0:
        loc = page.locator(f'a[href*="{path}"]')
    if loc.count() == 0:
        raise RuntimeError(f"検索結果に {path} へのリンクが見つかりません。")
    loc.first.click()


def _wait_quote_page(page, symbol: str, timeout_ms: int = 45_000) -> None:
    # glob の「.」を誤マッチさせないよう正規表現で待つ
    escaped = re.escape(symbol)
    page.wait_for_url(re.compile(rf".*/quote/{escaped}($|\?|#)"), timeout=timeout_ms)
    page.wait_for_load_state("load", timeout=timeout_ms)
    # 株価周りの描画待ち（networkidle は広告等で終わらないことがある）
    page.locator("main, [role='main'], body").first.wait_for(state="visible", timeout=timeout_ms)


def main() -> int:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    headless, browser_name = load_playwright_options()

    with sync_playwright() as p:
        print("ブラウザを起動しています…", file=sys.stderr)
        browser = launch_browser(p, headless=headless, browser=browser_name)
        try:
            page = browser.new_page(viewport={"width": 1280, "height": 900})
            page.set_default_timeout(45_000)
            page.set_default_navigation_timeout(45_000)

            for query, symbol, filename in TARGETS:
                out_path = OUT_DIR / filename
                print(f"検索: {query} → {symbol} …", file=sys.stderr)
                page.goto(_search_url(query), wait_until="domcontentloaded")
                _click_quote_link(page, symbol)
                _wait_quote_page(page, symbol)
                page.screenshot(path=str(out_path), full_page=True)
                print(f"  保存: {out_path}", file=sys.stderr)

        finally:
            _safe_browser_close(browser)

    print(
        f"OK: {len(TARGETS)} 件保存 (browser={browser_name}, headless={headless})",
        file=sys.stderr,
    )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("\n中断しました。", file=sys.stderr)
        raise SystemExit(130) from None
    except FileNotFoundError as e:
        print(e, file=sys.stderr)
        raise SystemExit(1) from e
    except ValueError as e:
        print(e, file=sys.stderr)
        raise SystemExit(1) from e
