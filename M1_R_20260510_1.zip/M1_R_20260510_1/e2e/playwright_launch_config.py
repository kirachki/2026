"""
Playwright 起動設定（JSON + 環境変数上書き）。

既定の設定ファイル: このファイルと同じディレクトリの playwright_settings.json
別パス: 環境変数 PLAYWRIGHT_SETTINGS_PATH

環境変数（任意・JSON より優先）:
  PLAYWRIGHT_HEADLESS   1/true/yes/on → headless、0/false/no/off → ウィンドウ表示
  PLAYWRIGHT_BROWSER    chromium | chrome | edge | firefox
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

from playwright.sync_api import Browser, Playwright

_E2E_DIR = Path(__file__).resolve().parent
_DEFAULT_SETTINGS_PATH = _E2E_DIR / "playwright_settings.json"
_ALLOWED_BROWSERS = frozenset({"chromium", "chrome", "edge", "firefox"})

# Windows + 本機 Chrome/Edge チャンネルで new_page が固まる事例への緩和（同梱 chromium 推奨）
_WIN_CHANNEL_EXTRA_ARGS = (
    "--disable-gpu",
    "--disable-software-rasterizer",
    "--disable-extensions",
)


def _settings_path() -> Path:
    custom = (os.environ.get("PLAYWRIGHT_SETTINGS_PATH") or "").strip()
    if custom:
        return Path(custom).expanduser().resolve()
    return _DEFAULT_SETTINGS_PATH


def _parse_headless_env(raw: str | None) -> bool | None:
    if raw is None or not str(raw).strip():
        return None
    v = str(raw).strip().lower()
    if v in ("1", "true", "yes", "on"):
        return True
    if v in ("0", "false", "no", "off"):
        return False
    return None


def load_playwright_options() -> tuple[bool, str]:
    """
    (headless, browser) を返す。
    browser は chromium / chrome / edge / firefox（小文字）。
    chromium は Playwright 同梱 Chromium（channel なし）。
    """
    path = _settings_path()
    if not path.is_file():
        raise FileNotFoundError(
            f"Playwright 設定ファイルがありません: {path}\n"
            f"e2e/playwright_settings.json を作成するか、PLAYWRIGHT_SETTINGS_PATH を設定してください。"
        )

    with path.open(encoding="utf-8") as f:
        data = json.load(f)

    if not isinstance(data, dict):
        raise ValueError(f"設定は JSON オブジェクトである必要があります: {path}")

    headless = data.get("headless", True)
    if not isinstance(headless, bool):
        raise ValueError(f'"headless" は true/false である必要があります: {path}')

    browser = str(data.get("browser", "chromium")).strip().lower()
    if browser not in _ALLOWED_BROWSERS:
        raise ValueError(
            f'"browser" は {sorted(_ALLOWED_BROWSERS)} のいずれかにしてください: {path!s}（現在: {browser!r}）'
        )

    ho = _parse_headless_env(os.environ.get("PLAYWRIGHT_HEADLESS"))
    if ho is not None:
        headless = ho

    bo = (os.environ.get("PLAYWRIGHT_BROWSER") or "").strip().lower()
    if bo:
        if bo not in _ALLOWED_BROWSERS:
            raise ValueError(
                f"PLAYWRIGHT_BROWSER は {sorted(_ALLOWED_BROWSERS)} のいずれかにしてください（現在: {bo!r}）"
            )
        browser = bo

    return headless, browser


def launch_browser(p: Playwright, *, headless: bool, browser: str) -> Browser:
    """
    chromium: Playwright 同梱 Chromium（channel なし。Windows では本機 chrome より安定なことが多い）。
    chrome / edge: 本機ブラウザのチャンネル。firefox: Playwright 同梱 Firefox。
    """
    b = browser.strip().lower()
    # 起動待ちが無制限だと環境不備時に固まるため上限を付ける
    _launch_kw: dict = {"headless": headless, "timeout": 60_000}
    if sys.platform == "win32" and b in ("chrome", "edge"):
        _launch_kw["args"] = list(_WIN_CHANNEL_EXTRA_ARGS)

    if b == "chromium":
        return p.chromium.launch(**_launch_kw)
    if b == "firefox":
        return p.firefox.launch(**_launch_kw)
    if b == "chrome":
        return p.chromium.launch(channel="chrome", **_launch_kw)
    if b == "edge":
        return p.chromium.launch(channel="msedge", **_launch_kw)
    raise ValueError(f"未対応の browser: {browser!r}")
