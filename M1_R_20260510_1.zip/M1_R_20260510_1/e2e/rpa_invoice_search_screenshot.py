"""
習熟用 RPA サンプル: ログイン → 請求一覧 → 詳細検索で請求書番号に「26」
→「検索」実行（htmx）→ スクリーンショット保存。

前提: アプリが起動済み（例: uvicorn main:app --reload で http://127.0.0.1:8000）

ブラウザ・ヘッドレス: e2e/playwright_settings.json（詳細は e2e/README.md）

環境変数（任意）:
  PLAYWRIGHT_BASE_URL  既定 http://127.0.0.1:8000
  CRM_PLAYWRIGHT_USER  既定 user01
  CRM_PLAYWRIGHT_PASSWORD  既定 a
  PLAYWRIGHT_SETTINGS_PATH  設定 JSON のパス（既定は e2e/playwright_settings.json）
  PLAYWRIGHT_HEADLESS  JSON より優先（1/true でヘッドレス、0/false でウィンドウ表示）
  PLAYWRIGHT_BROWSER   JSON より優先（chromium / chrome / edge / firefox）
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

from playwright.sync_api import sync_playwright

_REPO_ROOT = Path(__file__).resolve().parent.parent
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from e2e.playwright_launch_config import launch_browser, load_playwright_options

BASE_URL = (os.environ.get("PLAYWRIGHT_BASE_URL") or "http://127.0.0.1:8000").rstrip("/")
USER = os.environ.get("CRM_PLAYWRIGHT_USER") or "user01"
PASSWORD = os.environ.get("CRM_PLAYWRIGHT_PASSWORD") or "a"
INVOICE_NO_PARTIAL = "26"

OUT_DIR = Path(__file__).resolve().parent / "output"
OUT_PNG = OUT_DIR / "invoice_search_partial_26_after_search.png"


def _safe_browser_close(browser) -> None:
    """Ctrl+C 直後の close で二重割り込みや TargetClosedError のノイズを抑える。"""
    try:
        browser.close()
    except BaseException:
        pass


def main() -> int:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    headless, browser_name = load_playwright_options()

    with sync_playwright() as p:
        print("ブラウザを起動しています…", file=sys.stderr)
        browser = launch_browser(p, headless=headless, browser=browser_name)
        try:
            print("ページを作成しています…", file=sys.stderr)
            page = browser.new_page(viewport={"width": 1280, "height": 800})
            page.set_default_timeout(30_000)
            page.set_default_navigation_timeout(30_000)

            page.goto(f"{BASE_URL}/login", wait_until="domcontentloaded")

            page.locator("#userid").fill(USER)
            page.locator("#pwd").fill(PASSWORD)
            # networkidle は常時リクエストがあるページで終わらないことがあるため使わない
            with page.expect_navigation(timeout=30_000, wait_until="load"):
                page.locator('form#login-form button[type="submit"]').click()

            page.goto(
                f"{BASE_URL}/top/invoice-data",
                wait_until="load",
                timeout=30_000,
            )
            page.locator("#ag-detail-search-button").wait_for(
                state="visible", timeout=30_000
            )

            page.locator("#ag-detail-search-button").click()
            page.locator("#search-invoice-no").wait_for(state="visible")
            page.locator("#search-invoice-no").fill(INVOICE_NO_PARTIAL)

            with page.expect_response(
                lambda r: r.request.method == "GET"
                and "/fragment/invoice-data/search" in r.url
            ):
                page.locator("#detail-search-exec").click()

            # 検索結果サマリ・一覧テーブル・警告のいずれか（htmx 差し替え完了）
            page.locator(
                "#search-results-area .ag-search-results-summary, "
                "#search-results-area #dataList, "
                "#search-results-area .alert-warning"
            ).first.wait_for(state="visible", timeout=30_000)

            page.screenshot(path=str(OUT_PNG), full_page=True)
        finally:
            _safe_browser_close(browser)

    print(
        f"OK: {OUT_PNG} (browser={browser_name}, headless={headless})",
        file=sys.stderr,
    )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("\n中断しました。", file=sys.stderr)
        raise SystemExit(130) from None
    except FileNotFoundError as e:
        print(e, file=sys.stderr)
        raise SystemExit(1) from e
    except ValueError as e:
        print(e, file=sys.stderr)
        raise SystemExit(1) from e
