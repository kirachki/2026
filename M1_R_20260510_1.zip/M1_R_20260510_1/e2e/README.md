# Playwright 習熟用（E2E サンプル）

## 動作

### `rpa_yahoo_finance_rakuten_screenshots.py`（Yahoo!ファイナンス・外部サイト）

**CRM の起動は不要です。** Playwright だけで次を実行します。

1. Yahoo!ファイナンスで「楽天銀行」を検索し、東証 **5838** の株価ページへ遷移して `e2e/output/yahoo_finance_rakuten_bank_5838.png` を保存
2. 「楽天グループ」を検索し、東証 **4755** の株価ページへ遷移して `e2e/output/yahoo_finance_rakuten_group_4755.png` を保存

利用規約・スクレイピング可否は [Yahoo!ファイナンス](https://finance.yahoo.co.jp/) の定めに従ってください。

```powershell
python -m e2e.rpa_yahoo_finance_rakuten_screenshots
```

### `rpa_invoice_search_screenshot.py`（CRM 内の請求一覧）

`rpa_invoice_search_screenshot.py` が次を実行します。

1. ログイン（既定: `user01` / `a`、環境変数で変更可）
2. 請求一覧（`/top/invoice-data`）を開く
3. 「検索条件設定」で詳細検索を開き、請求書番号に `26` を入力
4. 詳細検索の「検索」ボタンを押し、htmx で結果エリアが更新されるまで待つ
5. `e2e/output/invoice_search_partial_26_after_search.png` にフルページスクリーンショットを保存

## ブラウザ・ヘッドレス設定（JSON）

`e2e/playwright_settings.json` を編集します。

```json
{
  "headless": true,
  "browser": "chromium"
}
```

| `browser` 値 | 説明 |
|--------------|------|
| `chromium` | **既定。** Playwright 同梱 **Chromium**（`playwright install chromium`）。Windows で本機 Chrome 利用時に「ページを作成」で止まる場合はこちらを推奨 |
| `chrome` | 本機の **Google Chrome**（`channel="chrome"`） |
| `edge` | 本機の **Microsoft Edge**（`channel="msedge"`） |
| `firefox` | Playwright 同梱 **Firefox**（`playwright install firefox` が必要） |

`headless` が `false` のときはブラウザウィンドウを表示します。

別ファイルを使う場合は環境変数 `PLAYWRIGHT_SETTINGS_PATH` に JSON のフルパスを指定します。

### 環境変数で JSON を上書き（任意）

| 変数 | 説明 |
|------|------|
| `PLAYWRIGHT_HEADLESS` | `1` / `true` → ヘッドレス、`0` / `false` → ウィンドウ表示 |
| `PLAYWRIGHT_BROWSER` | `chromium` / `chrome` / `edge` / `firefox` |

## 準備

プロジェクトルートで:

```powershell
pip install -r requirements-dev.txt
```

使うブラウザに応じてブラウザバイナリを入れます。既定の `chromium` なら次で十分です。

```powershell
playwright install chromium
```

`firefox` を使う場合は `playwright install firefox`。`chrome` / `edge` は **OS に該当ブラウザがインストール済み**である必要があります（同梱 Chromium の DL は不要）。

別ターミナルでアプリを起動したままにします。

```powershell
uvicorn main:app --reload --host 127.0.0.1 --port 8000
```

## 実行

**プロジェクトルートをカレント**にして次のいずれかで実行してください（スクリプトがルートを `sys.path` に追加するため、`PYTHONPATH` は不要です）。

```powershell
python -m e2e.rpa_invoice_search_screenshot
```

```powershell
python e2e\rpa_invoice_search_screenshot.py
```

## 環境変数（CRM ログイン・URL）

| 変数 | 説明 |
|------|------|
| `PLAYWRIGHT_BASE_URL` | 既定 `http://127.0.0.1:8000` |
| `CRM_PLAYWRIGHT_USER` | ログイン ID |
| `CRM_PLAYWRIGHT_PASSWORD` | パスワード |

## 注意

- 本番運用では認証情報を環境変数のみにし、既定の平文パスワードに頼らないでください。
- 初回ログインでパスワード変更を求められるユーザーでは失敗します。

## 終わらない・固まるように見えるとき

スクリプトは `wait_for_load_state("networkidle")` を使いません（常時通信のあるページでは **networkidle が永遠に来ない**ことがあるため）。進捗は標準エラーに「ブラウザを起動」「ページを作成」と出ます。

- **「ページを作成」で止まる**: Windows で本機 **Chrome**（`browser: chrome`）と組み合わせると CDP 接続で固まることがあります。既定の **`chromium`** と `playwright install chromium` を使うか、`edge` / `firefox` に切り替えてください（本機 Chrome を使う場合は `headless: false` も切り分けに有効なことがあります）。
- **ログイン後や一覧で止まる**: アプリ（`uvicorn`）が起動しているか、`PLAYWRIGHT_BASE_URL` が合っているか確認してください（タイムアウトは概ね 30 秒）。

## `playwright install` が失敗するとき

ネットワークやプロキシでタイムアウトすることがあります。Firefox を使う場合は `playwright install firefox` を再試行してください。Chrome / Edge は本機ブラウザ利用のため、同梱ブラウザの DL が不要な場合があります。
