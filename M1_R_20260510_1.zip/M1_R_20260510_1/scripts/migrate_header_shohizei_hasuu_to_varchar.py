"""
T1_請求書データ_ヘッダ.消費税端数 を INT から VARCHAR(255) に変更し、
全行を「切捨て」に更新する（アプリの db._header_value_for_persist と整合）。

db.py の _DB_CONFIG と同じ接続を使う。リポジトリルートで:

  python scripts/migrate_header_shohizei_hasuu_to_varchar.py
  python scripts/migrate_header_shohizei_hasuu_to_varchar.py -y   # 確認なし
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "-y",
        "--yes",
        action="store_true",
        help="接続先の確認プロンプトを省略する",
    )
    args = parser.parse_args()

    import db

    cfg = db._DB_CONFIG
    dbname = cfg.get("database", "")
    host = cfg.get("host", "")
    print(f"接続先: host={host} database={dbname}")
    if not args.yes:
        try:
            line = input("このデータベースに ALTER / UPDATE を実行します。続行しますか？ [y/N]: ")
        except EOFError:
            print("中断しました。-y を付けて再実行してください。")
            return 1
        if line.strip().lower() not in ("y", "yes"):
            print("中断しました。")
            return 1

    alter_sql = (
        "ALTER TABLE `T1_請求書データ_ヘッダ` "
        "MODIFY COLUMN `消費税端数` VARCHAR(255) DEFAULT NULL"
    )
    update_sql = "UPDATE `T1_請求書データ_ヘッダ` SET `消費税端数` = %s"
    value = "切捨て"

    conn = db._get_connection()
    try:
        conn.autocommit(True)
        with conn.cursor() as cur:
            print("実行中: ALTER TABLE ... MODIFY COLUMN 消費税端数 ...")
            cur.execute(alter_sql)
            print("実行中: UPDATE ... SET 消費税端数 = '切捨て'")
            cur.execute(update_sql, (value,))
            n = cur.rowcount
        print(f"完了しました。UPDATE 影響行数: {n}")
    except Exception as e:
        print(f"エラー: {e}", file=sys.stderr)
        return 1
    finally:
        conn.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
