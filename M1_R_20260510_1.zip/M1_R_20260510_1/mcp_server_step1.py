"""
ステップ1: シンプルなMCPサーバー

起動例:
  python mcp_server_step1.py
"""
import json

from mcp.server.fastmcp import FastMCP

from mcp_tools import (
    generate_invoice_pdf_file_subprocess,
    get_current_time,
    get_invoice_header_summary,
    read_text_file,
)


mcp = FastMCP("mcp-step1-server")


@mcp.tool()
def current_time() -> str:
    """現在時刻を返すツール。"""
    return get_current_time()


@mcp.tool()
def read_text(path: str) -> str:
    """テキストファイルを返すツール。"""
    return read_text_file(path)


@mcp.tool()
def invoice_header_summary(invoice_no: str) -> dict:
    """
    請求番号で請求ヘッダ主要項目を返すツール。
    返却項目: 宛名_取引先名 / 宛名_担当部署 / 宛名_担当者 / 郵便番号 / 住所
    """
    return get_invoice_header_summary(invoice_no)


@mcp.tool()
def generate_invoice_pdf(invoice_no: str, output_dir: str = "") -> str:
    """
    請求番号を受け取り、請求書PDFをサーバー保存して保存結果を返すツール。
    output_dir はプロジェクト配下の相対パスのみ指定可（未指定時: outputs/invoices）。
    """
    return json.dumps(
        generate_invoice_pdf_file_subprocess(invoice_no, output_dir), ensure_ascii=False
    )


if __name__ == "__main__":
    mcp.run()
