# FastAPI + htmx Hello World サンプル

## 概要

- **FastAPI**: バックエンドAPI
- **htmx**: フロントで「ボタンクリック → サーバーから部分HTML取得 → 表示」を実現

## 実行手順

### 1. 仮想環境の作成（推奨）

```powershell
cd c:\study\CRMs\M1
python -m venv venv

Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

.\venv\Scripts\Activate.ps1
```

### 2. 依存関係のインストール

```powershell
pip install -r requirements.txt
```

### 3. サーバーの起動

```powershell
uvicorn main:app --reload
uvicorn main:app --log-level info
uvicorn main:app --host 0.0.0.0 --port 8000
uvicorn main:app --host 0.0.0.0 --port 8000 --timeout-graceful-shutdown 5

### 4. ブラウザで確認

- ブラウザで *http://127.0.0.1:8000*** を開く
- ブラウザで *http://10.195.18.159:8000/top*** を開く
- ブラウザで *http://192.168.11.14:8000/top*** を開く



- 「Hello を取得」ボタンをクリックすると、その下に「Hello from FastAPI + htmx!」と表示される

## 顧客一覧・メンテナンス

- **顧客一覧**: http://127.0.0.1:8000/top（左メニューから顧客一覧を開き、検索）
- **取引先メンテナンス（新規タブ）**: 一覧の「法人名(漢字)」リンクをクリックすると、**毎回新しいブラウザタブ**で開きます。
  - URL: `/account/maintenance?tenban={店番号}&koza={口座番号}`（`koza` は URL エンコード済みで渡されます）
- **静的ファイル**: 次の順で**最初に存在する**フォルダをマウントします。
  - `/files` … `static/files` → `SamplesCRM/2/...`
  - `/ref3` … `static/ref3` → `SamplesCRM/3/...`
  - メンテ画面は `/ref3/*.css` に依存するため、**`/ref3` がマウントされないとフォームだけ無スタイル**になります（一覧は `/files` のみでも表示できます）。
- **Cursor の Simple Browser**: 表示がおかしい場合は、まず外部ブラウザで同じ URL を開き比較してください。上記の静的マウントが揃っていれば通常は同じ見た目になります。

## 補足

- 開発時は `--reload` でコード変更時に自動再読み込み
- API ドキュメント: http://127.0.0.1:8000/docs
