/**
 * チームチャット UI + SSE（EventSource）
 * htmx で #main-content が差し替わる前に __teamChatTeardown を呼ぶこと。
 */
(function () {
  'use strict';

  var root = null;
  var meUserid = '';
  var meName = '';
  /** 開いているチャンネルで /messages が返した閲覧者 ID（本人判定の基準） */
  var channelViewerUserid = '';
  var channels = [];
  var currentChannelId = null;
  var seenMessageIds = Object.create(null);
  /** selectChannel のメッセージ取得が重なったとき古い応答で DOM を汚さない */
  var channelLoadToken = 0;
  var es = null;
  var filterText = '';
  /** チャンネル既読（updated_at 文字列）を localStorage に保持 */
  var LS_ACK_KEY = 'crm_teamchat_ch_ack_v1';
  /** メンション既読（message id まで見た） */
  /** v2: 初回ベースラインで latest に合わせず 0 からにし、未読メンションで @ を表示できるようにした */
  var LS_MENTION_ACK_KEY = 'crm_teamchat_mention_ack_v2';
  var channelPollTimer = null;
  var CHANNEL_POLL_MS = 30000;
  /** 直近の一覧スナップショット（id -> updated_at）。デスクトップ通知の差分検知用 */
  var lastChannelPollSnapshot = null;
  /** 同上（id -> latest_mention_message_id 文字列）。メンション通知の差分検知用 */
  var lastChannelPollMentionSnapshot = null;
  /** メンション通知アイコン（白 @ ・PNG base64） */
  var TEAMCHAT_MENTION_ICON_DATA_URL =
    'data:image/png;base64,' +
    'iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAARJklEQVR4nO2daXhT15nH/7qSrMWL5AUvGON9CRizxpQkkLKYAGELtCUtJJnSkDYhT2jaSaadIZROEp5Mp00mncyTQLMHQidDKNsEWiAQIA0Oi8F4Axu8Ibxbtmzt23zwiMf2PVf3ypZ0r6z7+3iulmO///Oe97znPUcSBBDqlW/cgfz8cMG1dY4kUJ/t1w8WDR4c/CkIv3yQaHh+8IcQRvUBouGFwWiEMKI3ioYXJiMRAuXzG0TjC5aR2MYnAYjGFz6+2oiTyxANH5pwmRJYPYBo/NCFi+28CkA0fujDZkOfg0CRsQWjAMTRP3bwZkuiAETjjz2YbEoTgGj8sQvJtmIMEOYMEYA4+sc+w20seoAw564AxNEfPgy2tegBwhwKEEd/OOKxuegBwhxRAGGOKIAwRyLO/+GN6AHCHFEAYY4ogDBHFECYIwogzBEFEOaIAghzRAGEOaIAwhxRAGGOKIAwRxRAmCMKIMwRBRDmyPjuQKCRUxJMT47ElEQ1ChJUyIlVIilSjqQoOTQKKZQyCgopBYvDBYPViT6bEwarE7o+Gyo7TKjsMKO604zKDhPsrrG3cz4m6wHuSVBhZV4slubE4t6USChlo3d0vVYnjt/qwZHaHhy9qUenyeGHnvLPmBGAVinD+sIE/GRaIqYmqQP6XU63G4dv6PEfpS0429wX0O8KNCEvgAS1DM/PTsEzM5MRo5AG/fsvtxrxb3+/g33VXUH/bn8QsgKQURJsnpWM38ybAA0Phh/OyfpebD5Wj9puC99d8YmQFEDhODU+XpXjk6vvMNlxtc2EK21GVHaY0W12wGB1osfigMnuQlSEFDEKKaIiKGRoFZicoMbkRDWKEtWcBWZ1urDjnA47vtYhVOLFkBPA0zOT8IeSdCik3gM7N4Dzuj7sq+7GgZpuNPRaR/R9MkqCB9KisSI3Fivz45ClVbC+50itHusP1KHf5hzRdwaTkBGAnJLgrSWZeHJ6otfXdZsd+OOFVrx/pR26Pptf+yABsDRHi+dnp2BBhsbra8vbTVj139fRZBiZ8IJFSAhAKaOwb20eluZoGV/TbrTj9dIWvH2pLSgjb3pyJN5YnIG5adGMr2k22HD/hxV+F6I/EbwAFFIKRx7N9zri/lTWjn880ciLy11fmIDfLUxHcpSc+Ly83YQHP66EwSrM6UDQqWBKAuxencNo/CaDFYs/rcbPvrjF23y7p6ITM94tx5kmA/F5UaIa+9bmQU4F7Mr/USFoAby2IB1rCuKIz041GDB1VzlO1vcGuVd02ox2lOypxlsXWonPF2ZqsG3ehCD3ihuCFcCagjj88jspxGf7qruw7M/VgnKrDpcbW/7WgNdLW4jPX5wzHtOTI4PcK3YEKYC0mAi8tzyb+GzX5Tb88C+1sDmFGbq8cKIR75a109pllATvLc8W3FQgyN3AXQ9nEdO6X9T1YPOxep+TLBIACzI1WJKtxdy0aKTFKBCvlsFoc6K+x4pSXT/21XThdIMB/pDVM0frUZioxndSo4a0T01S49l7k/EGg5fgA8GtAtYXJuDjVTm09upOM+77sMInty+jJNg0PRFbilOQG6dkff21dhP++VQTvqjroT079dgkzJsYQ2t/vbQFL5xopLXnxilx+ckiqOVDnWxLvx3Zb5XB6nRx/jsCiaCmALWcwo75E2ntvVYnVn923SfjP5geg7JNRXhrSSYn4wPAlEQ1Dq8rwPsrsodkGqUSCWamRBHfc+FOP7G9ttuCraebae0pUXL8w9RxnPoTDAQlgJ8Xp2BCTAStfevpJtTpuW2yUBLgtw+m4eSGSZiUoBpRP54oGodjPypAVMTANFSUpEaknPyvYhIAALxzqY2YBPoFQ3DLB4IRQFSEFM/Ppv9jylqN2HmJHlSRUMooHPh+PrY+kDrqn0ObNzEGf34kF1KJBLNTyaO/0+RAfQ9zqtfqdOG1v+to' +
    '7TmxSswQyIpAMEHgT2ckIk41tDtuAJuP1cPpZg9T5JQEn63JxcO5sYyvMdpdOHi9G6caDWjqtUJGSZCuUeDhHC0WZ2tpEfrSHC1+ff945MaRPcnFFubR7+GDKx3YMX8ioiOGBrVr74nD5VYj6/sDjSAEIAHws5nJtPb91d0o1bH/kwHg3eXZXo2/63IbXvqqmVjKtfNyGwriVdj5cBYeGJbb3zp3Anot5NjjWy/u34PZ4cKhG3qsL0wY0v5Ifhz+5RQ9Rgg2gpgC5mdoiNusXJdLG6clYsOUBOIzq9OFdftr8fTReq91fDVdZpTsqcL+mu4h7XJKggQ1eZx4m/8Hs7eyk9aWH69CrJL/8ScIAfxkGj0qLtX14xsde71dfrwKby7OID5zuNz4wee1nMu1bE431h+oxdU2E6fXX7jDzYV/3dxHzC8EunaRC7wLQKuUYXU+Pd/PdfT/8aEM2lrbw4snm3CkVu9Tf2xONzYevsn6usZeKzpMdk6fabA6iaVi0wQQCPIugEWZGlrZttHuwmEOhluWo8WiTPJO4Rd1PXjz25Fl3K60GXGqgby754Gr+/dwtY3uLbhUFwUa3gVQQjDgiVs9sDi8Z8okAH63MJ34zGR34emjt0bVr90VHV6fcwkAB9PWT/cWGoUYA2BRFl0Ah7iM/txY3MOQ6PnPC624bRhdFQ7b6uMix/nfg95CD0C1Sv6rmXkVQHasEhkauhsk5eKH8/Ni+rIRACwOF14vvTParqGm08x4FMzlBi75uIbvIxSsDM8N8AGvAiDtjzcZrGg3eg+ucuOUjFVCn1V1+eXYlhtAD2HUAkBVp8nnCqRIOd3YQtjS5lUAJBde0W5mfd8jhFWDh0+u0dfcI6WXYfPJV/cPgHi2wGjnv6CFVwEUxNN36crb2f+5qxgE0Gly4KtG79G7LygZzh74GgACQFoMfarrEMABU14FkB9P9wBVHd49QHSElHFz5mRDL6d9A64wnTXksgcwnCmEpM8tjjucgYRXAYyPpm/9dpm9j4ppSWrGnb5TDf4rENUqZUQBWBwulHPMFHqIipAiO5buAWrDXQCkKJit6GOql+zZxRb/7a7lE6YnALjS5vtFESVZGkgldNly3egKJLwJgJKAmMJlE0AmYdkIDETt1Z3sASRXiseTp5mLI5j/VxB2Ket7rLgjgBNDvAmAaQ1MWi8PRsuwg9bab2fNHvrCd9Pp9X+A7wFgVISUuGo5yiHXEQx4E4CMoTxaxXKdC9NRbVKmbaQopBTjHoOv08xjUxKIscT/CORCCd4EYLSTRyvbLR9Ms6/Nj1W2y/O0d+sBB9NjceBGF/dpRkZJ8FwxvcytvseKc83+W66OBt4EYHG44CAEU9EsAmDKwMX4cWPlyWnkI+iXWow+nRv46Ywk5BEqkt/8tkUwF0jwugogGZPNA7QypIlj/bSxUpSoRkmWlvjsgg/r/ziVDNvm0s8Ddpkd+OCq953GYMKrAFoIW6Q5sd5r+GsYIv1YpQyphLyCr2yfN4Exz/CtDyng95ZnE0vJtp9pFtTNIbwKgDSfspVJeSvXKmbIEHLloWwtY5oZAC5x9ABbilOwMo++9KvqNGPXZW4l7sGCVwFcJ5RJTUlkE4CRcbfw0UnxI+5LYqSc8UAqMHAEnEuNwaOTE/D7RfRCFYfLjR8fqiPGPXzCqwBI7jw/XuX1Zk83mOsFVuXHIY1wsogNlYzC/u/nIYXhlg+AXNI1nB9OTsBHK7NBWuG+fPa2XzOV/oJXAXxNuGVTTkkY1+AeSMevPe99Z1mWT32IlFM4+IN8zEllvusHAK53MeftKQnw2oKJ2L06h5jfOFKrx46v6SeEhACvAqjTW4i3aK1luBXEwze6PsaM3JJsLV6dn8bp+9M1Cpx6bDIWsggOYA5OC+JVOPPEZLwwZzzxeUWHCRsO1Alm2Tcc3msCv6ynJ0RW5MWyXqTw6y+bGJ/96r5U7FyWRUzmAANnCLcUp+DqU0WYmcKtNHtp' +
    'jhbPFSffde9Tk9R4Z1kWrj5VxOg9buotWLq3hjW9zSe83w+wOj8On38vj9b+vc9v4C/DTukM59NHcrHOS+DX0m/HR+Xt+OZ2P7pMDiRHyzEvLQbrJscjKZI+3/+prB2bWO4hNNpdcLrcrPmKOr0FJburxXsC2ZBTEtzeMpO2Zr7SZsSsd695zbxpFFJcfLLIL/X1L5+9jVfP6WB4sRgR0tGdLS7V9WPVZ9c5HxzhE96nALvLjU8r6HV805IisdLLmhwYqNlb8mn1qLZV7S43Nh+rx/Yzt2F3uXGew3E0b/zXxVbM/6QqJIwPCEAAAPD+VXJU/5u5Exh3DT3c1FvwwEeVPp/UAQbc9PyPq/DOpba7bS+fHdlFzzVdZizZW43n/togmOtfuCAIAVxrN+Hgdfp8PzVJjZcI+fThNPZaMfejSrxwopHTtrDe4sC2r5oxdVc57QDqlw29ePZYPWcjVnaYsel/b2HarnIcv8X/nYW+wnsM4KFwnBplm4poSRSn240Fn1ThHMdf5lDLKawtiMfyXC1mjY9CUqQcEgxk8i63GHG4Vo/9Nd2skXl+vApPFI3D4iwNUqMjEKeSweJwocvsQFWHGaV3+nGkVo8yjgdElmRrcXhdAe3vcwOY80HFiDyYPxCMAADg7aWZeGpGEq29sdeK+z6sQCth8ygUyI1T4vyPC4nVTHsqOvH4wToeejWAIKYADy+ebEIj4V7/dI0CJzdMIi7dhM7EGAWOPFpANP6dPht+cbwh+J0ahKAE0GdzYuPhm8Ta/oJ4VciJIP//s4SkLKLT7cbjh+p4//UxQQkAAE43GvDL4/SLF4GBo2TnNxbi/gne8/ZCYFmOFmefmMy4OfXcXxtY7yAIBoITADBwvHvn5Tbis4kxCpx6fBK2zZ1ArLXnG4WUwhslGTi8rgDxKnKZ2qvndEOWnnwiqCBwMJQE2LksCxsZ6vOAgTsEt33VzOk4eTBYkReLf1+Y7vVm0pfP3sb2M7eD2CvvCFYAwMAtIG8+lIHNs8h3AXgo1fXjt2dv4283e/xy2bOvzE6NwivfTfP6qyYuN/BPJxsZr5PnC0ELwMPmWcn4Q0k66w5hk8GKvRVd2FPRgUqWQ6ajRSmjsG5SPJ6ZlYxZLDuKvVYnNhyoFYynGkxICAAA5qRGY++aXM4VP9WdZpxpMuBMUx/ONhn88sNN9ySosChTg0WZGjyYHsPpho9LLUZsOFCLGwL9QcmQEQAwcJxs+7wJePbeZNY9guG09NtRp7fgZrcFdXoLdH029NucMNpdMNmcsDrdUMkpRMopRMqliIqQIi0mAnnxSuTEKpEbp2Q8lkbC6nThX8/o8PvzdwRXBziYkBKAh6JENXbMn+j1Z+T4wo2Ba2peOt2MmwI4/s1GSArAw9QkNX51XyrWFMT57BH8jdPtxqHrerxyTocrHApIhUJIC8BDglqGdZMS8KPCBNrPtAQaXZ8Nu6914u1LrWge5dV0fDAmBDCYlCg55mdosDBjIFDL9PNtnDanG+XtJhy/1YODN/S4eKefl6Wnv5AAwFgTwWBiFFIUJapRmKhGTqwSqdERSImOQHKkHNERUqjkFJQyCSKkFKwOF8wOF8x2F4x2F1r6bdD12dBssOGW3oKyViPK202CuN7NH7i2zpHwf1dpgDFYnTjX3Me5niDcEORegEjwEAUQ5lDAwFzAd0dEgovH5qIHCHPuCkD0AuHDYFuLHiDMGSIA0QuMfYbbWPQAYQ5NAKIXGLuQbEv0AKIIxh5MNmWcAkQRjB282VKMAcIcrwIQvUDow2ZDVg8giiB04WI7n4w7lusGxhK+DFqfYgDRGwgfX23kcxAoikC4jMQ2ozKmOCUIg9EMSr+MZlEI/OAPb+xXdy4KITj4cxoO6HwuCsI/BDLu+j+KF1Ngsif1VgAAAABJRU5ErkJggg==';
  var channelAckBaselineDone = false;
  var channelMentionBaselineDone = false;
  var lastDesktopNotifyByChannel = Object.create(null);
  var DESKTOP_NOTIFY_THROTTLE_MS = 60000;
  var loadChannelsDebounceTimer = null;
  var globalSearchDocHandler = null;
  var globalSearchDebounceTimer = null;
  /** 現在チャンネルのメンションピッカー用メンバー */
  var mentionRosterList = [];
  var mentionRosterChannelId = null;
  var mentionPickerActive = false;
  var mentionSelectedIdx = 0;
  var mentionFiltered = [];
  var mentionAtIndex = 0;
  var mentionDocHandler = null;
  var mentionImeComposing = false;
  var mentionLastQuery = '';
  var mentionResizeHandler = null;

  function $(id) {
    return document.getElementById(id);
  }

  /** JSON の id と DOM の比較ズレ（number / string）を防ぐ */
  function normalizeChannelId(v) {
    if (v == null || v === '') return null;
    var n = parseInt(String(v), 10);
    return isNaN(n) ? null : n;
  }

  function dtGreater(a, b) {
    return String(a || '').trim() > String(b || '').trim();
  }

  function readAckMap() {
    try {
      var s = localStorage.getItem(LS_ACK_KEY);
      return s ? JSON.parse(s) : {};
    } catch (e) {
      return {};
    }
  }

  function writeAckMap(m) {
    try {
      localStorage.setItem(LS_ACK_KEY, JSON.stringify(m || {}));
    } catch (e) {}
  }

  function setAckStr(cid, updatedAt) {
    var m = readAckMap();
    m[String(cid)] = updatedAt || '';
    writeAckMap(m);
  }

  function getAckStr(cid) {
    var m = readAckMap();
    return String(m[String(cid)] || '').trim();
  }

  function readMentionAckMap() {
    try {
      var s = localStorage.getItem(LS_MENTION_ACK_KEY);
      return s ? JSON.parse(s) : {};
    } catch (e) {
      return {};
    }
  }

  function writeMentionAckMap(m) {
    try {
      localStorage.setItem(LS_MENTION_ACK_KEY, JSON.stringify(m || {}));
    } catch (e) {}
  }

  function setMentionAckStr(cid, messageId) {
    var m = readMentionAckMap();
    m[String(cid)] = String(messageId != null ? messageId : '0');
    writeMentionAckMap(m);
  }

  function getMentionAckStr(cid) {
    var m = readMentionAckMap();
    return String(m[String(cid)] || '').trim();
  }

  function shouldShowMentionBadge(c) {
    if (!channelMentionBaselineDone) return false;
    var cid = normalizeChannelId(c.id);
    if (cid == null) return false;
    if (normalizeChannelId(currentChannelId) === cid) return false;
    var lid = c.latest_mention_message_id;
    if (lid == null || lid === '') return false;
    var ack = getMentionAckStr(cid);
    if (!ack || ack === '') return false;
    var nl = parseInt(String(lid), 10);
    var na = parseInt(String(ack), 10);
    if (isNaN(nl) || isNaN(na)) return false;
    return nl > na;
  }

  function shouldShowNewBadge(c) {
    if (!channelAckBaselineDone) return false;
    var cid = normalizeChannelId(c.id);
    if (cid == null) return false;
    if (normalizeChannelId(currentChannelId) === cid) return false;
    var au = String(c.updated_at || '').trim();
    if (!au) return false;
    var ack = getAckStr(cid);
    if (!ack) return false;
    return dtGreater(au, ack);
  }

  function afterChannelsLoaded() {
    var ack = readAckMap();
    var i;
    var c;
    var cid;
    var key;

    if (!channelAckBaselineDone) {
      for (i = 0; i < channels.length; i++) {
        c = channels[i];
        cid = String(normalizeChannelId(c.id));
        if (!cid) continue;
        if (ack[cid] == null || ack[cid] === '') {
          ack[cid] = c.updated_at || '';
        }
      }
      channelAckBaselineDone = true;
      writeAckMap(ack);

      var mack = readMentionAckMap();
      for (i = 0; i < channels.length; i++) {
        c = channels[i];
        cid = String(normalizeChannelId(c.id));
        if (!cid) continue;
        /* チャンネル既読と違い、メンションは「未確認」を 0 で始める（latest に同期すると未読でも @ が出ない） */
        if (mack[cid] == null || mack[cid] === '') {
          mack[cid] = '0';
        }
      }
      channelMentionBaselineDone = true;
      writeMentionAckMap(mack);
    } else {
      ack = readAckMap();
      var chg = false;
      for (i = 0; i < channels.length; i++) {
        c = channels[i];
        cid = String(normalizeChannelId(c.id));
        if (!cid) continue;
        if (ack[cid] == null) {
          ack[cid] = c.updated_at || '';
          chg = true;
        }
      }
      if (chg) writeAckMap(ack);

      var mack = readMentionAckMap();
      var chgM = false;
      for (i = 0; i < channels.length; i++) {
        c = channels[i];
        cid = String(normalizeChannelId(c.id));
        if (!cid) continue;
        if (mack[cid] == null) {
          mack[cid] = '0';
          chgM = true;
        }
      }
      if (chgM) writeMentionAckMap(mack);
    }

    var cur = normalizeChannelId(currentChannelId);
    if (cur != null) {
      for (i = 0; i < channels.length; i++) {
        c = channels[i];
        if (normalizeChannelId(c.id) === cur && c.updated_at) {
          setAckStr(cur, c.updated_at);
          var lmCur = c.latest_mention_message_id;
          if (lmCur != null && lmCur !== '') {
            setMentionAckStr(cur, lmCur);
          }
          break;
        }
      }
    }

    if (lastChannelPollSnapshot != null) {
      for (i = 0; i < channels.length; i++) {
        c = channels[i];
        cid = normalizeChannelId(c.id);
        if (cid == null) continue;
        if (normalizeChannelId(currentChannelId) === cid) continue;
        key = String(cid);
        var prev = lastChannelPollSnapshot[key];
        if (!c.updated_at || prev == null || prev === '') continue;

        var nl = NaN;
        if (c.latest_mention_message_id != null && c.latest_mention_message_id !== '') {
          nl = parseInt(String(c.latest_mention_message_id), 10);
        }
        var pm = NaN;
        var prevM =
          lastChannelPollMentionSnapshot != null ? lastChannelPollMentionSnapshot[key] : undefined;
        if (prevM != null && prevM !== '') {
          pm = parseInt(String(prevM), 10);
        }

        var mentionInc =
          lastChannelPollMentionSnapshot != null &&
          !isNaN(nl) &&
          nl > 0 &&
          (isNaN(pm) || nl > pm);

        var updated = dtGreater(c.updated_at, prev);

        if (mentionInc) {
          maybeDesktopNotifyChannel(c, null, { isMention: true });
        } else if (updated) {
          maybeDesktopNotifyChannel(c);
        }
      }
    }

    var snap = Object.create(null);
    var snapM = Object.create(null);
    for (i = 0; i < channels.length; i++) {
      c = channels[i];
      key = String(normalizeChannelId(c.id));
      if (key) {
        snap[key] = c.updated_at || '';
        var lm = c.latest_mention_message_id;
        snapM[key] = lm != null && lm !== '' ? String(lm) : '';
      }
    }
    lastChannelPollSnapshot = snap;
    lastChannelPollMentionSnapshot = snapM;
  }

  /**
   * Windows + Chrome は Notification.icon に data URL が効かないことが多い。
   * 同一オリジンの PNG を fetch→blob URL で渡すと表示されやすい。
   */
  function postDesktopNotification(title, body, tag, cid, isMention) {
    function bindClick(n) {
      n.onclick = function () {
        try {
          window.focus();
        } catch (e) {}
        selectChannel(cid);
        try {
          n.close();
        } catch (e2) {}
      };
    }
    function show(iconUrl) {
      var notifOpts = {
        body: body,
        tag: tag,
      };
      if (isMention && iconUrl) {
        notifOpts.icon = iconUrl;
        try {
          notifOpts.badge = iconUrl;
        } catch (eBadge) {}
      }
      var n = new Notification(title, notifOpts);
      bindClick(n);
    }
    try {
      if (!isMention) {
        show('');
        return;
      }
      var origin =
        typeof window !== 'undefined' && window.location && window.location.origin
          ? window.location.origin
          : '';
      if (!origin && typeof document !== 'undefined' && document.location) {
        origin = document.location.origin;
      }
      var pngUrl =
        origin +
        '/files/team-chat-mention-128.png?v=m' +
        String(Math.floor(Date.now() / 3600000));
      fetch(pngUrl, { credentials: 'same-origin', cache: 'no-store' })
        .then(function (r) {
          if (!r.ok) throw new Error('png');
          return r.blob();
        })
        .then(function (blob) {
          var u = URL.createObjectURL(blob);
          show(u);
          setTimeout(function () {
            try {
              URL.revokeObjectURL(u);
            } catch (e) {}
          }, 120000);
        })
        .catch(function () {
          show(resolveMentionNotificationIcon());
        });
    } catch (e) {
      console.warn('team-chat: Notification failed', e);
    }
  }

  function maybeDesktopNotifyChannel(c, optBody, opts) {
    opts = opts || {};
    var isMention = !!opts.isMention;
    if (typeof Notification !== 'function') return;
    if (Notification.permission !== 'granted') return;
    var cid = normalizeChannelId(c.id);
    if (cid == null) return;
    var now = Date.now();
    var last = lastDesktopNotifyByChannel[cid] || 0;
    if (now - last < DESKTOP_NOTIFY_THROTTLE_MS) return;
    lastDesktopNotifyByChannel[cid] = now;
    var title = c.title && String(c.title).trim() ? String(c.title).trim() : 'チャット #' + cid;
    if (isMention) {
      title = '@ ' + title;
    }
    var body =
      optBody != null && String(optBody).trim()
        ? String(optBody).trim()
        : isMention
          ? 'あなたが@メンションされました。'
          : '新着メッセージがあります。';
    var tag = 'crm-teamchat-' + String(cid) + (isMention ? '-mention' : '');
    postDesktopNotification(title, body, tag, cid, isMention);
  }

  /**
   * SSE で他人の投稿を受けたときのデスクトップ通知。
   * 通常メッセージはタブが見えていてフォーカスがあるときは省略。
   * メンションはその限りでない（Chrome / Edge を並べても届くようにする）。
   */
  function maybeDesktopNotifyFromSseMessage(msg) {
    if (typeof document === 'undefined') return;
    if (!msg || typeof Notification !== 'function' || Notification.permission !== 'granted') return;
    if (messageIsFromViewer(msg)) return;
    var cid = normalizeChannelId(currentChannelId);
    if (cid == null) return;
    var ch = channels.filter(function (x) {
      return normalizeChannelId(x.id) === cid;
    })[0];
    if (!ch) return;
    /* mentions が空でも T1_ChatMention 未作成時など本文の @userid で検知 */
    var mentionMe = notificationIsMentionForViewer(msg);

    if (!mentionMe) {
      var winFocused =
        typeof document.hasFocus === 'function' ? document.hasFocus() : true;
      if (document.visibilityState !== 'hidden' && winFocused) return;
    }
    var rawBody = msg.body != null ? String(msg.body) : '';
    var previewOneLine = rawBody
      .replace(/\r\n|\r|\n/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    var preview = previewOneLine;
    if (preview.length > 160) preview = preview.slice(0, 160) + '…';
    if (!preview) preview = '新着メッセージがあります。';

    var body;
    if (mentionMe) {
      var senderName = String(
        msg.sender_display_name || msg.sender_userid || 'メンバー'
      ).trim();
      var stripIds =
        msg.mentions && msg.mentions.length
          ? msg.mentions.slice()
          : [viewerUseridForMentionMatch()].filter(function (x) {
              return !!normalizeUserid(x);
            });
      var afterStrip = stripAtTokensForUserids(rawBody, stripIds);
      afterStrip = afterStrip.replace(/\s+/g, ' ').trim();
      if (afterStrip.length > 160) afterStrip = afterStrip.slice(0, 160) + '…';
      if (!afterStrip) {
        body = senderName + ' があなたをメンションしました。';
      } else {
        body = senderName + ' があなたをメンション: ' + afterStrip;
      }
    } else {
      body = preview;
    }

    maybeDesktopNotifyChannel(ch, body, {
      isMention: mentionMe,
    });
  }

  function scheduleDebouncedLoadChannels() {
    if (loadChannelsDebounceTimer) clearTimeout(loadChannelsDebounceTimer);
    loadChannelsDebounceTimer = setTimeout(function () {
      loadChannelsDebounceTimer = null;
      loadChannels();
    }, 2500);
  }

  function syncNotifyButtonUi() {
    var btn = $('ag-chat-btn-notify');
    if (!btn) return;
    if (typeof Notification === 'undefined') {
      btn.style.display = 'none';
      return;
    }
    btn.style.display = '';
    btn.classList.remove('ag-team-chat-notify-on');
    if (Notification.permission === 'granted') {
      btn.title = 'デスクトップ通知は許可されています';
      btn.classList.add('ag-team-chat-notify-on');
      btn.innerHTML = '<i class="fa fa-bell" aria-hidden="true"></i>';
    } else if (Notification.permission === 'denied') {
      btn.title = '通知はブラウザ設定でブロックされています';
      btn.innerHTML = '<i class="fa fa-bell-slash-o" aria-hidden="true"></i>';
    } else {
      btn.title = 'クリックでデスクトップ通知を許可';
      btn.innerHTML = '<i class="fa fa-bell-o" aria-hidden="true"></i>';
    }
  }

  function requestNotifyPermission() {
    if (typeof Notification === 'undefined') {
      alert('このブラウザはデスクトップ通知に対応していません。');
      return;
    }
    function afterPerm(perm) {
      syncNotifyButtonUi();
      if (perm === 'granted') {
        try {
          new Notification('チームチャット', {
            body: '通知のテストです。新着があると同様に表示されます。',
            tag: 'crm-teamchat-test',
          });
        } catch (e) {
          console.warn('team-chat: test Notification failed', e);
          alert(
            '通知の表示に失敗しました。OS の「通知のオン／オフ」やブラウザのサイト設定を確認してください。'
          );
        }
      } else if (perm === 'denied') {
        alert(
          '通知が拒否されました。\nChrome / Edge: アドレスバー左の鍵または i アイコン → このサイトの権限 → 通知 → 許可'
        );
      }
    }
    try {
      var ret = Notification.requestPermission();
      if (ret && typeof ret.then === 'function') {
        ret.then(afterPerm).catch(function () {
          syncNotifyButtonUi();
        });
      } else {
        afterPerm(Notification.permission);
      }
    } catch (e) {
      console.warn('team-chat: requestPermission', e);
    }
  }

  function startChannelListPolling() {
    stopChannelListPolling();
    channelPollTimer = setInterval(function () {
      if (document.visibilityState !== 'visible') return;
      loadChannels();
    }, CHANNEL_POLL_MS);
  }

  function stopChannelListPolling() {
    if (channelPollTimer) {
      clearInterval(channelPollTimer);
      channelPollTimer = null;
    }
  }

  function escapeHtml(s) {
    var d = document.createElement('div');
    d.textContent = s == null ? '' : String(s);
    return d.innerHTML;
  }

  function showErr(el, msg) {
    if (!el) return;
    if (msg) {
      el.textContent = msg;
      el.style.display = 'block';
    } else {
      el.textContent = '';
      el.style.display = 'none';
    }
  }

  function parseJsonSafe(text) {
    try {
      return JSON.parse(text);
    } catch (e) {
      return null;
    }
  }

  function normalizeUserid(s) {
    return String(s == null ? '' : s).trim();
  }

  /**
   * メンション通知アイコン。優先: JS 内蔵 PNG data URL（ネットワーク・パス不問）。
   * フォールバック: /files/team-chat-mention-128.png（同一オリジン）。
   */
  function resolveMentionNotificationIcon() {
    try {
      if (
        typeof TEAMCHAT_MENTION_ICON_DATA_URL !== 'undefined' &&
        TEAMCHAT_MENTION_ICON_DATA_URL
      ) {
        return TEAMCHAT_MENTION_ICON_DATA_URL;
      }
    } catch (e1) {}
    try {
      var o =
        typeof window !== 'undefined' && window.location && window.location.origin
          ? window.location.origin
          : '';
      if (!o && typeof document !== 'undefined' && document.location) {
        o = document.location.origin;
      }
      return o ? o + '/files/team-chat-mention-128.png' : '';
    } catch (e2) {
      return '';
    }
  }

  /**
   * 通知用: 本文中の @userid（該当 id すべて）を除去。改行区切りのメンションも 1 行に潰してから除去。
   */
  function stripAtTokensForUserids(body, userids) {
    var rest = String(body || '')
      .replace(/\r\n|\r|\n/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    if (!userids || !userids.length) return rest;
    var j;
    for (j = 0; j < userids.length; j++) {
      var u = normalizeUserid(userids[j]);
      if (!u) continue;
      var esc = u.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      rest = rest
        .replace(new RegExp('@' + esc + '(?=\\s|$)', 'gi'), ' ')
        .replace(/\s+/g, ' ')
        .trim();
    }
    return rest;
  }

  /** ログイン ID の同一判定（一覧の created_by と meUserid 用） */
  function isSameLoginUser(a, b) {
    var x = normalizeUserid(a);
    var y = normalizeUserid(b);
    if (!x || !y) return false;
    if (x === y) return true;
    try {
      return x.toLowerCase() === y.toLowerCase();
    } catch (e) {
      return false;
    }
  }

  /** SSE 等で is_from_viewer が無いとき: 閲覧者 ID と送信者を比較（DB 正規化と揃えて大小文字のみ許容） */
  function isMeSender(senderUserid) {
    var s = normalizeUserid(senderUserid);
    var m = normalizeUserid(channelViewerUserid || meUserid);
    if (!m || !s) return false;
    if (s === m) return true;
    try {
      return s.toLowerCase() === m.toLowerCase();
    } catch (e) {
      return false;
    }
  }

  /**
   * 本人表示は常に sender_userid と閲覧者（channelViewerUserid / meUserid）の比較のみとする。
   * サーバの is_from_viewer はドライバ・シリアライズの差で誤真になり得るため参照しない。
   */
  function messageIsFromViewer(msg) {
    if (!msg) return false;
    return isMeSender(msg.sender_userid);
  }

  function viewerUseridForMentionMatch() {
    var v = normalizeUserid(meUserid || channelViewerUserid);
    if (v) return v;
    try {
      var el = document.getElementById('ag-chat-bootstrap');
      if (el && el.textContent) {
        var o = JSON.parse(el.textContent.trim());
        if (o && o.userid) return normalizeUserid(o.userid);
      }
    } catch (e1) {}
    try {
      if (root && root.getAttribute('data-me-userid')) {
        return normalizeUserid(root.getAttribute('data-me-userid'));
      }
    } catch (e2) {}
    return '';
  }

  /** msg.mentions に閲覧者自身が含まれるか（デスクトップ通知の @ アイコン用） */
  function messageMentionsViewer(msg) {
    if (!msg || !msg.mentions || !msg.mentions.length) return false;
    var m = viewerUseridForMentionMatch();
    if (!m) return false;
    var i;
    for (i = 0; i < msg.mentions.length; i++) {
      var u = normalizeUserid(msg.mentions[i]);
      if (!u) continue;
      if (u === m) return true;
      try {
        if (u.toLowerCase() === m.toLowerCase()) return true;
      } catch (e) {}
    }
    return false;
  }

  /**
   * 本文中の @トークンを db と同様に列挙し、閲覧者 userid と一致するか（大小無視）。
   * 改行のあるメンションや、mentions 配列が空のときも拾う。
   */
  function mentionTokensIncludeViewer(msg) {
    var viewer = viewerUseridForMentionMatch();
    if (!viewer || !msg || msg.body == null) return false;
    var re = /@([^\s@]+)/g;
    var s = String(msg.body);
    var m;
    while ((m = re.exec(s)) !== null) {
      var tok = normalizeUserid(m[1]);
      if (!tok) continue;
      if (tok === viewer) return true;
      try {
        if (tok.toLowerCase() === viewer.toLowerCase()) return true;
      } catch (e) {}
    }
    return false;
  }

  function notificationIsMentionForViewer(msg) {
    return messageMentionsViewer(msg) || mentionTokensIncludeViewer(msg);
  }

  /** サーバが返した「ログイン中のユーザー ID」のみ渡す（メッセージ送信者を渡さないこと）。 */
  function syncMeUseridFromServer(v) {
    var x = normalizeUserid(v);
    if (!x) return;
    meUserid = x;
    if (root) root.setAttribute('data-me-userid', x);
  }

  function syncMeFromServer() {
    return fetch('/api/chat/me', { credentials: 'same-origin' })
      .then(function (r) {
        if (!r.ok) throw new Error('me');
        return r.json();
      })
      .then(function (data) {
        if (data.userid) {
          meUserid = normalizeUserid(data.userid);
          if (root) root.setAttribute('data-me-userid', meUserid);
        }
        if (data.display_name != null && data.display_name !== '') {
          meName = String(data.display_name).trim();
          if (root) root.setAttribute('data-me-name', meName);
        }
      });
  }

  function readBootstrapFromPage() {
    var el = document.getElementById('ag-chat-bootstrap');
    if (!el || !el.textContent) return;
    try {
      var o = JSON.parse(el.textContent.trim());
      if (o && o.userid) {
        meUserid = normalizeUserid(o.userid);
        if (root) root.setAttribute('data-me-userid', meUserid);
      }
      if (o && o.display_name != null && o.display_name !== '') {
        meName = String(o.display_name).trim();
        if (root) root.setAttribute('data-me-name', meName);
      }
    } catch (e) {
      console.warn('ag-chat-bootstrap parse failed', e);
    }
  }

  function getMentionContext(ta) {
    if (!ta) return null;
    var v = ta.value;
    var pos =
      typeof ta.selectionStart === 'number' ? ta.selectionStart : v.length;
    var i = pos - 1;
    while (i >= 0) {
      var c = v.charAt(i);
      if (c === '\n' || c === ' ' || c === '\t') return null;
      if (c === '@') {
        var chunk = v.slice(i + 1, pos);
        if (chunk.indexOf('@') !== -1) return null;
        return { atIndex: i, query: chunk };
      }
      i--;
    }
    return null;
  }

  function filterMentionMembers(query) {
    var ql = String(query || '').toLowerCase();
    var list = mentionRosterList || [];
    if (!ql) return list.slice();
    return list.filter(function (m) {
      var id = String(m.userid || '').toLowerCase();
      var name = String(m.user_name || '').toLowerCase();
      return id.indexOf(ql) !== -1 || name.indexOf(ql) !== -1;
    });
  }

  function positionMentionPicker(ta) {
    var panel = $('ag-chat-mention-picker');
    if (!panel || !ta) return;
    var rect = ta.getBoundingClientRect();
    var w = Math.min(360, Math.max(220, rect.width));
    panel.style.left = rect.left + 'px';
    panel.style.top = rect.bottom + 4 + 'px';
    panel.style.width = w + 'px';
  }

  function closeMentionPicker() {
    var panel = $('ag-chat-mention-picker');
    if (panel) {
      panel.classList.remove('show');
      panel.innerHTML = '';
    }
    mentionPickerActive = false;
    mentionFiltered = [];
    mentionSelectedIdx = 0;
    mentionAtIndex = 0;
    mentionLastQuery = '';
    if (mentionDocHandler) {
      document.removeEventListener('click', mentionDocHandler, true);
      mentionDocHandler = null;
    }
  }

  function renderMentionPickerItems(ta) {
    var panel = $('ag-chat-mention-picker');
    if (!panel) return;
    panel.innerHTML = '';
    var list = mentionFiltered || [];
    if (list.length === 0) {
      var empty = document.createElement('div');
      empty.className = 'ag-team-chat-mention-empty';
      empty.textContent =
        (mentionRosterList || []).length === 0
          ? 'メンバー一覧を読み込み中か、該当がありません。'
          : '該当するメンバーがありません。';
      panel.appendChild(empty);
      mentionSelectedIdx = 0;
      return;
    }
    if (mentionSelectedIdx >= list.length) mentionSelectedIdx = list.length - 1;
    if (mentionSelectedIdx < 0) mentionSelectedIdx = 0;
    var si;
    for (si = 0; si < list.length; si++) {
      (function (idx, m) {
        var uid = normalizeUserid(m.userid);
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className =
          'ag-team-chat-mention-item' +
          (idx === mentionSelectedIdx ? ' is-active' : '');
        btn.setAttribute('role', 'option');
        btn.setAttribute('aria-selected', idx === mentionSelectedIdx ? 'true' : 'false');
        var line1 = document.createElement('div');
        line1.className = 'uid';
        line1.textContent = '@' + uid;
        btn.appendChild(line1);
        var line2 = document.createElement('div');
        line2.className = 'uname';
        line2.textContent = m.user_name || uid;
        btn.appendChild(line2);
        btn.addEventListener('mousedown', function (ev) {
          ev.preventDefault();
          insertMentionPick(ta, uid);
        });
        panel.appendChild(btn);
      })(si, list[si]);
    }
    var actEl = panel.querySelector('.is-active');
    if (actEl && actEl.scrollIntoView) {
      try {
        actEl.scrollIntoView({ block: 'nearest' });
      } catch (eScroll) {}
    }
  }

  function moveMentionSelection(delta, ta) {
    if (!mentionPickerActive || !mentionFiltered || mentionFiltered.length === 0) {
      return;
    }
    mentionSelectedIdx += delta;
    if (mentionSelectedIdx < 0) mentionSelectedIdx = mentionFiltered.length - 1;
    if (mentionSelectedIdx >= mentionFiltered.length) mentionSelectedIdx = 0;
    renderMentionPickerItems(ta);
    positionMentionPicker(ta);
  }

  function insertMentionPick(ta, userid) {
    if (!ta) return;
    var uid = normalizeUserid(userid);
    if (!uid) return;
    var ctx = getMentionContext(ta);
    if (!ctx) return;
    var start = ctx.atIndex;
    var end =
      typeof ta.selectionStart === 'number' ? ta.selectionStart : start;
    var v = ta.value;
    var before = v.slice(0, start);
    var after = v.slice(end);
    var insert = '@' + uid + ' ';
    ta.value = before + insert + after;
    var newPos = before.length + insert.length;
    ta.selectionStart = newPos;
    ta.selectionEnd = newPos;
    closeMentionPicker();
    try {
      ta.focus();
    } catch (e) {}
  }

  function syncMentionPickerFromInput(ta) {
    if (!ta || mentionImeComposing) return;
    var cid = normalizeChannelId(currentChannelId);
    if (cid == null) {
      closeMentionPicker();
      return;
    }
    var ctx = getMentionContext(ta);
    if (!ctx) {
      closeMentionPicker();
      return;
    }
    mentionAtIndex = ctx.atIndex;
    if (ctx.query !== mentionLastQuery) {
      mentionSelectedIdx = 0;
      mentionLastQuery = ctx.query;
    }
    mentionFiltered = filterMentionMembers(ctx.query);
    mentionPickerActive = true;
    if (mentionSelectedIdx >= mentionFiltered.length) {
      mentionSelectedIdx = Math.max(0, mentionFiltered.length - 1);
    }
    var panel = $('ag-chat-mention-picker');
    if (!panel) return;
    panel.classList.add('show');
    renderMentionPickerItems(ta);
    positionMentionPicker(ta);
    if (!mentionDocHandler) {
      mentionDocHandler = function (ev) {
        var t = ev.target;
        var panelEl = $('ag-chat-mention-picker');
        var inp = $('ag-chat-input');
        if (
          panelEl &&
          t &&
          (panelEl.contains(t) || (inp && inp.contains(t)))
        ) {
          return;
        }
        closeMentionPicker();
      };
      document.addEventListener('click', mentionDocHandler, true);
    }
  }

  function fetchMentionRoster(cid) {
    var ncid = normalizeChannelId(cid);
    if (ncid == null) return;
    fetch('/api/chat/channels/' + ncid + '/members', {
      credentials: 'same-origin',
    })
      .then(function (r) {
        return r.json().then(function (j) {
          if (r.status === 404 || r.status === 403) return null;
          if (!r.ok) return null;
          return j;
        });
      })
      .then(function (data) {
        if (data == null) return;
        if (normalizeChannelId(currentChannelId) !== ncid) return;
        mentionRosterList = data.members || [];
        mentionRosterChannelId = ncid;
        var ta = $('ag-chat-input');
        if (ta && mentionPickerActive) syncMentionPickerFromInput(ta);
      })
      .catch(function () {});
  }

  /**
   * 自分宛 @ メッセージは吹き出しでは @ 行を除いた本文だけ見せる（チャット画面の「改善」）。
   */
  function messageForBubbleRender(msg) {
    if (!msg) return msg;
    if (messageIsFromViewer(msg)) return msg;
    if (!notificationIsMentionForViewer(msg)) return msg;
    var ids =
      msg.mentions && msg.mentions.length
        ? msg.mentions.slice()
        : [viewerUseridForMentionMatch()].filter(function (x) {
            return !!normalizeUserid(x);
          });
    var stripped = stripAtTokensForUserids(msg.body, ids);
    var out = {};
    var k;
    for (k in msg) {
      if (Object.prototype.hasOwnProperty.call(msg, k)) out[k] = msg[k];
    }
    out.body = stripped;
    out.mentions = [];
    return out;
  }

  function fillMessageBubbleBody(bubbleEl, msg) {
    if (!bubbleEl || !msg) return;
    var body = msg.body != null ? String(msg.body) : '';
    var ments = msg.mentions;
    bubbleEl.textContent = '';
    if (!body) return;
    if (!ments || !ments.length) {
      bubbleEl.textContent = body;
      return;
    }
    var uidMatch = {};
    var mi;
    for (mi = 0; mi < ments.length; mi++) {
      var ux = normalizeUserid(ments[mi]);
      if (ux) uidMatch[ux.toLowerCase()] = true;
    }
    var re = /@([^\s@]+)/g;
    var lastIndex = 0;
    var m;
    while ((m = re.exec(body)) !== null) {
      var idx = m.index;
      var tok = (m[1] || '').trim();
      var segEnd = re.lastIndex;
      if (idx > lastIndex) {
        bubbleEl.appendChild(document.createTextNode(body.slice(lastIndex, idx)));
      }
      if (uidMatch[tok.toLowerCase()]) {
        var sp = document.createElement('span');
        sp.className = 'ag-team-chat-msg-mention';
        sp.textContent = '@' + tok;
        bubbleEl.appendChild(sp);
      } else {
        bubbleEl.appendChild(document.createTextNode(body.slice(idx, segEnd)));
      }
      lastIndex = segEnd;
    }
    if (lastIndex < body.length) {
      bubbleEl.appendChild(document.createTextNode(body.slice(lastIndex)));
    }
  }

  function applyMsgToBubbleEl(el, msg) {
    if (!el || !msg) return;
    var isMe = messageIsFromViewer(msg);
    el.className = 'ag-team-chat-msg ' + (isMe ? 'me' : 'other');
    el.setAttribute('data-is-from-viewer', isMe ? '1' : '0');
    el.setAttribute('data-sender-userid', normalizeUserid(msg.sender_userid));
    el.setAttribute(
      'data-sender-display',
      String(msg.sender_display_name || msg.sender_userid || '')
    );
    el.setAttribute('data-created-at', String(msg.created_at || ''));
    var meta = el.querySelector('.ag-team-chat-msg-meta');
    if (meta) {
      var who = isMe ? 'あなた' : (msg.sender_display_name || msg.sender_userid || '');
      meta.textContent = who + ' · ' + formatMsgTime(msg.created_at);
    }
    var bub = el.querySelector('.ag-team-chat-msg-bubble');
    if (bub) {
      var srcMsg = msg;
      if (
        msg &&
        (msg.body === undefined || msg.body === null || msg.body === '') &&
        bub.textContent
      ) {
        srcMsg = {};
        var km;
        for (km in msg) {
          if (Object.prototype.hasOwnProperty.call(msg, km)) srcMsg[km] = msg[km];
        }
        srcMsg.body = bub.textContent;
      }
      fillMessageBubbleBody(bub, messageForBubbleRender(srcMsg));
    }
  }

  function updateExistingMessageBubble(msg) {
    var box = $('ag-chat-messages');
    if (!box || !msg || msg.id == null) return;
    var id = String(msg.id);
    var el = box.querySelector('.ag-team-chat-msg[data-msg-id="' + id + '"]');
    if (!el) return;
    applyMsgToBubbleEl(el, msg);
  }

  /**
   * meUserid が /api/chat/me で更新されたあと、保存済みの sender ID だけで左右を付け直す。
   * （is_from_viewer は使わない。サーバの送信者 ID は data-sender-userid が正とする）
   */
  function refreshAllMessageBubbles() {
    var box = $('ag-chat-messages');
    if (!box) return;
    box.querySelectorAll('.ag-team-chat-msg[data-msg-id]').forEach(function (el) {
      var msg = {
        sender_userid: el.getAttribute('data-sender-userid'),
        sender_display_name: el.getAttribute('data-sender-display'),
        created_at: el.getAttribute('data-created-at'),
        is_from_viewer: undefined,
      };
      applyMsgToBubbleEl(el, msg);
    });
  }

  function closeGlobalSearchResults() {
    var panel = $('ag-chat-global-search-results');
    if (panel) {
      panel.classList.remove('show');
      panel.innerHTML = '';
    }
  }

  function renderGlobalSearchResults(items) {
    var panel = $('ag-chat-global-search-results');
    if (!panel) return;
    panel.innerHTML = '';
    panel.classList.add('show');
    if (!items || items.length === 0) {
      var empty = document.createElement('div');
      empty.className = 'ag-team-chat-global-search-empty';
      empty.setAttribute('role', 'option');
      empty.textContent = '該当するメッセージはありません。';
      panel.appendChild(empty);
      return;
    }
    items.forEach(function (hit) {
      var row = document.createElement('button');
      row.type = 'button';
      row.className = 'ag-team-chat-global-search-hit';
      row.setAttribute('role', 'option');
      var cidHit = normalizeChannelId(hit.channel_id);
      var midHit =
        hit.message_id != null ? parseInt(String(hit.message_id), 10) : NaN;
      var title = document.createElement('div');
      title.className = 'ag-team-chat-global-search-hit-title';
      title.textContent =
        (hit.channel_title && String(hit.channel_title).trim()) ||
        (cidHit != null ? '#' + cidHit : 'チャット');
      var sn = document.createElement('div');
      sn.className = 'ag-team-chat-global-search-hit-snippet';
      sn.textContent = hit.snippet != null ? String(hit.snippet) : '';
      var meta = document.createElement('div');
      meta.className = 'ag-team-chat-global-search-hit-meta';
      var who = hit.sender_display_name
        ? String(hit.sender_display_name)
        : '';
      meta.textContent =
        who + (who ? ' · ' : '') + formatMsgTime(hit.created_at);
      row.appendChild(title);
      row.appendChild(sn);
      row.appendChild(meta);
      row.addEventListener('click', function () {
        closeGlobalSearchResults();
        var inp = $('ag-chat-global-search');
        if (inp) inp.blur();
        if (cidHit != null && !isNaN(midHit)) {
          selectChannel(cidHit, { focusMessageId: midHit });
        }
      });
      panel.appendChild(row);
    });
  }

  function runGlobalSearch(query) {
    var panel = $('ag-chat-global-search-results');
    var qq = (query || '').trim();
    if (qq.length < 2) {
      closeGlobalSearchResults();
      return;
    }
    if (panel) {
      panel.innerHTML =
        '<div class="ag-team-chat-global-search-empty" role="status">検索中…</div>';
      panel.classList.add('show');
    }
    var qs = new URLSearchParams({ q: qq, limit: '30' });
    fetch('/api/chat/search?' + qs.toString(), { credentials: 'same-origin' })
      .then(function (r) {
        return r.json().then(function (j) {
          if (!r.ok) throw new Error(j.detail || '検索に失敗しました');
          return j;
        });
      })
      .then(function (data) {
        renderGlobalSearchResults(data.results || []);
      })
      .catch(function (e) {
        if (!panel) return;
        panel.innerHTML = '';
        panel.classList.add('show');
        var err = document.createElement('div');
        err.className = 'ag-team-chat-global-search-empty';
        err.setAttribute('role', 'alert');
        err.textContent = e.message || String(e);
        panel.appendChild(err);
      });
  }

  function formatMsgTime(isoLike) {
    if (!isoLike) return '';
    var parts = String(isoLike).split(/[\sT]/);
    var datePart = parts[0];
    var timePart = (parts[1] || '').slice(0, 5);
    var today = new Date();
    var y = today.getFullYear();
    var m = String(today.getMonth() + 1).padStart(2, '0');
    var d = String(today.getDate()).padStart(2, '0');
    var todayStr = y + '-' + m + '-' + d;
    if (datePart === todayStr) return timePart;
    if (datePart.length >= 10) return datePart.slice(5, 10).replace('-', '/') + ' ' + timePart;
    return String(isoLike);
  }

  function setSseConnected(on) {
    var pill = $('ag-chat-sse-status');
    if (!pill) return;
    if (on) {
      pill.classList.remove('off');
      pill.textContent = '新着を受信中';
      pill.title = '新着メッセージを自動で受信しています';
    } else {
      pill.classList.add('off');
      pill.textContent = '新着は接続後に届きます';
      pill.title = 'チャットを選ぶと接続され、新着が届きます';
    }
  }

  function disconnectSSE() {
    if (es) {
      try {
        es.close();
      } catch (e) {}
      es = null;
    }
    setSseConnected(false);
  }

  function connectSSE(cid) {
    disconnectSSE();
    if (!cid) return;
    var url = '/api/chat/channels/' + cid + '/events';
    es = new EventSource(url);

    es.addEventListener('open', function () {
      setSseConnected(true);
    });

    es.addEventListener('ready', function () {
      setSseConnected(true);
    });

    es.addEventListener('chat', function (ev) {
      var o = parseJsonSafe(ev.data);
      if (!o) return;
      if (o.type === 'chat_message' && o.message) {
        appendMessageBubble(o.message, true);
        maybeDesktopNotifyFromSseMessage(o.message);
        scheduleDebouncedLoadChannels();
      } else if (o.type === 'members_updated') {
        loadChannels();
      } else if (o.type === 'channel_deleted') {
        var deadId =
          o.channel_id != null ? parseInt(String(o.channel_id), 10) : NaN;
        if (!isNaN(deadId) && deadId === normalizeChannelId(currentChannelId)) {
          selectChannel(null);
        }
        loadChannels();
      }
    });

    es.onerror = function () {
      setSseConnected(false);
      if (es) {
        try {
          es.close();
        } catch (e2) {}
        es = null;
      }
      if (normalizeChannelId(currentChannelId) === cid) {
        setTimeout(function () {
          if (normalizeChannelId(currentChannelId) === cid) connectSSE(cid);
        }, 3500);
      }
    };
  }

  function clearMessagesDom() {
    var box = $('ag-chat-messages');
    if (!box) return;
    box.innerHTML = '';
    var ph = document.createElement('div');
    ph.className = 'ag-team-chat-empty';
    ph.id = 'ag-chat-messages-placeholder';
    ph.textContent = '読み込み中…';
    box.appendChild(ph);
  }

  function removePlaceholder() {
    var ph = $('ag-chat-messages-placeholder');
    if (ph && ph.parentNode) ph.parentNode.removeChild(ph);
  }

  function appendMessageBubble(msg, dedupe) {
    if (!msg || msg.id == null) return;
    var id = String(msg.id);
    if (dedupe && seenMessageIds[id]) {
      updateExistingMessageBubble(msg);
      return;
    }
    seenMessageIds[id] = true;

    removePlaceholder();
    var box = $('ag-chat-messages');
    if (!box) return;

    var wrap = document.createElement('div');
    wrap.setAttribute('data-msg-id', id);

    var bubble = document.createElement('div');
    bubble.className = 'ag-team-chat-msg-bubble';

    var meta = document.createElement('div');
    meta.className = 'ag-team-chat-msg-meta';

    wrap.appendChild(bubble);
    wrap.appendChild(meta);
    applyMsgToBubbleEl(wrap, msg);
    box.appendChild(wrap);

    box.scrollTop = box.scrollHeight;
  }

  function renderChannelList() {
    var list = $('ag-chat-channel-list');
    if (!list) return;
    list.innerHTML = '';
    var q = (filterText || '').trim().toLowerCase();
    var filtered = channels.filter(function (c) {
      if (!q) return true;
      return String(c.title || '').toLowerCase().indexOf(q) !== -1;
    });
    if (filtered.length === 0) {
      var empty = document.createElement('div');
      empty.className = 'ag-team-chat-channel-item';
      empty.style.cursor = 'default';
      empty.textContent = q ? '該当するチャットがありません' : 'チャットがありません。「＋」から作成してください。';
      list.appendChild(empty);
      return;
    }
    filtered.forEach(function (c) {
      var item = document.createElement('div');
      item.className = 'ag-team-chat-channel-item';
      if (normalizeChannelId(currentChannelId) === normalizeChannelId(c.id)) {
        item.classList.add('active');
      }
      item.setAttribute('data-channel-id', String(c.id));
      var body = document.createElement('div');
      body.className = 'ag-team-chat-channel-body';
      var t = document.createElement('div');
      t.className = 'ag-team-chat-channel-title';
      t.textContent = c.title || ('#' + c.id);
      var m = document.createElement('div');
      m.className = 'ag-team-chat-channel-meta';
      m.textContent = c.updated_at || c.created_at || '';
      body.appendChild(t);
      body.appendChild(m);
      item.appendChild(body);
      var showMen = shouldShowMentionBadge(c);
      var showNew = shouldShowNewBadge(c) && !showMen;
      if (showMen || showNew) {
        var nb = document.createElement('button');
        nb.type = 'button';
        nb.setAttribute('data-ag-channel-new-id', String(c.id));
        if (showMen) {
          nb.className =
            'ag-team-chat-channel-new-btn btn-torihiki btn-torihiki--xs btn-torihiki--mention';
          nb.title = 'あなた宛の@メンションがあります（クリックで既読）';
          nb.setAttribute('aria-label', '@メンション');
          nb.innerHTML = '<i class="fa fa-at" aria-hidden="true"></i>';
          nb.addEventListener('click', function (ev) {
            ev.preventDefault();
            ev.stopPropagation();
            var cidN = normalizeChannelId(c.id);
            var lid = c.latest_mention_message_id;
            if (cidN != null && lid != null && lid !== '') {
              setMentionAckStr(cidN, lid);
            }
            var up = String(c.updated_at || '').trim();
            if (cidN != null && up) setAckStr(cidN, up);
            renderChannelList();
          });
        } else {
          nb.className =
            'ag-team-chat-channel-new-btn btn-torihiki btn-torihiki--xs btn-torihiki--search';
          nb.title = '新着メッセージがあります（クリックで既読）';
          nb.setAttribute('aria-label', '新着メッセージ');
          nb.innerHTML = '<i class="fa fa-envelope" aria-hidden="true"></i>';
          nb.addEventListener('click', function (ev) {
            ev.preventDefault();
            ev.stopPropagation();
            var cidN = normalizeChannelId(c.id);
            var up = String(c.updated_at || '').trim();
            if (cidN != null && up) setAckStr(cidN, up);
            renderChannelList();
          });
        }
        item.appendChild(nb);
      }
      if (isSameLoginUser(c.created_by_userid, meUserid)) {
        var delBtn = document.createElement('button');
        delBtn.type = 'button';
        delBtn.className = 'ag-team-chat-channel-delete btn-torihiki btn-torihiki--xs btn-torihiki--danger';
        delBtn.title = 'このチャットを削除';
        delBtn.setAttribute('aria-label', 'このチャットを削除');
        delBtn.innerHTML =
          '<i class="fa fa-trash-o" aria-hidden="true"></i>';
        delBtn.addEventListener('click', function (ev) {
          ev.preventDefault();
          ev.stopPropagation();
          deleteChannelByUser(c);
        });
        item.appendChild(delBtn);
      }
      item.addEventListener('click', function () {
        selectChannel(c.id);
      });
      list.appendChild(item);
    });
  }

  function deleteChannelByUser(c) {
    if (!c || c.id == null) return;
    var name = (c.title || '').trim() || '#' + c.id;
    if (
      !confirm(
        '「' + name + '」を削除しますか？\n参加している全員が閲覧できなくなります。'
      )
    ) {
      return;
    }
    fetch('/api/chat/channels/' + c.id, {
      method: 'DELETE',
      credentials: 'same-origin',
    })
      .then(function (r) {
        return r.json().then(function (j) {
          if (!r.ok) throw new Error(j.detail || '削除に失敗しました');
          return j;
        });
      })
      .then(function () {
        if (normalizeChannelId(currentChannelId) === normalizeChannelId(c.id)) {
          selectChannel(null);
        }
        return loadChannels();
      })
      .catch(function (e) {
        alert(e.message || String(e));
      });
  }

  function loadChannels() {
    return fetch('/api/chat/channels', { credentials: 'same-origin' })
      .then(function (r) {
        if (!r.ok) throw new Error('一覧の取得に失敗しました');
        return r.json();
      })
      .then(function (data) {
        channels = data.channels || [];
        afterChannelsLoaded();
        renderChannelList();
        if (currentChannelId != null) {
          var cur = normalizeChannelId(currentChannelId);
          var still = channels.some(function (c) {
            return normalizeChannelId(c.id) === cur;
          });
          if (!still) {
            selectChannel(null);
          }
        }
      })
      .catch(function (e) {
        console.error(e);
        channels = [];
        renderChannelList();
      });
  }

  function selectChannel(cid, opts) {
    opts = opts || {};
    closeMentionPicker();
    var focusMid =
      opts.focusMessageId != null
        ? parseInt(String(opts.focusMessageId), 10)
        : NaN;
    if (isNaN(focusMid) || focusMid < 1) focusMid = null;

    currentChannelId = normalizeChannelId(cid);
    cid = currentChannelId;
    seenMessageIds = Object.create(null);
    if (cid != null) {
      var chOpen = channels.filter(function (x) {
        return normalizeChannelId(x.id) === cid;
      })[0];
      if (chOpen && chOpen.updated_at) {
        setAckStr(cid, chOpen.updated_at);
      }
      /* 一覧の再取得を待たず、開いた時点の latest_mention_message_id で既読化（@ が消えない抜けの防止） */
      if (
        chOpen &&
        chOpen.latest_mention_message_id != null &&
        chOpen.latest_mention_message_id !== ''
      ) {
        setMentionAckStr(cid, chOpen.latest_mention_message_id);
      }
    }
    renderChannelList();

    var titleEl = $('ag-chat-main-title');
    var ch = channels.filter(function (x) {
      return normalizeChannelId(x.id) === cid;
    })[0];
    if (titleEl) titleEl.textContent = ch ? ch.title || 'チャット' : 'チャット';

    var btnMem = $('ag-chat-btn-members');
    if (btnMem) btnMem.style.display = cid ? 'inline-block' : 'none';

    var composer = $('ag-chat-composer-wrap');
    if (composer) composer.style.display = cid ? 'block' : 'none';

    if (!cid) {
      mentionRosterList = [];
      mentionRosterChannelId = null;
      disconnectSSE();
      channelLoadToken++;
      channelViewerUserid = '';
      var box = $('ag-chat-messages');
      if (box) {
        box.innerHTML =
          '<div class="ag-team-chat-empty" id="ag-chat-messages-placeholder">' +
          '左の一覧からチャットを選ぶか、「＋」で新規チャットを作成してください。</div>';
      }
      return;
    }

    mentionRosterList = [];
    fetchMentionRoster(cid);

    disconnectSSE();
    clearMessagesDom();
    var loadId = ++channelLoadToken;
    var url =
      '/api/chat/channels/' + cid + '/messages?after_id=0';
    if (focusMid != null) {
      url =
        '/api/chat/channels/' +
        cid +
        '/messages?around_message_id=' +
        encodeURIComponent(String(focusMid));
    }
    fetch(url, { credentials: 'same-origin' })
      .then(function (r) {
        if (r.status === 404 || r.status === 403) {
          if (loadId === channelLoadToken && normalizeChannelId(currentChannelId) === cid) {
            selectChannel(null);
            loadChannels();
          }
          return null;
        }
        if (!r.ok) throw new Error('メッセージ取得に失敗');
        return r.json();
      })
      .then(function (data) {
        if (data == null) return;
        if (loadId !== channelLoadToken) return;
        if (normalizeChannelId(currentChannelId) !== cid) return;
        if (data.viewer_userid) syncMeUseridFromServer(data.viewer_userid);
        channelViewerUserid = normalizeUserid(data.viewer_userid || meUserid);
        var msgs = data.messages || [];
        removePlaceholder();
        if (msgs.length === 0) {
          var box = $('ag-chat-messages');
          if (box) {
            var ph = document.createElement('div');
            ph.className = 'ag-team-chat-empty';
            ph.id = 'ag-chat-messages-placeholder';
            ph.textContent = 'まだメッセージがありません。最初の一言を送ってみましょう。';
            box.appendChild(ph);
          }
        } else {
          msgs.forEach(function (m) {
            appendMessageBubble(m, false);
          });
        }
        var box2 = $('ag-chat-messages');
        if (focusMid != null && box2) {
          var hitEl = box2.querySelector(
            '.ag-team-chat-msg[data-msg-id="' + String(focusMid) + '"]'
          );
          if (hitEl) {
            hitEl.classList.add('ag-team-chat-msg--flash');
            hitEl.scrollIntoView({ block: 'center', behavior: 'smooth' });
            setTimeout(function () {
              try {
                hitEl.classList.remove('ag-team-chat-msg--flash');
              } catch (e2) {}
            }, 2200);
          } else if (box2) {
            box2.scrollTop = box2.scrollHeight;
          }
        } else if (box2) {
          box2.scrollTop = box2.scrollHeight;
        }
        if (loadId !== channelLoadToken || normalizeChannelId(currentChannelId) !== cid) return;
        connectSSE(cid);
        /* サーバの latest_mention / 一覧と再同期（既読 @ の取りこぼし防止） */
        loadChannels();
      })
      .catch(function (e) {
        console.error(e);
        if (loadId !== channelLoadToken || normalizeChannelId(currentChannelId) !== cid) return;
        var box = $('ag-chat-messages');
        if (box) {
          box.innerHTML =
            '<div class="ag-team-chat-empty">メッセージを読み込めませんでした。</div>';
        }
        disconnectSSE();
      });
  }

  function sendMessage() {
    closeMentionPicker();
    var cid = currentChannelId;
    var ta = $('ag-chat-input');
    if (!cid || !ta) return;
    var body = (ta.value || '').trim();
    if (!body) return;
    ta.disabled = true;
    fetch('/api/chat/channels/' + cid + '/messages', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ body: body }),
    })
      .then(function (r) {
        return r.json().then(function (j) {
          if (!r.ok) throw new Error(j.detail || '送信に失敗しました');
          return j;
        });
      })
      .then(function (j) {
        ta.value = '';
        if (j.message) appendMessageBubble(j.message, true);
        loadChannels();
      })
      .catch(function (e) {
        alert(e.message || String(e));
      })
      .finally(function () {
        ta.disabled = false;
        ta.focus();
      });
  }

  function openModal(id) {
    var m = $(id);
    if (m) m.classList.add('show');
  }

  function closeModal(id) {
    var m = $(id);
    if (m) m.classList.remove('show');
  }

  function renderUserChecks(container, users, namePrefix) {
    if (!container) return;
    container.innerHTML = '';
    users.forEach(function (u) {
      var row = document.createElement('label');
      row.className = 'ag-team-chat-user-check';
      var cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.value = u.userid;
      cb.name = namePrefix;
      var span = document.createElement('span');
      span.textContent = (u.user_name || u.userid) + ' (' + u.userid + ')';
      row.appendChild(cb);
      row.appendChild(span);
      container.appendChild(row);
    });
  }

  function collectCheckedUserids(container) {
    if (!container) return [];
    var out = [];
    container.querySelectorAll('input[type="checkbox"]').forEach(function (cb) {
      if (cb.checked) out.push(cb.value);
    });
    return out;
  }

  /** 新規チャットモーダル: API で得た候補の全件（検索で絞り込み元） */
  var newMembersPickList = [];
  /** 新規チャットモーダル: チェック状態（非表示に絞った後も POST に反映するため DOM 外も保持） */
  var newMembersCheckedIds = null;

  function matchesNewMemberQuery(u, qLower) {
    if (!qLower) return true;
    var name = String(u.user_name || '').toLowerCase();
    var id = String(u.userid || '').toLowerCase();
    return name.indexOf(qLower) !== -1 || id.indexOf(qLower) !== -1;
  }

  function renderNewMembersFiltered() {
    var container = $('ag-chat-new-members');
    if (!container) return;
    var inp = $('ag-chat-new-members-filter');
    var q = inp ? String(inp.value || '').trim().toLowerCase() : '';
    var list = newMembersPickList.filter(function (u) {
      return matchesNewMemberQuery(u, q);
    });
    container.innerHTML = '';
    if (list.length === 0) {
      var empty = document.createElement('div');
      empty.className = 'ag-team-chat-empty';
      empty.style.fontSize = '13px';
      empty.style.padding = '6px 0';
      empty.textContent =
        newMembersPickList.length === 0
          ? '追加できるユーザーがありません。'
          : '該当するユーザーがありません。';
      container.appendChild(empty);
      return;
    }
    renderUserChecks(container, list, 'newmem');
    if (newMembersCheckedIds) {
      container.querySelectorAll('input[type="checkbox"]').forEach(function (cb) {
        var uid = normalizeUserid(cb.value);
        cb.checked = !!newMembersCheckedIds[uid];
      });
    }
  }

  function getNewMembersSelectedUserids() {
    if (!newMembersCheckedIds) return [];
    return Object.keys(newMembersCheckedIds).filter(function (k) {
      return newMembersCheckedIds[k];
    });
  }

  function openNewChatModal() {
    showErr($('ag-chat-new-err'), '');
    $('ag-chat-new-title').value = '';
    fetch('/api/chat/pick-users', { credentials: 'same-origin' })
      .then(function (r) {
        if (!r.ok) throw new Error('ユーザー一覧の取得に失敗');
        return r.json();
      })
      .then(function (data) {
        newMembersPickList = (data.users || []).slice();
        newMembersCheckedIds = Object.create(null);
        var nf = $('ag-chat-new-members-filter');
        if (nf) nf.value = '';
        renderNewMembersFiltered();
        openModal('ag-chat-modal-new');
      })
      .catch(function (e) {
        alert(e.message || String(e));
      });
  }

  function submitNewChat() {
    var title = ($('ag-chat-new-title').value || '').trim();
    var ids = getNewMembersSelectedUserids();
    showErr($('ag-chat-new-err'), '');
    fetch('/api/chat/channels', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: title, member_userids: ids }),
    })
      .then(function (r) {
        return r.json().then(function (j) {
          if (!r.ok) throw new Error(j.detail || '作成に失敗しました');
          return j;
        });
      })
      .then(function (j) {
        closeModal('ag-chat-modal-new');
        loadChannels().then(function () {
          selectChannel(j.id);
        });
      })
      .catch(function (e) {
        showErr($('ag-chat-new-err'), e.message || String(e));
      });
  }

  var membersModalChannelId = null;
  /** メンバー追加モーダル: API で得た追加候補の全件（検索で絞り込み元） */
  var addMembersPickList = [];
  /** メンバー追加モーダル: チェック状態（非表示に絞った後も POST に反映するため DOM 外も保持） */
  var addMembersCheckedIds = null;

  function matchesAddMemberQuery(u, qLower) {
    if (!qLower) return true;
    var name = String(u.user_name || '').toLowerCase();
    var id = String(u.userid || '').toLowerCase();
    return name.indexOf(qLower) !== -1 || id.indexOf(qLower) !== -1;
  }

  function renderAddMembersFiltered() {
    var container = $('ag-chat-add-members');
    if (!container) return;
    var inp = $('ag-chat-add-members-filter');
    var q = inp ? String(inp.value || '').trim().toLowerCase() : '';
    var list = addMembersPickList.filter(function (u) {
      return matchesAddMemberQuery(u, q);
    });
    container.innerHTML = '';
    if (list.length === 0) {
      var empty = document.createElement('div');
      empty.className = 'ag-team-chat-empty';
      empty.style.fontSize = '13px';
      empty.style.padding = '6px 0';
      empty.textContent =
        addMembersPickList.length === 0
          ? '追加できるユーザーがありません。'
          : '該当するユーザーがありません。';
      container.appendChild(empty);
      return;
    }
    renderUserChecks(container, list, 'addmem');
    if (addMembersCheckedIds) {
      container.querySelectorAll('input[type="checkbox"]').forEach(function (cb) {
        var uid = normalizeUserid(cb.value);
        cb.checked = !!addMembersCheckedIds[uid];
      });
    }
  }

  function getAddMembersSelectedUserids() {
    if (!addMembersCheckedIds) return [];
    return Object.keys(addMembersCheckedIds).filter(function (k) {
      return addMembersCheckedIds[k];
    });
  }

  function openMembersModal() {
    var cid = normalizeChannelId(currentChannelId);
    if (cid == null) return;
    if (
      !channels.some(function (c) {
        return normalizeChannelId(c.id) === cid;
      })
    ) {
      selectChannel(null);
      return;
    }
    membersModalChannelId = cid;
    showErr($('ag-chat-members-err'), '');
    Promise.all([
      fetch('/api/chat/channels/' + cid + '/members', { credentials: 'same-origin' }).then(function (r) {
        return r.json().then(function (j) {
          if (r.status === 404 || r.status === 403) {
            var err = new Error(
              (j && j.detail) || 'このチャットにアクセスできません。'
            );
            err.accessLost = true;
            throw err;
          }
          if (!r.ok) throw new Error(j.detail || '取得失敗');
          return j;
        });
      }),
      fetch('/api/chat/pick-users', { credentials: 'same-origin' }).then(function (r) {
        return r.json().then(function (j) {
          if (!r.ok) throw new Error('ユーザー取得失敗');
          return j;
        });
      }),
    ])
      .then(function (pair) {
        var mem = pair[0].members || [];
        var pick = pair[1].users || [];
        var existing = {};
        mem.forEach(function (m) {
          existing[m.userid] = true;
        });
        var roster = $('ag-chat-members-roster');
        if (roster) {
          roster.innerHTML = '';
          mem.forEach(function (m) {
            var li = document.createElement('li');
            var line = (m.user_name || m.userid) + ' — ' + m.userid;
            if (m.is_creator) line += '（登録者）';
            li.textContent = line;
            roster.appendChild(li);
          });
        }
        var addList = pick.filter(function (u) {
          return !existing[u.userid];
        });
        addMembersPickList = addList.slice();
        addMembersCheckedIds = Object.create(null);
        var af = $('ag-chat-add-members-filter');
        if (af) af.value = '';
        renderAddMembersFiltered();
        openModal('ag-chat-modal-members');
      })
      .catch(function (e) {
        if (e && e.accessLost) {
          selectChannel(null);
          loadChannels();
        }
        alert(e.message || String(e));
      });
  }

  function submitAddMembers() {
    var cid = normalizeChannelId(membersModalChannelId || currentChannelId);
    if (cid == null) return;
    var ids = getAddMembersSelectedUserids();
    showErr($('ag-chat-members-err'), '');
    if (ids.length === 0) {
      showErr($('ag-chat-members-err'), '追加するユーザーを選択してください。');
      return;
    }
    fetch('/api/chat/channels/' + cid + '/members', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userids: ids }),
    })
      .then(function (r) {
        return r.json().then(function (j) {
          if (!r.ok) throw new Error(j.detail || '追加に失敗しました');
          return j;
        });
      })
      .then(function () {
        closeModal('ag-chat-modal-members');
        var cref = normalizeChannelId(membersModalChannelId || currentChannelId);
        if (cref != null) fetchMentionRoster(cref);
        loadChannels();
      })
      .catch(function (e) {
        showErr($('ag-chat-members-err'), e.message || String(e));
      });
  }

  function bindOnce() {
    if (!root || root.getAttribute('data-ag-chat-bound') === '1') return;
    root.setAttribute('data-ag-chat-bound', '1');

    var nf = $('ag-chat-filter');
    if (nf) {
      nf.addEventListener('input', function () {
        filterText = nf.value || '';
        renderChannelList();
      });
    }

    var gs = $('ag-chat-global-search');
    if (gs) {
      gs.addEventListener('input', function () {
        if (globalSearchDebounceTimer) {
          clearTimeout(globalSearchDebounceTimer);
          globalSearchDebounceTimer = null;
        }
        var v = (gs.value || '').trim();
        if (v.length < 2) {
          closeGlobalSearchResults();
          return;
        }
        globalSearchDebounceTimer = setTimeout(function () {
          globalSearchDebounceTimer = null;
          runGlobalSearch(gs.value || '');
        }, 320);
      });
      gs.addEventListener('keydown', function (ev) {
        if (ev.key === 'Escape') closeGlobalSearchResults();
      });
    }

    if (globalSearchDocHandler) {
      document.removeEventListener('click', globalSearchDocHandler, true);
      globalSearchDocHandler = null;
    }
    globalSearchDocHandler = function (ev) {
      var wrap = $('ag-chat-global-search-wrap');
      if (!wrap || !root) return;
      var t = ev.target;
      if (wrap.contains(t)) return;
      closeGlobalSearchResults();
    };
    document.addEventListener('click', globalSearchDocHandler, true);

    var addMemFilter = $('ag-chat-add-members-filter');
    if (addMemFilter) {
      addMemFilter.addEventListener('input', function () {
        renderAddMembersFiltered();
      });
    }
    var newMemFilter = $('ag-chat-new-members-filter');
    if (newMemFilter) {
      newMemFilter.addEventListener('input', function () {
        renderNewMembersFiltered();
      });
    }

    root.addEventListener('change', function (ev) {
      var t = ev.target;
      if (!t || t.type !== 'checkbox') return;
      var uid = normalizeUserid(t.value);
      if (t.name === 'addmem') {
        var wrap = t.closest ? t.closest('#ag-chat-add-members') : null;
        if (!wrap || !root.contains(wrap)) return;
        if (!addMembersCheckedIds) return;
        if (t.checked) addMembersCheckedIds[uid] = true;
        else delete addMembersCheckedIds[uid];
        return;
      }
      if (t.name === 'newmem') {
        var wrapNew = t.closest ? t.closest('#ag-chat-new-members') : null;
        if (!wrapNew || !root.contains(wrapNew)) return;
        if (!newMembersCheckedIds) return;
        if (t.checked) newMembersCheckedIds[uid] = true;
        else delete newMembersCheckedIds[uid];
      }
    });

    root.addEventListener('click', function (ev) {
      var t = ev.target;
      if (t && t.nodeType !== 1) t = t.parentElement;
      if (!t || !t.closest) return;

      var closer = t.closest('[data-ag-chat-close]');
      if (closer) {
        var mid = closer.getAttribute('data-ag-chat-close');
        if (mid) closeModal(mid);
        return;
      }

      var btn = t.closest('button');
      if (!btn || !root.contains(btn)) return;
      var bid = btn.id;
      if (bid === 'ag-chat-btn-notify') {
        ev.preventDefault();
        requestNotifyPermission();
      } else if (bid === 'ag-chat-btn-new') {
        ev.preventDefault();
        openNewChatModal();
      } else if (bid === 'ag-chat-new-submit') {
        ev.preventDefault();
        submitNewChat();
      } else if (bid === 'ag-chat-btn-members') {
        ev.preventDefault();
        openMembersModal();
      } else if (bid === 'ag-chat-add-submit') {
        ev.preventDefault();
        submitAddMembers();
      } else if (bid === 'ag-chat-send') {
        ev.preventDefault();
        sendMessage();
      }
    });

    var input = $('ag-chat-input');
    if (input) {
      input.addEventListener('compositionstart', function () {
        mentionImeComposing = true;
      });
      input.addEventListener('compositionend', function () {
        mentionImeComposing = false;
        syncMentionPickerFromInput(input);
      });
      input.addEventListener('input', function () {
        syncMentionPickerFromInput(input);
      });
      input.addEventListener('click', function () {
        syncMentionPickerFromInput(input);
      });
      if (!mentionResizeHandler) {
        mentionResizeHandler = function () {
          var ta = $('ag-chat-input');
          var panel = $('ag-chat-mention-picker');
          if (ta && panel && panel.classList.contains('show')) {
            positionMentionPicker(ta);
          }
        };
        window.addEventListener('resize', mentionResizeHandler);
      }
      input.addEventListener('keydown', function (ev) {
        if (mentionImeComposing) return;
        if (
          mentionPickerActive &&
          mentionFiltered &&
          mentionFiltered.length > 0
        ) {
          if (ev.key === 'ArrowDown') {
            ev.preventDefault();
            moveMentionSelection(1, input);
            return;
          }
          if (ev.key === 'ArrowUp') {
            ev.preventDefault();
            moveMentionSelection(-1, input);
            return;
          }
          if (ev.key === 'Enter' && !ev.shiftKey) {
            ev.preventDefault();
            var pick = mentionFiltered[mentionSelectedIdx];
            if (pick) insertMentionPick(input, pick.userid);
            return;
          }
          if (ev.key === 'Tab') {
            ev.preventDefault();
            var pickTab = mentionFiltered[mentionSelectedIdx];
            if (pickTab) insertMentionPick(input, pickTab.userid);
            return;
          }
        }
        if (ev.key === 'Escape' && mentionPickerActive) {
          ev.preventDefault();
          closeMentionPicker();
          return;
        }
        if (ev.key === 'Enter' && !ev.shiftKey) {
          ev.preventDefault();
          sendMessage();
        }
      });
    }

    ['ag-chat-modal-new', 'ag-chat-modal-members'].forEach(function (mid) {
      var el = $(mid);
      if (el) {
        el.addEventListener('click', function (ev) {
          if (ev.target === el) closeModal(mid);
        });
      }
    });
  }

  function teardown() {
    disconnectSSE();
    if (globalSearchDocHandler) {
      document.removeEventListener('click', globalSearchDocHandler, true);
      globalSearchDocHandler = null;
    }
    if (globalSearchDebounceTimer) {
      clearTimeout(globalSearchDebounceTimer);
      globalSearchDebounceTimer = null;
    }
    closeGlobalSearchResults();
    closeMentionPicker();
    mentionRosterList = [];
    mentionRosterChannelId = null;
    if (mentionResizeHandler) {
      window.removeEventListener('resize', mentionResizeHandler);
      mentionResizeHandler = null;
    }
    if (loadChannelsDebounceTimer) {
      clearTimeout(loadChannelsDebounceTimer);
      loadChannelsDebounceTimer = null;
    }
    stopChannelListPolling();
    lastChannelPollSnapshot = null;
    lastChannelPollMentionSnapshot = null;
    channelAckBaselineDone = false;
    channelMentionBaselineDone = false;
    channelLoadToken++;
    currentChannelId = null;
    channelViewerUserid = '';
    seenMessageIds = Object.create(null);
    if (root) {
      root.removeAttribute('data-ag-chat-bound');
      root = null;
    }
  }

  function boot() {
    disconnectSSE();
    root = document.getElementById('ag-team-chat-root');
    if (!root) return;
    meUserid = normalizeUserid(root.getAttribute('data-me-userid'));
    meName = String(root.getAttribute('data-me-name') || '').trim();
    readBootstrapFromPage();

    bindOnce();
    syncNotifyButtonUi();
    syncMeFromServer()
      .catch(function () {})
      .then(function () {
        refreshAllMessageBubbles();
        return loadChannels();
      })
      .then(function () {
        if (currentChannelId != null) {
          selectChannel(currentChannelId);
        }
        startChannelListPolling();
      });
  }

  window.__teamChatTeardown = teardown;
  window.initTeamChat = boot;
})();
