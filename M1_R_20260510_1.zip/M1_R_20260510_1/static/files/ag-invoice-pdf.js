/**
 * 請求書 PDF 生成（機能A）
 * - invoiceNos ごとに /invoice/pdf/{invoice_no} を取得する
 * - openPdfAfterSave が true で 1 件のみ: ダウンロードせず新規タブのみ（iframe でタブタイトル設定）
 * - それ以外: Content-Disposition の名前で通常ダウンロード
 *
 * 使用例:
 *   window.agInvoicePdfFeatureA.createInvoicePdfsToDirectory({
 *     invoiceNos: ['INV001'],
 *     meigiByInvoiceNo: { INV001: '株式会社サンプル' },
 *     openPdfAfterSave: true
 *   })
 */
(function () {
  if (window.agInvoicePdfFeatureA && window.agInvoicePdfFeatureA.createInvoicePdfsToDirectory) {
    return;
  }

  function sanitizeFilename(s) {
    return String(s || '').replace(/[\\/:*?"<>|]/g, '_').trim();
  }

  function filenameFromContentDisposition(cd) {
    if (!cd) return null;
    var m = /filename\*=UTF-8''([^;\s]+)/i.exec(cd);
    if (m) {
      try {
        return decodeURIComponent(m[1].trim());
      } catch (e) {
        // ignore
      }
    }
    m = /filename="([^"]+)"/i.exec(cd);
    if (m) return m[1];
    return null;
  }

  function escapeHtmlText(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  /**
   * blob を iframe で埋め込み、タブタイトルを指定。
   * 内蔵PDFビューアの「保存」は blob のため UUID 名になりがちなので、正しい名前の a[download] をツールバーに置く。
   */
  function openPdfBlobInNewTab(blobUrl, tabTitle, downloadFilename) {
    var t = (tabTitle && String(tabTitle).trim()) || '請求書';
    if (t.length > 150) {
      t = t.substring(0, 150);
    }
    var fn = (downloadFilename && String(downloadFilename).trim()) || '請求書.pdf';
    if (!/\.pdf$/i.test(fn)) {
      fn = fn + '.pdf';
    }
    if (fn.length > 180) {
      fn = fn.substring(0, 176) + '.pdf';
    }
    var w = window.open('about:blank', '_blank');
    if (!w) {
      alert('ポップアップがブロックされています。ブラウザの設定で許可してください。');
      return false;
    }
    var doc = w.document;
    doc.open();
    doc.write(
      '<!DOCTYPE html><html><head><meta charset="utf-8"><title>' +
        escapeHtmlText(t) +
        '</title><style>html,body{height:100%;margin:0;overflow:hidden;font-family:sans-serif}' +
        '.ag-pdf-toolbar{position:fixed;top:0;left:0;right:0;z-index:10;padding:8px 12px;' +
        'background:#f5f5f5;border-bottom:1px solid #ccc;font-size:14px;line-height:1.5}' +
        '.ag-pdf-toolbar a{color:#1565c0;text-decoration:none;margin-right:12px}' +
        '.ag-pdf-toolbar a:hover{text-decoration:underline}' +
        '.ag-pdf-toolbar .hint{color:#555;font-size:12px}' +
        '.ag-pdf-frame-wrap{position:fixed;top:44px;left:0;right:0;bottom:0}' +
        '.ag-pdf-frame-wrap iframe{border:0;width:100%;height:100%;vertical-align:top}' +
        '</style></head><body>' +
        '<div class="ag-pdf-toolbar">' +
        '<a download="' +
        escapeHtmlText(fn) +
        '" href="' +
        blobUrl +
        '">この名前でダウンロード</a>' +
        '<span class="hint">（ビューア内の保存ボタンは別名になることがあります）</span>' +
        '</div>' +
        '<div class="ag-pdf-frame-wrap"><iframe title="' +
        escapeHtmlText(t) +
        '" src="' +
        blobUrl +
        '"></iframe></div></body></html>'
    );
    doc.close();
    return true;
  }

  async function createInvoicePdfsToDirectory(options) {
    options = options || {};
    var invoiceNos = Array.isArray(options.invoiceNos) ? options.invoiceNos : [];
    var openPdfAfterSave = !!options.openPdfAfterSave;
    var meigiByInvoiceNo = options.meigiByInvoiceNo || {};

    if (invoiceNos.length === 0) {
      return { ok: false, errors: ['請求書番号がありません。'], saved: 0 };
    }

    var errs = [];
    var saved = 0;

    for (var i = 0; i < invoiceNos.length; i++) {
      var no = invoiceNos[i];
      if (!no) continue;

      try {
        var res = await fetch('/invoice/pdf/' + encodeURIComponent(no), {
          credentials: 'same-origin',
        });
        if (!res.ok) {
          errs.push(no + ': HTTP ' + res.status);
          continue;
        }

        var cd = res.headers.get('Content-Disposition');
        var filename = sanitizeFilename(filenameFromContentDisposition(cd) || (no + '.pdf')) || (no + '.pdf');
        var blob = await res.blob();
        var url = URL.createObjectURL(blob);

        var tabOnly = openPdfAfterSave && invoiceNos.length === 1;

        if (tabOnly) {
          var meigiForTitle =
            (meigiByInvoiceNo[no] && String(meigiByInvoiceNo[no]).trim()) || '';
          var tabTitle;
          if (meigiForTitle) {
            tabTitle = no + '_' + meigiForTitle;
          } else {
            tabTitle = filename.replace(/\.pdf$/i, '') || no;
          }
          openPdfBlobInNewTab(url, tabTitle, filename);
        } else {
          var a = document.createElement('a');
          a.href = url;
          a.download = filename;
          a.style.display = 'none';
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);

          setTimeout(function (u) {
            URL.revokeObjectURL(u);
          }, 2000, url);
        }

        saved += 1;
      } catch (e) {
        errs.push(no + ': ' + (e && e.message ? e.message : String(e)));
      }
    }

    return { ok: errs.length === 0, errors: errs, saved: saved };
  }

  window.agInvoicePdfFeatureA = {
    createInvoicePdfsToDirectory: createInvoicePdfsToDirectory,
  };
})();
