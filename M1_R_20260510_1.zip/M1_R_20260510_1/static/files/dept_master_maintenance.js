/**
 * 権限・組織設定（部署マスタ）
 * - DB から M_Department を読み込みつつ、オリジナルモック同様に各階層で「＋部門／＋部署／＋チーム」を表示。
 * - 追加・編集の保存は当面クライアント内のみ（サーバー POST は今後接続）。
 * TOP シェルの #main-content に htmx で載せたとき、afterSettle / DOMContentLoaded から init を呼ぶ。
 */
(function () {
  var LV_LABELS = ['', '部門', '部署', 'チーム'];
  var LV_BADGE = ['', 'lv1-b', 'lv2-b', 'lv3-b'];
  var LV_COLOR = ['', 'var(--blue)', 'var(--green)', 'var(--amber)'];

  function badgeIdx(lv) {
    var n = parseInt(lv, 10);
    if (isNaN(n) || n < 1) n = 1;
    if (n > 3) n = 3;
    return n;
  }

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/"/g, '&quot;');
  }

  function cloneInitialState() {
    return {
      readOnly: false,
      depts: [
        { id: 1, code: 'BANK', name: 'あいうえお銀行', parent: null, lv: 1 },
        { id: 2, code: 'KOJIN-HQ', name: '個人営業部門', parent: 1, lv: 2 },
        {
          id: 3,
          code: 'KOJIN-SUISIN',
          name: '個人営業推進チーム',
          parent: 2,
          lv: 3,
        },
      ],
      roles: [
        { id: 1, code: 'ADMIN', name: 'システム管理者' },
        { id: 2, code: 'APPROVER', name: '承認者' },
        { id: 3, code: 'EDITOR', name: 'データ入力' },
        { id: 4, code: 'VIEWER', name: '閲覧のみ' },
      ],
      deptRoles: [],
      users: [
        { id: 'user01', name: '営業 太郎', depts: [] },
        { id: 'user02', name: '営業 花子', depts: [] },
        { id: 'user03', name: '部門 次郎', depts: [] },
      ],
      nextId: 10,
      editingDept: null,
      permDept: null,
      assigningUser: null,
      pickedDept: null,
      fromDb: false,
      userSearchOverLimit: false,
    };
  }

  window.initDeptMasterMaintenance = function () {
    var root = document.getElementById('crm-permission-org-settings');
    if (!root) return;

    var bootEl = document.getElementById('crm-dept-mm-bootstrap');
    var bootData = null;
    if (bootEl && bootEl.textContent) {
      try {
        bootData = JSON.parse(bootEl.textContent.trim());
      } catch (e0) {}
    }

    var state = cloneInitialState();
    if (bootData && bootData.source === 'db' && Array.isArray(bootData.depts)) {
      state.depts = bootData.depts;
      state.fromDb = true;
      state.readOnly = !!bootData.readOnly;
      if (typeof bootData.nextId === 'number') state.nextId = bootData.nextId;
      if (Array.isArray(bootData.roles)) {
        state.roles = bootData.roles;
      }
      if (Array.isArray(bootData.department_roles)) {
        state.deptRoles = bootData.department_roles.slice();
      }
      state.users = [];
      state.userSearchOverLimit = false;
    } else {
      state.readOnly = false;
      state.fromDb = false;
    }

    var M = {};
    window.CrmDeptMaster = M;

    function sortDept(a, b) {
      var so = (a.sortOrder || 0) - (b.sortOrder || 0);
      if (so !== 0) return so;
      return String(a.code || '').localeCompare(String(b.code || ''));
    }

    function wrapIndent(level, inner) {
      var s = '';
      var i;
      for (i = 0; i < level; i++) {
        s +=
          '<div style="display:flex"><div class="tree-indent"></div><div style="flex:1;min-width:0">';
      }
      s += inner;
      for (i = 0; i < level; i++) {
        s += '</div></div>';
      }
      return s;
    }

    function renderSubtree(parentKey, indentLevel) {
      var children = state.depts.filter(function (d) {
        var p = d.parent;
        if (parentKey === null || parentKey === undefined) {
          return p === null || p === undefined;
        }
        return p === parentKey;
      });
      children.sort(sortDept);
      var html = '';
      children.forEach(function (d) {
        html += wrapIndent(indentLevel, nodeHtml(d));
        html += renderSubtree(d.id, indentLevel + 1);
      });
      return html;
    }

    function renderDeptPanelReadOnlyFlat() {
      var el = root.querySelector('#dept-panel');
      if (!el) return;
      if (!state.depts.length) {
        var msg =
          bootData && bootData.dbError
            ? '部署マスタを読み込めませんでした（DBエラー）。'
            : '表示する部署がありません。';
        el.innerHTML =
          '<p style="padding:12px;color:var(--text3);font-size:12px">' + esc(msg) + '</p>';
        return;
      }
      el.innerHTML = renderSubtree(null, 0);
    }

    function isRootDept(d) {
      return d.parent === null || d.parent === undefined;
    }

    /** オリジナルモックと同じ配置: 子ノードの後に、その親の深度に応じた「追加」ボタン */
    function renderDeptUnder(d, indent) {
      var html = '';
      html += wrapIndent(indent, nodeHtml(d));
      if (isEditTarget(d.id)) html += wrapIndent(indent, editFormHtml(d));
      if (isPermTarget(d.id)) html += wrapIndent(indent, permFormHtml(d));

      var children = state.depts.filter(function (c) {
        return c.parent === d.id;
      });
      children.sort(sortDept);
      children.forEach(function (c) {
        html += renderDeptUnder(c, indent + 1);
      });

      var dep = typeof d.lv === 'number' ? d.lv : 1;
      if (!state.readOnly) {
        if (dep === 1) {
          if (
            state.editingDept &&
            state.editingDept.new &&
            state.editingDept.parent === d.id &&
            state.editingDept.lv === 2
          )
            html += wrapIndent(indent + 1, editFormHtml(null, d.id, 2));
          else
            html +=
              wrapIndent(
                indent + 1,
                '<button type="button" class="btn-torihiki btn-torihiki--success btn-torihiki--xs crm-po-add-row" onclick="CrmDeptMaster.startAdd(' +
                  d.id +
                  ',2)">＋ 部署を追加</button>'
              );
        } else if (dep === 2) {
          if (
            state.editingDept &&
            state.editingDept.new &&
            state.editingDept.parent === d.id &&
            state.editingDept.lv === 3
          )
            html += wrapIndent(indent + 1, editFormHtml(null, d.id, 3));
          else
            html +=
              wrapIndent(
                indent + 1,
                '<button type="button" class="btn-torihiki btn-torihiki--success btn-torihiki--xs crm-po-add-row" onclick="CrmDeptMaster.startAdd(' +
                  d.id +
                  ',3)">＋ チームを追加</button>'
              );
        }
      }
      return html;
    }

    function renderDeptPanelTree() {
      var el = root.querySelector('#dept-panel');
      if (!el) return;

      if (state.readOnly) {
        renderDeptPanelReadOnlyFlat();
        return;
      }

      if (!state.depts.length) {
        var msg =
          bootData && bootData.dbError
            ? '部署マスタを読み込めませんでした（DBエラー）。'
            : '部署がありません。';
        var tail =
          '<button type="button" class="btn-torihiki btn-torihiki--success btn-torihiki--xs crm-po-add-row" onclick="CrmDeptMaster.startAdd(null,1)">＋ 部門を追加</button>';
        if (state.editingDept && state.editingDept.new && state.editingDept.lv === 1 && state.editingDept.parent == null)
          el.innerHTML =
            '<p style="padding:12px;color:var(--text3);font-size:12px;margin-bottom:10px">' +
            esc(msg) +
            '</p>' +
            editFormHtml(null, null, 1);
        else
          el.innerHTML =
            '<p style="padding:12px;color:var(--text3);font-size:12px;margin-bottom:10px">' +
            esc(msg) +
            '</p>' +
            tail;
        return;
      }

      var roots = state.depts.filter(isRootDept);
      roots.sort(sortDept);
      var html = '';
      roots.forEach(function (r) {
        html += renderDeptUnder(r, 0);
      });

      if (state.editingDept && state.editingDept.new && state.editingDept.lv === 1 && state.editingDept.parent == null)
        html += editFormHtml(null, null, 1);
      else
        html +=
          '<button type="button" class="btn-torihiki btn-torihiki--success btn-torihiki--xs crm-po-add-row" onclick="CrmDeptMaster.startAdd(null,1)">＋ 部門を追加</button>';

      el.innerHTML = html;
    }

    function renderDeptPanel() {
      renderDeptPanelTree();
    }

    function indent(innerHtml) {
      return (
        '<div style="display:flex"><div class="tree-indent"></div><div style="flex:1;min-width:0">' +
        innerHtml +
        '</div></div>'
      );
    }

    function isEditTarget(id) {
      return state.editingDept && state.editingDept.id === id;
    }

    function isPermTarget(id) {
      return state.permDept === id;
    }

    function nodeHtml(d) {
      var roleTags = state.deptRoles
        .filter(function (r) {
          return r.deptId === d.id;
        })
        .map(function (r) {
          var role = state.roles.find(function (x) {
            return x.id === r.roleId;
          });
          return role
            ? '<span class="role-tag">' +
                esc(role.name) +
                '<span class="rm" onclick="CrmDeptMaster.removeRole(' +
                d.id +
                ',' +
                r.roleId +
                ')">✕</span></span>'
            : '';
        })
        .join('');

      return (
        '<div class="tree-node' +
        (isEditTarget(d.id) ? ' editing' : '') +
        '">' +
        '<span class="lv-badge ' +
        LV_BADGE[badgeIdx(d.lv)] +
        '">' +
        LV_LABELS[badgeIdx(d.lv)] +
        '</span>' +
        '<div style="flex:1;min-width:0">' +
        '<div style="display:flex;align-items:center;gap:6px">' +
        '<span class="node-name">' +
        (d.name
          ? esc(d.name)
          : '<span style="color:var(--text3);font-style:italic">（名称未設定）</span>') +
        '</span>' +
        '<span class="node-code">' +
        esc(d.code) +
        '</span>' +
        '</div>' +
        (roleTags
          ? '<div style="margin-top:3px;display:flex;flex-wrap:wrap">' + roleTags + '</div>'
          : '') +
        '</div>' +
        (state.readOnly
          ? ''
          : '<div class="node-actions">' +
            '<button type="button" class="btn-torihiki btn-torihiki--info btn-torihiki--xs" onclick="event.stopPropagation();CrmDeptMaster.togglePerm(' +
            d.id +
            ')">権限付与</button>' +
            '<button type="button" class="btn-torihiki btn-torihiki--neutral btn-torihiki--xs" onclick="event.stopPropagation();CrmDeptMaster.startEdit(' +
            d.id +
            ')">編集</button>' +
            '<button type="button" class="btn-torihiki btn-torihiki--danger btn-torihiki--xs" onclick="event.stopPropagation();CrmDeptMaster.deleteDept(' +
            d.id +
            ')">削除</button>' +
            '</div>') +
        '</div>'
      );
    }

    function editFormHtml(d, parentId, lv) {
      var isNew = !d;
      var lvNum = d ? badgeIdx(d.lv) : badgeIdx(lv);
      var saveOnclick = isNew
        ? 'CrmDeptMaster.saveDept(null,' + parentId + ',' + lvNum + ')'
        : 'CrmDeptMaster.saveDept(' + d.id + ')';
      return (
        '<div class="edit-form">' +
        '<div class="edit-form-title" style="color:' +
        LV_COLOR[lvNum] +
        '">' +
        (isNew ? '新規追加' : '編集') +
        ' — ' +
        LV_LABELS[lvNum] +
        '</div>' +
        '<div class="form-row">' +
        '<div class="form-field"><label>コード</label>' +
        '<input id="ef-code" type="text" value="' +
        (d ? esc(d.code) : '') +
        '" placeholder="例: KOJIN-HQ"></div>' +
        '<div class="form-field"><label>名称</label>' +
        '<input id="ef-name" type="text" value="' +
        (d ? esc(d.name) : '') +
        '" placeholder="例: 個人営業部署"></div>' +
        '</div>' +
        '<div class="form-btns">' +
        '<button type="button" class="btn-torihiki btn-torihiki--success btn-torihiki--xs" onclick="' +
        saveOnclick +
        '">保存</button>' +
        '<button type="button" class="btn-torihiki btn-torihiki--neutral btn-torihiki--xs" onclick="CrmDeptMaster.cancelEdit()">キャンセル</button>' +
        '</div>' +
        '</div>'
      );
    }

    function permFormHtml(d) {
      var assigned = state.deptRoles
        .filter(function (r) {
          return r.deptId === d.id;
        })
        .map(function (r) {
          return r.roleId;
        });
      var opts = state.roles
        .map(function (r) {
          var chk = assigned.indexOf(r.id) !== -1 ? 'checked' : '';
          return (
            '<label class="role-opt">' +
            '<input type="checkbox" ' +
            chk +
            ' onchange="CrmDeptMaster.toggleRole(' +
            d.id +
            ',' +
            r.id +
            ',this.checked)">' +
            '<span class="role-opt-name">' +
            esc(r.name) +
            '</span>' +
            '<span class="role-opt-code">' +
            esc(r.code) +
            '</span>' +
            '</label>'
          );
        })
        .join('');

      return (
        '<div class="perm-form">' +
        '<div class="perm-form-title">' +
        '権限付与 — T_DepartmentRole' +
        '<span class="perm-target">▸ ' +
        (d.name ? esc(d.name) : '（名称未設定）') +
        '</span>' +
        '</div>' +
        '<div class="role-list">' +
        opts +
        '</div>' +
        '<div class="form-btns">' +
        '<button type="button" class="btn-torihiki btn-torihiki--success btn-torihiki--xs" onclick="CrmDeptMaster.closePerm()">完了</button>' +
        '</div>' +
        '</div>'
      );
    }

    M.togglePerm = function (id) {
      state.permDept = state.permDept === id ? null : id;
      state.editingDept = null;
      renderDeptPanel();
    };

    M.closePerm = function () {
      state.permDept = null;
      renderDeptPanel();
    };

    function updateDeptRolesLocal(deptId, roleId, grant) {
      if (grant) {
        if (
          !state.deptRoles.some(function (r) {
            return r.deptId === deptId && r.roleId === roleId;
          })
        ) {
          state.deptRoles.push({ deptId: deptId, roleId: roleId });
        }
      } else {
        state.deptRoles = state.deptRoles.filter(function (r) {
          return !(r.deptId === deptId && r.roleId === roleId);
        });
      }
    }

    function persistDepartmentRole(deptId, roleId, grant) {
      if (!state.fromDb) {
        updateDeptRolesLocal(deptId, roleId, grant);
        renderDeptPanel();
        return;
      }
      fetch('/api/org-settings/department-role', {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        body: JSON.stringify({
          dept_id: deptId,
          role_id: roleId,
          grant: grant,
        }),
      })
        .then(function (r) {
          return r.json().then(function (data) {
            return { status: r.status, data: data };
          });
        })
        .then(function (res) {
          if (res.status >= 200 && res.status < 300 && res.data && res.data.ok) {
            updateDeptRolesLocal(deptId, roleId, grant);
            renderDeptPanel();
          } else {
            var msg =
              (res.data && res.data.error) ||
              (res.data &&
                res.data.detail &&
                (typeof res.data.detail === 'string'
                  ? res.data.detail
                  : JSON.stringify(res.data.detail))) ||
              '保存に失敗しました。';
            alert(msg);
            renderDeptPanel();
          }
        })
        .catch(function () {
          alert('保存に失敗しました。');
          renderDeptPanel();
        });
    }

    M.toggleRole = function (deptId, roleId, checked) {
      persistDepartmentRole(deptId, roleId, checked);
    };

    M.removeRole = function (deptId, roleId) {
      persistDepartmentRole(deptId, roleId, false);
    };

    M.startAdd = function (parentId, lv) {
      state.editingDept = { new: true, parent: parentId, lv: lv };
      state.permDept = null;
      renderDeptPanel();
    };

    M.startEdit = function (id) {
      state.editingDept = { id: id };
      state.permDept = null;
      renderDeptPanel();
    };

    M.cancelEdit = function () {
      state.editingDept = null;
      renderDeptPanel();
    };

    function bumpNextIdFromDepts() {
      var maxId = 0;
      state.depts.forEach(function (d) {
        if (d.id > maxId) maxId = d.id;
      });
      state.nextId = maxId + 1;
    }

    M.saveDept = function (id, parentId, lv) {
      var codeEl = document.getElementById('ef-code');
      var nameEl = document.getElementById('ef-name');
      var code = codeEl ? codeEl.value.trim() : '';
      var name = nameEl ? nameEl.value.trim() : '';
      if (!code || !name) return;

      if (!state.fromDb) {
        if (id) {
          var d = state.depts.find(function (x) {
            return x.id === id;
          });
          if (d) {
            d.code = code;
            d.name = name;
          }
        } else {
          state.depts.push({
            id: state.nextId++,
            code: code,
            name: name,
            parent: parentId,
            lv: lv,
          });
        }
        state.editingDept = null;
        renderDeptPanel();
        renderUserPanel();
        return;
      }

      var url = id
        ? '/api/org-settings/department/' + id
        : '/api/org-settings/department';
      var method = id ? 'PUT' : 'POST';
      var payload = id
        ? { dept_code: code, dept_name: name }
        : {
            dept_code: code,
            dept_name: name,
            parent_dept_id:
              parentId === null || parentId === undefined ? null : parentId,
          };

      fetch(url, {
        method: method,
        credentials: 'same-origin',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        body: JSON.stringify(payload),
      })
        .then(function (r) {
          return r.json().then(function (data) {
            return { status: r.status, data: data };
          });
        })
        .then(function (res) {
          if (res.status >= 200 && res.status < 300 && res.data && res.data.ok) {
            if (res.data.dept) {
              var row = res.data.dept;
              if (id) {
                var dx = state.depts.find(function (x) {
                  return x.id === id;
                });
                if (dx) {
                  dx.code = row.code;
                  dx.name = row.name;
                  if (typeof row.lv === 'number') dx.lv = row.lv;
                  if (typeof row.sortOrder === 'number') dx.sortOrder = row.sortOrder;
                }
              } else {
                state.depts.push(row);
                bumpNextIdFromDepts();
              }
            }
            state.editingDept = null;
            renderDeptPanel();
            renderUserPanel();
          } else {
            var msg =
              (res.data && res.data.error) ||
              (res.data &&
                res.data.detail &&
                (typeof res.data.detail === 'string'
                  ? res.data.detail
                  : JSON.stringify(res.data.detail))) ||
              '保存に失敗しました。';
            alert(msg);
          }
        })
        .catch(function () {
          alert('保存に失敗しました。');
        });
    };

    M.deleteDept = function (id) {
      if (
        state.depts.some(function (d) {
          return d.parent === id;
        })
      ) {
        alert('配下を先に削除してください。');
        return;
      }
      if (!state.fromDb) {
        state.depts = state.depts.filter(function (d) {
          return d.id !== id;
        });
        state.deptRoles = state.deptRoles.filter(function (r) {
          return r.deptId !== id;
        });
        state.users.forEach(function (u) {
          u.depts = u.depts.filter(function (a) {
            return a.deptId !== id;
          });
        });
        renderDeptPanel();
        renderUserPanel();
        return;
      }

      fetch('/api/org-settings/department/' + id, {
        method: 'DELETE',
        credentials: 'same-origin',
        headers: { Accept: 'application/json' },
      })
        .then(function (r) {
          return r.json().then(function (data) {
            return { status: r.status, data: data };
          });
        })
        .then(function (res) {
          if (res.status >= 200 && res.status < 300 && res.data && res.data.ok) {
            state.depts = state.depts.filter(function (d) {
              return d.id !== id;
            });
            state.deptRoles = state.deptRoles.filter(function (r) {
              return r.deptId !== id;
            });
            state.users.forEach(function (u) {
              u.depts = u.depts.filter(function (a) {
                return a.deptId !== id;
              });
            });
            bumpNextIdFromDepts();
            if (state.permDept === id) state.permDept = null;
            renderDeptPanel();
            renderUserPanel();
          } else {
            var msg =
              (res.data && res.data.error) ||
              (res.data &&
                res.data.detail &&
                (typeof res.data.detail === 'string'
                  ? res.data.detail
                  : JSON.stringify(res.data.detail))) ||
              '削除に失敗しました。';
            alert(msg);
          }
        })
        .catch(function () {
          alert('削除に失敗しました。');
        });
    };

    function getDeptPath(id) {
      var parts = [];
      var d = state.depts.find(function (x) {
        return x.id === id;
      });
      while (d) {
        parts.unshift(d.name);
        d = d.parent
          ? state.depts.find(function (x) {
              return x.id === d.parent;
            })
          : null;
      }
      return parts.join(' › ');
    }

    function getUserFilterQuery() {
      var qid = '';
      var qn = '';
      var elId = root.querySelector('#crm-user-filter-id');
      var elNm = root.querySelector('#crm-user-filter-name');
      if (elId) qid = String(elId.value || '').trim().toLowerCase();
      if (elNm) qn = String(elNm.value || '').trim().toLowerCase();
      return { id: qid, name: qn };
    }

    /** DB 検索と無関係に、入力欄の生の値（空判定用） */
    function getUserFilterRaw() {
      var elId = root.querySelector('#crm-user-filter-id');
      var elNm = root.querySelector('#crm-user-filter-name');
      var uid = elId ? String(elId.value || '').trim() : '';
      var unm = elNm ? String(elNm.value || '').trim() : '';
      return { id: uid, name: unm };
    }

    function userMatchesFilter(u, q) {
      if (q.id && String(u.id).toLowerCase().indexOf(q.id) === -1) {
        return false;
      }
      if (q.name && String(u.name).toLowerCase().indexOf(q.name) === -1) {
        return false;
      }
      return true;
    }

    function clearAssignIfFilterHidesUser() {
      if (!state.assigningUser) return;
      var au = state.users.find(function (x) {
        return x.id === state.assigningUser;
      });
      if (!au) {
        state.assigningUser = null;
        state.pickedDept = null;
        return;
      }
      if (!state.fromDb) {
        var q = getUserFilterQuery();
        if (!userMatchesFilter(au, q)) {
          state.assigningUser = null;
          state.pickedDept = null;
        }
      }
    }

    var orgUserSearchTimer = null;

    function fetchOrgSettingsUsers() {
      var fi = root.querySelector('#crm-user-filter-id');
      var fn = root.querySelector('#crm-user-filter-name');
      var uid = fi ? String(fi.value || '').trim() : '';
      var unm = fn ? String(fn.value || '').trim() : '';
      state.userSearchOverLimit = false;
      if (!uid && !unm) {
        state.users = [];
        state.assigningUser = null;
        state.pickedDept = null;
        renderUserPanel();
        return;
      }
      var q = new URLSearchParams();
      q.set('userid', uid);
      q.set('user_name', unm);
      fetch('/api/org-settings/login-users?' + q.toString(), {
        credentials: 'same-origin',
        headers: { Accept: 'application/json' },
      })
        .then(function (r) {
          return r.json();
        })
        .then(function (data) {
          if (!data || !data.ok || !Array.isArray(data.users)) {
            state.users = [];
            state.userSearchOverLimit = false;
          } else {
            state.users = data.users;
            state.userSearchOverLimit = !!data.over_limit;
          }
          renderUserPanel();
        })
        .catch(function () {
          state.users = [];
          state.userSearchOverLimit = false;
          renderUserPanel();
        });
    }

    function scheduleOrgUserSearch() {
      if (orgUserSearchTimer) clearTimeout(orgUserSearchTimer);
      orgUserSearchTimer = setTimeout(function () {
        orgUserSearchTimer = null;
        fetchOrgSettingsUsers();
      }, 400);
    }

    function bindUserFilterInputs() {
      function onInput() {
        if (state.fromDb) {
          scheduleOrgUserSearch();
        } else {
          renderUserPanel();
        }
      }
      var fi = root.querySelector('#crm-user-filter-id');
      var fn = root.querySelector('#crm-user-filter-name');
      if (fi && !fi.getAttribute('data-crm-filter-bound')) {
        fi.setAttribute('data-crm-filter-bound', '1');
        fi.addEventListener('input', onInput);
      }
      if (fn && !fn.getAttribute('data-crm-filter-bound')) {
        fn.setAttribute('data-crm-filter-bound', '1');
        fn.addEventListener('input', onInput);
      }
    }

    function renderUserPanel() {
      clearAssignIfFilterHidesUser();
      var el = root.querySelector('#user-panel');
      if (!el) return;
      var visibleUsers = state.fromDb
        ? state.users.slice()
        : state.users.filter(function (u) {
            return userMatchesFilter(u, getUserFilterQuery());
          });
      var html = '';
      if (state.fromDb && state.userSearchOverLimit && visibleUsers.length > 0) {
        html +=
          '<div style="color:var(--amber);font-size:11px;padding:0 0 10px;text-align:center;">検索結果が多いため先頭のみ表示している可能性があります。</div>';
      }
      if (visibleUsers.length === 0) {
        if (state.fromDb) {
          var raw = getUserFilterRaw();
          if (!raw.id && !raw.name) {
            html +=
              '<div style="color:var(--text3);font-size:12px;padding:16px;text-align:center;">ユーザIDまたはユーザ名を入力して検索してください。</div>';
          } else {
            html +=
              '<div style="color:var(--text3);font-size:12px;padding:16px;text-align:center;">該当するユーザがありません。</div>';
          }
        }
      }
      visibleUsers.forEach(function (u) {
        var nm = String(u.name || '');
        var initials = nm.length >= 2 ? nm.slice(-2) : (nm || '?').slice(-1);
        var open = state.assigningUser === u.id;
        var tags = u.depts
          .map(function (a) {
            var d = state.depts.find(function (x) {
              return x.id === a.deptId;
            });
            return d
              ? '<span class="dept-tag"><span class="lv-badge lv3-b" style="font-size:8px">チーム</span>' +
                  esc(d.name) +
                  '<span class="rm" onclick="CrmDeptMaster.removeAssign(\'' +
                  u.id +
                  "'," +
                  a.deptId +
                  ')">✕</span></span>'
              : '';
          })
          .join('');

        html +=
          '<div class="user-row">' +
          '<div class="user-avatar">' +
          initials +
          '</div>' +
          '<div class="user-info">' +
          '<div class="user-name">' +
          esc(u.name) +
          '</div>' +
          '<div class="user-id">' +
          esc(u.id) +
          '</div>' +
          '<div class="user-dept">' +
          (tags || '<span class="no-dept">未所属</span>') +
          '</div>' +
          '</div>' +
          '<button type="button" class="btn-torihiki btn-torihiki--neutral btn-torihiki--xs" onclick="CrmDeptMaster.toggleAssign(\'' +
          u.id +
          "')\">＋ チームを紐付け</button>" +
          '</div>';

        if (open) {
          var teamCandidates = state.fromDb
            ? state.depts.filter(function (d) {
                return !state.depts.some(function (c) {
                  return c.parent === d.id;
                });
              })
            : state.depts.filter(function (d) {
                return d.lv === 3;
              });
          var opts =
            teamCandidates
              .map(function (d) {
                var path = getDeptPath(d.id);
                var picked = state.pickedDept === d.id;
                return (
                  '<div class="dept-opt' +
                  (picked ? ' picked' : '') +
                  '" onclick="CrmDeptMaster.pickDept(' +
                  d.id +
                  ')">' +
                  '<span class="lv-badge lv3-b" style="font-size:9px">チーム</span>' +
                  '<div><div style="font-size:12px">' +
                  esc(d.name) +
                  '</div><div class="dept-opt-path">' +
                  esc(path) +
                  '</div></div>' +
                  '</div>'
                );
              })
              .join('') ||
            '<div style="color:var(--text3);font-size:11px;padding:6px">チームがありません</div>';

          html +=
            '<div class="assign-popup">' +
            '<div class="assign-popup-title">チームを選択（Lv3のみ）</div>' +
            '<div class="dept-select-list">' +
            opts +
            '</div>' +
            '<div class="date-row">' +
            '<div class="form-field"><label>適用開始日</label>' +
            '<input type="date" id="af-' +
            u.id +
            '" value="' +
            new Date().toISOString().slice(0, 10) +
            '" style="background:var(--bg4);border:1px solid var(--border2);border-radius:5px;color:var(--text);padding:5px 8px;font-size:12px;width:100%;outline:none;"></div>' +
            '<div class="form-field"><label>適用終了日（空欄=無期限）</label>' +
            '<input type="date" id="at-' +
            u.id +
            '" style="background:var(--bg4);border:1px solid var(--border2);border-radius:5px;color:var(--text);padding:5px 8px;font-size:12px;width:100%;outline:none;"></div>' +
            '</div>' +
            '<div class="form-btns">' +
            '<button type="button" class="btn-torihiki btn-torihiki--success btn-torihiki--xs" onclick="CrmDeptMaster.confirmAssign(\'' +
            u.id +
            "')\">登録</button>" +
            '<button type="button" class="btn-torihiki btn-torihiki--neutral btn-torihiki--xs" onclick="CrmDeptMaster.cancelAssign()">キャンセル</button>' +
            '</div>' +
            '</div>';
        }
      });
      el.innerHTML = html;
    }

    M.toggleAssign = function (uid) {
      state.assigningUser = state.assigningUser === uid ? null : uid;
      state.pickedDept = null;
      renderUserPanel();
    };

    M.cancelAssign = function () {
      state.assigningUser = null;
      state.pickedDept = null;
      renderUserPanel();
    };

    M.pickDept = function (id) {
      state.pickedDept = id;
      renderUserPanel();
    };

    M.confirmAssign = function (uid) {
      if (!state.pickedDept) {
        alert('チームを選択してください。');
        return;
      }
      var u = state.users.find(function (x) {
        return x.id === uid;
      });
      if (!u) return;
      if (
        u.depts.some(function (a) {
          return a.deptId === state.pickedDept;
        })
      ) {
        alert('既に紐付け済みです。');
        return;
      }
      u.depts.push({ deptId: state.pickedDept });
      state.assigningUser = null;
      state.pickedDept = null;
      renderUserPanel();
    };

    M.removeAssign = function (uid, did) {
      var u = state.users.find(function (x) {
        return x.id === uid;
      });
      if (!u) return;
      u.depts = u.depts.filter(function (a) {
        return a.deptId !== did;
      });
      renderUserPanel();
    };

    renderDeptPanel();
    renderUserPanel();
    bindUserFilterInputs();
  };
})();
