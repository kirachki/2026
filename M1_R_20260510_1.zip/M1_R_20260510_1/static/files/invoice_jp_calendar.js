/**
 * 請求メンテ: 発行日の属する月の「最終営業日」（土日・国民の祝祭日を除く）。
 *
 * - f_get_lastBusinessDay(mode, issueYmd)
 *   mode 0: 土日 + 国民の祝祭日（holidays-jp API 取得データ）を休みとする
 *   mode 1: 上記に加え、window.__INVOICE_COMPANY_CLOSED_YMD_SET__ が Set のときその日付も休み（未設定時は mode 0 と同じ）
 * - issueYmd: 発行日 YYYY-MM-DD
 * 戻り: YYYY-MM-DD または null
 *
 * __ensureJpNationalHolidays() で祝日を初回取得してキャッシュする。
 * f_get_lastBusinessDay はキャッシュ完了後に呼ぶこと。
 */
(function (global) {
  var __jpHolidayYmdSet = null;
  var __jpHolidayLoadPromise = null;

  function _pad2(n) {
    return n < 10 ? '0' + n : String(n);
  }

  function _ymdFromDate(d) {
    return d.getFullYear() + '-' + _pad2(d.getMonth() + 1) + '-' + _pad2(d.getDate());
  }

  function _isWeekendLocal(d) {
    var wd = d.getDay();
    return wd === 0 || wd === 6;
  }

  function _companyClosedYmd(ymd) {
    var s = global.__INVOICE_COMPANY_CLOSED_YMD_SET__;
    if (s && typeof s.has === 'function') return s.has(ymd);
    return false;
  }

  function _isNationalHolidayYmd(ymd) {
    if (!__jpHolidayYmdSet) return false;
    return __jpHolidayYmdSet.has(ymd);
  }

  function _isNonBusinessDayLocal(d, mode) {
    var ymd = _ymdFromDate(d);
    if (_isWeekendLocal(d)) return true;
    if (_isNationalHolidayYmd(ymd)) return true;
    if (mode === 1 && _companyClosedYmd(ymd)) return true;
    return false;
  }

  /**
   * 国民の祝日を holidays-jp.github.io から取得してキャッシュする。
   * まず date.json を試し、件数が少なければ年次 JSON を束ねる。
   * @returns {Promise<Set<string>>}
   */
  function __ensureJpNationalHolidays() {
    if (__jpHolidayYmdSet) return Promise.resolve(__jpHolidayYmdSet);
    if (__jpHolidayLoadPromise) return __jpHolidayLoadPromise;

    var base = 'https://holidays-jp.github.io/api/v1/';

    function mergeObjectsIntoSet(set, obj) {
      if (!obj || typeof obj !== 'object') return;
      Object.keys(obj).forEach(function (k) {
        set.add(k);
      });
    }

    __jpHolidayLoadPromise = fetch(base + 'date.json', { credentials: 'omit', cache: 'force-cache' })
      .then(function (r) {
        return r.ok ? r.json() : {};
      })
      .catch(function () {
        return {};
      })
      .then(function (obj) {
        var set = new Set();
        mergeObjectsIntoSet(set, obj);
        if (set.size >= 200) {
          return set;
        }
        var years = [];
        for (var y = 2000; y <= 2050; y++) years.push(y);
        return Promise.all(
          years.map(function (yy) {
            return fetch(base + yy + '/date.json', { credentials: 'omit', cache: 'force-cache' })
              .then(function (r) {
                return r.ok ? r.json() : {};
              })
              .catch(function () {
                return {};
              });
          })
        ).then(function (arr) {
          var s2 = new Set();
          arr.forEach(function (o) {
            mergeObjectsIntoSet(s2, o);
          });
          return s2.size > set.size ? s2 : set;
        });
      })
      .then(function (set) {
        __jpHolidayYmdSet = set instanceof Set ? set : new Set();
        if (__jpHolidayYmdSet.size === 0 && typeof console !== 'undefined' && console.warn) {
          console.warn('[invoice_jp_calendar] 祝日データを取得できませんでした。最終営業日は土日のみ除外されます。');
        }
        return __jpHolidayYmdSet;
      })
      .catch(function () {
        __jpHolidayYmdSet = new Set();
        return __jpHolidayYmdSet;
      });

    return __jpHolidayLoadPromise;
  }

  /**
   * @param {0|1} mode
   * @param {string} issueYmd
   * @returns {string|null}
   */
  function f_get_lastBusinessDay(mode, issueYmd) {
    if (mode !== 0 && mode !== 1) mode = 0;
    if (issueYmd == null) return null;
    var s = String(issueYmd).trim();
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
    if (!m) return null;
    var y = parseInt(m[1], 10);
    var mo = parseInt(m[2], 10);
    if (!(mo >= 1 && mo <= 12)) return null;
    var lastDom = new Date(y, mo, 0).getDate();
    for (var dom = lastDom; dom >= 1; dom--) {
      var d = new Date(y, mo - 1, dom);
      if (!_isNonBusinessDayLocal(d, mode)) {
        return _ymdFromDate(d);
      }
    }
    return null;
  }

  global.__ensureJpNationalHolidays = __ensureJpNationalHolidays;
  global.f_get_lastBusinessDay = f_get_lastBusinessDay;
})(typeof window !== 'undefined' ? window : this);
