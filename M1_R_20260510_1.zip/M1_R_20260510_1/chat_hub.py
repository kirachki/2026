"""
チャット SSE 用ブロードキャスト。

- 環境変数 CRM_REDIS_URL 未設定: プロセス内メモリのみ（単一ワーカー向け）
- CRM_REDIS_URL 設定時: Redis Pub/Sub（uvicorn --workers N でも全ワーカーへ配信）

Redis チャンネル名: crm:chat:{channel_id}（JSON 文字列をペイロードにする）
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    import redis.asyncio as redis_async

logger = logging.getLogger(__name__)

_lock = asyncio.Lock()
_subscribers: dict[int, list[asyncio.Queue[str]]] = {}

_redis_url = (os.environ.get("CRM_REDIS_URL") or "").strip()
_redis_client: Optional[Any] = None
_listener_task: Optional[asyncio.Task] = None

REDIS_CHANNEL_PREFIX = "crm:chat:"

# SSE の queue.get() をブロックしたままにしないための終了マーカー（JSON ペイロードと衝突しない）
SSE_SHUTDOWN_SENTINEL = "__crm_sse_shutdown__"


async def wake_all_sse_streams_for_shutdown() -> None:
    """Graceful shutdown 時、待機中の SSE ストリームを即座に終了させる。"""
    async with _lock:
        snapshot: dict[int, list[asyncio.Queue[str]]] = {
            cid: list(qs) for cid, qs in _subscribers.items()
        }
    for qs in snapshot.values():
        for q in qs:
            try:
                q.put_nowait(SSE_SHUTDOWN_SENTINEL)
            except Exception:
                pass


def redis_channel_name(channel_id: int) -> str:
    return f"{REDIS_CHANNEL_PREFIX}{int(channel_id)}"


async def startup() -> None:
    """アプリ起動時（lifespan）。Redis URL があるとき接続と購読ループを開始。"""
    global _redis_client, _listener_task
    if not _redis_url:
        logger.info(
            "chat_hub: CRM_REDIS_URL 未設定のためインメモリ配信のみ（単一ワーカー向け）"
        )
        return
    try:
        import redis.asyncio as redis_mod

        _redis_client = redis_mod.from_url(
            _redis_url,
            decode_responses=True,
            socket_connect_timeout=5.0,
            health_check_interval=30,
        )
        await _redis_client.ping()
        _listener_task = asyncio.create_task(
            _redis_listener_loop(), name="chat_hub_redis_listener"
        )
        logger.info("chat_hub: Redis Pub/Sub 有効 (%s)", _redis_url.split("@")[-1])
    except Exception:
        logger.exception(
            "chat_hub: Redis 接続失敗 — インメモリ配信のみで起動します（マルチワーカーでは配信が分断されます）"
        )
        _redis_client = None
        _listener_task = None


async def shutdown() -> None:
    """アプリ終了時。SSE を先に閉じ、その後 Redis を閉じる。"""
    await wake_all_sse_streams_for_shutdown()
    global _redis_client, _listener_task
    t = _listener_task
    _listener_task = None
    if t is not None:
        t.cancel()
        try:
            await t
        except asyncio.CancelledError:
            pass
    rc = _redis_client
    _redis_client = None
    if rc is not None:
        try:
            await rc.aclose()
        except Exception as e:
            logger.warning("chat_hub: Redis クローズ時: %s", e)


async def _redis_listener_loop() -> None:
    """各ワーカーで 1 本。psubscribe 受信をローカル SSE キューへ振り分け。"""
    assert _redis_client is not None
    pubsub = _redis_client.pubsub()
    try:
        await pubsub.psubscribe(f"{REDIS_CHANNEL_PREFIX}*")
        async for message in pubsub.listen():
            if message is None:
                continue
            if message.get("type") != "pmessage":
                continue
            ch = message.get("channel")
            data = message.get("data")
            if ch is None or data is None:
                continue
            ch_str = str(ch)
            if not ch_str.startswith(REDIS_CHANNEL_PREFIX):
                continue
            suffix = ch_str[len(REDIS_CHANNEL_PREFIX) :].strip()
            try:
                cid = int(suffix)
            except ValueError:
                continue
            text = data if isinstance(data, str) else str(data)
            async with _lock:
                queues = list(_subscribers.get(cid, []))
            for q in queues:
                try:
                    await q.put(text)
                except Exception:
                    logger.debug("chat_hub: queue put skipped", exc_info=True)
    except asyncio.CancelledError:
        raise
    except Exception:
        logger.exception("chat_hub: Redis 購読ループが異常終了しました")
        raise
    finally:
        try:
            await pubsub.punsubscribe()
            await pubsub.aclose()
        except Exception:
            logger.debug("chat_hub: pubsub close", exc_info=True)


async def subscribe(channel_id: int) -> asyncio.Queue[str]:
    q: asyncio.Queue[str] = asyncio.Queue()
    async with _lock:
        _subscribers.setdefault(channel_id, []).append(q)
    return q


async def unsubscribe(channel_id: int, q: asyncio.Queue[str]) -> None:
    async with _lock:
        lst = _subscribers.get(channel_id)
        if not lst:
            return
        if q in lst:
            lst.remove(q)
        if not lst:
            del _subscribers[channel_id]


async def publish(channel_id: int, payload: Any) -> None:
    text = json.dumps(payload, ensure_ascii=False)
    if _redis_client is not None:
        await _redis_client.publish(redis_channel_name(channel_id), text)
        return
    async with _lock:
        queues = list(_subscribers.get(channel_id, []))
    for q in queues:
        await q.put(text)
