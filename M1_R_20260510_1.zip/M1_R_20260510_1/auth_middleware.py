"""
未ログイン時に保護ルートへのアクセスを /login へリダイレクトするミドルウェア。

BaseHTTPMiddleware は SessionMiddleware と組み合わせると request.session が
正しく見えない場合があるため、純粋な ASGI ミドルウェアで scope["session"] を参照する。
SessionMiddleware より内側に登録すること（main.py で Session を後から add）。

環境変数 CRM_AUTH_DISABLED=1 で認証チェックを無効化（ローカル開発のみ推奨）。
"""
from __future__ import annotations

import os
from urllib.parse import quote

from starlette.requests import Request
from starlette.responses import JSONResponse, RedirectResponse
from starlette.types import ASGIApp, Receive, Scope, Send


def _auth_disabled() -> bool:
    return os.environ.get("CRM_AUTH_DISABLED", "").strip().lower() in (
        "1",
        "true",
        "yes",
        "on",
    )


def is_public_path(path: str) -> bool:
    """認証不要のパス（静的・OpenAPI・ログイン画面）。"""
    if path.startswith("/files/") or path == "/files":
        return True
    if path.startswith("/ref3/") or path == "/ref3":
        return True
    if path in ("/docs", "/openapi.json", "/redoc", "/favicon.ico"):
        return True
    if path == "/login":
        return True
    if path == "/login/force-change":
        return True
    if path == "/logout":
        return True
    if path == "/logout/complete":
        return True
    return False


class RequireLoginMiddleware:
    """scope['session']['user_id'] が無い場合は /login へ 302。"""

    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        if _auth_disabled():
            await self.app(scope, receive, send)
            return

        request = Request(scope)
        path = request.url.path

        if is_public_path(path):
            await self.app(scope, receive, send)
            return

        session = scope.get("session")
        if not isinstance(session, dict):
            session = {}

        if session.get("user_id"):
            await self.app(scope, receive, send)
            return

        # fetch 用 API は HTML ログインではなく JSON（302 + HTML だと r.json() が壊れる）
        if path.startswith("/api/"):
            response = JSONResponse(
                status_code=401,
                content={"detail": "ログインが必要です。"},
            )
            await response(scope, receive, send)
            return

        # ログイン後に元の URL へ戻すため ?next= にパスを付与（オープンリダイレクト防止のためパスのみ）
        next_q = quote(path, safe="/")
        response = RedirectResponse(url=f"/login?next={next_q}", status_code=302)
        await response(scope, receive, send)
