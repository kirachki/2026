-- Generated from DDL.txt

CREATE TABLE `T1_請求書データ_ヘッダ` (
  `ID` BIGINT(11) AUTO_INCREMENT PRIMARY KEY,
  `請求書番号` VARCHAR(20),
  `郵便番号` VARCHAR(20),
  `住所` VARCHAR(500),
  `取引先コード` VARCHAR(20),
  `宛名_取引先名` VARCHAR(255),
  `宛名_担当部署` VARCHAR(255),
  `宛名_担当者` VARCHAR(255),
  `自行住所` VARCHAR(500),
  `自行電話_FAX番号` VARCHAR(20),
  `自行営業担当者` VARCHAR(255),
  `自行部署名` VARCHAR(255),
  `発行日` DATE,
  `決済方法` VARCHAR(255),
  `発行者` VARCHAR(255),
  `営業担当者` VARCHAR(255),
  `消費税率` VARCHAR(255),
  `消費税端数` VARCHAR(255),
  `件名` VARCHAR(255),
  `請求金額` DECIMAL(15,2),
  `支払期限` VARCHAR(255),
  `決済口座` VARCHAR(255),
  `コメント_振込` VARCHAR(500),
  `備考欄` VARCHAR(500),
  `店番` VARCHAR(255),
  `口座名義人` VARCHAR(255),
  `役職` VARCHAR(255),
  `敬称` VARCHAR(255),
  `削除フラグ` VARCHAR(10),
  `メモ備忘` VARCHAR(500)
) DEFAULT CHARSET=utf8mb4;

CREATE TABLE `T1_請求書データ_明細` (
  `請求書番号` VARCHAR(20),
  `明細番号` VARCHAR(20),
  `請求項目1` VARCHAR(255),
  `請求項目2` VARCHAR(255),
  `請求項目3` VARCHAR(255),
  `単価` VARCHAR(255),
  `数量` INT,
  `税抜金額` DECIMAL(15,2),
  `税抜金額端数処理区分` VARCHAR(255),
  `消費税` VARCHAR(255),
  `税込金額` DECIMAL(15,2),
  `プロジェクトコード` VARCHAR(20),
  `科目コード` VARCHAR(20),
  `中分類` VARCHAR(255),
  `小分類` VARCHAR(255),
  `消費税区分` VARCHAR(10)
) DEFAULT CHARSET=utf8mb4;

-- 取引先マスタ（請求メンテの取引先検索モーダル・UPSERT 用。db.search_m_torihikisaki_master 等）
CREATE TABLE `M_取引先マスタ` (
  `ID` BIGINT NOT NULL AUTO_INCREMENT,
  `取引先コード` VARCHAR(20),
  `請求先` VARCHAR(255),
  `郵便番号` VARCHAR(20),
  `住所` VARCHAR(500),
  `電話` VARCHAR(50),
  `FAX` VARCHAR(50),
  `消費税率` VARCHAR(255),
  `税端数処理` VARCHAR(20),
  `自社フラグ` TINYINT NOT NULL DEFAULT 0,
  `メモ備忘` VARCHAR(500),
  PRIMARY KEY (`ID`),
  KEY `idx_m_torihikisaki_seikyusaki` (`請求先`(191)),
  KEY `idx_m_torihikisaki_code` (`取引先コード`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 口座マスタ（請求メンテの店番・口座検索モーダル用。db.search_m_koza_master）
CREATE TABLE `M_口座マスタ` (
  `ID` INT(11) DEFAULT NULL,
  `店番` TEXT,
  `口座番号` TEXT,
  `口座名義人` TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `T1_AccountAttribute` (
  `店番号` INT,
  `口座番号` VARCHAR(20),
  `MDAS-ID` VARCHAR(20),
  `AIS開設日` DATE,
  `法人コード` VARCHAR(20),
  `登録番号` VARCHAR(20),
  `設立日` DATE,
  `口座名義(漢字)` VARCHAR(255),
  `口座名義(カナ)` VARCHAR(255),
  `法人名(漢字)` VARCHAR(255),
  `法人名(カナ)` VARCHAR(255),
  `住所(漢字)` VARCHAR(255),
  `住所コード住所(漢字)` VARCHAR(255),
  `補助住所(漢字)` VARCHAR(255),
  `電話番号(市外局番)` VARCHAR(10),
  `電話番号(市内局番)` VARCHAR(10),
  `電話番号(局番)` VARCHAR(10),
  `FAX番号(市外局番)` VARCHAR(10),
  `FAX番号(市内局番)` VARCHAR(10),
  `FAX番号(局番)` VARCHAR(10),
  `代表者姓(漢字)` VARCHAR(50),
  `代表者名(漢字)` VARCHAR(50),
  `代表者姓(カナ)` VARCHAR(50),
  `代表者名(カナ)` VARCHAR(50),
  `口座管理者姓(漢字)` VARCHAR(50),
  `口座管理者名(漢字)` VARCHAR(50),
  `口座管理者姓(カナ)` VARCHAR(50),
  `口座管理者名(カナ)` VARCHAR(50),
  `Emailアドレス` VARCHAR(255),
  `ホームページアドレス` VARCHAR(255),
  `振込入金口座全銀コード` VARCHAR(20),
  `対外出金口座全銀コード` VARCHAR(20),
  `日銀業種コード` VARCHAR(20),
  `グループID` VARCHAR(50),
  `エレメントID` VARCHAR(50),
  `CIF番号` VARCHAR(50),
  `預金残高(普通預金)` BIGINT,
  `預金残高(定期預金)` BIGINT,
  `行内:簡単決済(出金)` BIGINT,
  `行内:簡単決済(入金)` BIGINT,
  `行内:簡単決済＋(出金)` BIGINT,
  `行内:簡単決済＋(入金)` BIGINT,
  `行内:メルマネ(入金)` BIGINT,
  `行内:メルマネ(RT)(入金)` BIGINT,
  `行内:メルマネ(WEB-FB:メルマネマスペ)(入金)` BIGINT,
  `行内:自動引落(RT)(出金)` BIGINT,
  `行内:自動引落(RT)(入金)` BIGINT,
  `行内:自動引落(WEB-FB:自動引落)(出金)` BIGINT,
  `行内:自動引落(伝送:自動引落)(出金)` BIGINT,
  `行内:自動引落(WEB-FB/伝送:自動引落)(入金)` BIGINT,
  `行内:マスペ(出金)` BIGINT,
  `行内:マスペ(入金)` BIGINT,
  `行内:バンク決済(出金)` BIGINT,
  `行内:バンク決済(入金)` BIGINT,
  `行内:行内振替(出金)` BIGINT,
  `行内:行内振替(入金)` BIGINT,
  `行内:行内振替(RT送金)(出金)` BIGINT,
  `行内:行内振替(RT送金)(入金)` BIGINT,
  `行内:行内振替(総振)(出金)` BIGINT,
  `行内:行内振替(総振)(入金)` BIGINT,
  `行内:ペイジー(出金)` BIGINT,
  `行内:ペイジー(入金)` BIGINT,
  `行内:毎月お任せ振込(出金)` BIGINT,
  `行内:毎月お任せ振込(入金)` BIGINT,
  `行内:一括振込(出金)` BIGINT,
  `行内:一括振込(入金)` BIGINT,
  `行内:FB送金(出金)` BIGINT,
  `行内:FB送金(入金)` BIGINT,
  `他行:ゆうちょ(出金/3万未満)` BIGINT,
  `他行:ゆうちょ(出金/3万以上)` BIGINT,
  `他行:ゆうちょ(入金/3万未満)` BIGINT,
  `他行:ゆうちょ(入金/3万以上)` BIGINT,
  `他行:他行振込(出金/3万未満)` BIGINT,
  `他行:他行振込(出金/3万以上)` BIGINT,
  `他行:他行振込(RT)(出金/3万未満)` BIGINT,
  `他行:他行振込(RT)(出金/3万以上)` BIGINT,
  `他行:他行振込(WEB-FB/伝送:総振)(出金/3万未満)` BIGINT,
  `他行:他行振込(WEB-FB/伝送:総振)(出金/3万以上)` BIGINT,
  `他行:バンク決済:総振(出金/3万未満)` BIGINT,
  `他行:バンク決済:総振(出金/3万以上)` BIGINT,
  `他行:毎月お任せ振込(出金/3万未満)` BIGINT,
  `他行:毎月お任せ振込(出金/3万以上)` BIGINT,
  `他行:一括振込(出金/3万未満)` BIGINT,
  `他行:一括振込(出金/3万以上)` BIGINT,
  `他行:被仕向け(入金/3万未満)` BIGINT,
  `他行:被仕向け(入金/3万以上)` BIGINT,
  `他行:仮想口座向け被仕向け(入金/3万未満)` BIGINT,
  `他行:仮想口座向け被仕向け(入金/3万以上)` BIGINT,
  `他行:本人名義他行振込(出金/3万未満)` BIGINT,
  `他行:本人名義他行振込(出金/3万以上)` BIGINT,
  `メルマネ(出金)(未登録)` BIGINT,
  `メルマネ(出金)(登録済)` BIGINT,
  `メルマネ(RT)(出金)(未登録)` BIGINT,
  `メルマネ(RT)(出金)(登録済)` BIGINT,
  `メルマネ(WEB-FB:メルマネマスペ)(出金)(未登録)` BIGINT,
  `メルマネ(WEB-FB:メルマネマスペ)(出金)(登録済)` BIGINT,
  `行内:メルマネ(WEB-FB:メルマネマスペ＋)(入金)` BIGINT,
  `メルマネ(WEB-FB:メルマネマスペ＋)(行内出金)(行内受取)` BIGINT,
  `メルマネ(WEB-FB:メルマネマスペ＋)(行内出金)(他行受取可:送金人負担)` BIGINT,
  `メルマネ(WEB-FB:メルマネマスペ＋)(他行出金)(他行受取可:送金人負担)` BIGINT,
  `メルマネ(WEB-FB:メルマネマスペ＋)(行内出金)(他行受取可:双方負担)` BIGINT,
  `メルマネ(WEB-FB:メルマネマスペ＋)(他行出金)(他行受取可:双方負担)` BIGINT,
  `他行:給与・賞与振込(WEB-FB/伝送)（3万円未満)` BIGINT,
  `他行:給与・賞与振込(WEB-FB/伝送)（3万円以上)` BIGINT,
  `行内:給与・賞与振込(WEB-FB/伝送)（3万円未満)` BIGINT,
  `行内:給与・賞与振込(WEB-FB/伝送)（3万円以上)` BIGINT,
  `振込先口座確認（他行）` BIGINT,
  `振込先口座確認（行内）` BIGINT
) DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------------
-- ログインユーザ（step1: 認証用）
-- パスワードは本番では必ずハッシュで保存すること。下記 INSERT は SHA2 例。
-- ---------------------------------------------------------------------------
CREATE TABLE `T1_LoginUser` (
  `userid` VARCHAR(50) NOT NULL COMMENT 'ログインID（主キー）',
  `pwd` VARCHAR(255) NOT NULL COMMENT 'パスワード（ハッシュ文字列推奨）',
  `user_name` VARCHAR(100) NULL COMMENT '表示名',
  `admin_option` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '1=管理者, 0=一般',
  `Enabled` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '1=有効, 0=無効',
  `LastLoginDateTime` DATETIME NULL COMMENT '最終ログイン日時',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '登録日時',
  `updated_at` DATETIME NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新日時',
  PRIMARY KEY (`userid`),
  KEY `idx_T1_LoginUser_Enabled` (`Enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='ログインユーザ';

-- テストデータ 2 件（平文パスワード: admin / user01）
INSERT INTO `T1_LoginUser` (`userid`, `pwd`, `user_name`, `admin_option`, `Enabled`, `LastLoginDateTime`) VALUES
('admin', SHA2('admin', 256), '管理者', 1, 1, NULL),
('user01', SHA2('user01', 256), 'テストユーザー', 0, 1, NULL);

INSERT INTO `T1_LoginUser` (`userid`, `pwd`, `user_name`, `admin_option`, `Enabled`, `LastLoginDateTime`) VALUES
('user02', SHA2('user02', 256), '半井 大輔', 0, 1, NULL);

-- ---------------------------------------------------------------------------
-- チームチャット（SSE 連携・履歴は DB 永続化）
-- ---------------------------------------------------------------------------
CREATE TABLE `T1_ChatChannel` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(200) NOT NULL COMMENT 'チャットタイトル',
  `created_by_userid` VARCHAR(50) NOT NULL COMMENT '作成者（T1_LoginUser.userid）',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '最終メッセージ等で更新',
  PRIMARY KEY (`id`),
  KEY `idx_T1_ChatChannel_updated` (`updated_at`),
  CONSTRAINT `fk_T1_ChatChannel_creator` FOREIGN KEY (`created_by_userid`) REFERENCES `T1_LoginUser` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='チャットチャンネル';

CREATE TABLE `T1_ChatMember` (
  `channel_id` BIGINT NOT NULL,
  `userid` VARCHAR(50) NOT NULL,
  `joined_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`channel_id`, `userid`),
  KEY `idx_T1_ChatMember_userid` (`userid`),
  CONSTRAINT `fk_T1_ChatMember_channel` FOREIGN KEY (`channel_id`) REFERENCES `T1_ChatChannel` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_T1_ChatMember_user` FOREIGN KEY (`userid`) REFERENCES `T1_LoginUser` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='チャット参加ユーザー';

CREATE TABLE `T1_ChatMessage` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `channel_id` BIGINT NOT NULL,
  `sender_userid` VARCHAR(50) NOT NULL,
  `body` TEXT NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_T1_ChatMessage_channel_id` (`channel_id`, `id`),
  CONSTRAINT `fk_T1_ChatMessage_channel` FOREIGN KEY (`channel_id`) REFERENCES `T1_ChatChannel` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_T1_ChatMessage_sender` FOREIGN KEY (`sender_userid`) REFERENCES `T1_LoginUser` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='チャットメッセージ';

CREATE TABLE `zipMaster` (
  `zipcode` VARCHAR(10) NOT NULL,
  `address1` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`zipcode`),
  KEY `idx_zipMaster_zipcode` (`zipcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='郵便番号マスタ';


