# jinostest データベース ER 図（Mermaid）

DDL の正は `create_table_update.sql` を参照してください。ここでは **MySQL 上で定義されている外部キー** を線で表しています。請求・口座・郵便番号など、FK が無いテーブルは独立エンティティとして列挙しています。

```mermaid
erDiagram
  M_Department {
    int dept_id PK
    string dept_code UK
    string dept_name
    int parent_dept_id FK
  }

  M_Role {
    int role_id PK
    string role_code UK
    string role_name
  }

  T1_LoginUser {
    string userid PK
    string pwd
    string user_name
    tinyint admin_option
    tinyint Enabled
  }

  T_UserDepartment {
    int id PK
    string userid FK
    int dept_id FK
    tinyint is_primary
    date assigned_from
    date assigned_to
  }

  T_UserRole {
    int id PK
    string userid FK
    int role_id FK
    date assigned_from
    date assigned_to
  }

  T1_ChatChannel {
    bigint id PK
    string title
    string created_by_userid FK
    datetime created_at
  }

  T1_ChatMember {
    bigint channel_id PK
    string userid PK
    datetime joined_at
  }

  T1_ChatMessage {
    bigint id PK
    bigint channel_id FK
    string sender_userid FK
    text body
  }

  M_取引先マスタ {
    int ID
    string 取引先コード
    string 請求先
  }

  M_口座マスタ {
    int ID
    text 店番
    text 口座番号
  }

  M_担当者マスタ {
    int ID
    text 部署
    text 担当者
  }

  T1_請求書データ_ヘッダ {
    int ID
    string 請求書番号
    string 宛名_取引先名
  }

  T1_請求書データ_明細 {
    string 請求書番号
    int 明細番号
  }

  T1_AccountAttribute {
    int 店番号
    string 口座番号
  }

  zipMaster {
    string zipcode
    string address1
  }

  jinostest {
    int jinostest
  }

  M_Department ||--o{ M_Department : "parent_dept_id"
  T1_LoginUser ||--o{ T_UserDepartment : "userid"
  M_Department ||--o{ T_UserDepartment : "dept_id"
  T1_LoginUser ||--o{ T_UserRole : "userid"
  M_Role ||--o{ T_UserRole : "role_id"
  T1_LoginUser ||--o{ T1_ChatChannel : "created_by_userid"
  T1_ChatChannel ||--o{ T1_ChatMember : "channel_id"
  T1_LoginUser ||--o{ T1_ChatMember : "userid"
  T1_ChatChannel ||--o{ T1_ChatMessage : "channel_id"
  T1_LoginUser ||--o{ T1_ChatMessage : "sender_userid"
```
