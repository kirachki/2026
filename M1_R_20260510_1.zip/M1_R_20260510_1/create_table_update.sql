-- jinostest データベース DDL（MySQL 実体から取得・整列）
-- 取得元: host=10.1.100.30, database=jinostest
-- 注意: SHOW CREATE TABLE の結果をベースにしているため、型表記はサーバ設定に依存します。
--       AUTO_INCREMENT の「現在値」は除去済み（新規環境向け）。

CREATE TABLE `M_Department` (
  `dept_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '部署ID（主キー）',
  `dept_code` varchar(20) NOT NULL COMMENT '部署コード（外部システム連携用）',
  `dept_name` varchar(100) NOT NULL COMMENT '部署名',
  `parent_dept_id` int(11) DEFAULT NULL COMMENT '親部署ID（自己参照 / NULLはルート）',
  `sort_order` smallint(6) NOT NULL DEFAULT '0' COMMENT '表示順',
  `Enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=有効, 0=無効',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '登録日時',
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新日時',
  PRIMARY KEY (`dept_id`),
  UNIQUE KEY `uq_M_Department_code` (`dept_code`),
  KEY `idx_M_Department_parent` (`parent_dept_id`),
  KEY `idx_M_Department_Enabled` (`Enabled`),
  CONSTRAINT `fk_Dept_parent` FOREIGN KEY (`parent_dept_id`) REFERENCES `M_Department` (`dept_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='部署マスタ（自己参照で階層構造を表現）';

CREATE TABLE `M_Role` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ロールID（主キー）',
  `role_code` varchar(50) NOT NULL COMMENT 'ロールコード（アプリ内参照用）',
  `role_name` varchar(100) NOT NULL COMMENT 'ロール名',
  `description` text COMMENT '説明・付与できる権限の概要',
  `Enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=有効, 0=無効',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '登録日時',
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新日時',
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `uq_M_Role_code` (`role_code`),
  KEY `idx_M_Role_Enabled` (`Enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='ロールマスタ（アクセス制御の権限種別）';

CREATE TABLE `T1_LoginUser` (
  `userid` varchar(50) NOT NULL COMMENT 'ログインID（主キー）',
  `pwd` varchar(255) NOT NULL COMMENT 'パスワード（ハッシュ文字列推奨）',
  `user_name` varchar(100) DEFAULT NULL COMMENT '表示名',
  `admin_option` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1=管理者, 0=一般',
  `Enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=有効, 0=無効',
  `LastLoginDateTime` datetime DEFAULT NULL COMMENT '最終ログイン日時',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '登録日時',
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新日時',
  PRIMARY KEY (`userid`),
  KEY `idx_T1_LoginUser_Enabled` (`Enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='ログインユーザ';

CREATE TABLE `T_UserDepartment` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID（主キー）',
  `userid` varchar(50) NOT NULL COMMENT 'ログインID（T1_LoginUser.userid）',
  `dept_id` int(11) NOT NULL COMMENT '部署ID（M_Department.dept_id）',
  `is_primary` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=主所属, 0=兼務',
  `assigned_from` date NOT NULL COMMENT '適用開始日',
  `assigned_to` date DEFAULT NULL COMMENT '適用終了日（NULL=無期限）',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '登録日時',
  PRIMARY KEY (`id`),
  KEY `idx_TUD_userid` (`userid`),
  KEY `idx_TUD_dept_id` (`dept_id`),
  KEY `idx_TUD_period` (`assigned_from`,`assigned_to`),
  CONSTRAINT `fk_TUD_dept_id` FOREIGN KEY (`dept_id`) REFERENCES `M_Department` (`dept_id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_TUD_userid` FOREIGN KEY (`userid`) REFERENCES `T1_LoginUser` (`userid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='ユーザ部署中間テーブル（兼務・異動履歴対応）';

CREATE TABLE `T_UserRole` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID（主キー）',
  `userid` varchar(50) NOT NULL COMMENT 'ログインID（T1_LoginUser.userid）',
  `role_id` int(11) NOT NULL COMMENT 'ロールID（M_Role.role_id）',
  `assigned_from` date NOT NULL COMMENT '適用開始日',
  `assigned_to` date DEFAULT NULL COMMENT '適用終了日（NULL=無期限）',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '登録日時',
  PRIMARY KEY (`id`),
  KEY `idx_TUR_userid` (`userid`),
  KEY `idx_TUR_role_id` (`role_id`),
  KEY `idx_TUR_period` (`assigned_from`,`assigned_to`),
  CONSTRAINT `fk_TUR_role_id` FOREIGN KEY (`role_id`) REFERENCES `M_Role` (`role_id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_TUR_userid` FOREIGN KEY (`userid`) REFERENCES `T1_LoginUser` (`userid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='ユーザロール中間テーブル（一時権限・履歴対応）';

CREATE TABLE `T1_ChatChannel` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL COMMENT 'チャットタイトル',
  `created_by_userid` varchar(50) NOT NULL COMMENT '作成者（T1_LoginUser.userid）',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '最終メッセージ等で更新',
  PRIMARY KEY (`id`),
  KEY `idx_T1_ChatChannel_updated` (`updated_at`),
  KEY `fk_T1_ChatChannel_creator` (`created_by_userid`),
  CONSTRAINT `fk_T1_ChatChannel_creator` FOREIGN KEY (`created_by_userid`) REFERENCES `T1_LoginUser` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='チャットチャンネル';

CREATE TABLE `T1_ChatMember` (
  `channel_id` bigint(20) NOT NULL,
  `userid` varchar(50) NOT NULL,
  `joined_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`channel_id`,`userid`),
  KEY `idx_T1_ChatMember_userid` (`userid`),
  CONSTRAINT `fk_T1_ChatMember_channel` FOREIGN KEY (`channel_id`) REFERENCES `T1_ChatChannel` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_T1_ChatMember_user` FOREIGN KEY (`userid`) REFERENCES `T1_LoginUser` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='チャット参加ユーザー';

CREATE TABLE `T1_ChatMessage` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `channel_id` bigint(20) NOT NULL,
  `sender_userid` varchar(50) NOT NULL,
  `body` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_T1_ChatMessage_channel_id` (`channel_id`,`id`),
  KEY `fk_T1_ChatMessage_sender` (`sender_userid`),
  CONSTRAINT `fk_T1_ChatMessage_channel` FOREIGN KEY (`channel_id`) REFERENCES `T1_ChatChannel` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_T1_ChatMessage_sender` FOREIGN KEY (`sender_userid`) REFERENCES `T1_LoginUser` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='チャットメッセージ';

CREATE TABLE `M_取引先マスタ` (
  `ID` int(11) DEFAULT NULL,
  `取引先コード` varchar(255) DEFAULT NULL,
  `請求先` varchar(255) DEFAULT NULL,
  `郵便番号` varchar(255) DEFAULT NULL,
  `住所` varchar(255) DEFAULT NULL,
  `電話` varchar(255) DEFAULT NULL,
  `FAX` varchar(255) DEFAULT NULL,
  `消費税率` varchar(255) DEFAULT NULL,
  `税端数処理` varchar(255) DEFAULT NULL,
  `自社フラグ` bit(1) DEFAULT NULL,
  `メモ備忘` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `M_口座マスタ` (
  `ID` int(11) DEFAULT NULL,
  `店番` text,
  `口座番号` text,
  `口座名義人` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `M_担当者マスタ` (
  `ID` int(11) DEFAULT NULL,
  `部署` text,
  `役職` text,
  `担当者` text,
  `敬称` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `T1_請求書データ_ヘッダ` (
  `ID` int(11) DEFAULT NULL,
  `請求書番号` varchar(255) DEFAULT NULL,
  `郵便番号` varchar(255) DEFAULT NULL,
  `住所` varchar(255) DEFAULT NULL,
  `取引先コード` varchar(255) DEFAULT NULL,
  `宛名_取引先名` varchar(255) DEFAULT NULL,
  `宛名_担当部署` varchar(255) DEFAULT NULL,
  `宛名_担当者` varchar(255) DEFAULT NULL,
  `自行住所` varchar(255) DEFAULT NULL,
  `自行電話_FAX番号` varchar(255) DEFAULT NULL,
  `自行営業担当者` varchar(255) DEFAULT NULL,
  `自行部署名` varchar(255) DEFAULT NULL,
  `発行日` datetime DEFAULT NULL,
  `決済方法` varchar(255) DEFAULT NULL,
  `発行者` varchar(255) DEFAULT NULL,
  `営業担当者` varchar(255) DEFAULT NULL,
  `消費税率` varchar(255) DEFAULT NULL,
  `消費税端数` varchar(255) DEFAULT NULL,
  `件名` varchar(255) DEFAULT NULL,
  `請求金額` decimal(18,3) DEFAULT NULL,
  `支払期限` datetime DEFAULT NULL,
  `決済口座` varchar(255) DEFAULT NULL,
  `コメント_振込` varchar(255) DEFAULT NULL,
  `備考欄` varchar(255) DEFAULT NULL,
  `店番` varchar(255) DEFAULT NULL,
  `口座名義人` varchar(255) DEFAULT NULL,
  `役職` varchar(255) DEFAULT NULL,
  `敬称` varchar(255) DEFAULT NULL,
  `削除フラグ` bit(1) DEFAULT NULL,
  `メモ備忘` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `T1_請求書データ_明細` (
  `請求書番号` varchar(255) DEFAULT NULL,
  `明細番号` int(11) DEFAULT NULL,
  `請求項目1` varchar(255) DEFAULT NULL,
  `請求項目2` varchar(255) DEFAULT NULL,
  `請求項目3` varchar(255) DEFAULT NULL,
  `単価` decimal(18,3) DEFAULT NULL,
  `数量` decimal(18,0) DEFAULT NULL,
  `税抜金額` decimal(18,3) DEFAULT NULL,
  `税抜金額端数処理区分` varchar(255) DEFAULT NULL,
  `消費税` decimal(18,3) DEFAULT NULL,
  `税込金額` decimal(18,3) DEFAULT NULL,
  `プロジェクトコード` varchar(255) DEFAULT NULL,
  `科目コード` varchar(255) DEFAULT NULL,
  `中分類` varchar(255) DEFAULT NULL,
  `小分類` varchar(255) DEFAULT NULL,
  `消費税区分` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `T1_AccountAttribute` (
  `店番号` int(11) DEFAULT NULL,
  `口座番号` varchar(20) DEFAULT NULL,
  `MDAS-ID` varchar(20) DEFAULT NULL,
  `AIS開設日` date DEFAULT NULL,
  `法人コード` varchar(20) DEFAULT NULL,
  `登録番号` varchar(20) DEFAULT NULL,
  `設立日` date DEFAULT NULL,
  `口座名義(漢字)` varchar(255) DEFAULT NULL,
  `口座名義(カナ)` varchar(255) DEFAULT NULL,
  `法人名(漢字)` varchar(255) DEFAULT NULL,
  `法人名(カナ)` varchar(255) DEFAULT NULL,
  `住所(漢字)` varchar(255) DEFAULT NULL,
  `住所コード住所(漢字)` varchar(255) DEFAULT NULL,
  `補助住所(漢字)` varchar(255) DEFAULT NULL,
  `電話番号(市外局番)` varchar(10) DEFAULT NULL,
  `電話番号(市内局番)` varchar(10) DEFAULT NULL,
  `電話番号(局番)` varchar(10) DEFAULT NULL,
  `FAX番号(市外局番)` varchar(10) DEFAULT NULL,
  `FAX番号(市内局番)` varchar(10) DEFAULT NULL,
  `FAX番号(局番)` varchar(10) DEFAULT NULL,
  `代表者姓(漢字)` varchar(50) DEFAULT NULL,
  `代表者名(漢字)` varchar(50) DEFAULT NULL,
  `代表者姓(カナ)` varchar(50) DEFAULT NULL,
  `代表者名(カナ)` varchar(50) DEFAULT NULL,
  `口座管理者姓(漢字)` varchar(50) DEFAULT NULL,
  `口座管理者名(漢字)` varchar(50) DEFAULT NULL,
  `口座管理者姓(カナ)` varchar(50) DEFAULT NULL,
  `口座管理者名(カナ)` varchar(50) DEFAULT NULL,
  `Emailアドレス` varchar(255) DEFAULT NULL,
  `ホームページアドレス` varchar(255) DEFAULT NULL,
  `振込入金口座全銀コード` varchar(20) DEFAULT NULL,
  `対外出金口座全銀コード` varchar(20) DEFAULT NULL,
  `日銀業種コード` varchar(20) DEFAULT NULL,
  `グループID` varchar(50) DEFAULT NULL,
  `エレメントID` varchar(50) DEFAULT NULL,
  `CIF番号` varchar(50) DEFAULT NULL,
  `預金残高(普通預金)` bigint(20) DEFAULT NULL,
  `預金残高(定期預金)` bigint(20) DEFAULT NULL,
  `行内:簡単決済(出金)` bigint(20) DEFAULT NULL,
  `行内:簡単決済(入金)` bigint(20) DEFAULT NULL,
  `行内:簡単決済＋(出金)` bigint(20) DEFAULT NULL,
  `行内:簡単決済＋(入金)` bigint(20) DEFAULT NULL,
  `行内:メルマネ(入金)` bigint(20) DEFAULT NULL,
  `行内:メルマネ(RT)(入金)` bigint(20) DEFAULT NULL,
  `行内:メルマネ(WEB-FB:メルマネマスペ)(入金)` bigint(20) DEFAULT NULL,
  `行内:自動引落(RT)(出金)` bigint(20) DEFAULT NULL,
  `行内:自動引落(RT)(入金)` bigint(20) DEFAULT NULL,
  `行内:自動引落(WEB-FB:自動引落)(出金)` bigint(20) DEFAULT NULL,
  `行内:自動引落(伝送:自動引落)(出金)` bigint(20) DEFAULT NULL,
  `行内:自動引落(WEB-FB/伝送:自動引落)(入金)` bigint(20) DEFAULT NULL,
  `行内:マスペ(出金)` bigint(20) DEFAULT NULL,
  `行内:マスペ(入金)` bigint(20) DEFAULT NULL,
  `行内:バンク決済(出金)` bigint(20) DEFAULT NULL,
  `行内:バンク決済(入金)` bigint(20) DEFAULT NULL,
  `行内:行内振替(出金)` bigint(20) DEFAULT NULL,
  `行内:行内振替(入金)` bigint(20) DEFAULT NULL,
  `行内:行内振替(RT送金)(出金)` bigint(20) DEFAULT NULL,
  `行内:行内振替(RT送金)(入金)` bigint(20) DEFAULT NULL,
  `行内:行内振替(総振)(出金)` bigint(20) DEFAULT NULL,
  `行内:行内振替(総振)(入金)` bigint(20) DEFAULT NULL,
  `行内:ペイジー(出金)` bigint(20) DEFAULT NULL,
  `行内:ペイジー(入金)` bigint(20) DEFAULT NULL,
  `行内:毎月お任せ振込(出金)` bigint(20) DEFAULT NULL,
  `行内:毎月お任せ振込(入金)` bigint(20) DEFAULT NULL,
  `行内:一括振込(出金)` bigint(20) DEFAULT NULL,
  `行内:一括振込(入金)` bigint(20) DEFAULT NULL,
  `行内:FB送金(出金)` bigint(20) DEFAULT NULL,
  `行内:FB送金(入金)` bigint(20) DEFAULT NULL,
  `他行:ゆうちょ(出金/3万未満)` bigint(20) DEFAULT NULL,
  `他行:ゆうちょ(出金/3万以上)` bigint(20) DEFAULT NULL,
  `他行:ゆうちょ(入金/3万未満)` bigint(20) DEFAULT NULL,
  `他行:ゆうちょ(入金/3万以上)` bigint(20) DEFAULT NULL,
  `他行:他行振込(出金/3万未満)` bigint(20) DEFAULT NULL,
  `他行:他行振込(出金/3万以上)` bigint(20) DEFAULT NULL,
  `他行:他行振込(RT)(出金/3万未満)` bigint(20) DEFAULT NULL,
  `他行:他行振込(RT)(出金/3万以上)` bigint(20) DEFAULT NULL,
  `他行:他行振込(WEB-FB/伝送:総振)(出金/3万未満)` bigint(20) DEFAULT NULL,
  `他行:他行振込(WEB-FB/伝送:総振)(出金/3万以上)` bigint(20) DEFAULT NULL,
  `他行:バンク決済:総振(出金/3万未満)` bigint(20) DEFAULT NULL,
  `他行:バンク決済:総振(出金/3万以上)` bigint(20) DEFAULT NULL,
  `他行:毎月お任せ振込(出金/3万未満)` bigint(20) DEFAULT NULL,
  `他行:毎月お任せ振込(出金/3万以上)` bigint(20) DEFAULT NULL,
  `他行:一括振込(出金/3万未満)` bigint(20) DEFAULT NULL,
  `他行:一括振込(出金/3万以上)` bigint(20) DEFAULT NULL,
  `他行:被仕向け(入金/3万未満)` bigint(20) DEFAULT NULL,
  `他行:被仕向け(入金/3万以上)` bigint(20) DEFAULT NULL,
  `他行:仮想口座向け被仕向け(入金/3万未満)` bigint(20) DEFAULT NULL,
  `他行:仮想口座向け被仕向け(入金/3万以上)` bigint(20) DEFAULT NULL,
  `他行:本人名義他行振込(出金/3万未満)` bigint(20) DEFAULT NULL,
  `他行:本人名義他行振込(出金/3万以上)` bigint(20) DEFAULT NULL,
  `メルマネ(出金)(未登録)` bigint(20) DEFAULT NULL,
  `メルマネ(出金)(登録済)` bigint(20) DEFAULT NULL,
  `メルマネ(RT)(出金)(未登録)` bigint(20) DEFAULT NULL,
  `メルマネ(RT)(出金)(登録済)` bigint(20) DEFAULT NULL,
  `メルマネ(WEB-FB:メルマネマスペ)(出金)(未登録)` bigint(20) DEFAULT NULL,
  `メルマネ(WEB-FB:メルマネマスペ)(出金)(登録済)` bigint(20) DEFAULT NULL,
  `行内:メルマネ(WEB-FB:メルマネマスペ＋)(入金)` bigint(20) DEFAULT NULL,
  `メルマネ(WEB-FB:メルマネマスペ＋)(行内出金)(行内受取)` bigint(20) DEFAULT NULL,
  `メルマネ(WEB-FB:メルマネマスペ＋)(行内出金)(他行受取可:送金人負担)` bigint(20) DEFAULT NULL,
  `メルマネ(WEB-FB:メルマネマスペ＋)(他行出金)(他行受取可:送金人負担)` bigint(20) DEFAULT NULL,
  `メルマネ(WEB-FB:メルマネマスペ＋)(行内出金)(他行受取可:双方負担)` bigint(20) DEFAULT NULL,
  `メルマネ(WEB-FB:メルマネマスペ＋)(他行出金)(他行受取可:双方負担)` bigint(20) DEFAULT NULL,
  `他行:給与・賞与振込(WEB-FB/伝送)（3万円未満)` bigint(20) DEFAULT NULL,
  `他行:給与・賞与振込(WEB-FB/伝送)（3万円以上)` bigint(20) DEFAULT NULL,
  `行内:給与・賞与振込(WEB-FB/伝送)（3万円未満)` bigint(20) DEFAULT NULL,
  `行内:給与・賞与振込(WEB-FB/伝送)（3万円以上)` bigint(20) DEFAULT NULL,
  `振込先口座確認（他行）` bigint(20) DEFAULT NULL,
  `振込先口座確認（行内）` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `zipMaster` (
  `zipcode` varchar(10) NOT NULL,
  `address1` varchar(500) DEFAULT NULL,
  KEY `idx_zipMaster_zipcode` (`zipcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='郵便番号マスタ';

CREATE TABLE `jinostest` (
  `jinostest` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
