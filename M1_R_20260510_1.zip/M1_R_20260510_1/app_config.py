"""
アプリ実行モード設定。

起動時に読み込み（モジュール import 時 1 回）。
チャット専用モードは INI のみで指定する（環境変数では切り替えない）。

- 既定: プロジェクト直下の crm_app.ini（ファイルがあるときだけ読む）
- 別パスを使う場合のみ環境変数 CRM_CONFIG_INI で ini の場所を指定可能

[app]
chatOnly = true
"""
from __future__ import annotations

import logging
import os
from configparser import ConfigParser
from pathlib import Path

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent


def _ini_path_candidates() -> list[str]:
    out: list[str] = []
    env = (os.environ.get("CRM_CONFIG_INI") or "").strip()
    if env:
        out.append(env)
    out.append(str(BASE_DIR / "crm_app.ini"))
    return out


def _load_chat_only_from_ini() -> bool:
    for p in _ini_path_candidates():
        path = Path(p)
        if not path.is_file():
            continue
        cp = ConfigParser()
        try:
            read_ok = cp.read(path, encoding="utf-8")
            if not read_ok:
                continue
            if not cp.has_section("app"):
                continue
            # SectionProxy に has_option が無い環境があるため parser 側で判定する
            if cp.has_option("app", "chatOnly") and cp.getboolean("app", "chatOnly"):
                logger.info("app_config: chatOnly=true from %s", path)
                return True
            if cp.has_option("app", "chat_only") and cp.getboolean("app", "chat_only"):
                logger.info("app_config: chat_only=true from %s", path)
                return True
        except Exception:
            logger.exception("app_config: failed to read %s", path)
    return False


CHAT_ONLY: bool = _load_chat_only_from_ini()


DEFAULT_SHIFT_MANAGEMENT_URL = "http://localhost:8001/"


def _load_shift_management_url_from_ini() -> str:
    """メニュー「シフト管理」のリンク先（別タブ）。crm_app.ini の [app] を参照。"""
    default = DEFAULT_SHIFT_MANAGEMENT_URL
    for p in _ini_path_candidates():
        path = Path(p)
        if not path.is_file():
            continue
        cp = ConfigParser()
        try:
            read_ok = cp.read(path, encoding="utf-8")
            if not read_ok:
                continue
            if not cp.has_section("app"):
                continue
            for opt in ("shift_management_url", "shiftManagementUrl"):
                if cp.has_option("app", opt):
                    raw = cp.get("app", opt).strip()
                    if raw:
                        logger.info("app_config: shift_management_url from %s", path)
                        return raw
                    return default
        except Exception:
            logger.exception("app_config: failed to read %s for shift_management_url", path)
    return default


SHIFT_MANAGEMENT_URL: str = _load_shift_management_url_from_ini()


DEFAULT_SCHEDULE_URL = "http://localhost:8001/leave_requests/"


def _load_schedule_url_from_ini() -> str:
    """メニュー「個人予定」のリンク先（別タブ）。crm_app.ini の [app] を参照。"""
    default = DEFAULT_SCHEDULE_URL
    for p in _ini_path_candidates():
        path = Path(p)
        if not path.is_file():
            continue
        cp = ConfigParser()
        try:
            read_ok = cp.read(path, encoding="utf-8")
            if not read_ok:
                continue
            if not cp.has_section("app"):
                continue
            for opt in ("schedule_url", "scheduleUrl"):
                if cp.has_option("app", opt):
                    raw = cp.get("app", opt).strip()
                    if raw:
                        logger.info("app_config: schedule_url from %s", path)
                        return raw
                    return default
        except Exception:
            logger.exception("app_config: failed to read %s for schedule_url", path)
    return default


SCHEDULE_URL: str = _load_schedule_url_from_ini()


DEFAULT_SHIFT_SSO_PATH = "/auth/sso"


def _load_shift_jwt_secret() -> str:
    """
    シフトSSO用 JWT 共有鍵。
    優先順:
      1) 環境変数 CRM_SHIFT_JWT_SECRET
      2) crm_app.ini [app] shift_jwt_secret / shiftJwtSecret
    """
    env = (os.environ.get("CRM_SHIFT_JWT_SECRET") or "").strip()
    if env:
        return env
    for p in _ini_path_candidates():
        path = Path(p)
        if not path.is_file():
            continue
        cp = ConfigParser()
        try:
            read_ok = cp.read(path, encoding="utf-8")
            if not read_ok or not cp.has_section("app"):
                continue
            for opt in ("shift_jwt_secret", "shiftJwtSecret"):
                if cp.has_option("app", opt):
                    raw = cp.get("app", opt).strip()
                    if raw:
                        logger.info("app_config: shift_jwt_secret from %s", path)
                        return raw
        except Exception:
            logger.exception("app_config: failed to read %s for shift_jwt_secret", path)
    return ""


def _load_shift_jwt_issuer() -> str:
    return (os.environ.get("CRM_SHIFT_JWT_ISS") or "crm-8000").strip() or "crm-8000"


def _load_shift_jwt_audience() -> str:
    return (os.environ.get("CRM_SHIFT_JWT_AUD") or "shift-8001").strip() or "shift-8001"


def _load_shift_sso_post_url() -> str:
    """
    シフト管理側SSO受け口 URL（POST先）。
    未設定時は shift_management_url + /auth/sso を使用。
    """
    env = (os.environ.get("CRM_SHIFT_SSO_POST_URL") or "").strip()
    if env:
        return env
    for p in _ini_path_candidates():
        path = Path(p)
        if not path.is_file():
            continue
        cp = ConfigParser()
        try:
            read_ok = cp.read(path, encoding="utf-8")
            if not read_ok or not cp.has_section("app"):
                continue
            for opt in ("shift_sso_post_url", "shiftSsoPostUrl"):
                if cp.has_option("app", opt):
                    raw = cp.get("app", opt).strip()
                    if raw:
                        logger.info("app_config: shift_sso_post_url from %s", path)
                        return raw
        except Exception:
            logger.exception("app_config: failed to read %s for shift_sso_post_url", path)
    return f"{SHIFT_MANAGEMENT_URL.rstrip('/')}{DEFAULT_SHIFT_SSO_PATH}"


SHIFT_JWT_SECRET: str = _load_shift_jwt_secret()
SHIFT_JWT_ISSUER: str = _load_shift_jwt_issuer()
SHIFT_JWT_AUDIENCE: str = _load_shift_jwt_audience()
SHIFT_SSO_POST_URL: str = _load_shift_sso_post_url()


def is_chat_only() -> bool:
    """チャット専用モード（サイドメニュー非表示・/top はチャットへ誘導）。"""
    return CHAT_ONLY
