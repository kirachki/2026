import re
from playwright.sync_api import Playwright, sync_playwright, expect


def run(playwright: Playwright) -> None:
    browser = playwright.chromium.launch(headless=False)
    context = browser.new_context()
    page = context.new_page()

    # ログイン
    page.goto("http://127.0.0.1:8000/login")
    page.get_by_role("textbox", name="userid").fill("user01")
    page.get_by_role("textbox", name="pwd").fill("a")
    page.get_by_role("button", name="ログイン").click()

    # アコーディオンメニュー：「請求」を開く
    page.get_by_role("link", name="請求 ").click()

    # 展開されるまで待ってからクリック
    menu_item = page.get_by_role("link", name="請求一覧", exact=True)
    menu_item.wait_for(state="visible")
    menu_item.click()

    # 検索条件設定ボタン
    page.get_by_role("button", name=" 検索条件設定").click()

    # 発行日 from を直接入力（カレンダーは使わない）
    page.get_by_placeholder("YYYY-MM-DD").first.fill("2026-03-01")

    # 請求リンクをクリック（ポップアップが開く）
    with page.expect_popup() as page1_info:
        page.get_by_role("link", name="-C029").click()
    page1 = page1_info.value

    # ---------------------
    context.close()
    browser.close()


with sync_playwright() as playwright:
    run(playwright)
    