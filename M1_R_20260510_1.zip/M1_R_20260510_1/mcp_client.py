"""
Web側からMCPサーバーを呼び出すクライアント。
"""
from __future__ import annotations

from pathlib import Path

import anyio
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


BASE_DIR = Path(__file__).resolve().parent


async def call_mcp_tool_text_async(tool_name: str, arguments: dict) -> str:
    """
    MCPツールを呼び、先頭テキストコンテンツを返す。
    """
    params = StdioServerParameters(
        command="python",
        args=["mcp_server_step1.py"],
        cwd=str(BASE_DIR),
    )
    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            result = await session.call_tool(tool_name, arguments)
            if result.content:
                block = result.content[0]
                text = getattr(block, "text", "")
                return str(text or "")
            return str(result)


def call_mcp_tool_text(tool_name: str, arguments: dict) -> str:
    """
    同期コード向けラッパー。
    """
    return anyio.run(call_mcp_tool_text_async, tool_name, arguments)
