import anyio
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


async def main():
    params = StdioServerParameters(
        command="python",
        args=["mcp_server_step1.py"],
        cwd=r"c:\study\CRMs\M1",
    )
    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            result = await session.call_tool(
                "invoice_header_summary", {"invoice_no": "INV-001"}
            )
            if result.content:
                print(result.content[0].text)
            else:
                print(result)


if __name__ == "__main__":
    anyio.run(main)
