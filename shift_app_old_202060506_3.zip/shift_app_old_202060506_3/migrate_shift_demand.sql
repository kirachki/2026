-- 既存 DB 向け：曜日／日別の需要テーブル追加（冪等：既にある場合はエラーになるので手動スキップ可）
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS SH_PERIOD_SHIFT_WEEKDAY_DEMAND (
    id              INT             NOT NULL AUTO_INCREMENT,
    period_id       INT             NOT NULL,
    shift_type_id   INT             NOT NULL,
    weekday         TINYINT         NOT NULL COMMENT '0=月 … 6=日',
    min_staff       INT             NOT NULL DEFAULT 1,
    is_feasible     TINYINT(1)      NOT NULL DEFAULT 1,
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_period_shift_weekday (period_id, shift_type_id, weekday),
    INDEX idx_ps_weekday_period (period_id),
    CONSTRAINT chk_ps_weekday_wd CHECK (weekday BETWEEN 0 AND 6),
    CONSTRAINT chk_ps_weekday_min CHECK (min_staff BETWEEN 0 AND 99),
    CONSTRAINT fk_ps_weekday_period
        FOREIGN KEY (period_id) REFERENCES SH_SCHEDULE_PERIODS (id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_ps_weekday_shift_type
        FOREIGN KEY (shift_type_id) REFERENCES SH_SHIFT_TYPES (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS SH_PERIOD_SHIFT_DATE_DEMAND (
    id              INT             NOT NULL AUTO_INCREMENT,
    period_id       INT             NOT NULL,
    shift_type_id   INT             NOT NULL,
    demand_date     DATE            NOT NULL,
    min_staff       INT             NOT NULL DEFAULT 1,
    is_feasible     TINYINT(1)      NOT NULL DEFAULT 1,
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_period_shift_date (period_id, shift_type_id, demand_date),
    INDEX idx_ps_date_period (period_id),
    CONSTRAINT chk_ps_date_min CHECK (min_staff BETWEEN 0 AND 99),
    CONSTRAINT fk_ps_date_period
        FOREIGN KEY (period_id) REFERENCES SH_SCHEDULE_PERIODS (id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_ps_date_shift_type
        FOREIGN KEY (shift_type_id) REFERENCES SH_SHIFT_TYPES (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
