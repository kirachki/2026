"""期間に紐づく休業日（SH_CLOSED_DAYS）を date の集合として取得する。"""
from __future__ import annotations

from datetime import date

from sqlalchemy.exc import OperationalError
from sqlalchemy.orm import Session

import models
from date_keys import to_calendar_date


def closed_dates_in_period(db: Session, period_id: int) -> set[date]:
    """テーブル未作成時は空集合を返す。"""
    try:
        rows = (
            db.query(models.ClosedDay.closed_date)
            .filter(models.ClosedDay.period_id == period_id)
            .all()
        )
    except OperationalError:
        return set()
    out: set[date] = set()
    for (cd,) in rows:
        d = to_calendar_date(cd)
        if d:
            out.add(d)
    return out
