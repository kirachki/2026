-- 既存 DB 向け: 半休・時間指定休のスキーマ追加（MySQL）
-- 適用前にバックアップしてください。

ALTER TABLE SH_LEAVE_REQUESTS
  ADD COLUMN leave_kind VARCHAR(20) NOT NULL DEFAULT 'full_day'
    COMMENT 'full_day|morning_half|afternoon_half|custom' AFTER request_date,
  ADD COLUMN custom_start_time VARCHAR(8) NULL COMMENT '時間指定休の開始 HH:MM:SS' AFTER leave_kind,
  ADD COLUMN custom_end_time VARCHAR(8) NULL COMMENT '時間指定休の終了 HH:MM:SS' AFTER custom_start_time;

CREATE TABLE IF NOT EXISTS SH_LEAVE_HALF_DAY_RULES (
    id              INT             NOT NULL AUTO_INCREMENT,
    team_id         INT             NOT NULL,
    weekday         TINYINT         NOT NULL COMMENT '0=月 … 6=日',
    kind            VARCHAR(20)     NOT NULL COMMENT 'morning_half | afternoon_half',
    start_time      VARCHAR(8)      NOT NULL,
    end_time        VARCHAR(8)      NOT NULL,
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_leave_half_rule_team_day_kind (team_id, weekday, kind),
    CONSTRAINT fk_leave_half_rules_team
        FOREIGN KEY (team_id)
        REFERENCES SH_TEAMS (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
