-- シフトセル「✖」（guard_x）対応
ALTER TABLE SH_SHIFT_ASSIGNMENTS
  ADD COLUMN guard_x TINYINT(1) NOT NULL DEFAULT 0
  COMMENT '1=✖（shift_type NULL時のみ・勤務回避の意思）'
  AFTER is_locked;
