-- 既存 DB 向け: 期間単位の休業日（土日などタスクを付けない日）
-- 適用前にバックアップしてください。

CREATE TABLE IF NOT EXISTS SH_CLOSED_DAYS (
    id           INT         NOT NULL AUTO_INCREMENT,
    period_id    INT         NOT NULL COMMENT 'スケジュール期間ID（FK）',
    closed_date  DATE        NOT NULL COMMENT '休業日',
    created_at   DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_closed_day_period_date (period_id, closed_date),
    INDEX idx_sh_closed_days_period (period_id),
    INDEX idx_sh_closed_days_date (closed_date),
    CONSTRAINT fk_sh_closed_days_period
        FOREIGN KEY (period_id)
        REFERENCES SH_SCHEDULE_PERIODS (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
COMMENT='期間ごとの休業日';
