# ShiftOptima — シフト最適化Webアプリ

FastAPI + HTMX + OR-Tools で作られたシフト管理・自動最適化アプリです。

---

## 技術スタック

| レイヤー | 技術 |
|---|---|
| バックエンド | FastAPI (Python) |
| フロントエンド | HTMX + Jinja2テンプレート |
| 最適化エンジン | Google OR-Tools (CP-SAT) |
| データベース | MySQL |
| ORM | SQLAlchemy + PyMySQL |

---

## セットアップ手順

### 1. 前提条件

- Python 3.11 以上
- MySQL が起動していること

### 2. データベースの準備

MySQL に接続して DDL を実行してください。

```sql
-- ddl.sql を実行してテーブルを作成
source ddl.sql;

-- 必要に応じてサンプルデータを投入（先頭で SET NAMES utf8mb4 済み）
source sample_data.sql;
```

MySQL クライアントで **ERROR 1366（日本語が文字化け）** になる場合は、SQL ファイルを **UTF-8（BOM なし）** で保存し、`mysql` 起動時に  
`mysql --default-character-set=utf8mb4 -u...` を指定するか、セッションで `SET NAMES utf8mb4;` を実行してから `source` してください。

### 3. 仮想環境の作成と起動

```bash
# Windows
cd C:\study\SHIFTS\shift_app
python -m venv venv
venv\Scripts\activate

# Mac / Linux
python -m venv venv
source venv/bin/activate
```

### 4. ライブラリのインストール

```bash
pip install -r requirements.txt
```

### 5. DB接続設定の確認

`database.py` の `_DB_CONFIG` を確認・変更してください。

```python
_DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "kuro0711",
    "database": "sakila",
    "charset": "utf8mb4",
}
```

### 6. アプリの起動

```bash
uvicorn main:app --reload --port 8001
```

### 7. ブラウザでアクセス

```
http://localhost:8001
```

初回アクセス時にサンプルデータ（スタッフ5名・7月第1週のシフト）が自動で投入されます。

---

## 主な機能

### シフト表の表示
- 週単位のシフトグリッドをカラーで表示
- 土日は赤でハイライト

### シフトの手動編集
- **未** … まだ何も決めていない（未設定）。クリックでシフト入力へ進む
- **早番・遅番・夜勤** … クリックで種類が順に切り替わる
- **休** … この日は休むという意志で確定（ロック）。クリックで未設定に戻せる
- サイクルは **未 → 早番 → … → 夜勤 → 休 → 未**
- シフト側でロックしたセルは 🔒 表示（変更不可）

### 自動最適化
- 「⚡ 最適化を実行」ボタンで OR-Tools が自動でシフトを生成
- 処理結果はページ全体を再読込せず HTMX で差し替え

### 制約設定（リアルタイム保存）
- スライダーやトグルを操作すると即座にDBへ保存

### スタッフ管理
- サイドバーからスタッフを追加・削除（論理削除）

### 複数期間管理
- 週を追加してナビゲーションで切り替え可能

---

## プロジェクト構成

```
shift_app/
├── main.py                  # FastAPIエントリポイント
├── models.py                # SQLAlchemy ORM
├── database.py              # DB接続設定（MySQL）
├── optimizer.py             # OR-Tools最適化ロジック
├── init_db.py               # サンプルデータ投入
├── requirements.txt
├── ddl.sql                  # テーブル作成DDL（MySQL用）
├── sample_data.sql          # サンプルINSERT文
├── routers/
│   ├── staff.py
│   ├── assignments.py
│   ├── periods.py
│   └── optimizer_router.py
├── templates/
│   ├── base.html
│   ├── schedule.html
│   └── partials/
│       ├── staff_list.html
│       ├── cell.html
│       └── schedule_grid.html
└── static/
    └── style.css
```

---

## テーブル一覧（SH_プレフィックス）

| テーブル名 | 用途 |
|---|---|
| SH_TEAMS | チームマスタ（業務単位・最上位） |
| SH_STAFF | スタッフマスタ |
| SH_SHIFT_TYPES | タスク種別マスタ |
| SH_SCHEDULE_PERIODS | スケジュール期間 |
| SH_CONSTRAINTS | 制約設定 |
| SH_LEAVE_REQUESTS | 休み希望 |
| SH_SHIFT_ASSIGNMENTS | シフト割り当て結果 |

`SH_STAFF` 以外の従属テーブルはすべて `team_id` で `SH_TEAMS` に紐づきます（業務ごとのデータ分離用）。アプリは既定で **`team_config.DEFAULT_TEAM_ID`**（環境変数 `SHIFT_TEAM_ID`、未設定時は `1`）のチームのみ表示・更新します。別チーム用 UI は今後の拡張予定です。
