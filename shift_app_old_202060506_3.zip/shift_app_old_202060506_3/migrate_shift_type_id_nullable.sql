-- 既存 DB のみ: アプリは「休」行を shift_type_id=NULL & is_locked=1 で保存するため
-- NOT NULL 制約を外す（新規は ddl.sql が NULL 許容）
ALTER TABLE SH_SHIFT_ASSIGNMENTS
  MODIFY COLUMN shift_type_id INT NULL
    COMMENT 'タスク種別ID（FK・手動「休」確定時は NULL + is_locked）';
