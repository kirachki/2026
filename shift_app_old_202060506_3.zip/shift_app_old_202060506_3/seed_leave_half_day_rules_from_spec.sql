-- SH_LEAVE_HALF_DAY_RULES 登録用 SQL
-- weekday: 0=月, 1=火, 2=水, 3=木, 4=金, 5=土, 6=日
-- kind: morning_half | afternoon_half
--
-- 【注意】テーブルは UNIQUE(team_id, weekday, kind) のため、
--         同じ曜日・同じ kind に2行は入りません。
--         ご提示では午後休が「12:40–16:40（月）」と「13:20–17:10（月）」の両方がありましたが、
--         月曜の午後休は 12:40–16:40 のみ登録しています。
--         13:20–17:10 は表記が「月」のままでは月曜と重複するため、
--         よくある運用に合わせ **水曜の午後休** として登録する行を別コメントで示します。
--
-- 利用前に team_id を自分のチーム ID に置き換えてください。

SET @team_id := 1;

-- 既存ルールを差し替える場合（任意）
-- DELETE FROM SH_LEAVE_HALF_DAY_RULES WHERE team_id = @team_id;

INSERT INTO SH_LEAVE_HALF_DAY_RULES (team_id, weekday, kind, start_time, end_time) VALUES
  -- 午前休
  (@team_id, 0, 'morning_half',    '08:00:00', '11:40:00'),  -- 月
  (@team_id, 2, 'morning_half',    '08:30:00', '12:20:00'),  -- 水
  (@team_id, 1, 'morning_half',    '08:50:00', '12:40:00'),  -- 火
  (@team_id, 3, 'morning_half',    '08:50:00', '12:40:00'),  -- 木
  (@team_id, 4, 'morning_half',    '08:50:00', '12:40:00'),  -- 金
  -- 午後休（月は 12:40–16:40 のみ）
  (@team_id, 0, 'afternoon_half', '12:40:00', '16:40:00'),  -- 月
  (@team_id, 1, 'afternoon_half', '13:40:00', '17:30:00'),  -- 火
  (@team_id, 3, 'afternoon_half', '13:40:00', '17:30:00'),  -- 木
  (@team_id, 4, 'afternoon_half', '13:40:00', '17:30:00');  -- 金

-- 「13:20–17:10」も同一チームで必要な場合の例:
-- （月曜とは UNIQUE で共存できないため、意図が「水曜午後」などなら weekday=2 で追加）
-- INSERT INTO SH_LEAVE_HALF_DAY_RULES (team_id, weekday, kind, start_time, end_time) VALUES
--   (@team_id, 2, 'afternoon_half', '13:20:00', '17:10:00');
