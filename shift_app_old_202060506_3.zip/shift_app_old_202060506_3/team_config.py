"""マルチチーム UI 追加まで、既定で操作するチーム ID（環境変数 SHIFT_TEAM_ID で上書き可）。"""
import os

DEFAULT_TEAM_ID = int(os.getenv("SHIFT_TEAM_ID", "1"))
