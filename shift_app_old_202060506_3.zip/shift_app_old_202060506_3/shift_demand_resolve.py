"""期間の曜日／特定日需要から、ソルバ用の日×種別グリッドを組み立てる。"""
from __future__ import annotations

from datetime import date, timedelta
from typing import Any, Iterable


def dates_in_period(start: date, end: date) -> list[date]:
    out: list[date] = []
    d = start
    while d <= end:
        out.append(d)
        d += timedelta(days=1)
    return out


def build_shift_demand_grids(
    dates: list[date],
    shift_type_ids: list[int],
    base_min_by_shift: dict[int, int],
    weekday_rows: Iterable[Any],
    date_rows: Iterable[Any],
) -> tuple[list[list[int]], list[list[bool]]]:
    """
    Returns:
        mins[d_idx][sh_idx] … 最低人数（稼働停止日は 0）
        blocked[d_idx][sh_idx] … True のときその日その種別へは誰も配置しない
    """
    wd_map: dict[tuple[int, int], tuple[int, bool]] = {}
    for r in weekday_rows:
        wd_map[(int(r.shift_type_id), int(r.weekday))] = (
            max(0, int(r.min_staff)),
            bool(r.is_feasible),
        )
    dt_map: dict[tuple[int, date], tuple[int, bool]] = {}
    for r in date_rows:
        dt_map[(int(r.shift_type_id), r.demand_date)] = (
            max(0, int(r.min_staff)),
            bool(r.is_feasible),
        )

    n_days = len(dates)
    n_sh = len(shift_type_ids)
    idx_by_st = {st_id: i for i, st_id in enumerate(shift_type_ids)}
    mins: list[list[int]] = [[0] * n_sh for _ in range(n_days)]
    blocked: list[list[bool]] = [[False] * n_sh for _ in range(n_days)]

    for d_idx, work_date in enumerate(dates):
        py_wd = work_date.weekday()
        for st_id in shift_type_ids:
            sh_idx = idx_by_st[st_id]
            key_d = (st_id, work_date)
            if key_d in dt_map:
                mn, feasible = dt_map[key_d]
            elif (st_id, py_wd) in wd_map:
                mn, feasible = wd_map[(st_id, py_wd)]
            else:
                mn = max(0, int(base_min_by_shift.get(st_id, 1)))
                feasible = True
            if not feasible:
                mins[d_idx][sh_idx] = 0
                blocked[d_idx][sh_idx] = True
            else:
                mins[d_idx][sh_idx] = mn
                blocked[d_idx][sh_idx] = False
    return mins, blocked
