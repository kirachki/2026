"""リクエストから現在のチーム ID を解決する。"""
from fastapi import Depends, Request
from sqlalchemy.orm import Session

from database import get_db
import models
from team_config import DEFAULT_TEAM_ID


def resolve_team_id(request: Request, db: Session, team_id_param: int | None) -> int:
    """
    team_id_param: クエリ ?team_id= （明示時は優先）
    次に Cookie shift_team_id、最後に既定／先頭の有効チーム。
    """
    active = (
        db.query(models.Team)
        .filter(models.Team.is_active == True)
        .order_by(models.Team.id)
        .all()
    )
    valid_ids = {t.id for t in active}
    if not valid_ids:
        return DEFAULT_TEAM_ID

    auth_user = request.session.get("auth_user")
    if isinstance(auth_user, dict):
        role = str(auth_user.get("role", "")).strip().lower()
        team_raw = auth_user.get("team_id")
        team_from_session = int(team_raw) if str(team_raw).isdigit() else None
        # admin 以外は常に自チームへ固定（URL や Cookie の team_id 指定は無視）
        if role != "admin" and team_from_session in valid_ids:
            return int(team_from_session)

    if team_id_param is not None and team_id_param in valid_ids:
        return team_id_param
    c = request.cookies.get("shift_team_id")
    if c and c.isdigit() and int(c) in valid_ids:
        return int(c)
    if DEFAULT_TEAM_ID in valid_ids:
        return DEFAULT_TEAM_ID
    return min(valid_ids)


def get_current_team_id(request: Request, db: Session = Depends(get_db)) -> int:
    """Cookie 等からチーム ID（ルーター用 Dependency）。"""
    return resolve_team_id(request, db, None)
