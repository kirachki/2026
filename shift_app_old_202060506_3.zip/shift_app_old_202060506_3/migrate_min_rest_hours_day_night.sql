-- 既存 DB 向け: 日勤↔夜勤の最短休憩時間（時間）を追加
ALTER TABLE SH_CONSTRAINTS
ADD COLUMN min_rest_hours_day_night INT NOT NULL DEFAULT 48
COMMENT '日勤と夜勤の最短休憩時間（時間）';
