"""グリッド・ソルバで日付を datetime.date / ISO 文字列に統一する。"""
from __future__ import annotations

from datetime import date, datetime


def to_calendar_date(value) -> date | None:
    """MySQL DATE が datetime / 文字列として返る場合も datetime.date に揃える。"""
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if isinstance(value, str):
        s = value.strip()
        if len(s) >= 10:
            s = s[:10]
        try:
            return date.fromisoformat(s)
        except ValueError:
            return None
    return None


def schedule_date_key(value) -> str:
    """テンプレートの日付キー（ISO）と一致させる。"""
    d = to_calendar_date(value)
    return d.isoformat() if d else ""
