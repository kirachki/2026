-- 既存 DB: タスク種別の人数の意味（最低 or ちょうど）
-- MySQL 8+ 想定。実行前にバックアップ推奨。

ALTER TABLE SH_SHIFT_TYPES
  ADD COLUMN min_staff_mode VARCHAR(20) NOT NULL DEFAULT 'at_least'
  COMMENT 'at_least=指定人数以上 / exact=指定人数ちょうど'
  AFTER min_staff;
