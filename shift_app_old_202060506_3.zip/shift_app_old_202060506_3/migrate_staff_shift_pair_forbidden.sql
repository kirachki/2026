-- 既存 DB に SH_STAFF_SHIFT_PAIR_FORBIDDEN を追加（何度実行しても安全）
CREATE TABLE IF NOT EXISTS SH_STAFF_SHIFT_PAIR_FORBIDDEN (
    id              INT             NOT NULL AUTO_INCREMENT,
    team_id         INT             NOT NULL                    COMMENT 'チームID（FK）',
    staff_id_low    INT             NOT NULL                    COMMENT 'スタッフID（必ず staff_id_high より小さい値）',
    staff_id_high   INT             NOT NULL                    COMMENT 'スタッフID',
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    UNIQUE KEY uq_staff_shift_pair_forbidden (team_id, staff_id_low, staff_id_high),
    INDEX idx_staff_shift_pair_team (team_id),
    CONSTRAINT chk_staff_shift_pair_order CHECK (staff_id_low < staff_id_high),
    CONSTRAINT fk_staff_shift_pair_team
        FOREIGN KEY (team_id)
        REFERENCES SH_TEAMS (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT fk_staff_shift_pair_low
        FOREIGN KEY (staff_id_low)
        REFERENCES SH_STAFF (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT fk_staff_shift_pair_high
        FOREIGN KEY (staff_id_high)
        REFERENCES SH_STAFF (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='同一日同一シフト種別で同席させないスタッフペア';
