"""シフト表テンプレート用コンテキスト（main・closed_days・最適化後パッチなどから共用）。"""
from __future__ import annotations

from datetime import date, timedelta

from sqlalchemy.exc import OperationalError
from sqlalchemy.orm import Session, joinedload

import models
from constraint_rest_hours import get_min_rest_hours_day_night
from date_keys import schedule_date_key
from leave_sync import sync_approved_leave_assignments
from period_closed_days import closed_dates_in_period


def week_segments_for_dates(dates: list[date]) -> list[list[date]]:
    """ISO 週（月〜日のカレンダー週）ごとに連続日付を分割。表頭の週帯に使用。"""
    if not dates:
        return []
    segments: list[list[date]] = []
    cur_key: tuple[int, int] | None = None
    buf: list[date] = []
    for d in dates:
        y, w, _ = d.isocalendar()
        key = (y, w)
        if cur_key is not None and key != cur_key:
            segments.append(buf)
            buf = []
        cur_key = key
        buf.append(d)
    if buf:
        segments.append(buf)
    return segments


def build_schedule_context(
    db: Session,
    period_id: int | None = None,
    team_id: int | None = None,
) -> dict:
    """全テンプレートに共通で渡すデータを構築する。team_id は解決済みの整数を渡すこと。"""
    tid = team_id
    all_periods = (
        db.query(models.SchedulePeriod)
        .filter(models.SchedulePeriod.team_id == tid)
        .order_by(models.SchedulePeriod.start_date.desc())
        .all()
    )
    staff_list = (
        db.query(models.Staff)
        .filter(models.Staff.team_id == tid, models.Staff.is_active == True)
        .all()
    )
    shift_types = (
        db.query(models.ShiftType)
        .filter(models.ShiftType.team_id == tid)
        .order_by(models.ShiftType.start_time.asc(), models.ShiftType.id.asc())
        .all()
    )

    current_period = None
    if period_id:
        current_period = db.query(models.SchedulePeriod).filter(
            models.SchedulePeriod.id == period_id,
            models.SchedulePeriod.team_id == tid,
        ).first()
    if not current_period and all_periods:
        current_period = all_periods[0]

    dates: list[date] = []
    if current_period:
        d = current_period.start_date
        while d <= current_period.end_date:
            dates.append(d)
            d += timedelta(days=1)

    closed_dates_set: set[date] = set()
    if current_period:
        closed_dates_set = closed_dates_in_period(db, current_period.id)

    if current_period:
        sync_approved_leave_assignments(db, tid, current_period)
        db.commit()

    assignments_map: dict = {}
    if current_period:
        rows = (
            db.query(models.ShiftAssignment)
            .filter(
                models.ShiftAssignment.team_id == tid,
                models.ShiftAssignment.work_date >= current_period.start_date,
                models.ShiftAssignment.work_date <= current_period.end_date,
            )
            .all()
        )
        for a in rows:
            assignments_map[(a.staff_id, schedule_date_key(a.work_date))] = a

    constraint = None
    if current_period:
        constraint = db.query(models.Constraint).filter(
            models.Constraint.period_id == current_period.id
        ).first()
        if constraint:
            try:
                constraint.min_rest_hours_day_night = get_min_rest_hours_day_night(
                    db, constraint.id
                )
            except OperationalError:
                constraint.min_rest_hours_day_night = 48

    shift_weekday_demand_cells: dict = {}
    period_shift_date_demands: list = []
    leave_requests_map: dict = {}
    if current_period:
        try:
            for r in (
                db.query(models.PeriodShiftWeekdayDemand)
                .filter(
                    models.PeriodShiftWeekdayDemand.period_id == current_period.id,
                )
                .all()
            ):
                shift_weekday_demand_cells[f"{r.shift_type_id}_{r.weekday}"] = r
            period_shift_date_demands = (
                db.query(models.PeriodShiftDateDemand)
                .options(joinedload(models.PeriodShiftDateDemand.shift_type))
                .filter(
                    models.PeriodShiftDateDemand.period_id == current_period.id,
                )
                .order_by(
                    models.PeriodShiftDateDemand.demand_date.asc(),
                    models.PeriodShiftDateDemand.shift_type_id.asc(),
                )
                .all()
            )
        except OperationalError:
            shift_weekday_demand_cells = {}
            period_shift_date_demands = []
    if current_period:
        try:
            leave_rows = (
                db.query(models.LeaveRequest)
                .filter(
                    models.LeaveRequest.team_id == tid,
                    models.LeaveRequest.request_date >= current_period.start_date,
                    models.LeaveRequest.request_date <= current_period.end_date,
                )
                .all()
            )
            for lr in leave_rows:
                leave_requests_map[(lr.staff_id, schedule_date_key(lr.request_date))] = lr
        except OperationalError:
            leave_requests_map = {}

    violations: list[str] = []
    for s in staff_list:
        for i, work_date in enumerate(dates[:-1]):
            d_next = dates[i + 1]
            if work_date in closed_dates_set or d_next in closed_dates_set:
                continue
            a1 = assignments_map.get((s.id, schedule_date_key(work_date)))
            a2 = assignments_map.get((s.id, schedule_date_key(d_next)))
            if (
                a1
                and a2
                and a1.shift_type_id is not None
                and a2.shift_type_id is not None
                and a1.shift_type
                and a2.shift_type
                and a1.shift_type.name == "夜勤"
                and a2.shift_type.name == "早番"
            ):
                violations.append(f"{s.name}: {work_date} 夜勤→{d_next} 早番")

    prev_period = next_period = None
    if current_period:
        idx = next((i for i, p in enumerate(all_periods) if p.id == current_period.id), None)
        if idx is not None:
            if idx + 1 < len(all_periods):
                prev_period = all_periods[idx + 1]
            if idx > 0:
                next_period = all_periods[idx - 1]

    return {
        "all_periods": all_periods,
        "current_period": current_period,
        "staff_list": staff_list,
        "shift_types": shift_types,
        "dates": dates,
        "assignments": assignments_map,
        "constraint": constraint,
        "violations": violations,
        "prev_period": prev_period,
        "next_period": next_period,
        "total_assignments": len(assignments_map),
        "closed_dates_set": closed_dates_set,
        "week_segments": week_segments_for_dates(dates),
        "weekday_short_labels": ["月", "火", "水", "木", "金", "土", "日"],
        "weekday_indices": list(range(7)),
        "shift_weekday_demand_cells": shift_weekday_demand_cells,
        "period_shift_date_demands": period_shift_date_demands,
        "leave_requests": leave_requests_map,
    }
