"""
初回起動時にサンプルデータを投入するスクリプト。
main.py から自動で呼ばれます。
"""

from datetime import date
from sqlalchemy.orm import Session
import models


def seed_data(db: Session) -> None:
    team = models.Team(name="サポート第二チーム", code="support_team_2")
    db.add(team)
    db.flush()
    tid = team.id

    # ── スタッフ ─────────────────────────────
    staff_data = [
        {"name": "田中 一郎", "role": "リーダー",    "employment_type": "full_time"},
        {"name": "鈴木 花子", "role": "一般スタッフ", "employment_type": "full_time"},
        {"name": "佐藤 次郎", "role": "一般スタッフ", "employment_type": "full_time"},
        {"name": "山田 美咲", "role": "一般スタッフ", "employment_type": "part_time"},
        {"name": "伊藤 健太", "role": "一般スタッフ", "employment_type": "full_time"},
    ]
    staff_objs = []
    for d in staff_data:
        s = models.Staff(team_id=tid, **d)
        db.add(s)
        staff_objs.append(s)
    db.flush()

    # ── タスク種別 ───────────────────────────
    shift_data = [
        {"name": "早番", "start_time": "08:00:00", "end_time": "16:00:00", "min_staff": 1, "color_code": "#60a5fa"},
        {"name": "遅番", "start_time": "13:00:00", "end_time": "21:00:00", "min_staff": 1, "color_code": "#a78bfa"},
        {"name": "夜勤", "start_time": "21:00:00", "end_time": "06:00:00", "min_staff": 1, "color_code": "#34d399"},
    ]
    shift_objs = []
    for d in shift_data:
        st = models.ShiftType(team_id=tid, **d)
        db.add(st)
        shift_objs.append(st)
    db.flush()

    # ── スケジュール期間 ─────────────────────
    period = models.SchedulePeriod(
        team_id=tid,
        start_date=date(2025, 7, 1),
        end_date=date(2025, 7, 7),
        label="2025年7月 第1週",
        status="optimized",
    )
    db.add(period)
    db.flush()

    # ── 制約設定 ─────────────────────────────
    constraint = models.Constraint(
        team_id=tid,
        period_id=period.id,
        max_consecutive_days=5,
        max_days_per_week=6,
        min_days_off_per_week=1,
        max_nights_per_week=2,
        no_early_after_night=True,
        equalize_workload=True,
    )
    db.add(constraint)
    db.flush()

    # ── 半休の曜日別時間窓（例: 月〜金で異なる午前／午後）────────────────
    half_seed = [
        (0, models.LEAVE_KIND_MORNING_HALF, "08:00:00", "11:40:00"),
        (2, models.LEAVE_KIND_MORNING_HALF, "08:30:00", "12:20:00"),
        (1, models.LEAVE_KIND_MORNING_HALF, "08:50:00", "12:40:00"),
        (3, models.LEAVE_KIND_MORNING_HALF, "08:50:00", "12:40:00"),
        (4, models.LEAVE_KIND_MORNING_HALF, "08:50:00", "12:40:00"),
        (0, models.LEAVE_KIND_AFTERNOON_HALF, "12:40:00", "16:40:00"),
        (2, models.LEAVE_KIND_AFTERNOON_HALF, "13:20:00", "17:10:00"),
        (3, models.LEAVE_KIND_AFTERNOON_HALF, "13:40:00", "17:30:00"),
        (4, models.LEAVE_KIND_AFTERNOON_HALF, "13:40:00", "17:30:00"),
        (1, models.LEAVE_KIND_AFTERNOON_HALF, "13:40:00", "17:30:00"),
    ]
    for wd, kind, st_t, en_t in half_seed:
        db.add(
            models.LeaveHalfDayRule(
                team_id=tid,
                weekday=wd,
                kind=kind,
                start_time=st_t,
                end_time=en_t,
            )
        )
    db.flush()

    # ── 休み希望 ─────────────────────────────
    leave_data = [
        {
            "staff_id": staff_objs[1].id,
            "request_date": date(2025, 7, 4),
            "leave_kind": models.LEAVE_KIND_FULL_DAY,
            "reason": "私用",
            "status": "approved",
        },
        {
            "staff_id": staff_objs[3].id,
            "request_date": date(2025, 7, 6),
            "leave_kind": models.LEAVE_KIND_FULL_DAY,
            "reason": "家族行事",
            "status": "approved",
        },
    ]
    for d in leave_data:
        db.add(models.LeaveRequest(team_id=tid, **d))
    db.flush()

    # ── シフト割り当て（ソルバー結果） ─────────
    assignments_raw = [
        (0, date(2025, 7, 1), 0), (0, date(2025, 7, 2), 1), (0, date(2025, 7, 3), 2),
        (0, date(2025, 7, 4), 2), (0, date(2025, 7, 5), 2), (0, date(2025, 7, 7), 2),
        (1, date(2025, 7, 1), 1), (1, date(2025, 7, 2), 0), (1, date(2025, 7, 3), 1),
        (1, date(2025, 7, 5), 1), (1, date(2025, 7, 6), 0), (1, date(2025, 7, 7), 0),
        (2, date(2025, 7, 1), 2), (2, date(2025, 7, 3), 2), (2, date(2025, 7, 4), 1),
        (2, date(2025, 7, 5), 1), (2, date(2025, 7, 6), 0), (2, date(2025, 7, 7), 0),
        (3, date(2025, 7, 1), 0), (3, date(2025, 7, 2), 0), (3, date(2025, 7, 3), 0),
        (3, date(2025, 7, 4), 0), (3, date(2025, 7, 5), 1), (3, date(2025, 7, 7), 0),
        (4, date(2025, 7, 2), 2), (4, date(2025, 7, 3), 1), (4, date(2025, 7, 4), 0),
        (4, date(2025, 7, 5), 0), (4, date(2025, 7, 6), 2), (4, date(2025, 7, 7), 1),
    ]
    for si, work_date, shi in assignments_raw:
        db.add(models.ShiftAssignment(
            team_id=tid,
            staff_id=staff_objs[si].id,
            period_id=period.id,
            shift_type_id=shift_objs[shi].id,
            work_date=work_date,
            source="solver",
        ))

    db.commit()
    print("✅ サンプルデータを投入しました。")
