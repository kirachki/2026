-- 既存 DB に制約の個別オン／オフ（無効化）フラグを追加する場合に実行

ALTER TABLE SH_CONSTRAINTS
    ADD COLUMN enable_max_consecutive_days TINYINT(1) NOT NULL DEFAULT 1
        COMMENT '最大連続勤務日数を適用' AFTER equalize_workload,
    ADD COLUMN enable_max_days_per_week TINYINT(1) NOT NULL DEFAULT 1
        COMMENT '週最大勤務日数を適用' AFTER enable_max_consecutive_days,
    ADD COLUMN enable_min_days_off_per_week TINYINT(1) NOT NULL DEFAULT 1
        COMMENT '週最小休日由来の上限を適用' AFTER enable_max_days_per_week,
    ADD COLUMN enable_max_nights_per_week TINYINT(1) NOT NULL DEFAULT 1
        COMMENT '週夜勤回数上限を適用' AFTER enable_min_days_off_per_week,
    ADD COLUMN enable_no_consecutive_nights TINYINT(1) NOT NULL DEFAULT 1
        COMMENT '連続夜勤禁止を適用' AFTER enable_max_nights_per_week,
    ADD COLUMN enable_min_rest_day_night TINYINT(1) NOT NULL DEFAULT 1
        COMMENT '日勤↔夜勤の最短休憩を適用' AFTER enable_no_consecutive_nights;
