"""
OR-Tools CP-SAT を使ったシフト最適化エンジン。
ロック済みの割り当てと休み希望を考慮してシフトを生成します。
"""

from __future__ import annotations

from collections import defaultdict
from datetime import date, datetime, time as dt_time, timedelta
from typing import Any, Optional

from ortools.sat.python import cp_model

from leave_intervals import ApprovedLeaveSpec, build_partial_leave_forbidden_shift_indices
from schedule_context import week_segments_for_dates


def _norm_min_staff_modes(
    m: Optional[dict[int, str]],
) -> dict[int, str]:
    """タスク種別 ID → 'at_least' | 'exact'（不正値は at_least）。"""
    out: dict[int, str] = {}
    for k, v in (m or {}).items():
        out[k] = "exact" if v == "exact" else "at_least"
    return out


def _hhmm_pair_from_shift_time_column(val: Any) -> tuple[int, int]:
    """DB の HH:MM 文字列または MySQL の timedelta に対応。"""
    if hasattr(val, "total_seconds"):
        total = int(val.total_seconds())
        return total // 3600, (total % 3600) // 60
    s = str(val).strip()
    parts = s.replace(".", ":").split(":")
    h = int(parts[0])
    m = int(parts[1]) if len(parts) > 1 else 0
    return h, m


def _shift_interval_for_calendar_day(work_date: date, st: Any) -> tuple[datetime, datetime]:
    sh, sm = _hhmm_pair_from_shift_time_column(st.start_time)
    eh, em = _hhmm_pair_from_shift_time_column(st.end_time)
    start_dt = datetime.combine(work_date, dt_time(sh, sm))
    end_dt = datetime.combine(work_date, dt_time(eh, em))
    if end_dt <= start_dt:
        end_dt += timedelta(days=1)
    return start_dt, end_dt


def _gap_seconds_between_shifts_on_calendar_dates(
    work_date_a: date,
    st_a: Any,
    work_date_b: date,
    st_b: Any,
) -> float:
    """2 シフトを時系列順に並べたときの、先行の終了から後続の開始までの秒間隔。"""
    s1, e1 = _shift_interval_for_calendar_day(work_date_a, st_a)
    s2, e2 = _shift_interval_for_calendar_day(work_date_b, st_b)
    if e1 <= s2:
        return (s2 - e1).total_seconds()
    if e2 <= s1:
        return (s1 - e2).total_seconds()
    return 0.0


def _collect_day_night_short_gap_pairs(
    *,
    dates: list[date],
    shift_types_ordered: list[Any],
    night_idx: int,
    min_rest_seconds: float,
) -> list[tuple[int, int, int, int]]:
    """夜勤とそれ以外の組で、休憩が min_rest_seconds 未満になるカレンダー日ペアを列挙。"""
    num_days = len(dates)
    num_shifts = len(shift_types_ordered)
    if num_shifts < 2 or night_idx < 0 or night_idx >= num_shifts:
        return []
    out: list[tuple[int, int, int, int]] = []
    for d1 in range(num_days):
        wd1 = dates[d1]
        for d2 in range(d1 + 1, num_days):
            wd2 = dates[d2]
            for sh1 in range(num_shifts):
                for sh2 in range(num_shifts):
                    if (sh1 == night_idx) == (sh2 == night_idx):
                        continue
                    gap = _gap_seconds_between_shifts_on_calendar_dates(
                        wd1,
                        shift_types_ordered[sh1],
                        wd2,
                        shift_types_ordered[sh2],
                    )
                    if gap < min_rest_seconds:
                        out.append((d1, sh1, d2, sh2))
    return out


def _detect_night_shift_index(
    *,
    shift_type_ids: list[int],
    shift_types_ordered: Optional[list[Any]],
) -> Optional[int]:
    """翌日またぎ（end <= start）の種別を夜勤とみなし index を返す。"""
    if not shift_types_ordered or len(shift_types_ordered) != len(shift_type_ids):
        return None
    if [getattr(o, "id", None) for o in shift_types_ordered] != list(shift_type_ids):
        return None
    for idx, st in enumerate(shift_types_ordered):
        sh, sm = _hhmm_pair_from_shift_time_column(st.start_time)
        eh, em = _hhmm_pair_from_shift_time_column(st.end_time)
        if (eh * 60 + em) <= (sh * 60 + sm):
            return idx
    return None


def _merge_staff_day_sets(*parts: dict[int, set]) -> dict[int, set]:
    """staff_id -> 日付集合 を結合（同一スタッフは和集合）。"""
    out: dict[int, set] = {}
    for p in parts:
        for sid, ds in p.items():
            out.setdefault(sid, set()).update(ds)
    return out


def _min_days_off_for_segment(segment_len: int, min_days_off_per_week: int) -> int:
    """
    ISO週の端数（日数 < 7）では最小休日を日数按分（切り捨て）で適用する。
    例: 週最小休日1日のとき、6日以下の端数週は 0 日オフ要求。
    """
    if segment_len <= 0:
        return 0
    if min_days_off_per_week <= 0:
        return 0
    if segment_len >= 7:
        return min_days_off_per_week
    return (min_days_off_per_week * segment_len) // 7


def _solver_status_jp(status: int) -> str:
    return {
        cp_model.UNKNOWN: "不明・時間切れなど（UNKNOWN）",
        cp_model.MODEL_INVALID: "モデルが無効（MODEL_INVALID）",
        cp_model.FEASIBLE: "実行可能解あり（FEASIBLE）",
        cp_model.INFEASIBLE: "制約が矛盾して実行不可能（INFEASIBLE）",
        cp_model.OPTIMAL: "最適解（OPTIMAL）",
    }.get(status, f"コード {status}")


def _diagnose_infeasibility(
    *,
    staff_ids: list[int],
    shift_type_ids: list[int],
    min_staff_per_shift: dict[int, int],
    min_staff_mode_per_shift: Optional[dict[int, str]] = None,
    dates: list[date],
    leave_dates: dict[int, set],
    approved_leave_full_dates: dict[int, set],
    locked_off_dates: dict[int, set],
    locked_assignments: dict[tuple[int, date], int],
    closed_dates: set[date],
    no_early_after_night: bool,
    shift_eligibility_whitelist: Optional[dict[int, set[int]]] = None,
    max_days_per_week: int = 6,
    min_days_off_per_week: int = 1,
    max_nights_per_week: int = 7,
    forbidden_shift_pairs: Optional[list[tuple[int, int]]] = None,
    shift_day_min: Optional[list[list[int]]] = None,
    shift_day_blocked: Optional[list[list[bool]]] = None,
    min_rest_seconds_between_day_and_night: Optional[int] = None,
    shift_types_ordered: Optional[list[Any]] = None,
    enable_max_consecutive_days: bool = True,
    enable_max_days_per_week: bool = True,
    enable_min_days_off_per_week: bool = True,
    enable_max_nights_per_week: bool = True,
    enable_no_consecutive_nights: bool = True,
) -> list[str]:
    """実行不可能時にユーザー向けヒントを生成（十分条件ではない）。"""
    hints: list[str] = []
    num_staff = len(staff_ids)
    num_shifts = len(shift_type_ids)
    num_days = len(dates)
    elig_whitelist = shift_eligibility_whitelist or {}

    if shift_day_min is None or shift_day_blocked is None:
        shift_day_min = [
            [min_staff_per_shift.get(st_id, 1) for st_id in shift_type_ids]
            for _ in range(num_days)
        ]
        shift_day_blocked = [[False] * num_shifts for _ in range(num_days)]
    st_to_idx = {st: i for i, st in enumerate(shift_type_ids)}
    mode_map = _norm_min_staff_modes(min_staff_mode_per_shift)

    # 資格ホワイトリスト vs 最低人数・ロック
    staff_set = set(staff_ids)
    for st_id in shift_type_ids:
        allowed = elig_whitelist.get(st_id)
        if not allowed:
            continue
        eligible_here = len(staff_set & allowed)
        sh_idx = st_to_idx[st_id]
        max_need = 0
        any_feasible_day = False
        for d_idx, work_date in enumerate(dates):
            if work_date in closed_dates:
                continue
            if shift_day_blocked[d_idx][sh_idx]:
                continue
            any_feasible_day = True
            max_need = max(max_need, shift_day_min[d_idx][sh_idx])
        if not any_feasible_day:
            continue
        min_n = max_need
        if eligible_here < min_n:
            need_label = (
                "指定人数（ちょうど）"
                if mode_map.get(st_id) == "exact"
                else "最低人数"
            )
            hints.append(
                f"タスク種別 ID {st_id} は資格者のみ配置できますが、対象スタッフのうち資格者は "
                f"{eligible_here} 名だけです（{need_label} {min_n} 名）。スタッフｘタスクまたはスタッフ対象を見直してください。"
            )

    for (sid, wd), stid in locked_assignments.items():
        allowed = elig_whitelist.get(stid)
        if allowed and sid not in allowed:
            hints.append(
                f"{wd}: スタッフ ID {sid} はタスク種別 ID {stid} の資格者に含まれていませんが、"
                "ロック済みシフトがその種別を指定しています。"
            )

    # 日ごと: 必要シフト枠の合計 vs その日フルに勤務できる人数
    # 承認済み休暇 と 手動「休」確定（locked_off）は別物。未設定セルは出勤可能枠として数える。
    for work_date in dates:
        if work_date in closed_dates:
            continue
        ap = {
            sid
            for sid in staff_ids
            if work_date in approved_leave_full_dates.get(sid, set())
        }
        lo = {
            sid
            for sid in staff_ids
            if work_date in locked_off_dates.get(sid, set())
        }
        blocked = {
            sid for sid in staff_ids if work_date in leave_dates.get(sid, set())
        }
        avail = num_staff - len(blocked)
        d_idx = dates.index(work_date)
        need = sum(
            shift_day_min[d_idx][shi]
            for shi in range(num_shifts)
            if not shift_day_blocked[d_idx][shi]
        )
        if need > avail:
            parts: list[str] = []
            if (ap | lo) == blocked:
                if ap:
                    ids = ", ".join(str(x) for x in sorted(ap))
                    parts.append(
                        f"承認済み休暇として出勤不可: {len(ap)} 名（スタッフ ID: {ids}）"
                    )
                if lo:
                    ids = ", ".join(str(x) for x in sorted(lo))
                    parts.append(
                        f"手動で「休」に確定した日（ロック）により出勤不可: {len(lo)} 名（スタッフ ID: {ids}）"
                    )
            else:
                ids = ", ".join(str(x) for x in sorted(blocked))
                parts.append(
                    f"出勤不可としてモデルに渡されているスタッフ: {len(blocked)} 名（スタッフ ID: {ids}）"
                )
            detail = (
                " ".join(parts)
                if parts
                else "（出勤不可の登録は見えませんが、他制約と組み合わさって不足している可能性があります）"
            )
            hints.append(
                f"{work_date}: タスク種別ごとの最低人数の合計は {need} 名分必要です。"
                f"{detail} "
                f"上記を除き、その日にシフトを配置できるのは最大 {avail} 名です。"
                f"※表示が「未」（未設定）の日は休みの意思とはみなさず、ソルバはそこにシフトを入れられます。"
            )

    # 週夜勤上限 0 と「夜勤」枠への需要の整合（種別2種以上で末尾＝夜勤）
    if (
        enable_max_nights_per_week
        and len(shift_type_ids) >= 2
        and max_nights_per_week == 0
    ):
        night_idx = len(shift_type_ids) - 1
        night_tid = shift_type_ids[night_idx]
        max_need_night = 0
        need_night_dates = 0
        for d_idx, work_date in enumerate(dates):
            if work_date in closed_dates:
                continue
            if shift_day_blocked[d_idx][night_idx]:
                continue
            mn = shift_day_min[d_idx][night_idx]
            if mn > 0:
                need_night_dates += 1
                max_need_night = max(max_need_night, mn)
        if need_night_dates > 0:
            hints.append(
                f"週最大夜勤回数が 0 のため、どのスタッフも「夜勤」（開始時刻順で最後の種別・ID {night_tid}）には "
                "週あたり 1 回も入れません。"
                f"一方で需要ではその種別に最低人数が {max_need_night} 名の日が期間内に {need_night_dates} 日あります。"
                "夜勤の上限を 1 以上にするか、日別/曜日別パターンまたは種別マスタの最低人数で "
                "その枠を稼働停止／0人にしてください。"
            )

    per_day_lock: dict[date, dict[int, int]] = defaultdict(dict)
    for (sid, wd), stid in locked_assignments.items():
        per_day_lock[wd][sid] = stid

    for work_date in dates:
        if work_date not in per_day_lock:
            continue
        locks_here = per_day_lock[work_date]
        ap_here = {
            sid
            for sid in staff_ids
            if work_date in approved_leave_full_dates.get(sid, set())
        }
        lo_here = {
            sid
            for sid in staff_ids
            if work_date in locked_off_dates.get(sid, set())
        }
        for sid in set(locks_here.keys()) & (ap_here | lo_here):
            if sid in ap_here and sid in lo_here:
                src = "承認済み休暇と手動の「休」確定の両方"
            elif sid in ap_here:
                src = "承認済み休暇"
            else:
                src = "手動の「休」確定（ロック）"
            hints.append(
                f"{work_date}: スタッフ ID {sid} は{src}で出勤不可とされている一方で、"
                "ロック済みシフトも指定されており、データが矛盾している可能性があります。"
            )

    if (
        no_early_after_night
        and len(shift_type_ids) >= 2
        and locked_assignments
    ):
        st_to_idx = {st: i for i, st in enumerate(shift_type_ids)}
        night_idx = len(shift_type_ids) - 1
        early_idx = 0
        for idx in range(len(dates) - 1):
            d0, d1 = dates[idx], dates[idx + 1]
            L0, L1 = per_day_lock.get(d0, {}), per_day_lock.get(d1, {})
            for sid in set(L0) & set(L1):
                if st_to_idx.get(L0[sid]) == night_idx and st_to_idx.get(L1[sid]) == early_idx:
                    hints.append(
                        f"{d0}〜{d1}: スタッフ ID {sid} で「夜勤ロック」と「翌日の早番ロック」が同時に指定されており、"
                        "夜勤翌日早番禁止と両立しません。"
                    )

    week_segments = week_segments_for_dates(list(dates))
    for sid in staff_ids:
        for segment in week_segments:
            L = len(segment)
            if L == 0:
                continue
            locked_work_here = sum(
                1
                for wd in segment
                if (sid, wd) in locked_assignments
            )
            cap_max = max_days_per_week
            seg_min_off = _min_days_off_for_segment(L, min_days_off_per_week)
            cap_rest = L - seg_min_off
            if enable_max_days_per_week and locked_work_here > cap_max:
                first, last = segment[0], segment[-1]
                hints.append(
                    f"{first}〜{last}（ISO週内・期間に含まれる日）: スタッフ ID {sid} のロック済み勤務が "
                    f"{locked_work_here} 日あり、週最大勤務日数 {max_days_per_week} 日を超えています。"
                )
            if enable_min_days_off_per_week and locked_work_here > cap_rest:
                first, last = segment[0], segment[-1]
                hints.append(
                    f"{first}〜{last}（ISO週内）: スタッフ ID {sid} のロック済み勤務が "
                    f"{locked_work_here} 日あり、この週帯（{L} 日）では最小休日 "
                    f"{seg_min_off} 日（週設定 {min_days_off_per_week} 日を日数按分）のため勤務は最大 {cap_rest} 日までです。"
                )

    night_tid = shift_type_ids[-1] if len(shift_type_ids) >= 2 else None
    max_nights_per_week = max(0, min(7, max_nights_per_week))
    if night_tid is not None and locked_assignments:
        for sid in staff_ids:
            if enable_no_consecutive_nights:
                for idx in range(len(dates) - 1):
                    d0, d1 = dates[idx], dates[idx + 1]
                    if (
                        locked_assignments.get((sid, d0)) == night_tid
                        and locked_assignments.get((sid, d1)) == night_tid
                    ):
                        hints.append(
                            f"{d0}〜{d1}: スタッフ ID {sid} で連続2日が夜勤（種別 ID {night_tid}）のロックとなっており、"
                            "連続夜勤禁止と両立しません。"
                        )
            if enable_max_nights_per_week:
                for segment in week_segments:
                    L = len(segment)
                    if L == 0:
                        continue
                    night_locked_here = sum(
                        1
                        for wd in segment
                        if locked_assignments.get((sid, wd)) == night_tid
                    )
                    if night_locked_here > max_nights_per_week:
                        first, last = segment[0], segment[-1]
                        hints.append(
                            f"{first}〜{last}（ISO週内）: スタッフ ID {sid} の夜勤ロックが "
                            f"{night_locked_here} 回あり、週最大夜勤 {max_nights_per_week} 回を超えています。"
                        )

    if (
        min_rest_seconds_between_day_and_night
        and shift_types_ordered
        and len(shift_types_ordered) == len(shift_type_ids)
        and len(shift_type_ids) >= 2
        and locked_assignments
    ):
        st_objs = shift_types_ordered
        ids_ordered = [getattr(o, "id", None) for o in st_objs]
        if ids_ordered == list(shift_type_ids):
            night_idx = len(shift_type_ids) - 1
            mr = float(min_rest_seconds_between_day_and_night)
            dates_ok = set(dates)
            locked_by_staff: dict[int, list[tuple[date, int]]] = defaultdict(list)
            for (sid, wd), stid in locked_assignments.items():
                if sid in staff_set and wd in dates_ok:
                    locked_by_staff[sid].append((wd, stid))
            hrs = min_rest_seconds_between_day_and_night // 3600
            for sid, rows in locked_by_staff.items():
                for i, (wd_a, id_a) in enumerate(rows):
                    try:
                        ia = shift_type_ids.index(id_a)
                    except ValueError:
                        continue
                    for wd_b, id_b in rows[i + 1 :]:
                        try:
                            ib = shift_type_ids.index(id_b)
                        except ValueError:
                            continue
                        if wd_a == wd_b:
                            continue
                        if (ia == night_idx) == (ib == night_idx):
                            continue
                        gap = _gap_seconds_between_shifts_on_calendar_dates(
                            wd_a,
                            st_objs[ia],
                            wd_b,
                            st_objs[ib],
                        )
                        if gap < mr:
                            hints.append(
                                f"{wd_a}・{wd_b}: スタッフ ID {sid} のロックが日勤系と夜勤（開始時刻順で最後の種別）の組で、"
                                f"先行終了から後続開始まで {hrs} 時間未満です。"
                                "実時間ベースの休憩制約と両立しません。"
                            )

    staff_id_set = set(staff_ids)
    pair_seen_diag: set[tuple[int, int]] = set()
    for a, b in forbidden_shift_pairs or []:
        if a == b:
            continue
        lo, hi = (a, b) if a < b else (b, a)
        if lo not in staff_id_set or hi not in staff_id_set:
            continue
        if (lo, hi) in pair_seen_diag:
            continue
        pair_seen_diag.add((lo, hi))
        for wd in dates:
            la = locked_assignments.get((lo, wd))
            lb = locked_assignments.get((hi, wd))
            if la is not None and lb is not None and la == lb:
                hints.append(
                    f"{wd}: スタッフ ID {lo} と {hi} が同じシフト種別 ID {la} でロックされており、"
                    "同シフト同時配置ペア禁止と両立しません。"
                )

    for (sid, wd), stid in locked_assignments.items():
        if wd in closed_dates:
            continue
        try:
            d_idx = dates.index(wd)
        except ValueError:
            continue
        shi = st_to_idx.get(stid)
        if shi is None:
            continue
        if shift_day_blocked[d_idx][shi]:
            hints.append(
                f"{wd}: タスク種別 ID {stid} は「稼働停止」の需要設定ですが、"
                f"スタッフ ID {sid} にその種別のロック済みシフトがあります。"
            )

    if not hints:
        hints.append(
            "ソルバは制約全体として矛盾（実行不可能）と判定しました。"
            "個別の理由は自動では特定できません。日別/曜日別パターン・稼働可否、タスク種別の最低人数・スタッフｘタスク、"
            "夜勤の週上限・連続夜勤禁止・日勤と夜勤の実時間ベース休憩、同シフトペア禁止、承認済み休暇、"
            "手動の「休」確定・ロック済みシフトを見直してください。"
        )

    return hints


def _build_failure_date_candidates(
    *,
    staff_ids: list[int],
    shift_type_ids: list[int],
    dates: list[date],
    leave_dates: dict[int, set],
    approved_leave_full_dates: dict[int, set],
    locked_off_dates: dict[int, set],
    closed_dates: set[date],
    shift_day_min: list[list[int]],
    shift_day_blocked: list[list[bool]],
    top_k: int = 5,
) -> list[dict[str, Any]]:
    """実行不可能時の「NG候補日」を日別スコアで返す。"""
    out: list[dict[str, Any]] = []
    num_staff = len(staff_ids)
    num_shifts = len(shift_type_ids)
    for d_idx, work_date in enumerate(dates):
        if work_date in closed_dates:
            continue
        blocked = {
            sid for sid in staff_ids if work_date in leave_dates.get(sid, set())
        }
        approved_cnt = sum(
            1 for sid in staff_ids if work_date in approved_leave_full_dates.get(sid, set())
        )
        locked_off_cnt = sum(
            1 for sid in staff_ids if work_date in locked_off_dates.get(sid, set())
        )
        available = num_staff - len(blocked)
        need = sum(
            shift_day_min[d_idx][shi]
            for shi in range(num_shifts)
            if not shift_day_blocked[d_idx][shi]
        )
        shortage = max(0, need - available)
        # 短絡不足が無い日も、出勤不可が多い日は候補として弱く表示できるよう微小スコアを与える
        score = shortage * 100 + len(blocked)
        if score <= 0:
            continue
        out.append(
            {
                "date": work_date.isoformat(),
                "need": need,
                "available": available,
                "blocked": len(blocked),
                "approved_full_day": approved_cnt,
                "locked_off": locked_off_cnt,
                "shortage": shortage,
                "score": score,
            }
        )

    out.sort(key=lambda x: (x["score"], x["shortage"], x["blocked"]), reverse=True)
    return out[: max(1, top_k)]


def run_optimizer(
    staff_ids: list[int],
    shift_type_ids: list[int],
    min_staff_per_shift: dict[int, int],  # shift_type_id -> 人数（意味は min_staff_mode による）
    start_date: date,
    end_date: date,
    min_staff_mode_per_shift: Optional[dict[int, str]] = None,  # shift_type_id -> at_least | exact
    max_consecutive_days: int = 5,
    max_days_per_week: int = 6,
    min_days_off_per_week: int = 1,
    max_nights_per_week: int = 2,
    no_early_after_night: bool = True,
    min_rest_seconds_between_day_and_night: Optional[int] = 48 * 3600,
    equalize_workload: bool = True,
    leave_dates: Optional[dict[int, set]] = None,  # staff_id -> 全日出勤禁止日（locked_off ∪ 承認・全日）
    approved_leave_dates: Optional[dict[int, set]] = None,  # 後方互換: specs が無いとき全日として解釈
    approved_leave_specs: Optional[list[ApprovedLeaveSpec]] = None,
    half_day_rule_minutes: Optional[dict[tuple[int, str], tuple[int, int]]] = None,
    shift_types_ordered: Optional[list] = None,
    locked_off_dates: Optional[dict[int, set]] = None,  # 手動「休」確定（shift_type=None ロック）のみ
    locked_assignments: Optional[dict] = None,  # (staff_id, date) -> shift_type_id
    closed_dates: Optional[set] = None,  # set of dates (全員休み)
    shift_eligibility_whitelist: Optional[dict[int, set[int]]] = None,
    # shift_type_id -> その種別に入れる staff_id の集合。キー無しまたは空集合は「制限なし」（全員可）。
    forbidden_shift_pairs: Optional[list[tuple[int, int]]] = None,
    shift_day_min: Optional[list[list[int]]] = None,
    shift_day_blocked: Optional[list[list[bool]]] = None,
    enable_max_consecutive_days: bool = True,
    enable_max_days_per_week: bool = True,
    enable_min_days_off_per_week: bool = True,
    enable_max_nights_per_week: bool = True,
    enable_no_consecutive_nights: bool = True,
    soft_guard_cells: Optional[list[tuple[int, date]]] = None,
    # (staff_id, date) 未ロックの ✖ — 最適化では原則勤務 0、足りなければ割当可（目的関数ペナルティ）
) -> tuple[Optional[dict[tuple[int, date], int]], dict[str, Any]]:
    """
    Returns:
        (割り当て辞書 or None, メタデータ)
        メタデータは常に返る。成功時も wall_time / モデル概要を含む。
    """

    approved_leave_dates = approved_leave_dates or {}
    locked_off_dates = locked_off_dates or {}
    specs_in: list[ApprovedLeaveSpec] = (
        list(approved_leave_specs)
        if approved_leave_specs is not None
        else []
    )
    if not specs_in and approved_leave_dates:
        for sid, ds in approved_leave_dates.items():
            for wd in ds:
                specs_in.append(ApprovedLeaveSpec(sid, wd, "full_day"))

    approved_leave_full_dates: dict[int, set] = {}
    for sp in specs_in:
        if sp.kind == "full_day":
            approved_leave_full_dates.setdefault(sp.staff_id, set()).add(sp.work_date)

    if leave_dates is None:
        leave_dates = _merge_staff_day_sets(approved_leave_full_dates, locked_off_dates)
    half_day_rule_minutes = half_day_rule_minutes or {}
    locked_assignments = locked_assignments or {}
    closed_dates = closed_dates or {}
    soft_guard_cells = soft_guard_cells or []
    elig_whitelist = shift_eligibility_whitelist or {}
    max_nights_per_week = max(0, min(7, max_nights_per_week))
    min_rest_dn_req = min_rest_seconds_between_day_and_night
    night_idx_opt = _detect_night_shift_index(
        shift_type_ids=shift_type_ids,
        shift_types_ordered=shift_types_ordered,
    )
    has_night_shift = night_idx_opt is not None
    no_early_after_night_eff = no_early_after_night and has_night_shift
    enable_max_nights_per_week_eff = enable_max_nights_per_week and has_night_shift
    enable_no_consecutive_nights_eff = enable_no_consecutive_nights and has_night_shift
    min_rest_dn_req_eff = (
        min_rest_dn_req if (min_rest_dn_req is not None and has_night_shift) else None
    )

    staff_set_ids = set(staff_ids)
    pair_seen: set[tuple[int, int]] = set()
    forbidden_pairs_eff: list[tuple[int, int]] = []
    for a, b in forbidden_shift_pairs or []:
        if a == b:
            continue
        lo, hi = (a, b) if a < b else (b, a)
        if lo not in staff_set_ids or hi not in staff_set_ids:
            continue
        if (lo, hi) in pair_seen:
            continue
        pair_seen.add((lo, hi))
        forbidden_pairs_eff.append((lo, hi))

    dates: list[date] = []
    d = start_date
    while d <= end_date:
        dates.append(d)
        d += timedelta(days=1)

    num_staff = len(staff_ids)
    num_shifts = len(shift_type_ids)
    num_days = len(dates)

    meta: dict[str, Any] = {
        "solver_status_code": None,
        "solver_status_name": "",
        "wall_time_seconds": 0.0,
        "hints": [],
        "model_overview": {
            "active_staff": num_staff,
            "calendar_days": num_days,
            "shift_types": num_shifts,
            "locked_shift_cells": len(locked_assignments),
            "leave_approved_day_entries": len(specs_in),
            "leave_approved_full_day_entries": sum(
                len(v) for v in approved_leave_full_dates.values()
            ),
            "leave_locked_off_day_entries": sum(
                len(v) for v in locked_off_dates.values()
            ),
            "leave_blocked_day_entries": sum(len(v) for v in leave_dates.values()),
            "closed_days": len(closed_dates),
            "soft_guard_cells": len(soft_guard_cells),
            "shift_eligibility_restricted_types": sum(
                1 for st_id in shift_type_ids if bool(elig_whitelist.get(st_id))
            ),
            "constraints_in_model": {
                "max_consecutive_days": max_consecutive_days,
                "max_days_per_week": max_days_per_week,
                "min_days_off_per_week": min_days_off_per_week,
                "week_rule_scope": "ISO週（月曜始まり）。期間内で同一ISO週に属する連続日ごとにスタッフごとに適用（端数週の最小休日は日数按分で適用）",
                "max_nights_per_week": max_nights_per_week,
                "night_shift_slot_note": (
                    "タスク種別が2種以上のとき、開始時刻順の並びで最後の種別を夜勤として"
                    "連続夜勤禁止・週夜勤上限を適用（既存の「夜勤翌早番禁止」と同じ前提）"
                    if has_night_shift
                    else "翌日またぎのタスク種別（夜勤）が無いため、夜勤関連制約は適用しません。"
                ),
                "no_early_after_night": no_early_after_night_eff,
                "equalize_workload_objective": equalize_workload,
                "forbidden_shift_pairs_count": len(forbidden_pairs_eff),
                "forbidden_pair_note": (
                    "登録ペアは同一日・同一シフト種別に両名が同時配置されないように制約します。"
                ),
                "shift_demand_note": (
                    "曜日別／特定日の最低人数・稼働可否を適用（未設定セルは種別マスタの最低人数・全日稼働）。"
                ),
                "min_rest_hours_between_day_and_night": (
                    (min_rest_dn_req_eff // 3600)
                    if min_rest_dn_req_eff is not None and num_shifts >= 2
                    else None
                ),
                "min_rest_day_night_note": (
                    "種別が2種以上かつ時刻が解釈できるとき、夜勤（開始時刻順で最後）とそれ以外の組について"
                    "終業〜次開始が上記時間未満の日ペアには同一スタッフを割り当てません。"
                    if min_rest_dn_req_eff is not None and num_shifts >= 2
                    else None
                ),
                "constraint_enables": {
                    "max_consecutive_days": enable_max_consecutive_days,
                    "max_days_per_week": enable_max_days_per_week,
                    "min_days_off_per_week": enable_min_days_off_per_week,
                    "max_nights_per_week_cap": enable_max_nights_per_week_eff,
                    "no_consecutive_nights": enable_no_consecutive_nights_eff,
                    "min_rest_day_night": min_rest_dn_req_eff is not None,
                },
            },
        },
    }

    if num_staff == 0 or num_days == 0:
        meta["solver_status_name"] = "データ不足"
        meta["hints"] = [
            "有効なスタッフがいないか、期間の日付が空です。スタッフマスタと期間を確認してください。"
        ]
        return None, meta

    if num_shifts == 0:
        meta["solver_status_name"] = "データ不足"
        meta["hints"] = ["タスク種別が登録されていません。"]
        return None, meta

    shift_day_min_grid = shift_day_min
    shift_day_blocked_grid = shift_day_blocked
    if shift_day_min_grid is None or shift_day_blocked_grid is None:
        shift_day_min_grid = [
            [min_staff_per_shift.get(st_id, 1) for st_id in shift_type_ids]
            for _ in range(num_days)
        ]
        shift_day_blocked_grid = [[False] * num_shifts for _ in range(num_days)]

    min_staff_mode_map = _norm_min_staff_modes(min_staff_mode_per_shift)

    # shift_type_id -> index マッピング
    st_to_idx = {st_id: i for i, st_id in enumerate(shift_type_ids)}
    # shift_type index 0 = 早番（夜勤翌日禁止に使う）
    EARLY_IDX = 0
    NIGHT_IDX = night_idx_opt if night_idx_opt is not None else num_shifts - 1

    model = cp_model.CpModel()

    # 決定変数: works[s][d][sh] = 1 なら勤務
    works = {}
    for s in range(num_staff):
        for d_idx in range(num_days):
            for sh in range(num_shifts):
                works[(s, d_idx, sh)] = model.new_bool_var(
                    f"w_s{s}_d{d_idx}_sh{sh}"
                )

    week_segments = week_segments_for_dates(dates)

    # ── ハード制約 ──────────────────────────────────────────────

    # 1. 各シフト・各日の人数制約（最低 N 名 or ちょうど N 名）／稼働停止日は 0 人固定（休業日は後続で全員禁止）
    for d_idx, work_date in enumerate(dates):
        if work_date in closed_dates:
            continue
        for sh_idx, st_id in enumerate(shift_type_ids):
            if shift_day_blocked_grid[d_idx][sh_idx]:
                model.add(
                    sum(works[(s, d_idx, sh_idx)] for s in range(num_staff)) == 0
                )
                continue
            min_n = shift_day_min_grid[d_idx][sh_idx]
            total_var = sum(works[(s, d_idx, sh_idx)] for s in range(num_staff))
            if min_staff_mode_map.get(st_id) == "exact":
                model.add(total_var == min_n)
            else:
                model.add(total_var >= min_n)

    # 2. 1人が1日に複数シフト禁止
    for s in range(num_staff):
        for d_idx in range(num_days):
            model.add(sum(works[(s, d_idx, sh)] for sh in range(num_shifts)) <= 1)

    # 2b. タスク種別ごとの資格（ホワイトリスト・非資格者はその種別を全日禁止）
    for sh_idx, st_type_id in enumerate(shift_type_ids):
        allowed = elig_whitelist.get(st_type_id)
        if not allowed:
            continue
        for s_idx, sid in enumerate(staff_ids):
            if sid not in allowed:
                for d_idx in range(num_days):
                    model.add(works[(s_idx, d_idx, sh_idx)] == 0)

    # 2c. 同一日・同一シフト種別でのペア同時配置禁止
    idx_by_staff = {sid: i for i, sid in enumerate(staff_ids)}
    for lo, hi in forbidden_pairs_eff:
        ia, ib = idx_by_staff[lo], idx_by_staff[hi]
        for d_idx in range(num_days):
            for sh_idx in range(num_shifts):
                model.add(
                    works[(ia, d_idx, sh_idx)] + works[(ib, d_idx, sh_idx)] <= 1
                )

    # 3. 夜勤翌日の早番禁止
    if no_early_after_night_eff:
        for s in range(num_staff):
            for d_idx in range(num_days - 1):
                model.add(
                    works[(s, d_idx, NIGHT_IDX)] + works[(s, d_idx + 1, EARLY_IDX)]
                    <= 1
                )

    # 3a. 日勤系と夜勤のあいだを実時間で最低 min_rest 確保（種別2種以上・時刻が揃うとき）
    if (
        min_rest_dn_req_eff is not None
        and num_shifts >= 2
        and shift_types_ordered
        and len(shift_types_ordered) == num_shifts
        and [getattr(o, "id", None) for o in shift_types_ordered] == list(shift_type_ids)
        and night_idx_opt is not None
    ):
        dn_pairs = _collect_day_night_short_gap_pairs(
            dates=dates,
            shift_types_ordered=list(shift_types_ordered),
            night_idx=night_idx_opt,
            min_rest_seconds=float(min_rest_dn_req_eff),
        )
        for d1, sh1, d2, sh2 in dn_pairs:
            for s in range(num_staff):
                model.add(works[(s, d1, sh1)] + works[(s, d2, sh2)] <= 1)

    # 3b–3c. 連続夜勤禁止・ISO週あたりの夜勤回数上限（種別が2種以上のとき最終インデックスを夜勤とみなす）
    if num_shifts >= 2:
        if enable_no_consecutive_nights_eff:
            for s in range(num_staff):
                for d_idx in range(num_days - 1):
                    model.add(
                        works[(s, d_idx, NIGHT_IDX)] + works[(s, d_idx + 1, NIGHT_IDX)]
                        <= 1
                    )
        if enable_max_nights_per_week_eff:
            for segment in week_segments:
                d_idxs = [dates.index(d) for d in segment]
                if not d_idxs:
                    continue
                for s in range(num_staff):
                    nights_in_week = sum(works[(s, di, NIGHT_IDX)] for di in d_idxs)
                    model.add(nights_in_week <= max_nights_per_week)

    # 4. 連続勤務上限
    if enable_max_consecutive_days:
        for s in range(num_staff):
            for d_idx in range(num_days - max_consecutive_days):
                model.add(
                    sum(
                        sum(works[(s, d_idx + k, sh)] for sh in range(num_shifts))
                        for k in range(max_consecutive_days + 1)
                    )
                    <= max_consecutive_days
                )

    # 4b. 週ごとの勤務日上限・最小休日（ISO週＝シフト表ヘッダの週帯と同一）
    if enable_max_days_per_week or enable_min_days_off_per_week:
        for segment in week_segments:
            L = len(segment)
            if L == 0:
                continue
            d_idxs = [dates.index(d) for d in segment]
            seg_min_off = _min_days_off_for_segment(L, min_days_off_per_week)
            cap_rest = L - seg_min_off
            for s in range(num_staff):
                worked_days_in_week = sum(
                    sum(works[(s, di, sh)] for sh in range(num_shifts)) for di in d_idxs
                )
                if enable_max_days_per_week:
                    model.add(worked_days_in_week <= max_days_per_week)
                if enable_min_days_off_per_week:
                    model.add(worked_days_in_week <= cap_rest)

    # 5. 全日の出勤禁止（承認・全日休 + 手動ロック「休」）
    for s_idx, st_id in enumerate(staff_ids):
        blocked = leave_dates.get(st_id, set())
        for d_idx, work_date in enumerate(dates):
            if work_date in blocked:
                for sh in range(num_shifts):
                    model.add(works[(s_idx, d_idx, sh)] == 0)

    # 5b. 部分休・時間指定休（specs は呼び出し元で承認済みのみ）
    if shift_types_ordered and specs_in:
        partial_forbid = build_partial_leave_forbidden_shift_indices(
            staff_ids=staff_ids,
            dates=dates,
            shift_types_ordered=shift_types_ordered,
            specs=specs_in,
            half_day_rule_minutes=half_day_rule_minutes,
        )
        for (sid, wd), sh_idxs in partial_forbid.items():
            try:
                s_idx = staff_ids.index(sid)
            except ValueError:
                continue
            try:
                d_idx = dates.index(wd)
            except ValueError:
                continue
            for sh_idx in sh_idxs:
                if 0 <= sh_idx < num_shifts:
                    model.add(works[(s_idx, d_idx, sh_idx)] == 0)

    # 6. 休業日は全スタッフのシフトを禁止
    for d_idx, work_date in enumerate(dates):
        if work_date in closed_dates:
            for s in range(num_staff):
                for sh in range(num_shifts):
                    model.add(works[(s, d_idx, sh)] == 0)

    # 7. ロック済み割り当てを固定
    for s_idx, st_id in enumerate(staff_ids):
        for d_idx, work_date in enumerate(dates):
            key = (st_id, work_date)
            if key in locked_assignments:
                locked_sh_id = locked_assignments[key]
                locked_sh_idx = st_to_idx.get(locked_sh_id)
                if locked_sh_idx is not None:
                    model.add(works[(s_idx, d_idx, locked_sh_idx)] == 1)

    # ✖（未ロック）— 勤務をペナルティ化（努力義務：他に行きようがなければペナルティを払って割当）
    PEN_SOFT_GUARD = 1_000_000
    soft_guard_penalty_exprs: list = []
    for sid, wd in soft_guard_cells:
        try:
            s_idx = staff_ids.index(sid)
            d_idx = dates.index(wd)
        except ValueError:
            continue
        if wd in closed_dates:
            continue
        soft_guard_penalty_exprs.append(
            sum(works[(s_idx, d_idx, sh)] for sh in range(num_shifts))
        )

    # ── ソフト制約（均等配分の最小化 + ✖ 回避） ─────────────────
    if equalize_workload:
        total_work = [
            sum(
                works[(s, d_idx, sh)]
                for d_idx in range(num_days)
                for sh in range(num_shifts)
            )
            for s in range(num_staff)
        ]
        max_w = model.new_int_var(0, num_days, "max_w")
        min_w = model.new_int_var(0, num_days, "min_w")
        model.add_max_equality(max_w, total_work)
        model.add_min_equality(min_w, total_work)
        if soft_guard_penalty_exprs:
            model.minimize(
                (max_w - min_w)
                + PEN_SOFT_GUARD * sum(soft_guard_penalty_exprs)
            )
        else:
            model.minimize(max_w - min_w)
    elif soft_guard_penalty_exprs:
        model.minimize(sum(soft_guard_penalty_exprs))

    # ── ソルバー実行 ─────────────────────────────────────────────
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = 15.0
    status = solver.solve(model)

    meta["solver_status_code"] = status
    meta["solver_status_name"] = _solver_status_jp(status)
    meta["wall_time_seconds"] = solver.WallTime()
    if hasattr(solver, "StatusName"):
        meta["solver_status_name_or_tools"] = solver.StatusName(status)

    meta["solver_internal"] = {}
    for attr, key in (
        ("NumConflicts", "num_conflicts"),
        ("NumBranches", "num_branches"),
    ):
        if hasattr(solver, attr):
            meta["solver_internal"][key] = getattr(solver, attr)()

    if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        meta["hints"] = _diagnose_infeasibility(
            staff_ids=staff_ids,
            shift_type_ids=shift_type_ids,
            min_staff_per_shift=min_staff_per_shift,
            min_staff_mode_per_shift=min_staff_mode_per_shift,
            dates=dates,
            leave_dates=leave_dates,
            approved_leave_full_dates=approved_leave_full_dates,
            locked_off_dates=locked_off_dates,
            locked_assignments=locked_assignments,
            closed_dates=closed_dates,
            no_early_after_night=no_early_after_night_eff,
            shift_eligibility_whitelist=elig_whitelist,
            max_days_per_week=max_days_per_week,
            min_days_off_per_week=min_days_off_per_week,
            max_nights_per_week=max_nights_per_week,
            forbidden_shift_pairs=forbidden_pairs_eff,
            shift_day_min=shift_day_min_grid,
            shift_day_blocked=shift_day_blocked_grid,
            min_rest_seconds_between_day_and_night=min_rest_dn_req_eff,
            shift_types_ordered=shift_types_ordered,
            enable_max_consecutive_days=enable_max_consecutive_days,
            enable_max_days_per_week=enable_max_days_per_week,
            enable_min_days_off_per_week=enable_min_days_off_per_week,
            enable_max_nights_per_week=enable_max_nights_per_week_eff,
            enable_no_consecutive_nights=enable_no_consecutive_nights_eff,
        )
        meta["candidate_dates"] = _build_failure_date_candidates(
            staff_ids=staff_ids,
            shift_type_ids=shift_type_ids,
            dates=dates,
            leave_dates=leave_dates,
            approved_leave_full_dates=approved_leave_full_dates,
            locked_off_dates=locked_off_dates,
            closed_dates=closed_dates,
            shift_day_min=shift_day_min_grid,
            shift_day_blocked=shift_day_blocked_grid,
            top_k=5,
        )
        if status == cp_model.UNKNOWN:
            meta["hints"].insert(
                0,
                "ソルバが15秒以内に可行解を証明できませんでした（時間切れなど）。"
                "スタッフ数・日数が大きい場合は制約を強めすぎないか確認してください。",
            )
        return None, meta

    # ── 結果を辞書に変換 ──────────────────────────────────────────
    result: dict[tuple[int, date], int] = {}
    for s_idx, st_id in enumerate(staff_ids):
        for d_idx, work_date in enumerate(dates):
            for sh_idx, sh_type_id in enumerate(shift_type_ids):
                if solver.value(works[(s_idx, d_idx, sh_idx)]) == 1:
                    result[(st_id, work_date)] = sh_type_id
                    break

    meta["hints"] = []
    return result, meta
