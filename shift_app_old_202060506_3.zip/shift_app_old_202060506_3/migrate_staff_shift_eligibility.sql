-- 既存 DB 向け: スタッフ×タスク種別の資格（ホワイトリスト）
-- 適用前にバックアップしてください。
-- ルール: ある種別に 1 行でも資格があれば、その種別は資格者のみ配置可能。
--         資格 0 件の種別は制限なし（従来どおり全員可）。

CREATE TABLE IF NOT EXISTS SH_STAFF_SHIFT_ELIGIBILITY (
    id              INT             NOT NULL AUTO_INCREMENT,
    staff_id        INT             NOT NULL COMMENT 'スタッフID（FK）',
    shift_type_id   INT             NOT NULL COMMENT 'タスク種別ID（FK）',
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_staff_shift_eligibility (staff_id, shift_type_id),
    CONSTRAINT fk_staff_shift_eligibility_staff
        FOREIGN KEY (staff_id)
        REFERENCES SH_STAFF (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT fk_staff_shift_eligibility_shift_type
        FOREIGN KEY (shift_type_id)
        REFERENCES SH_SHIFT_TYPES (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    INDEX idx_staff_shift_eligibility_shift (shift_type_id),
    INDEX idx_staff_shift_eligibility_staff (staff_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
COMMENT='タスク種別ごとの担当資格（ホワイトリスト）';
