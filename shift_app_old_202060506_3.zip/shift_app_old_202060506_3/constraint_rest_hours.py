from sqlalchemy import text
from sqlalchemy.exc import OperationalError
from sqlalchemy.orm import Session


def ensure_min_rest_hours_column(db: Session) -> None:
    """
    SH_CONSTRAINTS に min_rest_hours_day_night 列が無ければ追加する。
    既存環境を壊さないため、参照時に遅延で自己修復する。
    """
    try:
        db.execute(text("SELECT min_rest_hours_day_night FROM SH_CONSTRAINTS LIMIT 1"))
        return
    except OperationalError:
        pass
    db.execute(
        text(
            "ALTER TABLE SH_CONSTRAINTS "
            "ADD COLUMN min_rest_hours_day_night INTEGER NOT NULL DEFAULT 48"
        )
    )
    db.commit()


def get_min_rest_hours_day_night(db: Session, constraint_id: int) -> int:
    ensure_min_rest_hours_column(db)
    row = db.execute(
        text(
            "SELECT min_rest_hours_day_night "
            "FROM SH_CONSTRAINTS WHERE id = :cid"
        ),
        {"cid": constraint_id},
    ).fetchone()
    if not row:
        return 48
    v = int(row[0]) if row[0] is not None else 48
    return max(1, min(168, v))


def set_min_rest_hours_day_night(db: Session, constraint_id: int, hours: int) -> None:
    ensure_min_rest_hours_column(db)
    h = max(1, min(168, int(hours)))
    db.execute(
        text(
            "UPDATE SH_CONSTRAINTS "
            "SET min_rest_hours_day_night = :h "
            "WHERE id = :cid"
        ),
        {"h": h, "cid": constraint_id},
    )
