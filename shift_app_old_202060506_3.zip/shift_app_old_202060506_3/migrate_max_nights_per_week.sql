-- 既存 DB に SH_CONSTRAINTS.max_nights_per_week を追加する場合に実行
-- （ddl.sql から新規作成した場合は既に含まれます）

ALTER TABLE SH_CONSTRAINTS
    ADD COLUMN max_nights_per_week INT NOT NULL DEFAULT 2
        COMMENT '週最大夜勤回数（ISO週、夜勤＝開始時刻順で最後の種別）'
        AFTER min_days_off_per_week;

ALTER TABLE SH_CONSTRAINTS
    ADD CONSTRAINT chk_sh_constraints_max_nights CHECK (max_nights_per_week BETWEEN 0 AND 7);
