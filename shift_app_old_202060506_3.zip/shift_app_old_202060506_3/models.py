from sqlalchemy import (
    Column,
    Integer,
    String,
    Boolean,
    Date,
    DateTime,
    ForeignKey,
    UniqueConstraint,
    CheckConstraint,
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from database import Base


class Team(Base):
    __tablename__ = "SH_TEAMS"

    id         = Column(Integer, primary_key=True, autoincrement=True)
    name       = Column(String(100), nullable=False)
    code       = Column(String(50), nullable=True)
    is_active  = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())

    staff_members  = relationship("Staff",            back_populates="team")
    shift_types    = relationship("ShiftType",        back_populates="team")
    periods        = relationship("SchedulePeriod",  back_populates="team")
    constraints    = relationship("Constraint",      back_populates="team")
    leave_requests      = relationship("LeaveRequest",       back_populates="team")
    leave_half_day_rules = relationship("LeaveHalfDayRule", back_populates="team", cascade="all, delete-orphan")
    assignments         = relationship("ShiftAssignment",    back_populates="team")


class Staff(Base):
    __tablename__ = "SH_STAFF"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    team_id         = Column(Integer, ForeignKey("SH_TEAMS.id"), nullable=False)
    name            = Column(String(100), nullable=False)
    role            = Column(String(50),  nullable=False, default="一般スタッフ")
    employment_type = Column(String(20),  nullable=False, default="full_time")
    is_active       = Column(Boolean,     nullable=False, default=True)
    created_at      = Column(DateTime, server_default=func.now())
    updated_at      = Column(DateTime, server_default=func.now(), onupdate=func.now())

    team           = relationship("Team", back_populates="staff_members")
    assignments    = relationship("ShiftAssignment", back_populates="staff",  cascade="all, delete-orphan")
    leave_requests = relationship("LeaveRequest",    back_populates="staff",  cascade="all, delete-orphan")
    shift_eligibilities = relationship(
        "StaffShiftEligibility",
        back_populates="staff",
    )


class StaffShiftPairForbidden(Base):
    """同一日・同一シフト種別への同時配置を禁止するペア（staff_id_low < staff_id_high で保持）。"""

    __tablename__ = "SH_STAFF_SHIFT_PAIR_FORBIDDEN"
    __table_args__ = (
        UniqueConstraint(
            "team_id",
            "staff_id_low",
            "staff_id_high",
            name="uq_staff_shift_pair_forbidden",
        ),
        CheckConstraint(
            "staff_id_low < staff_id_high",
            name="chk_staff_shift_pair_order",
        ),
    )

    id             = Column(Integer, primary_key=True, autoincrement=True)
    team_id        = Column(Integer, ForeignKey("SH_TEAMS.id"), nullable=False)
    staff_id_low   = Column(Integer, ForeignKey("SH_STAFF.id"), nullable=False)
    staff_id_high  = Column(Integer, ForeignKey("SH_STAFF.id"), nullable=False)
    created_at     = Column(DateTime, server_default=func.now())

    team = relationship("Team")


MIN_STAFF_MODE_AT_LEAST = "at_least"
MIN_STAFF_MODE_EXACT = "exact"


class ShiftType(Base):
    __tablename__ = "SH_SHIFT_TYPES"

    id          = Column(Integer,    primary_key=True, autoincrement=True)
    team_id     = Column(Integer,    ForeignKey("SH_TEAMS.id"), nullable=False)
    name        = Column(String(50), nullable=False)
    start_time  = Column(String(8),  nullable=False)   # HH:MM:SS
    end_time    = Column(String(8),  nullable=False)
    min_staff   = Column(Integer,    nullable=False, default=1)
    min_staff_mode = Column(
        String(20),
        nullable=False,
        default=MIN_STAFF_MODE_AT_LEAST,
    )  # at_least=指定人数以上 / exact=指定人数ちょうど
    color_code  = Column(String(7),  nullable=False, default="#888888")
    created_at  = Column(DateTime, server_default=func.now())
    updated_at  = Column(DateTime, server_default=func.now(), onupdate=func.now())

    team        = relationship("Team", back_populates="shift_types")
    assignments = relationship("ShiftAssignment", back_populates="shift_type")
    shift_eligibilities = relationship(
        "StaffShiftEligibility",
        back_populates="shift_type",
    )

    def _fmt_time(self, val) -> str:
        """timedelta（MySQL）でも str（SQLite）でも HH:MM を返す。"""
        if hasattr(val, 'total_seconds'):
            total = int(val.total_seconds())
            return f"{total // 3600:02d}:{(total % 3600) // 60:02d}"
        return str(val)[:5]

    @property
    def start_time_str(self) -> str:
        return self._fmt_time(self.start_time)

    @property
    def end_time_str(self) -> str:
        return self._fmt_time(self.end_time)


class SchedulePeriod(Base):
    __tablename__ = "SH_SCHEDULE_PERIODS"

    id         = Column(Integer,    primary_key=True, autoincrement=True)
    team_id    = Column(Integer,    ForeignKey("SH_TEAMS.id"), nullable=False)
    start_date = Column(Date,       nullable=False)
    end_date   = Column(Date,       nullable=False)
    label      = Column(String(100), nullable=False)
    status     = Column(String(20), nullable=False, default="draft")
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())

    team         = relationship("Team", back_populates="periods")
    assignments  = relationship("ShiftAssignment", back_populates="period",     cascade="all, delete-orphan")
    constraint   = relationship("Constraint",      back_populates="period",     cascade="all, delete-orphan", uselist=False)
    closed_days  = relationship("ClosedDay",     back_populates="period",    cascade="all, delete-orphan")
    shift_weekday_demands = relationship(
        "PeriodShiftWeekdayDemand",
        back_populates="period",
        cascade="all, delete-orphan",
    )
    shift_date_demands = relationship(
        "PeriodShiftDateDemand",
        back_populates="period",
        cascade="all, delete-orphan",
    )


class ClosedDay(Base):
    """期間単位の休業日。最適化では全員シフト禁止・最低人数制約なし。"""

    __tablename__ = "SH_CLOSED_DAYS"
    __table_args__ = (
        UniqueConstraint("period_id", "closed_date", name="uq_closed_day_period_date"),
    )

    id          = Column(Integer, primary_key=True, autoincrement=True)
    period_id   = Column(
        Integer,
        ForeignKey("SH_SCHEDULE_PERIODS.id", ondelete="CASCADE"),
        nullable=False,
    )
    closed_date = Column(Date, nullable=False)

    period = relationship("SchedulePeriod", back_populates="closed_days")


class PeriodShiftWeekdayDemand(Base):
    """期間×種別×曜日の最低人数・稼働可否（無ければ種別マスタの最低人数・全日稼働とみなす）。"""

    __tablename__ = "SH_PERIOD_SHIFT_WEEKDAY_DEMAND"
    __table_args__ = (
        UniqueConstraint(
            "period_id", "shift_type_id", "weekday",
            name="uq_period_shift_weekday",
        ),
    )

    id             = Column(Integer, primary_key=True, autoincrement=True)
    period_id      = Column(
        Integer,
        ForeignKey("SH_SCHEDULE_PERIODS.id", ondelete="CASCADE"),
        nullable=False,
    )
    shift_type_id  = Column(
        Integer,
        ForeignKey("SH_SHIFT_TYPES.id", ondelete="CASCADE"),
        nullable=False,
    )
    weekday        = Column(Integer, nullable=False)  # 0=月 … 6=日
    min_staff      = Column(Integer, nullable=False, default=1)
    is_feasible    = Column(Boolean, nullable=False, default=True)
    created_at     = Column(DateTime, server_default=func.now())
    updated_at     = Column(DateTime, server_default=func.now(), onupdate=func.now())

    period      = relationship("SchedulePeriod", back_populates="shift_weekday_demands")
    shift_type  = relationship("ShiftType")


class PeriodShiftDateDemand(Base):
    """特定カレンダー日での上書き（曜日既定より優先）。"""

    __tablename__ = "SH_PERIOD_SHIFT_DATE_DEMAND"
    __table_args__ = (
        UniqueConstraint(
            "period_id", "shift_type_id", "demand_date",
            name="uq_period_shift_date",
        ),
    )

    id             = Column(Integer, primary_key=True, autoincrement=True)
    period_id      = Column(
        Integer,
        ForeignKey("SH_SCHEDULE_PERIODS.id", ondelete="CASCADE"),
        nullable=False,
    )
    shift_type_id  = Column(
        Integer,
        ForeignKey("SH_SHIFT_TYPES.id", ondelete="CASCADE"),
        nullable=False,
    )
    demand_date    = Column(Date, nullable=False)
    min_staff      = Column(Integer, nullable=False, default=1)
    is_feasible    = Column(Boolean, nullable=False, default=True)
    created_at     = Column(DateTime, server_default=func.now())
    updated_at     = Column(DateTime, server_default=func.now(), onupdate=func.now())

    period      = relationship("SchedulePeriod", back_populates="shift_date_demands")
    shift_type  = relationship("ShiftType")


class Constraint(Base):
    __tablename__ = "SH_CONSTRAINTS"

    id                    = Column(Integer,  primary_key=True, autoincrement=True)
    team_id               = Column(Integer,  ForeignKey("SH_TEAMS.id"), nullable=False)
    period_id             = Column(Integer,  ForeignKey("SH_SCHEDULE_PERIODS.id"), nullable=False, unique=True)
    max_consecutive_days  = Column(Integer,  nullable=False, default=5)
    max_days_per_week     = Column(Integer,  nullable=False, default=5)
    min_days_off_per_week = Column(Integer,  nullable=False, default=2)
    max_nights_per_week   = Column(Integer,  nullable=False, default=0)
    no_early_after_night  = Column(Boolean,  nullable=False, default=True)
    equalize_workload     = Column(Boolean,  nullable=False, default=True)
    enable_max_consecutive_days = Column(
        Boolean, nullable=False, default=True,
        comment="最大連続勤務日数制約をソルバに適用する",
    )
    enable_max_days_per_week = Column(
        Boolean, nullable=False, default=True,
        comment="週最大勤務日数制約を適用する",
    )
    enable_min_days_off_per_week = Column(
        Boolean, nullable=False, default=True,
        comment="週最小休日に基づく勤務上限を適用する",
    )
    enable_max_nights_per_week = Column(
        Boolean, nullable=False, default=True,
        comment="ISO週あたりの夜勤回数上限を適用する",
    )
    enable_no_consecutive_nights = Column(
        Boolean, nullable=False, default=True,
        comment="連続夜勤禁止を適用する",
    )
    enable_min_rest_day_night = Column(
        Boolean, nullable=False, default=True,
        comment="日勤と夜勤の実時間ベース最短休憩を適用する",
    )
    created_at            = Column(DateTime, server_default=func.now())
    updated_at            = Column(DateTime, server_default=func.now(), onupdate=func.now())

    team   = relationship("Team",             back_populates="constraints")
    period = relationship("SchedulePeriod",   back_populates="constraint")


# 休暇区分（CP-SAT は時間帯とシフトの重なりで部分禁止）
LEAVE_KIND_FULL_DAY = "full_day"
LEAVE_KIND_MORNING_HALF = "morning_half"
LEAVE_KIND_AFTERNOON_HALF = "afternoon_half"
LEAVE_KIND_CUSTOM = "custom"


class StaffShiftEligibility(Base):
    """タスク種別ごとの担当資格（ホワイトリスト）。種別に行が無い場合は全員がその種別に入れる。"""

    __tablename__ = "SH_STAFF_SHIFT_ELIGIBILITY"
    __table_args__ = (
        UniqueConstraint(
            "staff_id",
            "shift_type_id",
            name="uq_staff_shift_eligibility",
        ),
    )

    id            = Column(Integer, primary_key=True, autoincrement=True)
    staff_id      = Column(
        Integer, ForeignKey("SH_STAFF.id", ondelete="CASCADE"), nullable=False
    )
    shift_type_id = Column(
        Integer, ForeignKey("SH_SHIFT_TYPES.id", ondelete="CASCADE"), nullable=False
    )
    created_at    = Column(DateTime, server_default=func.now())

    staff      = relationship("Staff", back_populates="shift_eligibilities")
    shift_type = relationship("ShiftType", back_populates="shift_eligibilities")


class LeaveHalfDayRule(Base):
    """曜日ごとの午前休・午後休の時刻窓（チーム単位）。weekday: 0=月 … 6=日"""

    __tablename__ = "SH_LEAVE_HALF_DAY_RULES"
    __table_args__ = (
        UniqueConstraint("team_id", "weekday", "kind", name="uq_leave_half_rule_team_day_kind"),
    )

    id          = Column(Integer, primary_key=True, autoincrement=True)
    team_id     = Column(Integer, ForeignKey("SH_TEAMS.id"), nullable=False)
    weekday     = Column(Integer, nullable=False)
    kind        = Column(String(20), nullable=False)
    start_time  = Column(String(8), nullable=False)
    end_time    = Column(String(8), nullable=False)
    created_at  = Column(DateTime, server_default=func.now())
    updated_at  = Column(DateTime, server_default=func.now(), onupdate=func.now())

    team = relationship("Team", back_populates="leave_half_day_rules")


class LeaveRequest(Base):
    __tablename__ = "SH_LEAVE_REQUESTS"
    __table_args__ = (
        UniqueConstraint("staff_id", "request_date", name="uq_leave_staff_date"),
    )

    id           = Column(Integer,    primary_key=True, autoincrement=True)
    team_id      = Column(Integer,    ForeignKey("SH_TEAMS.id"), nullable=False)
    staff_id     = Column(Integer,    ForeignKey("SH_STAFF.id"), nullable=False)
    request_date = Column(Date,       nullable=False)
    leave_kind   = Column(String(20), nullable=False, default=LEAVE_KIND_FULL_DAY)
    custom_start_time = Column(String(8), nullable=True)
    custom_end_time   = Column(String(8), nullable=True)
    reason       = Column(String(255), nullable=True)
    status       = Column(String(20), nullable=False, default="pending")
    created_at   = Column(DateTime, server_default=func.now())
    updated_at   = Column(DateTime, server_default=func.now(), onupdate=func.now())

    team  = relationship("Team",  back_populates="leave_requests")
    staff = relationship("Staff", back_populates="leave_requests")


class ShiftAssignment(Base):
    __tablename__ = "SH_SHIFT_ASSIGNMENTS"
    __table_args__ = (
        UniqueConstraint("staff_id", "work_date", name="uq_assignment_staff_date"),
    )

    id            = Column(Integer,  primary_key=True, autoincrement=True)
    team_id       = Column(Integer,  ForeignKey("SH_TEAMS.id"), nullable=False)
    staff_id      = Column(Integer,  ForeignKey("SH_STAFF.id"),           nullable=False)
    period_id     = Column(Integer,  ForeignKey("SH_SCHEDULE_PERIODS.id"), nullable=False)
    shift_type_id = Column(Integer,  ForeignKey("SH_SHIFT_TYPES.id"),     nullable=True)
    work_date     = Column(Date,     nullable=False)
    is_locked     = Column(Boolean,  nullable=False, default=False)
    # shift_type_id が NULL のとき: 休(0) / ✖(1) — 勤務枠に入れない意思表示（✖は努力義務・✖+ロックは禁止）
    guard_x       = Column(Boolean,  nullable=False, default=False)
    source        = Column(String(20), nullable=False, default="solver")
    created_at    = Column(DateTime, server_default=func.now())
    updated_at    = Column(DateTime, server_default=func.now(), onupdate=func.now())

    team       = relationship("Team",           back_populates="assignments")
    staff      = relationship("Staff",          back_populates="assignments")
    period     = relationship("SchedulePeriod", back_populates="assignments")
    shift_type = relationship("ShiftType",      back_populates="assignments")
