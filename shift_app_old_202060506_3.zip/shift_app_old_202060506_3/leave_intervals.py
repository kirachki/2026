"""休暇時間帯とタスク種別の重なり判定（部分休・時間指定休）。"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from datetime import date
from typing import Any


@dataclass(frozen=True)
class ApprovedLeaveSpec:
    staff_id: int
    work_date: date
    kind: str
    custom_start_time: str | None = None
    custom_end_time: str | None = None


def time_column_to_minutes(val: Any) -> int:
    """SQLAlchemy TIME / timedelta / str → 0時からの分。"""
    if val is None:
        return 0
    if hasattr(val, "total_seconds"):
        sec = int(val.total_seconds()) % 86400
        if sec < 0:
            sec += 86400
        return sec // 60
    return parse_hhmm_to_minutes(str(val))


def parse_hhmm_to_minutes(s: str | None) -> int:
    if not s:
        return 0
    t = str(s).strip()[:8]
    parts = t.split(":")
    h = int(parts[0]) if parts else 0
    m = int(parts[1]) if len(parts) > 1 else 0
    sec = int(parts[2]) if len(parts) > 2 else 0
    return h * 60 + m + sec // 60


def shift_interval_minutes(start_val: Any, end_val: Any) -> tuple[int, int]:
    """シフト1本分の [開始分, 終了分]。終了が翌日にまたがる場合は end に 1440 を加算。"""
    sm = time_column_to_minutes(start_val)
    em = time_column_to_minutes(end_val)
    if em <= sm:
        em += 24 * 60
    return sm, em


def closed_intervals_overlap(a0: int, a1: int, b0: int, b1: int) -> bool:
    """閉区間 [a0,a1] と [b0,b1]（分）が重なるか。"""
    return a0 <= b1 and b0 <= a1


def resolve_leave_window_minutes(
    spec: ApprovedLeaveSpec,
    weekday: int,
    half_day_rule_minutes: dict[tuple[int, str], tuple[int, int]],
) -> tuple[int, int] | None:
    """休暇レコードと曜日マスタから禁止ウィンドウ（分）を得る。未定義なら None。"""
    if spec.kind == "morning_half":
        return half_day_rule_minutes.get((weekday, "morning_half"))
    if spec.kind == "afternoon_half":
        return half_day_rule_minutes.get((weekday, "afternoon_half"))
    if spec.kind == "custom":
        if not spec.custom_start_time or not spec.custom_end_time:
            return None
        a = parse_hhmm_to_minutes(spec.custom_start_time)
        b = parse_hhmm_to_minutes(spec.custom_end_time)
        if b <= a:
            b += 24 * 60
        return a, b
    return None


def build_partial_leave_forbidden_shift_indices(
    *,
    staff_ids: list[int],
    dates: list[date],
    shift_types_ordered: list[Any],
    specs: list[ApprovedLeaveSpec],
    half_day_rule_minutes: dict[tuple[int, str], tuple[int, int]],
) -> dict[tuple[int, date], set[int]]:
    """
    (staff_id, work_date) → 禁止するタスク種別のインデックス集合。
    full_day は含めない（全日禁止は別ループ）。
    """
    staff_set = set(staff_ids)
    date_set = set(dates)
    st_to_idx = {st.id: i for i, st in enumerate(shift_types_ordered)}
    out: dict[tuple[int, date], set[int]] = defaultdict(set)

    for spec in specs:
        if spec.kind == "full_day":
            continue
        if spec.staff_id not in staff_set:
            continue
        wd = spec.work_date
        if wd not in date_set:
            continue
        window = resolve_leave_window_minutes(spec, wd.weekday(), half_day_rule_minutes)
        if window is None:
            continue
        lw0, lw1 = window
        for st in shift_types_ordered:
            sm, em = shift_interval_minutes(st.start_time, st.end_time)
            if closed_intervals_overlap(sm, em, lw0, lw1):
                idx = st_to_idx.get(st.id)
                if idx is not None:
                    out[(spec.staff_id, wd)].add(idx)
    return dict(out)
