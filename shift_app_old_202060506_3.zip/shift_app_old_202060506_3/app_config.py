import os
from configparser import ConfigParser
from functools import lru_cache
from pathlib import Path

_SETTINGS_PATH = Path(__file__).resolve().parent / "settings.ini"


@lru_cache(maxsize=1)
def _load_parser() -> ConfigParser:
    parser = ConfigParser(interpolation=None)
    parser.read(_SETTINGS_PATH, encoding="utf-8")
    return parser


def get_security_setting(key: str, default: str = "") -> str:
    if key == "crm_shift_jwt_secret":
        for env_key in ("CRM_SHIFT_JWT_SECRET", "SHIFT_JWT_SECRET"):
            value = os.getenv(env_key, "").strip()
            if value:
                return value
    elif key == "shift_app_session_secret":
        value = os.getenv("SHIFT_APP_SESSION_SECRET", "").strip()
        if value:
            return value

    parser = _load_parser()
    return parser.get("security", key, fallback=default).strip()


def get_setting(section: str, key: str, default: str = "") -> str:
    parser = _load_parser()
    return parser.get(section, key, fallback=default).strip()
