from fastapi import APIRouter, Depends, Request, Form, Query
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import text
from sqlalchemy.exc import OperationalError
from sqlalchemy.orm import Session

from database import get_db
import models
from deps import get_current_team_id

router = APIRouter()
templates = Jinja2Templates(directory="templates")


def _is_admin(request: Request) -> bool:
    user = request.session.get("auth_user")
    role = str((user or {}).get("role", "")).strip().lower()
    return role in ("admin", "manager")


def _like_pattern(q: str) -> str:
    """LIKE 用に % _ \\ をエスケープ（MySQL ESCAPE '\\\\' と組み合わせる）。"""
    s = (q or "").strip()
    if not s:
        return ""
    return s.replace("\\", "\\\\").replace("%", r"\%").replace("_", r"\_")


@router.get("/loginuser-suggest", response_class=HTMLResponse)
def loginuser_suggest(
    request: Request,
    userid_lookup: str = Query(""),
    staff_q_lookup: str = Query(""),
    userid: str = Query(""),
    db: Session = Depends(get_db),
):
    """
    t1_loginuser.userid を部分一致で検索し、候補リストを返す（HTMX 用 HTML）。
    休み希望検索は staff_q_lookup、サイドバーは userid_lookup。
    """
    q = (userid_lookup or staff_q_lookup or userid or "").strip()
    if len(q) < 1:
        return HTMLResponse("")
    if not _is_admin(request):
        return HTMLResponse("")
    p = _like_pattern(q)
    if not p:
        return HTMLResponse("")
    pat = f"%{p}%"
    sql = text(
        """
        SELECT userid, user_name
        FROM t1_loginuser
        WHERE Enabled = 1
          AND userid IS NOT NULL
          AND TRIM(userid) <> ''
          AND userid LIKE :pat ESCAPE '\\\\'
        ORDER BY userid ASC
        LIMIT 40
        """
    )
    try:
        rows = db.execute(sql, {"pat": pat}).mappings().all()
    except OperationalError:
        return HTMLResponse("")
    return templates.TemplateResponse(
        "partials/loginuser_suggest.html",
        {"request": request, "rows": rows},
    )


def _staff_list_response(
    request: Request,
    db: Session,
    team_tid: int,
    staff_error: str | None = None,
):
    staff_list = (
        db.query(models.Staff)
        .filter(models.Staff.team_id == team_tid, models.Staff.is_active == True)
        .all()
    )
    return templates.TemplateResponse(
        "partials/staff_list.html",
        {
            "request": request,
            "staff_list": staff_list,
            "staff_error": staff_error,
            "is_admin": _is_admin(request),
        },
    )


@router.post("/add", response_class=HTMLResponse)
def add_staff(
    request: Request,
    userid: str = Form(...),
    role: str = Form("一般スタッフ"),
    employment_type: str = Form("full_time"),
    db: Session = Depends(get_db),
    team_tid: int = Depends(get_current_team_id),
):
    if not _is_admin(request):
        return _staff_list_response(request, db, team_tid, "この操作の権限がありません。")

    uid = (userid or "").strip()
    if not uid:
        return _staff_list_response(request, db, team_tid, "ユーザーIDを入力してください。")

    sql = text(
        """
        SELECT user_name FROM t1_loginuser
        WHERE userid = :uid AND Enabled = 1
        LIMIT 1
        """
    )
    try:
        row = db.execute(sql, {"uid": uid}).mappings().first()
    except OperationalError:
        return _staff_list_response(
            request, db, team_tid, "ログインユーザー表を参照できません。"
        )

    if not row:
        return _staff_list_response(
            request, db, team_tid, f"ユーザーID「{uid}」は見つかりません。"
        )

    un = row.get("user_name")
    display_name = (un or "").strip() or uid

    staff = models.Staff(
        team_id=team_tid,
        name=display_name,
        role=role,
        employment_type=employment_type,
    )
    db.add(staff)
    db.commit()
    db.refresh(staff)
    return _staff_list_response(request, db, team_tid, None)


@router.delete("/{staff_id}", response_class=HTMLResponse)
def delete_staff(
    request: Request,
    staff_id: int,
    db: Session = Depends(get_db),
    team_tid: int = Depends(get_current_team_id),
):
    if not _is_admin(request):
        return _staff_list_response(request, db, team_tid, "この操作の権限がありません。")

    staff = db.query(models.Staff).filter(models.Staff.id == staff_id).first()
    if staff:
        staff.is_active = False
        db.commit()
    return _staff_list_response(request, db, team_tid, None)
