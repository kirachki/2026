"""「解釈が要る」労務・制約ルールの専用説明・編集画面（別タブ想定）。"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from database import get_db
import models
from deps import resolve_team_id
from schedule_context import build_schedule_context

router = APIRouter()
templates = Jinja2Templates(directory="templates")


def _teams_query(db: Session):
    return (
        db.query(models.Team)
        .filter(models.Team.is_active == True)
        .order_by(models.Team.name.asc())
        .all()
    )


@router.get("/", response_class=HTMLResponse)
def policy_constraints_page(
    request: Request,
    period_id: int | None = Query(default=None),
    team_id: int | None = Query(default=None),
    db: Session = Depends(get_db),
):
    tid = resolve_team_id(request, db, team_id)
    ctx = build_schedule_context(db, period_id, team_id=tid)
    ctx["request"] = request
    ctx["current_team_id"] = tid
    ctx["all_teams"] = _teams_query(db)
    resp = templates.TemplateResponse("policy_constraints.html", ctx)
    resp.set_cookie(
        "shift_team_id",
        str(tid),
        max_age=31536000,
        path="/",
        httponly=False,
        samesite="lax",
    )
    return resp
