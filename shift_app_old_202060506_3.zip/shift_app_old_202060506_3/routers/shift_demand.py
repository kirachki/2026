"""期間ごとの曜日／特定日シフト需要（最低人数・稼働可否）の編集。"""
from __future__ import annotations

from datetime import date

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from starlette.responses import Response
from sqlalchemy.exc import OperationalError
from sqlalchemy.orm import Session

from database import get_db
import models
from deps import get_current_team_id, resolve_team_id
from schedule_context import build_schedule_context

router = APIRouter()
templates = Jinja2Templates(directory="templates")


def _teams_query(db: Session):
    return (
        db.query(models.Team)
        .filter(models.Team.is_active == True)
        .order_by(models.Team.name.asc())
        .all()
    )


def _period_scope(db: Session, period_id: int, team_tid: int) -> models.SchedulePeriod:
    p = (
        db.query(models.SchedulePeriod)
        .filter(
            models.SchedulePeriod.id == period_id,
            models.SchedulePeriod.team_id == team_tid,
        )
        .first()
    )
    if not p:
        raise HTTPException(status_code=404, detail="期間が見つかりません")
    return p


def _refresh_response() -> Response:
    return Response(status_code=200, headers={"HX-Refresh": "true"})


@router.get("/", response_class=HTMLResponse)
def shift_demand_page(
    request: Request,
    period_id: int | None = Query(default=None),
    team_id: int | None = Query(default=None),
    db: Session = Depends(get_db),
):
    """日別/曜日別パターンの専用メンテナンス画面（シフト表とは別タブ想定）。"""
    tid = resolve_team_id(request, db, team_id)
    ctx = build_schedule_context(db, period_id, team_id=tid)
    ctx["request"] = request
    ctx["current_team_id"] = tid
    ctx["all_teams"] = _teams_query(db)
    resp = templates.TemplateResponse("shift_demand.html", ctx)
    resp.set_cookie(
        "shift_team_id",
        str(tid),
        max_age=31536000,
        path="/",
        httponly=False,
        samesite="lax",
    )
    return resp


@router.post("/period/{period_id}/weekdays")
async def save_weekday_demands(
    request: Request,
    period_id: int,
    db: Session = Depends(get_db),
    team_tid: int = Depends(get_current_team_id),
):
    period = _period_scope(db, period_id, team_tid)
    form = await request.form()
    shift_types = (
        db.query(models.ShiftType)
        .filter(models.ShiftType.team_id == team_tid)
        .order_by(models.ShiftType.start_time.asc(), models.ShiftType.id.asc())
        .all()
    )

    try:
        db.query(models.PeriodShiftWeekdayDemand).filter(
            models.PeriodShiftWeekdayDemand.period_id == period_id,
        ).delete(synchronize_session=False)
        for st in shift_types:
            for wd in range(7):
                key_min = f"w_min_s{st.id}_{wd}"
                key_run = f"w_run_s{st.id}_{wd}"
                raw_min = form.get(key_min)
                raw_run = form.get(key_run)
                try:
                    mn = int(raw_min) if raw_min not in (None, "") else st.min_staff
                except (TypeError, ValueError):
                    mn = st.min_staff
                mn = max(0, min(99, mn))
                feasible = str(raw_run or "1") == "1"
                db.add(
                    models.PeriodShiftWeekdayDemand(
                        period_id=period_id,
                        shift_type_id=st.id,
                        weekday=wd,
                        min_staff=mn,
                        is_feasible=feasible,
                    )
                )
        db.commit()
    except OperationalError:
        db.rollback()
        raise HTTPException(
            status_code=503,
            detail="SH_PERIOD_SHIFT_WEEKDAY_DEMAND が未作成です。migrate_shift_demand.sql を実行してください。",
        )
    return _refresh_response()


@router.post("/period/{period_id}/dates")
async def upsert_date_demand(
    request: Request,
    period_id: int,
    db: Session = Depends(get_db),
    team_tid: int = Depends(get_current_team_id),
):
    period = _period_scope(db, period_id, team_tid)
    form = await request.form()
    try:
        shift_type_id = int(form.get("shift_type_id", ""))
        demand_date = date.fromisoformat(str(form.get("demand_date", "")))
        mn = int(form.get("min_staff", "1"))
        feasible = str(form.get("is_feasible", "1")) == "1"
    except (TypeError, ValueError):
        raise HTTPException(status_code=400, detail="入力が不正です")

    if demand_date < period.start_date or demand_date > period.end_date:
        raise HTTPException(status_code=400, detail="期間外の日付です")

    st = (
        db.query(models.ShiftType)
        .filter(
            models.ShiftType.id == shift_type_id,
            models.ShiftType.team_id == team_tid,
        )
        .first()
    )
    if not st:
        raise HTTPException(status_code=400, detail="タスク種別が不正です")

    mn = max(0, min(99, mn))

    try:
        row = (
            db.query(models.PeriodShiftDateDemand)
            .filter(
                models.PeriodShiftDateDemand.period_id == period_id,
                models.PeriodShiftDateDemand.shift_type_id == shift_type_id,
                models.PeriodShiftDateDemand.demand_date == demand_date,
            )
            .first()
        )
        if row:
            row.min_staff = mn
            row.is_feasible = feasible
        else:
            db.add(
                models.PeriodShiftDateDemand(
                    period_id=period_id,
                    shift_type_id=shift_type_id,
                    demand_date=demand_date,
                    min_staff=mn,
                    is_feasible=feasible,
                )
            )
        db.commit()
    except OperationalError:
        db.rollback()
        raise HTTPException(
            status_code=503,
            detail="SH_PERIOD_SHIFT_DATE_DEMAND が未作成です。migrate_shift_demand.sql を実行してください。",
        )
    return _refresh_response()


@router.delete("/period/{period_id}/dates")
def delete_date_demand(
    period_id: int,
    shift_type_id: int = Query(...),
    demand_date: date = Query(...),
    db: Session = Depends(get_db),
    team_tid: int = Depends(get_current_team_id),
):
    _period_scope(db, period_id, team_tid)
    try:
        db.query(models.PeriodShiftDateDemand).filter(
            models.PeriodShiftDateDemand.period_id == period_id,
            models.PeriodShiftDateDemand.shift_type_id == shift_type_id,
            models.PeriodShiftDateDemand.demand_date == demand_date,
        ).delete(synchronize_session=False)
        db.commit()
    except OperationalError:
        db.rollback()
        raise HTTPException(status_code=503, detail="テーブルが未作成です")
    return _refresh_response()
