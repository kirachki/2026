"""SH_STAFF_SHIFT_ELIGIBILITY（タスク種別ごとの担当資格・ホワイトリスト）の編集 UI。"""

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.exc import OperationalError
from sqlalchemy.orm import Session

from database import get_db
import models
from deps import resolve_team_id

router = APIRouter()
templates = Jinja2Templates(directory="templates")


def _teams_query(db: Session):
    return (
        db.query(models.Team)
        .filter(models.Team.is_active == True)
        .order_by(models.Team.name.asc())
        .all()
    )


def _load_selected(db: Session, team_tid: int) -> set[tuple[int, int]]:
    try:
        rows = (
            db.query(models.StaffShiftEligibility)
            .join(
                models.Staff,
                models.Staff.id == models.StaffShiftEligibility.staff_id,
            )
            .join(
                models.ShiftType,
                models.ShiftType.id == models.StaffShiftEligibility.shift_type_id,
            )
            .filter(
                models.Staff.team_id == team_tid,
                models.ShiftType.team_id == team_tid,
            )
            .all()
        )
        return {(r.staff_id, r.shift_type_id) for r in rows}
    except OperationalError:
        return set()


@router.get("/", response_class=HTMLResponse)
def shift_eligibility_page(
    request: Request,
    team_id: int | None = Query(default=None),
    db: Session = Depends(get_db),
):
    tid = resolve_team_id(request, db, team_id)
    staff_list = (
        db.query(models.Staff)
        .filter(models.Staff.team_id == tid, models.Staff.is_active == True)
        .order_by(models.Staff.name.asc())
        .all()
    )
    shift_types = (
        db.query(models.ShiftType)
        .filter(models.ShiftType.team_id == tid)
        .order_by(models.ShiftType.start_time.asc(), models.ShiftType.id.asc())
        .all()
    )
    ctx = {
        "request": request,
        "all_teams": _teams_query(db),
        "current_team_id": tid,
        "staff_list": staff_list,
        "shift_types": shift_types,
        "selected_pairs": _load_selected(db, tid),
        "save_message": None,
        "save_error": None,
    }
    resp = templates.TemplateResponse("shift_eligibility.html", ctx)
    resp.set_cookie(
        "shift_team_id",
        str(tid),
        max_age=31536000,
        path="/",
        httponly=False,
        samesite="lax",
    )
    return resp


@router.post("/save", response_class=HTMLResponse)
async def shift_eligibility_save(
    request: Request,
    db: Session = Depends(get_db),
):
    form = await request.form()
    team_raw = form.get("team_id")
    try:
        team_param = int(team_raw) if team_raw is not None and str(team_raw).strip() else None
    except (TypeError, ValueError):
        team_param = None
    tid = resolve_team_id(request, db, team_param)

    staff_rows = (
        db.query(models.Staff)
        .filter(models.Staff.team_id == tid, models.Staff.is_active == True)
        .all()
    )
    shift_rows = (
        db.query(models.ShiftType).filter(models.ShiftType.team_id == tid).all()
    )
    staff_ok = {s.id for s in staff_rows}
    st_ok = {st.id for st in shift_rows}

    pairs_raw = form.getlist("e")
    to_insert: list[tuple[int, int]] = []
    parse_errors = 0
    for raw in pairs_raw:
        part = str(raw).strip().split("|", 1)
        if len(part) != 2:
            parse_errors += 1
            continue
        try:
            sid = int(part[0].strip())
            stid = int(part[1].strip())
        except ValueError:
            parse_errors += 1
            continue
        if sid not in staff_ok or stid not in st_ok:
            parse_errors += 1
            continue
        to_insert.append((sid, stid))

    to_insert = list(dict.fromkeys(to_insert))

    save_error = None
    save_message = None

    try:
        if staff_ok and st_ok:
            db.query(models.StaffShiftEligibility).filter(
                models.StaffShiftEligibility.staff_id.in_(staff_ok),
                models.StaffShiftEligibility.shift_type_id.in_(st_ok),
            ).delete(synchronize_session=False)
        for sid, stid in to_insert:
            db.add(
                models.StaffShiftEligibility(
                    staff_id=sid,
                    shift_type_id=stid,
                )
            )
        db.commit()
        save_message = f"資格を保存しました（{len(to_insert)} 件）。"
        if parse_errors:
            save_message += f" 読み取り不能な項目が {parse_errors} 件無視されました。"
    except OperationalError as ex:
        db.rollback()
        save_error = (
            "テーブル SH_STAFF_SHIFT_ELIGIBILITY が存在しません。"
            "migrate_staff_shift_eligibility.sql を適用するか、DB を更新してください。"
            f" （詳細: {ex}）"
        )

    staff_list = (
        db.query(models.Staff)
        .filter(models.Staff.team_id == tid, models.Staff.is_active == True)
        .order_by(models.Staff.name.asc())
        .all()
    )
    shift_types = (
        db.query(models.ShiftType)
        .filter(models.ShiftType.team_id == tid)
        .order_by(models.ShiftType.start_time.asc(), models.ShiftType.id.asc())
        .all()
    )

    ctx = {
        "request": request,
        "all_teams": _teams_query(db),
        "current_team_id": tid,
        "staff_list": staff_list,
        "shift_types": shift_types,
        "selected_pairs": _load_selected(db, tid),
        "save_message": save_message,
        "save_error": save_error,
    }
    resp = templates.TemplateResponse("shift_eligibility.html", ctx)
    resp.set_cookie(
        "shift_team_id",
        str(tid),
        max_age=31536000,
        path="/",
        httponly=False,
        samesite="lax",
    )
    return resp
