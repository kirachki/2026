import json
from dataclasses import dataclass
from datetime import date as date_type

from fastapi import APIRouter, Depends, Request, Form, Query
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, joinedload

from database import get_db
import models
from deps import resolve_team_id, get_current_team_id

router = APIRouter()
templates = Jinja2Templates(directory="templates")

_STATUS_VALUES = frozenset({"pending", "approved", "rejected"})
_SORT_VALUES = frozenset({"date_asc", "date_desc", "staff_asc", "id_desc"})
_LEAVE_KIND_VALUES = frozenset(
    {
        models.LEAVE_KIND_FULL_DAY,
        models.LEAVE_KIND_MORNING_HALF,
        models.LEAVE_KIND_AFTERNOON_HALF,
        models.LEAVE_KIND_CUSTOM,
    }
)


def _coerce_leave_kind(s: str) -> str:
    t = (s or "").strip()
    return t if t in _LEAVE_KIND_VALUES else models.LEAVE_KIND_FULL_DAY


def _normalize_optional_time(value: str) -> str | None:
    """HTML time は HH:MM → HH:MM:00 で保存。"""
    raw = (value or "").strip()
    if not raw:
        return None
    if len(raw) == 5 and raw[2] == ":":
        return f"{raw}:00"
    return raw[:8] if raw else None


def _leave_kind_times_or_error(kind: str, cs: str, ce: str) -> tuple[str | None, str | None, str | None]:
    """Returns (custom_start, custom_end, error_message)."""
    if kind != models.LEAVE_KIND_CUSTOM:
        return None, None, None
    a = _normalize_optional_time(cs)
    b = _normalize_optional_time(ce)
    if not a or not b:
        return None, None, "時間指定休は開始時刻と終了時刻の両方が必要です。"
    return a, b, None


@dataclass
class LeaveFilters:
    staff_q: str = ""
    reason_q: str = ""
    status: str | None = None
    date_from: date_type | None = None
    date_to: date_type | None = None
    sort: str = "date_asc"


def _parse_iso_date(s: str | None) -> date_type | None:
    if s is None:
        return None
    t = (s or "").strip()
    if not t:
        return None
    try:
        return date_type.fromisoformat(t[:10])
    except ValueError:
        return None


def _filters_from_form(
    filter_staff_q: str = Form(""),
    filter_reason_q: str = Form(""),
    filter_status: str = Form(""),
    filter_date_from: str = Form(""),
    filter_date_to: str = Form(""),
    filter_sort: str = Form("date_asc"),
) -> LeaveFilters:
    st = filter_status.strip() if filter_status else ""
    return LeaveFilters(
        staff_q=(filter_staff_q or "").strip(),
        reason_q=(filter_reason_q or "").strip(),
        status=st if st in _STATUS_VALUES else None,
        date_from=_parse_iso_date(filter_date_from),
        date_to=_parse_iso_date(filter_date_to),
        sort=filter_sort if filter_sort in _SORT_VALUES else "date_asc",
    )


def _like_pattern(q: str) -> str:
    s = (q or "").strip()
    if not s:
        return ""
    return s.replace("\\", "\\\\").replace("%", r"\%").replace("_", r"\_")


def _load_rows_filtered(
    db: Session,
    team_tid: int,
    *,
    staff_q: str | None = None,
    reason_q: str | None = None,
    status: str | None = None,
    date_from: date_type | None = None,
    date_to: date_type | None = None,
    sort: str = "date_asc",
) -> list[models.LeaveRequest]:
    if sort not in _SORT_VALUES:
        sort = "date_asc"

    q = (
        db.query(models.LeaveRequest)
        .join(models.Staff, models.Staff.id == models.LeaveRequest.staff_id)
        .filter(
            models.LeaveRequest.team_id == team_tid,
            models.Staff.team_id == team_tid,
        )
        .options(joinedload(models.LeaveRequest.staff))
    )
    if staff_q and (p := _like_pattern(staff_q)):
        q = q.filter(models.Staff.name.like(f"%{p}%", escape="\\"))
    if reason_q and (p := _like_pattern(reason_q)):
        q = q.filter(
            models.LeaveRequest.reason.isnot(None),
            models.LeaveRequest.reason.like(f"%{p}%", escape="\\"),
        )
    if status in _STATUS_VALUES:
        q = q.filter(models.LeaveRequest.status == status)
    if date_from is not None:
        q = q.filter(models.LeaveRequest.request_date >= date_from)
    if date_to is not None:
        q = q.filter(models.LeaveRequest.request_date <= date_to)

    if sort == "date_desc":
        q = q.order_by(
            models.LeaveRequest.request_date.desc(),
            models.LeaveRequest.id.desc(),
        )
    elif sort == "staff_asc":
        q = q.order_by(models.Staff.name.asc(), models.LeaveRequest.request_date.asc())
    elif sort == "id_desc":
        q = q.order_by(models.LeaveRequest.id.desc())
    else:
        q = q.order_by(
            models.LeaveRequest.request_date.asc(),
            models.LeaveRequest.id.asc(),
        )
    return q.all()


def _teams_query(db: Session):
    return (
        db.query(models.Team)
        .filter(models.Team.is_active == True)
        .order_by(models.Team.name.asc())
        .all()
    )


def _staff_list_for_team(db: Session, team_tid: int) -> list[models.Staff]:
    """休暇登録フォーム用: 現チームの有効スタッフのみ（サイドバーと同条件）。"""
    return (
        db.query(models.Staff)
        .filter(
            models.Staff.team_id == team_tid,
            models.Staff.is_active == True,
        )
        .order_by(models.Staff.id)
        .all()
    )


def _leave_half_rules_json(db: Session, team_tid: int) -> str:
    """曜日(0=月…6=日) → 区分 → [開始,終了] の JSON（クライアントの時間自動セット用）。"""
    rows = (
        db.query(models.LeaveHalfDayRule)
        .filter(models.LeaveHalfDayRule.team_id == team_tid)
        .all()
    )
    out: dict[int, dict[str, list[str]]] = {}
    for r in rows:
        st = (r.start_time or "")[:8]
        et = (r.end_time or "")[:8]
        if len(st) >= 5:
            st = st[:5]
        if len(et) >= 5:
            et = et[:5]
        out.setdefault(r.weekday, {})[r.kind] = [st, et]
    return json.dumps(out, ensure_ascii=False)


def _render_panel(
    request: Request,
    db: Session,
    team_tid: int,
    error: str | None = None,
    filters: LeaveFilters | None = None,
) -> HTMLResponse:
    filters = filters or LeaveFilters()
    staff_list = _staff_list_for_team(db, team_tid)
    rows = _load_rows_filtered(
        db,
        team_tid,
        staff_q=filters.staff_q or None,
        reason_q=filters.reason_q or None,
        status=filters.status,
        date_from=filters.date_from,
        date_to=filters.date_to,
        sort=filters.sort,
    )
    return templates.TemplateResponse(
        "partials/leave_request_list.html",
        {
            "request": request,
            "staff_list": staff_list,
            "leave_requests": rows,
            "error": error,
            "current_team_id": team_tid,
            "leave_half_rules_json": _leave_half_rules_json(db, team_tid),
            "f_staff_q": filters.staff_q,
            "f_reason_q": filters.reason_q,
            "f_status": filters.status or "",
            "f_date_from": filters.date_from.isoformat() if filters.date_from else "",
            "f_date_to": filters.date_to.isoformat() if filters.date_to else "",
            "f_sort": filters.sort,
        },
    )


def _leave_page_context(
    db: Session,
    tid: int,
    filters: LeaveFilters,
) -> dict:
    staff_list = _staff_list_for_team(db, tid)
    rows = _load_rows_filtered(
        db,
        tid,
        staff_q=filters.staff_q or None,
        reason_q=filters.reason_q or None,
        status=filters.status,
        date_from=filters.date_from,
        date_to=filters.date_to,
        sort=filters.sort,
    )
    return {
        "staff_list": staff_list,
        "leave_requests": rows,
        "current_team_id": tid,
        "leave_half_rules_json": _leave_half_rules_json(db, tid),
        "f_staff_q": filters.staff_q,
        "f_reason_q": filters.reason_q,
        "f_status": filters.status or "",
        "f_date_from": filters.date_from.isoformat() if filters.date_from else "",
        "f_date_to": filters.date_to.isoformat() if filters.date_to else "",
        "f_sort": filters.sort,
    }


@router.get("/panel", response_class=HTMLResponse)
def leave_requests_panel(
    request: Request,
    team_id: int | None = Query(default=None),
    staff_q: str = "",
    reason_q: str = "",
    status: str = "",
    # type=date の空値は "" になり date 変換で 422 になるため文字列で受ける
    date_from: str = Query(default=""),
    date_to: str = Query(default=""),
    sort: str = "date_asc",
    db: Session = Depends(get_db),
):
    """HTMX 用: 検索結果パネルだけ返す。"""
    tid = resolve_team_id(request, db, team_id)
    st_f = status.strip() if status else ""
    filters = LeaveFilters(
        staff_q=staff_q.strip(),
        reason_q=reason_q.strip(),
        status=st_f if st_f in _STATUS_VALUES else None,
        date_from=_parse_iso_date(date_from),
        date_to=_parse_iso_date(date_to),
        sort=sort if sort in _SORT_VALUES else "date_asc",
    )
    return _render_panel(request, db, tid, None, filters)


@router.get("/", response_class=HTMLResponse)
def leave_requests_page(
    request: Request,
    team_id: int | None = Query(default=None),
    staff_q: str = "",
    reason_q: str = "",
    status: str = "",
    date_from: str = Query(default=""),
    date_to: str = Query(default=""),
    sort: str = "date_asc",
    db: Session = Depends(get_db),
):
    tid = resolve_team_id(request, db, team_id)
    st_f = status.strip() if status else ""
    filters = LeaveFilters(
        staff_q=staff_q.strip(),
        reason_q=reason_q.strip(),
        status=st_f if st_f in _STATUS_VALUES else None,
        date_from=_parse_iso_date(date_from),
        date_to=_parse_iso_date(date_to),
        sort=sort if sort in _SORT_VALUES else "date_asc",
    )
    ctx = _leave_page_context(db, tid, filters)
    resp = templates.TemplateResponse(
        "leave_requests.html",
        {
            "request": request,
            "error": None,
            "all_teams": _teams_query(db),
            "current_team_id": tid,
            **ctx,
        },
    )
    resp.set_cookie(
        "shift_team_id",
        str(tid),
        max_age=31536000,
        path="/",
        httponly=False,
        samesite="lax",
    )
    return resp


@router.post("/add", response_class=HTMLResponse)
def add_leave_request(
    request: Request,
    staff_id: int = Form(...),
    request_date: date_type = Form(...),
    leave_kind: str = Form(models.LEAVE_KIND_FULL_DAY),
    custom_start_time: str = Form(""),
    custom_end_time: str = Form(""),
    reason: str = Form(""),
    status: str = Form("approved"),
    filter_staff_q: str = Form(""),
    filter_reason_q: str = Form(""),
    filter_status: str = Form(""),
    filter_date_from: str = Form(""),
    filter_date_to: str = Form(""),
    filter_sort: str = Form("date_asc"),
    db: Session = Depends(get_db),
    team_tid: int = Depends(get_current_team_id),
):
    if status not in _STATUS_VALUES:
        status = "approved"
    flt = _filters_from_form(
        filter_staff_q,
        filter_reason_q,
        filter_status,
        filter_date_from,
        filter_date_to,
        filter_sort,
    )
    lk = _coerce_leave_kind(leave_kind)
    cs_final, ce_final, time_err = _leave_kind_times_or_error(
        lk, custom_start_time, custom_end_time
    )
    if time_err:
        return _render_panel(request, db, team_tid, time_err, flt)
    reason = (reason or "").strip() or None
    st = db.query(models.Staff).filter(
        models.Staff.id == staff_id,
        models.Staff.team_id == team_tid,
        models.Staff.is_active == True,
    ).first()
    if not st:
        return _render_panel(request, db, team_tid, "スタッフが見つかりません。", flt)
    db.add(
        models.LeaveRequest(
            team_id=st.team_id,
            staff_id=staff_id,
            request_date=request_date,
            leave_kind=lk,
            custom_start_time=cs_final,
            custom_end_time=ce_final,
            reason=reason,
            status=status,
        )
    )
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        return _render_panel(
            request,
            db,
            team_tid,
            "同じスタッフ・同じ日付の休暇/予定が既に登録されています。",
            flt,
        )
    return _render_panel(request, db, team_tid, None, flt)


@router.post("/quick_lock_from_cell", response_class=JSONResponse)
def quick_lock_from_cell(
    staff_id: int = Form(...),
    request_date: date_type = Form(...),
    reason: str = Form(""),
    custom_start_time: str = Form(""),
    custom_end_time: str = Form(""),
    db: Session = Depends(get_db),
    team_tid: int = Depends(get_current_team_id),
):
    st = db.query(models.Staff).filter(
        models.Staff.id == staff_id,
        models.Staff.team_id == team_tid,
        models.Staff.is_active == True,
    ).first()
    if not st:
        return JSONResponse({"ok": False, "message": "スタッフが見つかりません。"}, status_code=404)

    rs = (reason or "").strip()
    if not rs:
        return JSONResponse({"ok": False, "message": "理由を入力してください。"}, status_code=400)

    cs = _normalize_optional_time(custom_start_time)
    ce = _normalize_optional_time(custom_end_time)
    if (cs and not ce) or (ce and not cs):
        return JSONResponse(
            {"ok": False, "message": "時間を入力する場合は開始・終了の両方を入力してください。"},
            status_code=400,
        )
    lk = models.LEAVE_KIND_CUSTOM if (cs and ce) else models.LEAVE_KIND_FULL_DAY

    row = (
        db.query(models.LeaveRequest)
        .filter(
            models.LeaveRequest.team_id == team_tid,
            models.LeaveRequest.staff_id == staff_id,
            models.LeaveRequest.request_date == request_date,
        )
        .first()
    )
    if row:
        row.leave_kind = lk
        row.custom_start_time = cs
        row.custom_end_time = ce
        row.reason = rs
        row.status = "approved"
    else:
        db.add(
            models.LeaveRequest(
                team_id=team_tid,
                staff_id=staff_id,
                request_date=request_date,
                leave_kind=lk,
                custom_start_time=cs,
                custom_end_time=ce,
                reason=rs,
                status="approved",
            )
        )
    db.commit()
    return JSONResponse({"ok": True})


@router.post("/{leave_id}/update", response_class=HTMLResponse)
def update_leave_request(
    request: Request,
    leave_id: int,
    staff_id: int = Form(...),
    request_date: date_type = Form(...),
    leave_kind: str = Form(models.LEAVE_KIND_FULL_DAY),
    custom_start_time: str = Form(""),
    custom_end_time: str = Form(""),
    reason: str = Form(""),
    status: str = Form("approved"),
    filter_staff_q: str = Form(""),
    filter_reason_q: str = Form(""),
    filter_status: str = Form(""),
    filter_date_from: str = Form(""),
    filter_date_to: str = Form(""),
    filter_sort: str = Form("date_asc"),
    db: Session = Depends(get_db),
    team_tid: int = Depends(get_current_team_id),
):
    if status not in _STATUS_VALUES:
        status = "approved"
    reason = (reason or "").strip() or None
    flt = _filters_from_form(
        filter_staff_q,
        filter_reason_q,
        filter_status,
        filter_date_from,
        filter_date_to,
        filter_sort,
    )
    lk = _coerce_leave_kind(leave_kind)
    cs_final, ce_final, time_err = _leave_kind_times_or_error(
        lk, custom_start_time, custom_end_time
    )
    if time_err:
        return _render_panel(request, db, team_tid, time_err, flt)
    row = (
        db.query(models.LeaveRequest)
        .filter(
            models.LeaveRequest.id == leave_id,
            models.LeaveRequest.team_id == team_tid,
        )
        .first()
    )
    if row:
        st = db.query(models.Staff).filter(
            models.Staff.id == staff_id,
            models.Staff.team_id == team_tid,
            models.Staff.is_active == True,
        ).first()
        if not st:
            return _render_panel(request, db, team_tid, "スタッフが見つかりません。", flt)
        row.team_id = st.team_id
        row.staff_id = staff_id
        row.request_date = request_date
        row.leave_kind = lk
        row.custom_start_time = cs_final
        row.custom_end_time = ce_final
        row.reason = reason
        row.status = status
        try:
            db.commit()
        except IntegrityError:
            db.rollback()
            return _render_panel(
                request,
                db,
                team_tid,
                "同じスタッフ・同じ日付の休暇/予定が既に登録されています。",
                flt,
            )
    return _render_panel(request, db, team_tid, None, flt)


def _delete_leave_impl(
    db: Session,
    team_tid: int,
    leave_id: int,
    request: Request,
    flt: LeaveFilters,
) -> HTMLResponse:
    db.query(models.LeaveRequest).filter(
        models.LeaveRequest.id == leave_id,
        models.LeaveRequest.team_id == team_tid,
    ).delete()
    db.commit()
    return _render_panel(request, db, team_tid, None, flt)


@router.delete("/{leave_id}", response_class=HTMLResponse)
def delete_leave_request(
    request: Request,
    leave_id: int,
    filter_staff_q: str = Query(""),
    filter_reason_q: str = Query(""),
    filter_status: str = Query(""),
    filter_date_from: str = Query(""),
    filter_date_to: str = Query(""),
    filter_sort: str = Query("date_asc"),
    db: Session = Depends(get_db),
    team_tid: int = Depends(get_current_team_id),
):
    flt = _filters_from_form(
        filter_staff_q,
        filter_reason_q,
        filter_status,
        filter_date_from,
        filter_date_to,
        filter_sort,
    )
    return _delete_leave_impl(db, team_tid, leave_id, request, flt)


@router.post("/{leave_id}/delete", response_class=HTMLResponse)
def delete_leave_request_post(
    request: Request,
    leave_id: int,
    filter_staff_q: str = Form(""),
    filter_reason_q: str = Form(""),
    filter_status: str = Form(""),
    filter_date_from: str = Form(""),
    filter_date_to: str = Form(""),
    filter_sort: str = Form("date_asc"),
    db: Session = Depends(get_db),
    team_tid: int = Depends(get_current_team_id),
):
    """HTMX から Form でフィルタを渡す削除用。"""
    flt = _filters_from_form(
        filter_staff_q,
        filter_reason_q,
        filter_status,
        filter_date_from,
        filter_date_to,
        filter_sort,
    )
    return _delete_leave_impl(db, team_tid, leave_id, request, flt)
