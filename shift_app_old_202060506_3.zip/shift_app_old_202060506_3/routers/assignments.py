import io
from datetime import date as date_type, timedelta
from urllib.parse import quote
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse, StreamingResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session, joinedload
from database import get_db
import models
from deps import get_current_team_id
from schedule_context import build_schedule_context

router = APIRouter()
templates = Jinja2Templates(directory="templates")


def _is_admin_user(request: Request) -> bool:
    user = request.session.get("auth_user", {})
    role = str(user.get("role", "")).strip().lower()
    return role in ("admin", "manager")


def _get_shift_types(db: Session, team_id: int) -> list[models.ShiftType]:
    """表示・サイクル順は開始時刻の昇順（早→遅→夜）。tie-break は id。"""
    return (
        db.query(models.ShiftType)
        .filter(models.ShiftType.team_id == team_id)
        .order_by(models.ShiftType.start_time.asc(), models.ShiftType.id.asc())
        .all()
    )


@router.post("/toggle/{staff_id}/{work_date}", response_class=HTMLResponse)
def toggle_assignment(
    request: Request,
    staff_id: int,
    work_date: date_type,
    db: Session = Depends(get_db),
):
    """
    シングルクリックのサイクル:
      未 → 早→…→夜 → 休 → ✖ → 未
    鍵付きにするのはダブルクリック（toggle_lock）のみ。
    """
    staff_row = db.query(models.Staff).filter(models.Staff.id == staff_id).first()
    if not staff_row:
        return HTMLResponse("<td class='shift-cell'><span class='shift-chip chip-off'>—</span></td>")
    team_id = staff_row.team_id
    shift_types = _get_shift_types(db, team_id)
    assignment = (
        db.query(models.ShiftAssignment)
        .filter(
            models.ShiftAssignment.staff_id == staff_id,
            models.ShiftAssignment.work_date == work_date,
            models.ShiftAssignment.team_id == team_id,
        )
        .first()
    )

    # ── 通常シフト・ロック済み → 変更不可 ──────────────────────
    if assignment and assignment.shift_type_id is not None and assignment.is_locked:
        return _render_cell(request, assignment, staff_id, work_date, shift_types, db, team_id)

    # ── 通常シフト・未ロック → 次の種別へ、または「休」へ ───────
    if assignment and assignment.shift_type_id is not None and not assignment.is_locked:
        current_idx = next(
            (i for i, st in enumerate(shift_types) if st.id == assignment.shift_type_id),
            -1,
        )
        next_idx = current_idx + 1
        if next_idx >= len(shift_types):
            assignment.shift_type_id = None
            assignment.is_locked = False
            assignment.guard_x = False
            assignment.source = "manual"
            db.commit()
            db.refresh(assignment)
        else:
            assignment.shift_type_id = shift_types[next_idx].id
            assignment.source = "manual"
            db.commit()
            db.refresh(assignment)
        return _render_cell(request, assignment, staff_id, work_date, shift_types, db, team_id)

    # ── shift_type_id が NULL（休 / ✖）───────────────────────────
    if assignment and assignment.shift_type_id is None:
        if assignment.is_locked:
            if getattr(assignment, "guard_x", False):
                # ✖🔒 — シングルでは変更しない（最適化でも勤務禁止）
                return _render_cell(request, assignment, staff_id, work_date, shift_types, db, team_id)
            # 休🔒 — 解除して未設定へ（承認休同期の行など）
            db.delete(assignment)
            db.commit()
            return _render_cell(request, None, staff_id, work_date, shift_types, db, team_id)
        else:
            if getattr(assignment, "guard_x", False):
                # ✖（未ロック）→ 未設定へ
                db.delete(assignment)
                db.commit()
                return _render_cell(request, None, staff_id, work_date, shift_types, db, team_id)
            # 休（未ロック）→ ✖ へ
            assignment.guard_x = True
            assignment.source = "manual"
            db.commit()
            db.refresh(assignment)
            return _render_cell(request, assignment, staff_id, work_date, shift_types, db, team_id)

    # ── レコードなし（未設定）→ 最初のシフトを新規作成 ────────────
    period = (
        db.query(models.SchedulePeriod)
        .filter(
            models.SchedulePeriod.team_id == team_id,
            models.SchedulePeriod.start_date <= work_date,
            models.SchedulePeriod.end_date >= work_date,
        )
        .first()
    )
    if not period:
        return HTMLResponse("<td class='shift-cell'><span class='shift-chip chip-off' title=\"未設定\">未</span></td>")

    new_assignment = models.ShiftAssignment(
        team_id=team_id,
        staff_id=staff_id,
        period_id=period.id,
        shift_type_id=shift_types[0].id,
        work_date=work_date,
        guard_x=False,
        source="manual",
    )
    db.add(new_assignment)
    db.commit()
    db.refresh(new_assignment)
    return _render_cell(request, new_assignment, staff_id, work_date, shift_types, db, team_id)


def _render_cell(request, assignment, staff_id, work_date, shift_types, db: Session, team_id: int):
    leave_req = None
    if staff_id and work_date:
        leave_req = (
            db.query(models.LeaveRequest)
            .filter(
                models.LeaveRequest.team_id == team_id,
                models.LeaveRequest.staff_id == staff_id,
                models.LeaveRequest.request_date == work_date,
            )
            .first()
        )
    return templates.TemplateResponse(
        "partials/cell.html",
        {
            "request": request,
            "assignment": assignment,
            "staff_id": staff_id,
            "work_date": work_date,
            "shift_types": shift_types,
            "leave_req": leave_req,
        },
    )


@router.post("/toggle_lock/{staff_id}/{work_date}", response_class=HTMLResponse)
def toggle_lock_by_cell(
    request: Request,
    staff_id: int,
    work_date: date_type,
    db: Session = Depends(get_db),
    team_tid: int = Depends(get_current_team_id),
):
    """ダブルクリック用: is_locked のオン／オフのみ。"""
    staff_row = db.query(models.Staff).filter(models.Staff.id == staff_id).first()
    if not staff_row or staff_row.team_id != team_tid:
        return HTMLResponse("<td class='shift-cell'><span class='shift-chip chip-off'>—</span></td>")
    team_id = staff_row.team_id
    shift_types = _get_shift_types(db, team_id)
    assignment = (
        db.query(models.ShiftAssignment)
        .filter(
            models.ShiftAssignment.staff_id == staff_id,
            models.ShiftAssignment.work_date == work_date,
            models.ShiftAssignment.team_id == team_id,
        )
        .first()
    )
    if not assignment:
        return _render_cell(request, None, staff_id, work_date, shift_types, db, team_id)
    assignment.is_locked = not assignment.is_locked
    db.commit()
    db.refresh(assignment)
    return _render_cell(request, assignment, staff_id, work_date, shift_types, db, team_id)


@router.post("/lock/{assignment_id}", response_class=HTMLResponse)
def toggle_lock(
    request: Request,
    assignment_id: int,
    db: Session = Depends(get_db),
    team_tid: int = Depends(get_current_team_id),
):
    assignment = db.query(models.ShiftAssignment).filter(
        models.ShiftAssignment.id == assignment_id,
        models.ShiftAssignment.team_id == team_tid,
    ).first()
    if assignment:
        assignment.is_locked = not assignment.is_locked
        db.commit()
        db.refresh(assignment)
    tid = assignment.team_id if assignment else team_tid
    shift_types = _get_shift_types(db, tid)
    return _render_cell(
        request,
        assignment,
        assignment.staff_id if assignment else None,
        assignment.work_date if assignment else None,
        shift_types,
        db,
        tid,
    )


@router.post("/lock_period/{period_id}", response_class=HTMLResponse)
def lock_period_assignments(
    request: Request,
    period_id: int,
    db: Session = Depends(get_db),
    team_tid: int = Depends(get_current_team_id),
):
    if not _is_admin_user(request):
        raise HTTPException(status_code=403, detail="この操作の権限がありません")
    period = db.query(models.SchedulePeriod).filter(
        models.SchedulePeriod.id == period_id,
        models.SchedulePeriod.team_id == team_tid,
    ).first()
    if not period:
        raise HTTPException(status_code=404, detail="期間が見つかりません")

    rows = db.query(models.ShiftAssignment).filter(
        models.ShiftAssignment.team_id == team_tid,
        models.ShiftAssignment.period_id == period_id,
        ~(
            (models.ShiftAssignment.shift_type_id.is_(None))
            & (models.ShiftAssignment.guard_x == True)
        ),
    ).all()
    for row in rows:
        row.is_locked = True
    db.commit()

    ctx = build_schedule_context(db, period_id, team_id=team_tid)
    ctx["request"] = request
    ctx["current_team_id"] = team_tid
    ctx["is_admin"] = True
    ctx["force_readonly"] = bool(request.session.get("force_readonly", False))
    return templates.TemplateResponse("partials/schedule_grid.html", ctx)


@router.post("/protect_period/{period_id}", response_class=HTMLResponse)
def protect_period_view(
    request: Request,
    period_id: int,
    db: Session = Depends(get_db),
    team_tid: int = Depends(get_current_team_id),
):
    if not _is_admin_user(request):
        raise HTTPException(status_code=403, detail="この操作の権限がありません")

    period = db.query(models.SchedulePeriod).filter(
        models.SchedulePeriod.id == period_id,
        models.SchedulePeriod.team_id == team_tid,
    ).first()
    if not period:
        raise HTTPException(status_code=404, detail="期間が見つかりません")

    current = bool(request.session.get("force_readonly", False))
    request.session["force_readonly"] = (not current)

    ctx = build_schedule_context(db, period_id, team_id=team_tid)
    ctx["request"] = request
    ctx["current_team_id"] = team_tid
    ctx["is_admin"] = True
    ctx["force_readonly"] = bool(request.session.get("force_readonly", False))
    return templates.TemplateResponse("partials/schedule_grid.html", ctx)


@router.get("/export/{period_id}")
def export_period_assignments_xlsx(
    period_id: int,
    db: Session = Depends(get_db),
    team_tid: int = Depends(get_current_team_id),
):
    period = db.query(models.SchedulePeriod).filter(
        models.SchedulePeriod.id == period_id,
        models.SchedulePeriod.team_id == team_tid,
    ).first()
    if not period:
        raise HTTPException(status_code=404, detail="期間が見つかりません")

    staff_list = (
        db.query(models.Staff)
        .filter(
            models.Staff.team_id == team_tid,
            models.Staff.is_active == True,
        )
        .order_by(models.Staff.name.asc(), models.Staff.id.asc())
        .all()
    )
    rows = (
        db.query(models.ShiftAssignment)
        .options(joinedload(models.ShiftAssignment.shift_type))
        .filter(
            models.ShiftAssignment.team_id == team_tid,
            models.ShiftAssignment.period_id == period_id,
            models.ShiftAssignment.work_date >= period.start_date,
            models.ShiftAssignment.work_date <= period.end_date,
        )
        .all()
    )
    assignment_map = {(r.staff_id, r.work_date): r for r in rows}
    closed_dates = {
        r.closed_date
        for r in db.query(models.ClosedDay).filter(
            models.ClosedDay.period_id == period_id,
        ).all()
    }

    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
        from openpyxl.utils import get_column_letter
    except ImportError as exc:
        raise HTTPException(
            status_code=500,
            detail="Excelエクスポートには openpyxl が必要です。",
        ) from exc

    wb = Workbook()
    ws = wb.active
    ws.title = "シフト表"

    base_font = Font(name="Meiryo UI", size=13)
    header_font = Font(name="Meiryo UI", size=13, bold=True, color="FFFFFFFF")
    header_fill = PatternFill(fill_type="solid", fgColor="FF1F2937")
    thin = Side(style="thin", color="FF2E3248")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    center = Alignment(horizontal="center", vertical="center")

    normal_fill = PatternFill(fill_type="solid", fgColor="FFD9D9D9")
    off_fill = PatternFill(fill_type="solid", fgColor="FFD9D9D9")
    x_fill = PatternFill(fill_type="solid", fgColor="FF7F1D1D")
    unassigned_fill = PatternFill(fill_type="solid", fgColor="FFD9D9D9")
    locked_font = Font(name="Meiryo UI", size=13, color="FFF59E0B", bold=True)
    closed_day_header_font = Font(name="Meiryo UI", size=13, bold=True, color="FFFF0000")

    def to_excel_color(hex_color: str) -> str:
        c = (hex_color or "").strip()
        if len(c) == 7 and c.startswith("#"):
            return f"FF{c[1:].upper()}"
        return "FF888888"

    date_list: list[date_type] = []
    d = period.start_date
    while d <= period.end_date:
        date_list.append(d)
        d += timedelta(days=1)

    ws.cell(row=1, column=1, value=f"{period.label}（{period.start_date}〜{period.end_date}）")
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=3 + len(date_list))
    ws.cell(row=1, column=1).font = Font(name="Meiryo UI", size=13, bold=True)

    ws.cell(row=2, column=1, value="スタッフID")
    ws.cell(row=2, column=2, value="スタッフ名")
    for idx, work_date in enumerate(date_list, start=3):
        wd = ["月", "火", "水", "木", "金", "土", "日"][work_date.weekday()]
        ws.cell(row=2, column=idx, value=f"{work_date.month}/{work_date.day}({wd})")
    ws.cell(row=2, column=3 + len(date_list), value="合計")

    for col in range(1, 4 + len(date_list)):
        cell = ws.cell(row=2, column=col)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = center
        cell.border = border
    for idx, work_date in enumerate(date_list, start=3):
        if work_date in closed_dates:
            ws.cell(row=2, column=idx).font = closed_day_header_font

    row_idx = 3
    for staff in staff_list:
        ws.cell(row=row_idx, column=1, value=staff.id)
        ws.cell(row=row_idx, column=2, value=staff.name)
        ws.cell(row=row_idx, column=1).alignment = center
        ws.cell(row=row_idx, column=1).font = base_font
        ws.cell(row=row_idx, column=2).font = base_font
        ws.cell(row=row_idx, column=1).fill = normal_fill
        ws.cell(row=row_idx, column=2).fill = normal_fill
        ws.cell(row=row_idx, column=1).border = border
        ws.cell(row=row_idx, column=2).border = border

        assigned_count = 0
        for i, work_date in enumerate(date_list, start=3):
            a = assignment_map.get((staff.id, work_date))
            cell = ws.cell(row=row_idx, column=i)
            cell.alignment = center
            cell.border = border
            cell.font = base_font
            if a and a.shift_type_id is not None and a.shift_type:
                cell.value = a.shift_type.name
                cell.fill = PatternFill(fill_type="solid", fgColor=to_excel_color(a.shift_type.color_code))
                assigned_count += 1
            elif a and a.shift_type_id is None and a.guard_x:
                cell.value = "✖"
                cell.fill = x_fill
            elif a and a.shift_type_id is None:
                cell.value = "休"
                cell.fill = off_fill
            else:
                cell.value = "未"
                cell.fill = unassigned_fill

            if a and a.is_locked:
                cell.font = locked_font
                cell.value = f"{cell.value}🔒"

        total_cell = ws.cell(row=row_idx, column=3 + len(date_list), value=assigned_count)
        total_cell.alignment = center
        total_cell.font = base_font
        total_cell.fill = normal_fill
        total_cell.border = border
        row_idx += 1

    ws.column_dimensions["A"].width = 10
    ws.column_dimensions["B"].width = 18
    for i in range(3, 3 + len(date_list)):
        ws.column_dimensions[get_column_letter(i)].width = 12
    ws.column_dimensions[get_column_letter(3 + len(date_list))].width = 8
    ws.freeze_panes = "C3"

    safe_label = "".join(
        ch if (("a" <= ch <= "z") or ("A" <= ch <= "Z") or ("0" <= ch <= "9") or ch in ("-", "_")) else "_"
        for ch in period.label
    ).strip("_")
    if not safe_label:
        safe_label = "period"
    filename = f"shift_export_{safe_label}_{period.start_date.isoformat()}_{period.end_date.isoformat()}.xlsx"
    out = io.BytesIO()
    wb.save(out)
    out.seek(0)
    content_disposition = (
        f"attachment; filename=\"{filename}\"; "
        f"filename*=UTF-8''{quote(filename)}"
    )
    return StreamingResponse(
        out,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": content_disposition},
    )
