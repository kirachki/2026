import time
from collections import defaultdict
from datetime import date

from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.exc import OperationalError
from sqlalchemy.orm import Session
from database import get_db
import models
from constraint_rest_hours import get_min_rest_hours_day_night
from date_keys import to_calendar_date
from leave_intervals import ApprovedLeaveSpec, parse_hhmm_to_minutes
from leave_sync import sync_approved_leave_assignments
from optimizer import run_optimizer
from shift_demand_resolve import build_shift_demand_grids, dates_in_period
from deps import get_current_team_id
from period_closed_days import closed_dates_in_period
from schedule_context import build_schedule_context

router = APIRouter()
templates = Jinja2Templates(directory="templates")


@router.post("/{period_id}", response_class=HTMLResponse)
def optimize(
    request: Request,
    period_id: int,
    db: Session = Depends(get_db),
    current_tid: int = Depends(get_current_team_id),
):
    period = db.query(models.SchedulePeriod).filter(
        models.SchedulePeriod.id == period_id,
    ).first()
    if not period or period.team_id != current_tid:
        return HTMLResponse("<p>期間が見つかりません</p>", status_code=404)

    tid = period.team_id
    staff_list  = db.query(models.Staff).filter(
        models.Staff.team_id == tid,
        models.Staff.is_active == True,
    ).all()
    shift_types = (
        db.query(models.ShiftType)
        .filter(models.ShiftType.team_id == tid)
        .order_by(models.ShiftType.start_time.asc(), models.ShiftType.id.asc())
        .all()
    )
    constraint  = db.query(models.Constraint).filter(
        models.Constraint.period_id == period_id
    ).first()

    leaves = (
        db.query(models.LeaveRequest)
        .join(models.Staff, models.Staff.id == models.LeaveRequest.staff_id)
        .filter(
            models.LeaveRequest.status == "approved",
            models.LeaveRequest.team_id == tid,
            models.Staff.team_id == tid,
            models.Staff.is_active == True,
        )
        .all()
    )
    approved_leave_specs: list[ApprovedLeaveSpec] = []
    for lr in leaves:
        rd = to_calendar_date(lr.request_date)
        if rd is None:
            continue
        lk = getattr(lr, "leave_kind", None) or models.LEAVE_KIND_FULL_DAY
        approved_leave_specs.append(
            ApprovedLeaveSpec(
                staff_id=lr.staff_id,
                work_date=rd,
                kind=lk,
                custom_start_time=lr.custom_start_time,
                custom_end_time=lr.custom_end_time,
            )
        )

    half_day_rule_minutes: dict[tuple[int, str], tuple[int, int]] = {}
    try:
        for rule in (
            db.query(models.LeaveHalfDayRule)
            .filter(models.LeaveHalfDayRule.team_id == tid)
            .all()
        ):
            half_day_rule_minutes[(rule.weekday, rule.kind)] = (
                parse_hhmm_to_minutes(rule.start_time),
                parse_hhmm_to_minutes(rule.end_time),
            )
    except OperationalError:
        half_day_rule_minutes = {}

    locked_off_dates: dict[int, set] = {}

    # ロック済み割り当て（日付範囲のみで取得）
    # period_id では絞らない。複数の SH_SCHEDULE_PERIODS が日付で重なると、
    # セル作成時は .first() で別 period の id が付くことがあり、最適化対象 period と
    # 不一致だとロックが読み飛ばされ UNIQUE(staff_id, work_date) と INSERT が衝突する。
    locked: dict[tuple, int] = {}
    existing = db.query(models.ShiftAssignment).filter(
        models.ShiftAssignment.team_id == tid,
        models.ShiftAssignment.work_date >= period.start_date,
        models.ShiftAssignment.work_date <= period.end_date,
        models.ShiftAssignment.is_locked == True,
    ).all()
    for a in existing:
        wd = to_calendar_date(a.work_date)
        if wd is None:
            continue
        if a.shift_type_id is not None:
            locked[(a.staff_id, wd)] = a.shift_type_id
        else:
            # 手動で「休」に確定した日（shift_type_id=None, is_locked）
            locked_off_dates.setdefault(a.staff_id, set()).add(wd)

    full_day_block: dict[int, set] = defaultdict(set)
    for sp in approved_leave_specs:
        if sp.kind == models.LEAVE_KIND_FULL_DAY:
            full_day_block[sp.staff_id].add(sp.work_date)
    for sid, ds in locked_off_dates.items():
        full_day_block[sid].update(ds)

    min_staff_per_shift = {st.id: st.min_staff for st in shift_types}
    min_staff_mode_per_shift = {
        st.id: (
            models.MIN_STAFF_MODE_EXACT
            if getattr(st, "min_staff_mode", None) == models.MIN_STAFF_MODE_EXACT
            else models.MIN_STAFF_MODE_AT_LEAST
        )
        for st in shift_types
    }

    dates_list = dates_in_period(period.start_date, period.end_date)
    weekday_demand_rows: list = []
    date_demand_rows: list = []
    try:
        weekday_demand_rows = (
            db.query(models.PeriodShiftWeekdayDemand)
            .filter(models.PeriodShiftWeekdayDemand.period_id == period_id)
            .all()
        )
        date_demand_rows = (
            db.query(models.PeriodShiftDateDemand)
            .filter(models.PeriodShiftDateDemand.period_id == period_id)
            .all()
        )
    except OperationalError:
        weekday_demand_rows = []
        date_demand_rows = []
    shift_day_min, shift_day_blocked = build_shift_demand_grids(
        dates_list,
        [st.id for st in shift_types],
        min_staff_per_shift,
        weekday_demand_rows,
        date_demand_rows,
    )

    shift_eligibility_whitelist: dict[int, set[int]] = {}
    try:
        elig_rows = (
            db.query(models.StaffShiftEligibility)
            .join(
                models.Staff,
                models.Staff.id == models.StaffShiftEligibility.staff_id,
            )
            .join(
                models.ShiftType,
                models.ShiftType.id == models.StaffShiftEligibility.shift_type_id,
            )
            .filter(
                models.Staff.team_id == tid,
                models.ShiftType.team_id == tid,
                models.Staff.is_active == True,
            )
            .all()
        )
        for er in elig_rows:
            shift_eligibility_whitelist.setdefault(er.shift_type_id, set()).add(
                er.staff_id
            )
    except OperationalError:
        shift_eligibility_whitelist = {}

    forbidden_shift_pairs: list[tuple[int, int]] = []
    try:
        prow = (
            db.query(models.StaffShiftPairForbidden)
            .filter(models.StaffShiftPairForbidden.team_id == tid)
            .all()
        )
        active_staff_ids = {s.id for s in staff_list}
        for pr in prow:
            if (
                pr.staff_id_low in active_staff_ids
                and pr.staff_id_high in active_staff_ids
            ):
                forbidden_shift_pairs.append((pr.staff_id_low, pr.staff_id_high))
    except OperationalError:
        forbidden_shift_pairs = []

    c = constraint
    min_rest_hours_day_night = 48
    if c:
        try:
            min_rest_hours_day_night = get_min_rest_hours_day_night(db, c.id)
        except OperationalError:
            min_rest_hours_day_night = 48
    closed_dates_set = closed_dates_in_period(db, period_id)

    soft_guard_cells: list[tuple[int, date]] = []
    open_assignments = (
        db.query(models.ShiftAssignment)
        .filter(
            models.ShiftAssignment.team_id == tid,
            models.ShiftAssignment.work_date >= period.start_date,
            models.ShiftAssignment.work_date <= period.end_date,
            models.ShiftAssignment.is_locked == False,
            models.ShiftAssignment.shift_type_id == None,
        )
        .all()
    )
    for a in open_assignments:
        if getattr(a, "guard_x", False):
            wd = to_calendar_date(a.work_date)
            if wd is not None:
                soft_guard_cells.append((a.staff_id, wd))

    start = time.perf_counter()
    result, opt_meta = run_optimizer(
        staff_ids=[s.id for s in staff_list],
        shift_type_ids=[st.id for st in shift_types],
        min_staff_per_shift=min_staff_per_shift,
        start_date=period.start_date,
        end_date=period.end_date,
        min_staff_mode_per_shift=min_staff_mode_per_shift,
        max_consecutive_days=c.max_consecutive_days if c else 5,
        max_days_per_week=c.max_days_per_week if c else 6,
        min_days_off_per_week=c.min_days_off_per_week if c else 1,
        max_nights_per_week=(
            max(0, min(7, c.max_nights_per_week)) if c else 2
        ),
        min_rest_seconds_between_day_and_night=(
            min_rest_hours_day_night * 3600
            if (c is None or getattr(c, "enable_min_rest_day_night", True))
            else None
        ),
        no_early_after_night=c.no_early_after_night if c else True,
        equalize_workload=c.equalize_workload if c else True,
        enable_max_consecutive_days=getattr(c, "enable_max_consecutive_days", True) if c else True,
        enable_max_days_per_week=getattr(c, "enable_max_days_per_week", True) if c else True,
        enable_min_days_off_per_week=getattr(c, "enable_min_days_off_per_week", True) if c else True,
        enable_max_nights_per_week=getattr(c, "enable_max_nights_per_week", True) if c else True,
        enable_no_consecutive_nights=getattr(c, "enable_no_consecutive_nights", True) if c else True,
        locked_off_dates=locked_off_dates,
        locked_assignments=locked,
        approved_leave_specs=approved_leave_specs,
        half_day_rule_minutes=half_day_rule_minutes,
        shift_types_ordered=shift_types,
        shift_eligibility_whitelist=shift_eligibility_whitelist or None,
        closed_dates=closed_dates_set,
        forbidden_shift_pairs=forbidden_shift_pairs or None,
        shift_day_min=shift_day_min,
        shift_day_blocked=shift_day_blocked,
        soft_guard_cells=soft_guard_cells or None,
    )
    elapsed = time.perf_counter() - start

    if not result:
        return templates.TemplateResponse(
            "partials/optimize_failure.html",
            {
                "request":         request,
                "detail":          opt_meta,
                "elapsed_total":   elapsed,
                "current_team_id": tid,
                "return_period_id": period_id,
            },
        )

    # ロックされていない既存割り当てを削除
    # ※ period_idではなく日付範囲で削除（異なるperiod_idの重複レコードも除去）
    db.query(models.ShiftAssignment).filter(
        models.ShiftAssignment.team_id == tid,
        models.ShiftAssignment.work_date >= period.start_date,
        models.ShiftAssignment.work_date <= period.end_date,
        models.ShiftAssignment.is_locked == False,
    ).delete(synchronize_session="fetch")
    db.flush()
    db.commit()

    # 新しい割り当てを保存
    # ロック済み（locked / locked-off）はDBに残っているのでINSERTをスキップ
    locked_keys = set(locked.keys())
    for s in staff_list:
        for lv in full_day_block.get(s.id, set()):
            locked_keys.add((s.id, lv))

    for (staff_id, work_date), shift_type_id in result.items():
        if work_date in closed_dates_set:
            continue
        if (staff_id, work_date) in locked_keys:
            continue  # すでにDBにあるのでINSERT不要
        db.add(models.ShiftAssignment(
            team_id=tid,
            staff_id=staff_id,
            period_id=period_id,
            shift_type_id=shift_type_id,
            work_date=work_date,
            source="solver",
        ))

    # 承認済み休暇 → シフト表では「休🔒」（shift_type_id=NULL & is_locked）で表示
    sync_approved_leave_assignments(db, tid, period)

    period.status = "optimized"
    db.commit()

    ctx = build_schedule_context(db, period_id, team_id=tid)
    ctx["request"] = request
    ctx["current_team_id"] = tid
    ctx["elapsed"] = f"{elapsed:.2f}"
    return templates.TemplateResponse("partials/schedule_grid.html", ctx)
