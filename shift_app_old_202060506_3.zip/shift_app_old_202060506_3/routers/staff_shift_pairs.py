"""同一日同一シフト種別で同席させないスタッフペアの編集 UI。"""

from fastapi import APIRouter, Depends, Form, Query, Request
from fastapi.responses import HTMLResponse, Response
from fastapi.templating import Jinja2Templates
from sqlalchemy.exc import IntegrityError, OperationalError
from sqlalchemy.orm import Session

from database import get_db
import models
from deps import resolve_team_id

router = APIRouter()
templates = Jinja2Templates(directory="templates")


def _teams_query(db: Session):
    return (
        db.query(models.Team)
        .filter(models.Team.is_active == True)
        .order_by(models.Team.name.asc())
        .all()
    )


def _pair_rows(db: Session, team_tid: int):
    try:
        rows = (
            db.query(models.StaffShiftPairForbidden)
            .filter(models.StaffShiftPairForbidden.team_id == team_tid)
            .order_by(
                models.StaffShiftPairForbidden.staff_id_low.asc(),
                models.StaffShiftPairForbidden.staff_id_high.asc(),
            )
            .all()
        )
        staff_map = {
            s.id: s
            for s in db.query(models.Staff)
            .filter(models.Staff.team_id == team_tid)
            .all()
        }
        out = []
        for r in rows:
            lo = staff_map.get(r.staff_id_low)
            hi = staff_map.get(r.staff_id_high)
            out.append(
                {
                    "id": r.id,
                    "staff_id_low": r.staff_id_low,
                    "staff_id_high": r.staff_id_high,
                    "name_low": lo.name if lo else f"ID{r.staff_id_low}",
                    "name_high": hi.name if hi else f"ID{r.staff_id_high}",
                }
            )
        return out
    except OperationalError:
        return []


@router.get("/", response_class=HTMLResponse)
def staff_shift_pairs_page(
    request: Request,
    team_id: int | None = Query(default=None),
    db: Session = Depends(get_db),
):
    tid = resolve_team_id(request, db, team_id)
    staff_list = (
        db.query(models.Staff)
        .filter(models.Staff.team_id == tid, models.Staff.is_active == True)
        .order_by(models.Staff.name.asc())
        .all()
    )
    pair_rows = _pair_rows(db, tid)
    ctx = {
        "request": request,
        "all_teams": _teams_query(db),
        "current_team_id": tid,
        "staff_list": staff_list,
        "pair_rows": pair_rows,
        "save_message": None,
        "save_error": None,
    }
    resp = templates.TemplateResponse("staff_shift_pairs.html", ctx)
    resp.set_cookie(
        "shift_team_id",
        str(tid),
        max_age=31536000,
        path="/",
        httponly=False,
        samesite="lax",
    )
    return resp


@router.post("/add", response_class=HTMLResponse)
def add_pair(
    request: Request,
    team_id: int = Form(...),
    staff_a_id: int = Form(...),
    staff_b_id: int = Form(...),
    db: Session = Depends(get_db),
):
    tid = resolve_team_id(request, db, team_id)
    save_message = None
    save_error = None

    if staff_a_id == staff_b_id:
        save_error = "同じスタッフを2回選ぶことはできません。"
    else:
        lo, hi = min(staff_a_id, staff_b_id), max(staff_a_id, staff_b_id)
        sa = (
            db.query(models.Staff)
            .filter(
                models.Staff.id == lo,
                models.Staff.team_id == tid,
                models.Staff.is_active == True,
            )
            .first()
        )
        sb = (
            db.query(models.Staff)
            .filter(
                models.Staff.id == hi,
                models.Staff.team_id == tid,
                models.Staff.is_active == True,
            )
            .first()
        )
        if not sa or not sb:
            save_error = "選択したスタッフがこのチームの有効メンバーではありません。"
        else:
            row = models.StaffShiftPairForbidden(
                team_id=tid,
                staff_id_low=lo,
                staff_id_high=hi,
            )
            db.add(row)
            try:
                db.commit()
                save_message = "ペア禁止を追加しました。"
            except IntegrityError:
                db.rollback()
                save_error = "このペアは既に登録されています。"

    staff_list = (
        db.query(models.Staff)
        .filter(models.Staff.team_id == tid, models.Staff.is_active == True)
        .order_by(models.Staff.name.asc())
        .all()
    )
    ctx = {
        "request": request,
        "all_teams": _teams_query(db),
        "current_team_id": tid,
        "staff_list": staff_list,
        "pair_rows": _pair_rows(db, tid),
        "save_message": save_message,
        "save_error": save_error,
    }
    return templates.TemplateResponse("staff_shift_pairs.html", ctx)


@router.delete("/{pair_id}")
def delete_pair(
    request: Request,
    pair_id: int,
    team_id: int | None = Query(default=None),
    db: Session = Depends(get_db),
):
    tid = resolve_team_id(request, db, team_id)
    row = (
        db.query(models.StaffShiftPairForbidden)
        .filter(
            models.StaffShiftPairForbidden.id == pair_id,
            models.StaffShiftPairForbidden.team_id == tid,
        )
        .first()
    )
    if row:
        db.delete(row)
        db.commit()
    url = f"/staff_shift_pairs/?team_id={tid}"
    return Response(status_code=200, headers={"HX-Redirect": url})
