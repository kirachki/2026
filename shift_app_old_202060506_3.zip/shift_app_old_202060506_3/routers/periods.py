from datetime import date as date_type, timedelta
from fastapi import APIRouter, Depends, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse, Response
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from database import get_db
import models
from constraint_rest_hours import set_min_rest_hours_day_night
from deps import get_current_team_id

router = APIRouter()
templates = Jinja2Templates(directory="templates")


@router.post("/add", response_class=HTMLResponse)
def add_period(
    request: Request,
    start_date: date_type = Form(...),
    end_date: date_type   = Form(...),
    label: str            = Form(...),
    db: Session = Depends(get_db),
    team_tid: int = Depends(get_current_team_id),
):
    period = models.SchedulePeriod(
        team_id=team_tid,
        start_date=start_date,
        end_date=end_date,
        label=label,
        status="draft",
    )
    db.add(period)
    db.flush()
    # デフォルト制約を自動生成
    db.add(
        models.Constraint(
            team_id=team_tid,
            period_id=period.id,
            max_consecutive_days=5,
            max_days_per_week=5,
            min_days_off_per_week=2,
            max_nights_per_week=0,
            enable_max_consecutive_days=True,
            enable_max_days_per_week=True,
            enable_min_days_off_per_week=True,
            enable_max_nights_per_week=True,
            enable_no_consecutive_nights=True,
            enable_min_rest_day_night=True,
            no_early_after_night=True,
            equalize_workload=True,
        )
    )
    db.commit()
    return RedirectResponse(
        url=f"/?period_id={period.id}&team_id={team_tid}",
        status_code=303,
    )


@router.post("/{period_id}/constraints", response_class=HTMLResponse)
def update_constraints(
    request: Request,
    period_id: int,
    max_consecutive_days: int = Form(5),
    max_days_per_week: int = Form(6),
    min_days_off_per_week: int = Form(1),
    max_nights_per_week: int = Form(2),
    enable_max_consecutive_days: bool = Form(False),
    enable_max_days_per_week: bool = Form(False),
    enable_min_days_off_per_week: bool = Form(False),
    enable_max_nights_per_week: bool = Form(False),
    enable_no_consecutive_nights: bool = Form(False),
    enable_min_rest_day_night: bool = Form(False),
    min_rest_hours_day_night: int = Form(48),
    no_early_after_night: bool = Form(False),
    equalize_workload: bool = Form(False),
    db: Session = Depends(get_db),
):
    c = db.query(models.Constraint).filter(
        models.Constraint.period_id == period_id
    ).first()
    if c:
        c.max_consecutive_days = max_consecutive_days
        c.max_days_per_week = max_days_per_week
        c.min_days_off_per_week = min_days_off_per_week
        c.max_nights_per_week = max(0, min(7, max_nights_per_week))
        c.enable_max_consecutive_days = enable_max_consecutive_days
        c.enable_max_days_per_week = enable_max_days_per_week
        c.enable_min_days_off_per_week = enable_min_days_off_per_week
        c.enable_max_nights_per_week = enable_max_nights_per_week
        c.enable_no_consecutive_nights = enable_no_consecutive_nights
        c.enable_min_rest_day_night = enable_min_rest_day_night
        set_min_rest_hours_day_night(db, c.id, min_rest_hours_day_night)
        c.no_early_after_night = no_early_after_night
        c.equalize_workload = equalize_workload
        db.commit()
    return HTMLResponse('<span class="save-ok">✅ 保存しました</span>')


@router.delete("/{period_id}")
def delete_period(
    period_id: int,
    db: Session = Depends(get_db),
    team_tid: int = Depends(get_current_team_id),
):
    """期間を削除する。子の割り当て・制約は ORM / DB の CASCADE で削除。休み希望は period に紐づかないため残る。"""
    period = db.query(models.SchedulePeriod).filter(models.SchedulePeriod.id == period_id).first()
    if not period or period.team_id != team_tid:
        return Response(status_code=404)

    others = (
        db.query(models.SchedulePeriod)
        .filter(
            models.SchedulePeriod.id != period_id,
            models.SchedulePeriod.team_id == period.team_id,
        )
        .order_by(models.SchedulePeriod.start_date.desc())
        .all()
    )
    fallback_id = others[0].id if others else None

    db.delete(period)
    db.commit()

    if fallback_id is not None:
        url = f"/?period_id={fallback_id}&team_id={team_tid}"
    else:
        url = f"/?team_id={team_tid}"
    return Response(status_code=200, headers={"HX-Redirect": url})
