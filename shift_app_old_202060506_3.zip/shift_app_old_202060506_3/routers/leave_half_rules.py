"""SH_LEAVE_HALF_DAY_RULES（半休の曜日別時間窓）の CRUD UI。"""

from fastapi import APIRouter, Depends, Request, Form, Query
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.exc import IntegrityError, OperationalError
from sqlalchemy.orm import Session

from database import get_db
import models
from deps import resolve_team_id

router = APIRouter()
templates = Jinja2Templates(directory="templates")

_KIND_VALUES = frozenset(
    {models.LEAVE_KIND_MORNING_HALF, models.LEAVE_KIND_AFTERNOON_HALF}
)


def _teams_query(db: Session):
    return (
        db.query(models.Team)
        .filter(models.Team.is_active == True)
        .order_by(models.Team.name.asc())
        .all()
    )


def _normalize_time(value: str) -> str:
    raw = (value or "").strip()
    if not raw:
        return ""
    if len(raw) == 5 and raw[2] == ":":
        return f"{raw}:00"
    return raw[:8]


def _load_rules(db: Session, team_tid: int) -> list[models.LeaveHalfDayRule]:
    try:
        return (
            db.query(models.LeaveHalfDayRule)
            .filter(models.LeaveHalfDayRule.team_id == team_tid)
            .order_by(
                models.LeaveHalfDayRule.weekday.asc(),
                models.LeaveHalfDayRule.kind.asc(),
            )
            .all()
        )
    except OperationalError:
        return []


def _panel_response(
    request: Request,
    db: Session,
    team_tid: int,
    error: str | None = None,
) -> HTMLResponse:
    return templates.TemplateResponse(
        "partials/leave_half_rules_panel.html",
        {
            "request": request,
            "rules": _load_rules(db, team_tid),
            "current_team_id": team_tid,
            "error": error,
            "weekday_labels": ["月", "火", "水", "木", "金", "土", "日"],
        },
    )


@router.get("/", response_class=HTMLResponse)
def leave_half_rules_page(
    request: Request,
    team_id: int | None = Query(default=None),
    db: Session = Depends(get_db),
):
    tid = resolve_team_id(request, db, team_id)
    ctx = {
        "request": request,
        "all_teams": _teams_query(db),
        "current_team_id": tid,
        "rules": _load_rules(db, tid),
        "weekday_labels": ["月", "火", "水", "木", "金", "土", "日"],
        "error": None,
    }
    resp = templates.TemplateResponse("leave_half_rules.html", ctx)
    resp.set_cookie(
        "shift_team_id",
        str(tid),
        max_age=31536000,
        path="/",
        httponly=False,
        samesite="lax",
    )
    return resp


@router.post("/add", response_class=HTMLResponse)
def add_leave_half_rule(
    request: Request,
    weekday: int = Form(...),
    kind: str = Form(...),
    start_time: str = Form(...),
    end_time: str = Form(...),
    team_id: int | None = Form(None),
    db: Session = Depends(get_db),
):
    tid = resolve_team_id(request, db, team_id)
    if weekday < 0 or weekday > 6:
        return _panel_response(request, db, tid, "曜日は 0（月）〜6（日）の範囲で指定してください。")
    k = (kind or "").strip()
    if k not in _KIND_VALUES:
        return _panel_response(request, db, tid, "種別が不正です（午前休／午後休のみ）。")
    st = _normalize_time(start_time)
    et = _normalize_time(end_time)
    if not st or not et:
        return _panel_response(request, db, tid, "開始・終了時刻を入力してください。")

    db.add(
        models.LeaveHalfDayRule(
            team_id=tid,
            weekday=weekday,
            kind=k,
            start_time=st,
            end_time=et,
        )
    )
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        return _panel_response(
            request,
            db,
            tid,
            "同じチーム・曜日・種別のルールが既にあります。一覧から編集するか、一度削除してください。",
        )
    return _panel_response(request, db, tid, None)


@router.post("/{rule_id}/update", response_class=HTMLResponse)
def update_leave_half_rule(
    request: Request,
    rule_id: int,
    start_time: str = Form(...),
    end_time: str = Form(...),
    team_id: int | None = Form(None),
    db: Session = Depends(get_db),
):
    tid = resolve_team_id(request, db, team_id)
    row = (
        db.query(models.LeaveHalfDayRule)
        .filter(
            models.LeaveHalfDayRule.id == rule_id,
            models.LeaveHalfDayRule.team_id == tid,
        )
        .first()
    )
    if not row:
        return _panel_response(request, db, tid, "ルールが見つかりません。")
    st = _normalize_time(start_time)
    et = _normalize_time(end_time)
    if not st or not et:
        return _panel_response(request, db, tid, "開始・終了時刻を入力してください。")
    row.start_time = st
    row.end_time = et
    db.commit()
    return _panel_response(request, db, tid, None)


@router.post("/{rule_id}/delete", response_class=HTMLResponse)
def delete_leave_half_rule(
    request: Request,
    rule_id: int,
    team_id: int | None = Form(None),
    db: Session = Depends(get_db),
):
    tid = resolve_team_id(request, db, team_id)
    q = db.query(models.LeaveHalfDayRule).filter(
        models.LeaveHalfDayRule.id == rule_id,
        models.LeaveHalfDayRule.team_id == tid,
    )
    q.delete(synchronize_session=False)
    db.commit()
    return _panel_response(request, db, tid, None)
