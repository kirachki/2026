from fastapi import APIRouter, Depends, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from database import get_db
import models
from deps import get_current_team_id

router = APIRouter()
templates = Jinja2Templates(directory="templates")


def _parse_min_staff_mode(raw: str | None) -> str:
    if raw == models.MIN_STAFF_MODE_EXACT:
        return models.MIN_STAFF_MODE_EXACT
    return models.MIN_STAFF_MODE_AT_LEAST


def _render_list(request: Request, db: Session, team_tid: int, error: str | None = None) -> HTMLResponse:
    shift_types = (
        db.query(models.ShiftType)
        .filter(models.ShiftType.team_id == team_tid)
        .order_by(models.ShiftType.start_time.asc(), models.ShiftType.id.asc())
        .all()
    )
    return templates.TemplateResponse(
        "partials/shift_type_list.html",
        {"request": request, "shift_types": shift_types, "error": error},
    )


@router.post("/add", response_class=HTMLResponse)
def add_shift_type(
    request: Request,
    name: str       = Form(...),
    start_time: str = Form(...),
    end_time: str   = Form(...),
    min_staff: int  = Form(1),
    min_staff_mode: str = Form(models.MIN_STAFF_MODE_AT_LEAST),
    color_code: str = Form("#888888"),
    db: Session = Depends(get_db),
    team_tid: int = Depends(get_current_team_id),
):
    db.add(models.ShiftType(
        team_id=team_tid,
        name=name,
        start_time=start_time + ":00",
        end_time=end_time + ":00",
        min_staff=min_staff,
        min_staff_mode=_parse_min_staff_mode(min_staff_mode),
        color_code=color_code,
    ))
    db.commit()
    return _render_list(request, db, team_tid)


@router.post("/{shift_type_id}/update", response_class=HTMLResponse)
def update_shift_type(
    request: Request,
    shift_type_id: int,
    name: str       = Form(...),
    start_time: str = Form(...),
    end_time: str   = Form(...),
    min_staff: int  = Form(1),
    min_staff_mode: str = Form(models.MIN_STAFF_MODE_AT_LEAST),
    color_code: str = Form("#888888"),
    db: Session = Depends(get_db),
    team_tid: int = Depends(get_current_team_id),
):
    st = db.query(models.ShiftType).filter(
        models.ShiftType.id == shift_type_id,
        models.ShiftType.team_id == team_tid,
    ).first()
    if st:
        st.name       = name
        st.start_time = start_time + ":00" if len(start_time) == 5 else start_time
        st.end_time   = end_time   + ":00" if len(end_time)   == 5 else end_time
        st.min_staff  = min_staff
        st.min_staff_mode = _parse_min_staff_mode(min_staff_mode)
        st.color_code = color_code
        db.commit()
    return _render_list(request, db, team_tid)


@router.delete("/{shift_type_id}", response_class=HTMLResponse)
def delete_shift_type(
    request: Request,
    shift_type_id: int,
    db: Session = Depends(get_db),
    team_tid: int = Depends(get_current_team_id),
):
    st = db.query(models.ShiftType).filter(
        models.ShiftType.id == shift_type_id,
        models.ShiftType.team_id == team_tid,
    ).first()
    if not st:
        return _render_list(request, db, team_tid)

    # タスク削除時は、同一チーム内でこの種別を参照するデータも合わせて削除する。
    # これにより「使用中で削除不可」に詰まらず、UI から確実に削除できる。
    db.query(models.ShiftAssignment).filter(
        models.ShiftAssignment.team_id == team_tid,
        models.ShiftAssignment.shift_type_id == shift_type_id,
    ).delete(synchronize_session=False)

    db.query(models.StaffShiftEligibility).filter(
        models.StaffShiftEligibility.shift_type_id == shift_type_id,
    ).delete(synchronize_session=False)

    period_ids_subq = db.query(models.SchedulePeriod.id).filter(
        models.SchedulePeriod.team_id == team_tid
    ).subquery()
    db.query(models.PeriodShiftWeekdayDemand).filter(
        models.PeriodShiftWeekdayDemand.shift_type_id == shift_type_id,
        models.PeriodShiftWeekdayDemand.period_id.in_(period_ids_subq),
    ).delete(synchronize_session=False)
    db.query(models.PeriodShiftDateDemand).filter(
        models.PeriodShiftDateDemand.shift_type_id == shift_type_id,
        models.PeriodShiftDateDemand.period_id.in_(period_ids_subq),
    ).delete(synchronize_session=False)

    db.delete(st)
    db.commit()
    return _render_list(request, db, team_tid)
