import jwt
from fastapi import APIRouter, Form, Request
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from jwt import ExpiredSignatureError, InvalidTokenError
from app_config import get_security_setting, get_setting

router = APIRouter()
templates = Jinja2Templates(directory="templates")

JWT_ISSUER = "crm-8000"
JWT_AUDIENCE = "shift-8001"
ALLOWED_ROLES = {"admin", "manager", "staff"}
CRM_SSO_ENTRY_URL = get_setting("sso", "crm_shift_link_url", "http://localhost:8000/shift-app-link")


def _error_redirect(reason: str) -> RedirectResponse:
    return RedirectResponse(url=f"/auth/error?reason={reason}", status_code=303)


def _reason_message(reason: str) -> str:
    messages = {
        "missing_token": "SSOトークンが送信されていません。",
        "secret_not_configured": "サーバ設定エラー: 共有鍵が未設定です。",
        "expired": "SSOトークンの有効期限が切れています。",
        "invalid_token": "SSOトークンの署名または形式が不正です。",
        "invalid_claims": "SSOトークンのクレームが不正です。",
    }
    return messages.get(reason, "SSO認証に失敗しました。")


@router.post("/sso")
def sso_login(request: Request, token: str = Form(default="", alias="token")):
    raw_token = (token or "").strip()
    if not raw_token:
        return _error_redirect("missing_token")

    secret = get_security_setting("crm_shift_jwt_secret", "").strip()
    if not secret:
        return _error_redirect("secret_not_configured")

    try:
        claims = jwt.decode(
            raw_token,
            secret,
            algorithms=["HS256"],
            issuer=JWT_ISSUER,
            audience=JWT_AUDIENCE,
            options={
                "require": [
                    "sub",
                    "user_id",
                    "user_name",
                    "role",
                    "team_id",
                    "iss",
                    "aud",
                    "iat",
                    "exp",
                ]
            },
        )
    except ExpiredSignatureError:
        return _error_redirect("expired")
    except InvalidTokenError:
        return _error_redirect("invalid_token")

    role = claims.get("role")
    team_id = claims.get("team_id")
    if role not in ALLOWED_ROLES or not str(team_id).isdigit():
        return _error_redirect("invalid_claims")

    request.session["auth_user"] = {
        "sub": str(claims["sub"]),
        "user_id": str(claims["user_id"]),
        "user_name": str(claims["user_name"]),
        "role": role,
        "team_id": int(str(team_id)),
        "iss": str(claims["iss"]),
        "aud": claims["aud"],
        "iat": claims["iat"],
        "exp": claims["exp"],
    }

    response = RedirectResponse(url="/", status_code=303)
    response.set_cookie(
        "shift_team_id",
        str(int(str(team_id))),
        max_age=31536000,
        path="/",
        httponly=False,
        samesite="lax",
    )
    return response


@router.get("/error")
def auth_error(request: Request, reason: str = "invalid_token"):
    return templates.TemplateResponse(
        "auth_error.html",
        {
            "request": request,
            "reason": reason,
            "message": _reason_message(reason),
        },
        status_code=401,
    )


@router.post("/logout")
def logout(request: Request):
    request.session.clear()
    response = RedirectResponse(url=CRM_SSO_ENTRY_URL, status_code=303)
    response.delete_cookie("session", path="/")
    response.delete_cookie("shift_team_id", path="/")
    return response
