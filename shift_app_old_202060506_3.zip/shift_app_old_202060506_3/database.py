from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, DeclarativeBase

_DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "kuro0711",
    "database": "sakila",
    "charset": "utf8mb4",
}

SQLALCHEMY_DATABASE_URL = (
    "mysql+pymysql://{user}:{password}@{host}/{database}?charset={charset}".format(
        **_DB_CONFIG
    )
)

engine = create_engine(SQLALCHEMY_DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


class Base(DeclarativeBase):
    pass


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
