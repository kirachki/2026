-- 請求書明細の税込金額合計（画面 /invoice/maintenance-new の「合計金額」と同ロジック）
-- 引数: 請求書番号（T1_請求書データ_ヘッダ・明細のキー列）
-- 利用例:
--   SELECT h.`請求書番号`, g_get_sum(h.`請求書番号`) AS 合計金額
--     FROM `T1_請求書データ_ヘッダ` h;
--
-- 前提:
--   - 税率は画面 JS と同様 10% 固定（FLOOR(税抜 * 0.1)）
--   - 消費税区分が「内税」「非課税」「不課税」の行は消費税 0
--   - 税抜 = 単価 × 数量（税抜金額端数処理区分で端数処理）
-- 権限: CREATE ROUTINE / 呼び出し側に EXECUTE

DELIMITER $$

DROP FUNCTION IF EXISTS g_get_sum$$

CREATE FUNCTION g_get_sum(p_seikyu_no VARCHAR(20))
RETURNS DECIMAL(20, 3)
READS SQL DATA
COMMENT '請求書番号に紐づく明細税込金額の合計（メンテ画面の合計金額相当）'
BEGIN
  DECLARE v_sum DECIMAL(20, 3) DEFAULT 0;

  SELECT COALESCE(SUM(line_zeikomi), 0)
    INTO v_sum
    FROM (
      SELECT
        (
          z.zeinuki
          + CASE
              WHEN z.`消費税区分` IN ('内税', '非課税', '不課税') THEN 0
              ELSE FLOOR(z.zeinuki * 0.1)
            END
        ) AS line_zeikomi
      FROM (
        SELECT
          d.`消費税区分`,
          CASE
            WHEN d.`単価` IS NULL OR TRIM(d.`単価`) = ''
              OR d.`数量` IS NULL THEN NULL
            WHEN d.`税抜金額端数処理区分` IN ('0', '切捨て') THEN
              FLOOR(
                CAST(REPLACE(TRIM(d.`単価`), ',', '') AS DECIMAL(20, 10))
                * d.`数量`
              )
            WHEN d.`税抜金額端数処理区分` IN ('1', '切り上げ') THEN
              CEILING(
                CAST(REPLACE(TRIM(d.`単価`), ',', '') AS DECIMAL(20, 10))
                * d.`数量`
              )
            WHEN d.`税抜金額端数処理区分` IN ('2', '四捨五入') THEN
              ROUND(
                CAST(REPLACE(TRIM(d.`単価`), ',', '') AS DECIMAL(20, 10))
                * d.`数量`
              )
            ELSE
              CAST(REPLACE(TRIM(d.`単価`), ',', '') AS DECIMAL(20, 10))
              * d.`数量`
          END AS zeinuki
        FROM `T1_請求書データ_明細` d
        WHERE d.`請求書番号` = p_seikyu_no
      ) z
      WHERE z.zeinuki IS NOT NULL
    ) calc;

  RETURN v_sum;
END$$

DELIMITER ;
