cd C:\study\LLM\llm-app-lesson
- python -m venv venv
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\venv\Scripts\Activate.ps1
cursor .

