import os
from dotenv import load_dotenv
from openai import OpenAI
from fastapi import FastAPI
from pydantic import BaseModel

load_dotenv()
client = OpenAI()
app = FastAPI()

# session_idごとの会話履歴を保存する辞書（学習用の簡易メモリストレージ）
conversation_history: dict[str, list[dict]] = {}

class ChatRequest(BaseModel):
    session_id: str
    message: str

@app.post("/chat")
def chat(request: ChatRequest):
    # このsession_idが初めてなら、systemプロンプトから履歴をスタート
    if request.session_id not in conversation_history:
        conversation_history[request.session_id] = [
            {"role": "system", "content": "あなたは親切なアシスタントです。"}
        ]

    history = conversation_history[request.session_id]
    history.append({"role": "user", "content": request.message})

    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=history
    )

    reply = response.choices[0].message.content
    history.append({"role": "assistant", "content": reply})

    return {
        "reply": reply,
        "tokens": response.usage.total_tokens,
        "history_length": len(history)
    }