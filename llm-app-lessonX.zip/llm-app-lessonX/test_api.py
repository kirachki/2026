import os
from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()
client = OpenAI()  # .envのOPENAI_API_KEYを自動で読み込む

response = client.chat.completions.create(
    model="gpt-4o-mini",
    messages=[
        {"role": "system", "content": "あなたはChatGPTではなくカスタムアシスタントです。"},
        {"role": "user", "content": "こんにちは、自己紹介してください。"}
    ]
)

print(response.choices[0].message.content)
print(f"使用トークン数: {response.usage.total_tokens}")
