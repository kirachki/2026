
import os
from typing import TypedDict
from dotenv import load_dotenv
from openai import OpenAI
from langgraph.graph import StateGraph, START, END

load_dotenv()
client = OpenAI()

# State: このグラフが扱うデータの「型」を定義
class ChatState(TypedDict):
    messages: list[dict]

# Node: 状態を受け取り、処理して、更新した状態を返す関数
def call_model(state: ChatState) -> ChatState:
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=state["messages"]
    )
    reply = response.choices[0].message.content
    state["messages"].append({"role": "assistant", "content": reply})
    return state

# グラフを作る
graph = StateGraph(ChatState)
graph.add_node("call_model", call_model)   # ノードを登録
graph.add_edge(START, "call_model")        # 開始 → call_model
graph.add_edge("call_model", END)          # call_model → 終了

app = graph.compile()  # グラフを実行可能な形にコンパイル

# 実行
initial_state = {
    "messages": [
        {"role": "system", "content": "あなたは親切なアシスタントです。"},
        # {"role": "user", "content": "こんにちは、自己紹介してください。"}
        {"role": "user", "content": "アメリカが週単位で独立している理由は？"}
    ]
}

result = app.invoke(initial_state)
print(result["messages"][-1]["content"])


# コードの流れ
# StateGraph(ChatState) → 「このグラフはChatStateという形のデータを状態として扱います」と宣言
# add_node("call_model", call_model) → call_modelという名前で、さっき定義した関数をノードとして登録
# add_edge(START, "call_model") / add_edge("call_model", END) → 「開始したらcall_modelを実行し、終わったら終了する」という道筋を定義
# graph.compile() → 定義した構成を、実際に動かせるappオブジェクトに変換
# app.invoke(initial_state) → 初期状態を渡して実行。戻り値は処理後の状態全体
