from fastapi import APIRouter, Depends, Request, Form, Query
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import text
from sqlalchemy.exc import OperationalError
from sqlalchemy.orm import Session, joinedload

from database import get_db
import models
from deps import get_current_team_id
from staff_sort_order import staff_rows_order_by

router = APIRouter()
templates = Jinja2Templates(directory="templates")


def _is_admin(request: Request) -> bool:
    user = request.session.get("auth_user")
    role = str((user or {}).get("role", "")).strip().lower()
    return role in ("admin", "manager")


def _like_pattern(q: str) -> str:
    """LIKE 用に % _ \\ をエスケープ（MySQL ESCAPE '\\\\' と組み合わせる）。"""
    s = (q or "").strip()
    if not s:
        return ""
    return s.replace("\\", "\\\\").replace("%", r"\%").replace("_", r"\_")


def _resolve_work_ptn_id(db: Session, raw: str | None) -> int | None:
    s = (raw or "").strip()
    if not s.isdigit():
        return None
    pid = int(s)
    row = db.query(models.WorkPtn.id).filter(models.WorkPtn.id == pid).first()
    return pid if row else None


def _normalize_team_label(value: str | None) -> str | None:
    s = (value or "").strip()
    if not s:
        return None
    return s[:6]


def _normalize_sort_order(value: str | int | None) -> int:
    if value is None:
        return 500
    try:
        n = int(str(value).strip())
    except (TypeError, ValueError):
        return 500
    if n < 0:
        return 0
    if n > 999:
        return 999
    return n


@router.get("/loginuser-suggest", response_class=HTMLResponse)
def loginuser_suggest(
    request: Request,
    userid_lookup: str = Query(""),
    staff_q_lookup: str = Query(""),
    userid: str = Query(""),
    db: Session = Depends(get_db),
):
    """
    t1_loginuser.userid を部分一致で検索し、候補リストを返す（HTMX 用 HTML）。
    休み希望検索は staff_q_lookup、サイドバーは userid_lookup。
    """
    q = (userid_lookup or staff_q_lookup or userid or "").strip()
    if len(q) < 1:
        return HTMLResponse("")
    if not _is_admin(request):
        return HTMLResponse("")
    p = _like_pattern(q)
    if not p:
        return HTMLResponse("")
    pat = f"%{p}%"
    sql = text(
        """
        SELECT userid, user_name
        FROM t1_loginuser
        WHERE Enabled = 1
          AND userid IS NOT NULL
          AND TRIM(userid) <> ''
          AND userid LIKE :pat ESCAPE '\\\\'
        ORDER BY userid ASC
        LIMIT 40
        """
    )
    try:
        rows = db.execute(sql, {"pat": pat}).mappings().all()
    except OperationalError:
        return HTMLResponse("")
    return templates.TemplateResponse(
        "partials/loginuser_suggest.html",
        {"request": request, "rows": rows},
    )


def _staff_list_response(
    request: Request,
    db: Session,
    team_tid: int,
    staff_error: str | None = None,
):
    try:
        work_patterns = (
            db.query(models.WorkPtn)
            .order_by(models.WorkPtn.sort_order.asc(), models.WorkPtn.id.asc())
            .all()
        )
    except OperationalError:
        work_patterns = []
    staff_list = (
        db.query(models.Staff)
        .options(joinedload(models.Staff.work_ptn))
        .filter(models.Staff.team_id == team_tid, models.Staff.is_active == True)
        .order_by(*staff_rows_order_by())
        .all()
    )
    return templates.TemplateResponse(
        "partials/staff_list.html",
        {
            "request": request,
            "staff_list": staff_list,
            "work_patterns": work_patterns,
            "staff_error": staff_error,
            "is_admin": _is_admin(request),
        },
    )


@router.post("/add", response_class=HTMLResponse)
def add_staff(
    request: Request,
    userid: str = Form(...),
    role: str = Form("一般スタッフ"),
    employment_type: str = Form("full_time"),
    work_ptn_id: str = Form(""),
    team_label: str = Form(""),
    sort_order: str = Form("500"),
    db: Session = Depends(get_db),
    team_tid: int = Depends(get_current_team_id),
):
    if not _is_admin(request):
        return _staff_list_response(request, db, team_tid, "この操作の権限がありません。")

    uid = (userid or "").strip()
    if not uid:
        return _staff_list_response(request, db, team_tid, "ユーザーIDを入力してください。")

    sql = text(
        """
        SELECT user_name FROM t1_loginuser
        WHERE userid = :uid AND Enabled = 1
        LIMIT 1
        """
    )
    try:
        row = db.execute(sql, {"uid": uid}).mappings().first()
    except OperationalError:
        return _staff_list_response(
            request, db, team_tid, "ログインユーザー表を参照できません。"
        )

    if not row:
        return _staff_list_response(
            request, db, team_tid, f"ユーザーID「{uid}」は見つかりません。"
        )

    un = row.get("user_name")
    display_name = (un or "").strip() or uid

    staff = models.Staff(
        team_id=team_tid,
        name=display_name,
        login_userid=uid,
        role=_normalize_role(role),
        employment_type=_normalize_employment_type(employment_type),
        work_ptn_id=_resolve_work_ptn_id(db, work_ptn_id),
        team_label=_normalize_team_label(team_label),
        sort_order=_normalize_sort_order(sort_order),
    )
    db.add(staff)
    db.commit()
    db.refresh(staff)
    return _staff_list_response(request, db, team_tid, None)


_ALLOWED_ROLES = ("リーダー", "一般スタッフ")
_ALLOWED_EMPLOYMENT_TYPES = ("full_time", "part_time", "haken")


def _normalize_role(value: str) -> str:
    v = (value or "").strip()
    return v if v in _ALLOWED_ROLES else "一般スタッフ"


def _normalize_employment_type(value: str) -> str:
    v = (value or "").strip()
    return v if v in _ALLOWED_EMPLOYMENT_TYPES else "full_time"


@router.post("/{staff_id}/update", response_class=HTMLResponse)
def update_staff(
    request: Request,
    staff_id: int,
    role: str = Form("一般スタッフ"),
    employment_type: str = Form("full_time"),
    work_ptn_id: str = Form(""),
    team_label: str = Form(""),
    sort_order: str = Form("500"),
    db: Session = Depends(get_db),
    team_tid: int = Depends(get_current_team_id),
):
    if not _is_admin(request):
        return _staff_list_response(request, db, team_tid, "この操作の権限がありません。")

    staff = (
        db.query(models.Staff)
        .filter(models.Staff.id == staff_id, models.Staff.team_id == team_tid)
        .first()
    )
    if not staff:
        return _staff_list_response(request, db, team_tid, "対象のスタッフが見つかりません。")

    staff.role = _normalize_role(role)
    staff.employment_type = _normalize_employment_type(employment_type)
    staff.work_ptn_id = _resolve_work_ptn_id(db, work_ptn_id)
    staff.team_label = _normalize_team_label(team_label)
    staff.sort_order = _normalize_sort_order(sort_order)
    db.commit()
    return _staff_list_response(request, db, team_tid, None)


@router.delete("/{staff_id}", response_class=HTMLResponse)
def delete_staff(
    request: Request,
    staff_id: int,
    db: Session = Depends(get_db),
    team_tid: int = Depends(get_current_team_id),
):
    if not _is_admin(request):
        return _staff_list_response(request, db, team_tid, "この操作の権限がありません。")

    staff = db.query(models.Staff).filter(models.Staff.id == staff_id).first()
    if staff:
        staff.is_active = False
        db.commit()
    return _staff_list_response(request, db, team_tid, None)
