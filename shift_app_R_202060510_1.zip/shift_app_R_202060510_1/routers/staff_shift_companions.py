"""主スタッフに対する同伴必須ルールの編集 UI。"""

from fastapi import APIRouter, Depends, Form, Query, Request
from fastapi.responses import HTMLResponse, Response
from fastapi.templating import Jinja2Templates
from sqlalchemy.exc import OperationalError
from sqlalchemy.orm import Session

from database import get_db
import models
from deps import resolve_team_id

router = APIRouter()
templates = Jinja2Templates(directory="templates")


def _teams_query(db: Session):
    return (
        db.query(models.Team)
        .filter(models.Team.is_active == True)
        .order_by(models.Team.name.asc())
        .all()
    )


def _active_staff_list(db: Session, team_tid: int):
    return (
        db.query(models.Staff)
        .filter(models.Staff.team_id == team_tid, models.Staff.is_active == True)
        .order_by(models.Staff.name.asc())
        .all()
    )


def _shift_type_list(db: Session, team_tid: int):
    return (
        db.query(models.ShiftType)
        .filter(models.ShiftType.team_id == team_tid)
        .order_by(models.ShiftType.start_time.asc(), models.ShiftType.id.asc())
        .all()
    )


def _companion_rule_rows(db: Session, team_tid: int):
    try:
        rules = (
            db.query(models.StaffShiftCompanionRule)
            .filter(models.StaffShiftCompanionRule.team_id == team_tid)
            .order_by(models.StaffShiftCompanionRule.primary_staff_id.asc())
            .all()
        )
        staff_map = {s.id: s for s in _active_staff_list(db, team_tid)}
        shift_map = {st.id: st for st in _shift_type_list(db, team_tid)}
        out = []
        for rule in rules:
            primary = staff_map.get(rule.primary_staff_id)
            if not primary:
                continue
            companions: list[dict] = []
            for m in rule.members:
                sm = staff_map.get(m.companion_staff_id)
                if sm:
                    companions.append({"id": sm.id, "name": sm.name})
            companions.sort(key=lambda x: x["name"])
            if not companions:
                continue
            out.append(
                {
                    "id": rule.id,
                    "primary_staff_id": primary.id,
                    "primary_name": primary.name,
                    "companions": companions,
                    "targets": [
                        {
                            "id": st.id,
                            "name": st.name,
                        }
                        for st in sorted(
                            (
                                shift_map.get(t.shift_type_id)
                                for t in rule.targets
                            ),
                            key=lambda x: x.id if x else 0,
                        )
                        if st is not None
                    ],
                }
            )
        return out
    except OperationalError:
        return []


def _render_page(
    request: Request,
    db: Session,
    team_tid: int,
    save_message: str | None = None,
    save_error: str | None = None,
):
    staff_list = _active_staff_list(db, team_tid)
    shift_types = _shift_type_list(db, team_tid)
    ctx = {
        "request": request,
        "all_teams": _teams_query(db),
        "current_team_id": team_tid,
        "staff_list": staff_list,
        "shift_types": shift_types,
        "rule_rows": _companion_rule_rows(db, team_tid),
        "save_message": save_message,
        "save_error": save_error,
    }
    return templates.TemplateResponse("staff_shift_companions.html", ctx)


@router.get("/", response_class=HTMLResponse)
def staff_shift_companions_page(
    request: Request,
    team_id: int | None = Query(default=None),
    db: Session = Depends(get_db),
):
    tid = resolve_team_id(request, db, team_id)
    resp = _render_page(request, db, tid)
    resp.set_cookie(
        "shift_team_id",
        str(tid),
        max_age=31536000,
        path="/",
        httponly=False,
        samesite="lax",
    )
    return resp


@router.post("/save", response_class=HTMLResponse)
def save_companion_rule(
    request: Request,
    team_id: int = Form(...),
    primary_staff_id: int = Form(...),
    companion_staff_ids: list[int] = Form(default=[]),
    target_shift_type_ids: list[int] = Form(default=[]),
    db: Session = Depends(get_db),
):
    tid = resolve_team_id(request, db, team_id)
    save_message = None
    save_error = None

    primary = (
        db.query(models.Staff)
        .filter(
            models.Staff.id == primary_staff_id,
            models.Staff.team_id == tid,
            models.Staff.is_active == True,
        )
        .first()
    )
    if not primary:
        return _render_page(
            request,
            db,
            tid,
            save_error="主スタッフが見つかりませんでした。",
        )

    uniq_companions = sorted({sid for sid in companion_staff_ids if sid != primary_staff_id})
    if not uniq_companions:
        return _render_page(
            request,
            db,
            tid,
            save_error="同伴者を1名以上選択してください。",
        )

    valid_companions = (
        db.query(models.Staff)
        .filter(
            models.Staff.id.in_(uniq_companions),
            models.Staff.team_id == tid,
            models.Staff.is_active == True,
        )
        .all()
    )
    valid_ids = sorted({s.id for s in valid_companions})
    if valid_ids != uniq_companions:
        return _render_page(
            request,
            db,
            tid,
            save_error="同伴者に無効なスタッフが含まれています。",
        )

    uniq_target_shift_ids = sorted(set(target_shift_type_ids))
    valid_target_ids: list[int] = []
    if uniq_target_shift_ids:
        valid_targets = (
            db.query(models.ShiftType)
            .filter(
                models.ShiftType.id.in_(uniq_target_shift_ids),
                models.ShiftType.team_id == tid,
            )
            .all()
        )
        valid_target_ids = sorted({st.id for st in valid_targets})
        if valid_target_ids != uniq_target_shift_ids:
            return _render_page(
                request,
                db,
                tid,
                save_error="対象タスクに無効な種別が含まれています。",
            )

    try:
        rule = (
            db.query(models.StaffShiftCompanionRule)
            .filter(
                models.StaffShiftCompanionRule.team_id == tid,
                models.StaffShiftCompanionRule.primary_staff_id == primary_staff_id,
            )
            .first()
        )
        if not rule:
            rule = models.StaffShiftCompanionRule(
                team_id=tid,
                primary_staff_id=primary_staff_id,
            )
            db.add(rule)
            db.flush()

        db.query(models.StaffShiftCompanionMember).filter(
            models.StaffShiftCompanionMember.rule_id == rule.id
        ).delete(synchronize_session=False)
        for sid in valid_ids:
            db.add(
                models.StaffShiftCompanionMember(
                    rule_id=rule.id,
                    companion_staff_id=sid,
                )
            )
        db.query(models.StaffShiftCompanionTargetShift).filter(
            models.StaffShiftCompanionTargetShift.rule_id == rule.id
        ).delete(synchronize_session=False)
        for stid in valid_target_ids:
            db.add(
                models.StaffShiftCompanionTargetShift(
                    rule_id=rule.id,
                    shift_type_id=stid,
                )
            )
        db.commit()
        save_message = "同伴必須ルールを保存しました。"
    except OperationalError:
        db.rollback()
        save_error = "同伴必須ルールの保存に失敗しました。"

    return _render_page(request, db, tid, save_message=save_message, save_error=save_error)


@router.delete("/{rule_id}")
def delete_companion_rule(
    request: Request,
    rule_id: int,
    team_id: int | None = Query(default=None),
    db: Session = Depends(get_db),
):
    tid = resolve_team_id(request, db, team_id)
    row = (
        db.query(models.StaffShiftCompanionRule)
        .filter(
            models.StaffShiftCompanionRule.id == rule_id,
            models.StaffShiftCompanionRule.team_id == tid,
        )
        .first()
    )
    if row:
        db.delete(row)
        db.commit()
    url = f"/staff_shift_companions/?team_id={tid}"
    return Response(status_code=200, headers={"HX-Redirect": url})
