"""期間ごとの休業日（全員タスクなし・最適化で配置禁止）。"""

from datetime import date as date_type, timedelta

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from database import get_db
import models
from date_keys import to_calendar_date
from deps import get_current_team_id

router = APIRouter()
templates = Jinja2Templates(directory="templates")


def _is_admin_user(request: Request) -> bool:
    user = request.session.get("auth_user", {})
    role = str(user.get("role", "")).strip().lower()
    return role in ("admin", "manager")


def _clear_assignments_for_period_day(db: Session, period_id: int, work_date: date_type) -> None:
    db.query(models.ShiftAssignment).filter(
        models.ShiftAssignment.period_id == period_id,
        models.ShiftAssignment.work_date == work_date,
    ).delete(synchronize_session="fetch")


def _period_for_team(db: Session, period_id: int, team_tid: int) -> models.SchedulePeriod:
    period = db.query(models.SchedulePeriod).filter(
        models.SchedulePeriod.id == period_id,
        models.SchedulePeriod.team_id == team_tid,
    ).first()
    if not period:
        raise HTTPException(status_code=404, detail="期間が見つかりません")
    return period


@router.post("/toggle/{period_id}/{closed_date}", response_class=HTMLResponse)
def toggle_closed_day(
    request: Request,
    period_id: int,
    closed_date: date_type,
    db: Session = Depends(get_db),
    current_tid: int = Depends(get_current_team_id),
):
    is_admin = _is_admin_user(request)
    if not is_admin:
        raise HTTPException(status_code=403, detail="この操作の権限がありません")
    period_row = _period_for_team(db, period_id, current_tid)

    existing = (
        db.query(models.ClosedDay)
        .filter(
            models.ClosedDay.period_id == period_id,
            models.ClosedDay.closed_date == closed_date,
        )
        .first()
    )

    if existing:
        db.delete(existing)
        db.commit()
        is_closed = False
    else:
        db.add(models.ClosedDay(period_id=period_id, closed_date=closed_date))
        _clear_assignments_for_period_day(db, period_id, closed_date)
        db.commit()
        is_closed = True

    force_readonly = bool(getattr(period_row, "schedule_protect_enabled", False))
    return templates.TemplateResponse(
        "partials/day_header_cell.html",
        {
            "request": request,
            "day": closed_date,
            "period_id": period_id,
            "is_closed": is_closed,
            "is_admin": is_admin,
            "force_readonly": force_readonly,
        },
    )


@router.post("/bulk_weekends/{period_id}", response_class=HTMLResponse)
def bulk_weekends_closed(
    request: Request,
    period_id: int,
    db: Session = Depends(get_db),
    current_tid: int = Depends(get_current_team_id),
):
    """期間内の土曜・日曜を休業日に一括登録（既に登録済みの日はスキップ）。"""
    is_admin = _is_admin_user(request)
    if not is_admin:
        raise HTTPException(status_code=403, detail="この操作の権限がありません")
    period = _period_for_team(db, period_id, current_tid)

    existing_dates: set[date_type] = set()
    for r in db.query(models.ClosedDay).filter(
        models.ClosedDay.period_id == period_id,
    ).all():
        cd = to_calendar_date(r.closed_date)
        if cd:
            existing_dates.add(cd)

    d = period.start_date
    while d <= period.end_date:
        if d.weekday() >= 5:
            if d not in existing_dates:
                db.add(models.ClosedDay(period_id=period_id, closed_date=d))
                _clear_assignments_for_period_day(db, period_id, d)
                existing_dates.add(d)
        d += timedelta(days=1)

    db.commit()

    from schedule_context import build_schedule_context

    ctx = build_schedule_context(db, period_id, team_id=current_tid, request=request)
    ctx["request"] = request
    ctx["current_team_id"] = current_tid
    ctx["is_admin"] = is_admin
    return templates.TemplateResponse("partials/schedule_grid.html", ctx)
