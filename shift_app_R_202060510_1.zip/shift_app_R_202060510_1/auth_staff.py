"""ログインユーザと SH_STAFF の対応（本人行の編集可否に使用）。"""
from __future__ import annotations

from datetime import date
from typing import Optional

from fastapi import Request
from sqlalchemy.orm import Session

import models


def is_leave_admin_role(request: Request | None) -> bool:
    """休暇/予定のチーム単位運用権限（admin / manager）。一般 staff は本人分のみ閲覧等。"""
    if request is None:
        return False
    auth = request.session.get("auth_user")
    if not isinstance(auth, dict):
        return False
    role = str(auth.get("role", "")).strip().lower()
    return role in ("admin", "manager")


def resolve_own_staff_id(request: Request, db: Session, team_id: int) -> Optional[int]:
    """チーム内でセッション・ユーザーに対応する有効スタッフの id。見つからなければ None。"""
    auth = request.session.get("auth_user") if request else None
    if not isinstance(auth, dict):
        return None
    uid = str(auth.get("user_id") or "").strip()
    uname = str(auth.get("user_name") or "").strip()
    base_q = db.query(models.Staff).filter(
        models.Staff.team_id == team_id,
        models.Staff.is_active == True,
    )
    if uid:
        row = base_q.filter(models.Staff.login_userid == uid).first()
        if row:
            return row.id
    if uname:
        row = base_q.filter(models.Staff.name == uname).first()
        if row:
            return row.id
    return None


def _schedule_period_for_cell(
    db: Session,
    team_id: int,
    work_date: Optional[date],
    assignment: Optional[models.ShiftAssignment],
) -> Optional[models.SchedulePeriod]:
    """セルが属する期間（assignment 優先、なければ日付で期間を解決）。"""
    if assignment is not None and assignment.period_id is not None:
        return (
            db.query(models.SchedulePeriod)
            .filter(
                models.SchedulePeriod.id == assignment.period_id,
                models.SchedulePeriod.team_id == team_id,
            )
            .first()
        )
    if work_date is None:
        return None
    return (
        db.query(models.SchedulePeriod)
        .filter(
            models.SchedulePeriod.team_id == team_id,
            models.SchedulePeriod.start_date <= work_date,
            models.SchedulePeriod.end_date >= work_date,
        )
        .first()
    )


def period_schedule_protect_enabled(
    db: Session,
    team_id: int,
    work_date: Optional[date] = None,
    assignment: Optional[models.ShiftAssignment] = None,
) -> bool:
    """当該セルの期間でプロテクトが ON か（DB の schedule_protect_enabled）。"""
    p = _schedule_period_for_cell(db, team_id, work_date, assignment)
    if not p:
        return False
    return bool(getattr(p, "schedule_protect_enabled", False))


def can_edit_staff_shift_cell(
    request: Request,
    db: Session,
    staff_row: models.Staff,
    *,
    work_date: Optional[date] = None,
    assignment: Optional[models.ShiftAssignment] = None,
) -> bool:
    """シフトセルの手動編集（トグル／ロック）が許可されるか。"""
    if period_schedule_protect_enabled(db, staff_row.team_id, work_date, assignment):
        return False
    team_id = staff_row.team_id
    own_id = resolve_own_staff_id(request, db, team_id)
    is_own = own_id is not None and own_id == staff_row.id
    auth = request.session.get("auth_user") or {}
    role = str(auth.get("role", "")).strip().lower()
    if role in ("admin", "manager"):
        return True
    return is_own
