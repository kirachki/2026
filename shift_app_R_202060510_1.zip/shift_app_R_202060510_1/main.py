from fastapi import FastAPI, Request, Depends, Query
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.middleware.sessions import SessionMiddleware
from starlette.responses import Response
from sqlalchemy.orm import Session

from database import engine, get_db, Base
from app_config import get_security_setting, get_setting
import models
from deps import resolve_team_id
from routers import (
    staff,
    assignments,
    periods,
    optimizer_router,
    shift_types,
    leave_requests,
    leave_half_rules,
    shift_eligibility,
    staff_shift_pairs,
    staff_shift_companions,
    closed_days,
    shift_demand,
    policy_constraints,
    auth,
)
from schedule_context import build_schedule_context

# テーブル作成
Base.metadata.create_all(bind=engine)

app = FastAPI(title="ShiftOptima", version="1.0.0")
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

CRM_SSO_ENTRY_URL = get_setting("sso", "crm_shift_link_url", "http://localhost:8000/shift-app-link")
_PUBLIC_PATH_PREFIXES = ("/auth/sso", "/auth/error", "/static", "/favicon.ico")


class RequireSSOSessionMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next) -> Response:
        path = request.url.path
        if path.startswith(_PUBLIC_PATH_PREFIXES):
            return await call_next(request)
        if not request.session.get("auth_user"):
            return RedirectResponse(url=CRM_SSO_ENTRY_URL, status_code=303)
        return await call_next(request)


app.add_middleware(RequireSSOSessionMiddleware)
app.add_middleware(
    SessionMiddleware,
    secret_key=get_security_setting("shift_app_session_secret", "dev-session-secret-change-me"),
    same_site="lax",
    https_only=False,
)

# ルーター登録
app.include_router(staff.router, prefix="/staff")
app.include_router(assignments.router, prefix="/assignments")
app.include_router(periods.router, prefix="/periods")
app.include_router(optimizer_router.router, prefix="/optimize")
app.include_router(shift_types.router, prefix="/shift_types")
app.include_router(leave_requests.router, prefix="/leave_requests")
app.include_router(leave_half_rules.router, prefix="/leave_half_rules")
app.include_router(shift_eligibility.router, prefix="/shift_eligibility")
app.include_router(staff_shift_pairs.router, prefix="/staff_shift_pairs")
app.include_router(staff_shift_companions.router, prefix="/staff_shift_companions")
app.include_router(closed_days.router, prefix="/closed_days")
app.include_router(shift_demand.router, prefix="/shift_demand")
app.include_router(policy_constraints.router, prefix="/policy_constraints")
app.include_router(auth.router, prefix="/auth")


def _teams_context(db: Session):
    return (
        db.query(models.Team)
        .filter(models.Team.is_active == True)
        .order_by(models.Team.name.asc())
        .all()
    )


def _resolve_period_id(request: Request, db: Session, team_id: int, period_id: int | None) -> int | None:
    """明示指定がなければ Cookie の期間IDを使う（同一チームに属する場合のみ）。"""
    if period_id is not None:
        return period_id
    raw = (request.cookies.get("shift_period_id") or "").strip()
    if not raw.isdigit():
        return None
    pid = int(raw)
    exists = (
        db.query(models.SchedulePeriod.id)
        .filter(
            models.SchedulePeriod.id == pid,
            models.SchedulePeriod.team_id == team_id,
        )
        .first()
    )
    return pid if exists else None


def _set_schedule_cookies(resp: HTMLResponse, team_id: int, period_id: int | None) -> None:
    resp.set_cookie(
        "shift_team_id",
        str(team_id),
        max_age=31536000,
        path="/",
        httponly=False,
        samesite="lax",
    )
    if period_id is not None:
        resp.set_cookie(
            "shift_period_id",
            str(period_id),
            max_age=31536000,
            path="/",
            httponly=False,
            samesite="lax",
        )


@app.get("/", response_class=HTMLResponse)
def index(
    request: Request,
    period_id: int | None = None,
    team_id: int | None = Query(default=None),
    db: Session = Depends(get_db),
):
    auth_user = request.session.get("auth_user", {})
    is_admin = str(auth_user.get("role", "")).lower() in ("admin", "manager")

    # データがなければシードを投入
    if not db.query(models.Staff).first():
        from init_db import seed_data

        seed_data(db)

    tid = resolve_team_id(request, db, team_id)
    selected_period_id = _resolve_period_id(request, db, tid, period_id)
    ctx = build_schedule_context(db, selected_period_id, team_id=tid, request=request)
    ctx["request"] = request
    ctx["all_teams"] = _teams_context(db)
    ctx["current_team_id"] = tid
    ctx["user"] = auth_user
    ctx["is_admin"] = is_admin
    ctx["current_user_name"] = str(auth_user.get("user_name", "")).strip()
    resp = templates.TemplateResponse("schedule.html", ctx)
    current_period = ctx.get("current_period")
    _set_schedule_cookies(resp, tid, current_period.id if current_period else None)
    return resp


@app.get("/schedule/grid", response_class=HTMLResponse)
def schedule_grid(
    request: Request,
    period_id: int | None = None,
    team_id: int | None = Query(default=None),
    db: Session = Depends(get_db),
):
    """週ナビゲーション用: グリッド部分だけ返す。"""
    auth_user = request.session.get("auth_user", {})
    is_admin = str(auth_user.get("role", "")).lower() in ("admin", "manager")
    tid = resolve_team_id(request, db, team_id)
    selected_period_id = _resolve_period_id(request, db, tid, period_id)
    ctx = build_schedule_context(db, selected_period_id, team_id=tid, request=request)
    ctx["request"] = request
    ctx["all_teams"] = _teams_context(db)
    ctx["current_team_id"] = tid
    ctx["user"] = auth_user
    ctx["is_admin"] = is_admin
    ctx["current_user_name"] = str(auth_user.get("user_name", "")).strip()
    resp = templates.TemplateResponse("partials/schedule_grid.html", ctx)
    current_period = ctx.get("current_period")
    _set_schedule_cookies(resp, tid, current_period.id if current_period else None)
    return resp
