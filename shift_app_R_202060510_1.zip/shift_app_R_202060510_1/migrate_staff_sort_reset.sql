-- 既存スタッフの sort_order を 3 桁仕様に揃える
-- 旧デフォルト 3000 で作成された行を、新しい既定値 500 に置換する
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;

UPDATE SH_STAFF SET sort_order = 500 WHERE sort_order = 3000;

-- 念のため、3 桁を超える残り値（300 や任意の入力）を 999 にクリップ
UPDATE SH_STAFF SET sort_order = 999 WHERE sort_order > 999;
