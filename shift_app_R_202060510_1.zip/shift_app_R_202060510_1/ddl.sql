-- ============================================================
-- シフト管理アプリ DDL
-- データベース: MySQL 8.0+
-- チーム（業務単位）が最上位。名称は SH_TEAMS（アプリ内では SH_TeamS と表記することも可）
-- ============================================================
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;

-- ──────────────────────────────────────────
-- 既存テーブルがあれば削除してから再作成する
-- ──────────────────────────────────────────
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS SH_SHIFT_ASSIGNMENTS;
DROP TABLE IF EXISTS SH_LEAVE_REQUESTS;
DROP TABLE IF EXISTS SH_STAFF_SHIFT_ELIGIBILITY;
DROP TABLE IF EXISTS SH_STAFF_SHIFT_PAIR_FORBIDDEN;
DROP TABLE IF EXISTS SH_CONSTRAINTS;
DROP TABLE IF EXISTS SH_CLOSED_DAYS;
DROP TABLE IF EXISTS SH_PERIOD_SHIFT_DATE_DEMAND;
DROP TABLE IF EXISTS SH_PERIOD_SHIFT_WEEKDAY_DEMAND;
DROP TABLE IF EXISTS SH_SCHEDULE_PERIODS;
DROP TABLE IF EXISTS SH_STAFF;
DROP TABLE IF EXISTS SH_SHIFT_TYPES;
DROP TABLE IF EXISTS SH_WORK_PTN;
DROP TABLE IF EXISTS SH_TEAMS;
SET FOREIGN_KEY_CHECKS = 1;


-- ──────────────────────────────────────────
-- 0. SH_TEAMS（チームマスタ・最上位）
-- ──────────────────────────────────────────
CREATE TABLE SH_TEAMS (
    id          INT             NOT NULL AUTO_INCREMENT,
    name        VARCHAR(100)    NOT NULL                    COMMENT 'チーム表示名',
    code        VARCHAR(50)         NULL                    COMMENT '任意のコード（連携用）',
    is_active   TINYINT(1)      NOT NULL DEFAULT 1          COMMENT '有効フラグ',
    created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP
                                         ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    UNIQUE KEY uq_sh_teams_name (name),
    INDEX idx_sh_teams_is_active (is_active)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='チームマスタ（業務単位・テナント相当）';


-- ──────────────────────────────────────────
-- 0b. SH_WORK_PTN（勤務時間パターンマスタ・チーム非依存）
-- ──────────────────────────────────────────
CREATE TABLE SH_WORK_PTN (
    id          INT             NOT NULL AUTO_INCREMENT,
    label       VARCHAR(32)     NOT NULL                    COMMENT '表示（例 08:50-17:30）',
    sort_order  INT             NOT NULL DEFAULT 0          COMMENT '一覧・ドロップダウン順',
    created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    UNIQUE KEY uq_sh_work_ptn_label (label),
    INDEX idx_sh_work_ptn_sort (sort_order)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='勤務時間パターンマスタ';

INSERT INTO SH_WORK_PTN (label, sort_order) VALUES
    ('08:50-17:30', 1),
    ('08:50-16:00', 2),
    ('21:00-09:00', 3),
    ('07:50-16:00', 4);


-- ──────────────────────────────────────────
-- 1. SH_STAFF（スタッフマスタ）
-- ──────────────────────────────────────────
CREATE TABLE SH_STAFF (
    id              INT             NOT NULL AUTO_INCREMENT,
    team_id         INT             NOT NULL                    COMMENT 'チームID（FK）',
    name            VARCHAR(100)    NOT NULL                    COMMENT 'スタッフ氏名',
    login_userid    VARCHAR(50)     NULL                        COMMENT 'ログインID（t1_loginuser.userid と対応）',
    role            VARCHAR(50)     NOT NULL                    COMMENT '役割（例: リーダー, 一般スタッフ）',
    employment_type ENUM(
                        'full_time',
                        'part_time',
                        'haken'
                    )               NOT NULL DEFAULT 'full_time' COMMENT '雇用形態',
    work_ptn_id     INT             NULL                        COMMENT '勤務時間パターン（SH_WORK_PTN）',
    team_label      VARCHAR(6)      NULL                        COMMENT 'チーム短縮ラベル（全角6文字想定）',
    sort_order      INT             NOT NULL DEFAULT 500        COMMENT '一覧での表示順（小さいほど上）',
    is_active       TINYINT(1)      NOT NULL DEFAULT 1          COMMENT '有効フラグ（0=退職済み）',
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP
                                             ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    INDEX idx_sh_staff_team       (team_id),
    INDEX idx_staff_team_login_userid (team_id, login_userid),
    INDEX idx_sh_staff_is_active (is_active),
    INDEX idx_sh_staff_work_ptn (work_ptn_id),
    INDEX idx_sh_staff_sort_order (team_id, sort_order),
    CONSTRAINT fk_sh_staff_team
        FOREIGN KEY (team_id)
        REFERENCES SH_TEAMS (id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,
    CONSTRAINT fk_sh_staff_work_ptn
        FOREIGN KEY (work_ptn_id)
        REFERENCES SH_WORK_PTN (id)
        ON DELETE SET NULL
        ON UPDATE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='スタッフマスタ';


-- ──────────────────────────────────────────
-- 1b. SH_STAFF_SHIFT_PAIR_FORBIDDEN（同シフト同時配置ペア禁止）
-- ──────────────────────────────────────────
CREATE TABLE SH_STAFF_SHIFT_PAIR_FORBIDDEN (
    id              INT             NOT NULL AUTO_INCREMENT,
    team_id         INT             NOT NULL                    COMMENT 'チームID（FK）',
    staff_id_low    INT             NOT NULL                    COMMENT 'スタッフID（必ず staff_id_high より小さい値）',
    staff_id_high   INT             NOT NULL                    COMMENT 'スタッフID',
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    UNIQUE KEY uq_staff_shift_pair_forbidden (team_id, staff_id_low, staff_id_high),
    INDEX idx_staff_shift_pair_team (team_id),
    CONSTRAINT chk_staff_shift_pair_order CHECK (staff_id_low < staff_id_high),
    CONSTRAINT fk_staff_shift_pair_team
        FOREIGN KEY (team_id)
        REFERENCES SH_TEAMS (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT fk_staff_shift_pair_low
        FOREIGN KEY (staff_id_low)
        REFERENCES SH_STAFF (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT fk_staff_shift_pair_high
        FOREIGN KEY (staff_id_high)
        REFERENCES SH_STAFF (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='同一日同一シフト種別で同席させないスタッフペア';


-- ──────────────────────────────────────────
-- 2. SH_SHIFT_TYPES（タスク種別マスタ）
-- ──────────────────────────────────────────
CREATE TABLE SH_SHIFT_TYPES (
    id          INT             NOT NULL AUTO_INCREMENT,
    team_id     INT             NOT NULL                    COMMENT 'チームID（FK）',
    name        VARCHAR(50)     NOT NULL                    COMMENT 'シフト名（例: 早番, 遅番, 夜勤）',
    start_time  TIME            NOT NULL                    COMMENT '開始時刻',
    end_time    TIME            NOT NULL                    COMMENT '終了時刻',
    min_staff   INT             NOT NULL DEFAULT 1          COMMENT '人数（min_staff_mode に応じて「ちょうど」または「以上」）',
    min_staff_mode VARCHAR(20)  NOT NULL DEFAULT 'at_least'  COMMENT 'at_least=指定人数以上 / exact=指定人数ちょうど',
    color_code  VARCHAR(7)      NOT NULL DEFAULT '#888888'  COMMENT 'UI表示用カラーコード（例: #60a5fa）',
    created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP
                                         ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    INDEX idx_sh_shift_types_team (team_id),
    CONSTRAINT fk_sh_shift_types_team
        FOREIGN KEY (team_id)
        REFERENCES SH_TEAMS (id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,
    CONSTRAINT chk_sh_shift_types_min_staff CHECK (min_staff >= 1),
    CONSTRAINT chk_sh_shift_types_color     CHECK (color_code REGEXP '^#[0-9A-Fa-f]{6}$')
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='タスク種別マスタ';


-- ──────────────────────────────────────────
-- 3. SH_SCHEDULE_PERIODS（スケジュール期間）
-- ──────────────────────────────────────────
CREATE TABLE SH_SCHEDULE_PERIODS (
    id          INT             NOT NULL AUTO_INCREMENT,
    team_id     INT             NOT NULL                    COMMENT 'チームID（FK）',
    start_date  DATE            NOT NULL                    COMMENT '期間開始日',
    end_date    DATE            NOT NULL                    COMMENT '期間終了日',
    label       VARCHAR(100)    NOT NULL                    COMMENT '表示ラベル（例: 2025年7月 第1週）',
    status      ENUM(
                    'draft',
                    'optimized',
                    'published'
                )               NOT NULL DEFAULT 'draft'   COMMENT 'ステータス',
    schedule_protect_enabled TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'プロテクト（閲覧専用・DB永続）',
    created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP
                                         ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    INDEX idx_sh_schedule_periods_team       (team_id),
    CONSTRAINT chk_sh_schedule_periods_dates CHECK (end_date >= start_date),
    INDEX idx_sh_schedule_periods_status     (status),
    INDEX idx_sh_schedule_periods_start_date (start_date),
    CONSTRAINT fk_sh_schedule_periods_team
        FOREIGN KEY (team_id)
        REFERENCES SH_TEAMS (id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='スケジュール期間';


-- ──────────────────────────────────────────
-- 3b. SH_CLOSED_DAYS（期間内の休業日・全員シフトなし）
-- ──────────────────────────────────────────
CREATE TABLE SH_CLOSED_DAYS (
    id           INT         NOT NULL AUTO_INCREMENT,
    period_id    INT         NOT NULL                    COMMENT 'スケジュール期間ID（FK）',
    closed_date  DATE        NOT NULL                    COMMENT '休業日（カレンダー日）',
    created_at   DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    UNIQUE KEY uq_closed_day_period_date (period_id, closed_date),
    INDEX idx_sh_closed_days_period (period_id),
    INDEX idx_sh_closed_days_date   (closed_date),
    CONSTRAINT fk_sh_closed_days_period
        FOREIGN KEY (period_id)
        REFERENCES SH_SCHEDULE_PERIODS (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='期間ごとの休業日（最適化で全員配置禁止・最低人数免除）';


-- ──────────────────────────────────────────
-- 3c–3d. 期間×シフト種別の需要（曜日既定・特定日上書き）
-- ──────────────────────────────────────────
CREATE TABLE SH_PERIOD_SHIFT_WEEKDAY_DEMAND (
    id              INT             NOT NULL AUTO_INCREMENT,
    period_id       INT             NOT NULL                    COMMENT 'スケジュール期間ID',
    shift_type_id   INT             NOT NULL                    COMMENT 'シフト種別ID',
    weekday         TINYINT         NOT NULL                    COMMENT '0=月 … 6=日',
    min_staff       INT             NOT NULL DEFAULT 1          COMMENT 'その曜日の最低人数',
    is_feasible     TINYINT(1)      NOT NULL DEFAULT 1          COMMENT '1=その曜は種別を稼働（配置可）、0=不可（配置禁止）',
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    UNIQUE KEY uq_period_shift_weekday (period_id, shift_type_id, weekday),
    INDEX idx_ps_weekday_period (period_id),
    CONSTRAINT chk_ps_weekday_wd CHECK (weekday BETWEEN 0 AND 6),
    CONSTRAINT chk_ps_weekday_min CHECK (min_staff BETWEEN 0 AND 99),
    CONSTRAINT fk_ps_weekday_period
        FOREIGN KEY (period_id)
        REFERENCES SH_SCHEDULE_PERIODS (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT fk_ps_weekday_shift_type
        FOREIGN KEY (shift_type_id)
        REFERENCES SH_SHIFT_TYPES (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='期間内：曜日ごとの種別別最低人数・稼働可否';

CREATE TABLE SH_PERIOD_SHIFT_DATE_DEMAND (
    id              INT             NOT NULL AUTO_INCREMENT,
    period_id       INT             NOT NULL                    COMMENT 'スケジュール期間ID',
    shift_type_id   INT             NOT NULL                    COMMENT 'シフト種別ID',
    demand_date     DATE            NOT NULL                    COMMENT '対象日（その期間内）',
    min_staff       INT             NOT NULL DEFAULT 1          COMMENT 'その日の最低人数',
    is_feasible     TINYINT(1)      NOT NULL DEFAULT 1          COMMENT '1=稼働可、0=種別をその日は禁止',
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    UNIQUE KEY uq_period_shift_date (period_id, shift_type_id, demand_date),
    INDEX idx_ps_date_period (period_id),
    CONSTRAINT chk_ps_date_min CHECK (min_staff BETWEEN 0 AND 99),
    CONSTRAINT fk_ps_date_period
        FOREIGN KEY (period_id)
        REFERENCES SH_SCHEDULE_PERIODS (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT fk_ps_date_shift_type
        FOREIGN KEY (shift_type_id)
        REFERENCES SH_SHIFT_TYPES (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='期間内：特定日の種別別最低人数・稼働可否（曜日既定より優先）';


-- ──────────────────────────────────────────
-- 4. SH_CONSTRAINTS（制約設定）
-- ──────────────────────────────────────────
CREATE TABLE SH_CONSTRAINTS (
    id                      INT         NOT NULL AUTO_INCREMENT,
    team_id                 INT         NOT NULL                COMMENT 'チームID（FK）※ period と整合',
    period_id               INT         NOT NULL                COMMENT 'スケジュール期間ID（FK）',
    max_consecutive_days    INT         NOT NULL DEFAULT 5      COMMENT '最大連続勤務日数',
    max_days_per_week       INT         NOT NULL DEFAULT 6      COMMENT '週最大勤務日数',
    min_days_off_per_week   INT         NOT NULL DEFAULT 1      COMMENT '週最小休日数',
    max_nights_per_week     INT         NOT NULL DEFAULT 2      COMMENT '週最大夜勤回数（ISO週、夜勤＝開始時刻順で最後の種別）',
    no_early_after_night    TINYINT(1)  NOT NULL DEFAULT 1      COMMENT '夜勤翌日の早番禁止フラグ',
    equalize_workload       TINYINT(1)  NOT NULL DEFAULT 1      COMMENT '勤務日数均等化フラグ',
    enable_max_consecutive_days TINYINT(1) NOT NULL DEFAULT 1 COMMENT '最大連続勤務日数を適用',
    enable_max_days_per_week   TINYINT(1) NOT NULL DEFAULT 1 COMMENT '週最大勤務日数を適用',
    enable_min_days_off_per_week TINYINT(1) NOT NULL DEFAULT 1 COMMENT '週最小休日由来の上限を適用',
    enable_max_nights_per_week TINYINT(1) NOT NULL DEFAULT 1 COMMENT '週夜勤回数上限を適用',
    enable_no_consecutive_nights TINYINT(1) NOT NULL DEFAULT 1 COMMENT '連続夜勤禁止を適用',
    enable_min_rest_day_night TINYINT(1) NOT NULL DEFAULT 1 COMMENT '日勤↔夜勤の最短休憩を適用',
    created_at              DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at              DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP
                                                 ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    UNIQUE  KEY uq_sh_constraints_period   (period_id),
    INDEX idx_sh_constraints_team (team_id),
    CONSTRAINT fk_sh_constraints_team
        FOREIGN KEY (team_id)
        REFERENCES SH_TEAMS (id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,
    CONSTRAINT fk_sh_constraints_period
        FOREIGN KEY (period_id)
        REFERENCES SH_SCHEDULE_PERIODS (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT chk_sh_constraints_max_consec  CHECK (max_consecutive_days BETWEEN 1 AND 7),
    CONSTRAINT chk_sh_constraints_max_week    CHECK (max_days_per_week    BETWEEN 1 AND 7),
    CONSTRAINT chk_sh_constraints_min_off     CHECK (min_days_off_per_week >= 1),
    CONSTRAINT chk_sh_constraints_max_nights CHECK (max_nights_per_week BETWEEN 0 AND 7)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='制約設定（スケジュール期間ごと）';


-- ──────────────────────────────────────────
-- 5. SH_LEAVE_REQUESTS（休み希望）
-- ──────────────────────────────────────────
CREATE TABLE SH_LEAVE_REQUESTS (
    id              INT             NOT NULL AUTO_INCREMENT,
    team_id         INT             NOT NULL                    COMMENT 'チームID（FK）※ staff と整合',
    staff_id        INT             NOT NULL                    COMMENT 'スタッフID（FK）',
    request_date    DATE            NOT NULL                    COMMENT '希望休日',
    leave_kind      VARCHAR(20)     NOT NULL DEFAULT 'full_day' COMMENT 'full_day|morning_half|afternoon_half|custom',
    custom_start_time VARCHAR(8)          NULL                    COMMENT '時間指定休の開始 HH:MM:SS',
    custom_end_time   VARCHAR(8)          NULL                    COMMENT '時間指定休の終了 HH:MM:SS',
    reason          VARCHAR(255)        NULL                    COMMENT '申請理由',
    status          ENUM(
                        'pending',
                        'approved',
                        'rejected'
                    )               NOT NULL DEFAULT 'pending'  COMMENT '承認ステータス',
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP
                                         ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    UNIQUE  KEY uq_sh_leave_requests_staff_date (staff_id, request_date),
    INDEX idx_sh_leave_requests_team          (team_id),
    CONSTRAINT fk_sh_leave_requests_team
        FOREIGN KEY (team_id)
        REFERENCES SH_TEAMS (id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,
    CONSTRAINT fk_sh_leave_requests_staff
        FOREIGN KEY (staff_id)
        REFERENCES SH_STAFF (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    INDEX idx_sh_leave_requests_status       (status),
    INDEX idx_sh_leave_requests_request_date (request_date)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='休み希望申請';


-- ──────────────────────────────────────────
-- 5b. SH_LEAVE_HALF_DAY_RULES（半休の曜日別時間窓）
-- ──────────────────────────────────────────
CREATE TABLE SH_LEAVE_HALF_DAY_RULES (
    id              INT             NOT NULL AUTO_INCREMENT,
    team_id         INT             NOT NULL                    COMMENT 'チームID（FK）',
    weekday         TINYINT         NOT NULL                    COMMENT '0=月 … 6=日',
    kind            VARCHAR(20)     NOT NULL                    COMMENT 'morning_half | afternoon_half',
    start_time      VARCHAR(8)      NOT NULL,
    end_time        VARCHAR(8)      NOT NULL,
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP
                                         ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_leave_half_rule_team_day_kind (team_id, weekday, kind),
    CONSTRAINT fk_leave_half_rules_team
        FOREIGN KEY (team_id)
        REFERENCES SH_TEAMS (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='半休の曜日別時間窓（オプティマイザがシフトとの重なりで禁止）';


-- ──────────────────────────────────────────
-- 5c. SH_STAFF_SHIFT_ELIGIBILITY（タスク種別×スタッフ資格・ホワイトリスト）
-- ──────────────────────────────────────────
CREATE TABLE SH_STAFF_SHIFT_ELIGIBILITY (
    id              INT             NOT NULL AUTO_INCREMENT,
    staff_id        INT             NOT NULL                    COMMENT 'スタッフID（FK）',
    shift_type_id   INT             NOT NULL                    COMMENT 'タスク種別ID（FK）',
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    UNIQUE  KEY uq_staff_shift_eligibility (staff_id, shift_type_id),
    INDEX idx_staff_shift_eligibility_shift (shift_type_id),
    INDEX idx_staff_shift_eligibility_staff (staff_id),
    CONSTRAINT fk_staff_shift_eligibility_staff
        FOREIGN KEY (staff_id)
        REFERENCES SH_STAFF (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT fk_staff_shift_eligibility_shift_type
        FOREIGN KEY (shift_type_id)
        REFERENCES SH_SHIFT_TYPES (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='タスク種別ごとの担当資格（ホワイトリスト・未登録種別は全員可）';


-- ──────────────────────────────────────────
-- 6. SH_SHIFT_ASSIGNMENTS（シフト割り当て）
-- ──────────────────────────────────────────
CREATE TABLE SH_SHIFT_ASSIGNMENTS (
    id              INT             NOT NULL AUTO_INCREMENT,
    team_id         INT             NOT NULL                    COMMENT 'チームID（FK）※ period/staff と整合',
    staff_id        INT             NOT NULL                    COMMENT 'スタッフID（FK）',
    period_id       INT             NOT NULL                    COMMENT 'スケジュール期間ID（FK）',
    shift_type_id   INT                 NULL                    COMMENT 'タスク種別ID（FK・手動「休」確定時は NULL + is_locked）',
    work_date       DATE            NOT NULL                    COMMENT '勤務日',
    is_locked       TINYINT(1)      NOT NULL DEFAULT 0          COMMENT 'ロックフラグ（1=手動確定済み）',
    guard_x         TINYINT(1)      NOT NULL DEFAULT 0          COMMENT '1=✖（shift_type NULL時のみ・勤務回避の意思）',
    source          ENUM(
                        'solver',
                        'manual'
                    )               NOT NULL DEFAULT 'solver'   COMMENT '登録元（solver=自動, manual=手動）',
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP
                                         ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    UNIQUE  KEY uq_sh_shift_assignments_staff_date (staff_id, work_date),
    INDEX idx_sh_shift_assignments_team        (team_id),
    CONSTRAINT fk_sh_shift_assignments_team
        FOREIGN KEY (team_id)
        REFERENCES SH_TEAMS (id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,
    CONSTRAINT fk_sh_shift_assignments_staff
        FOREIGN KEY (staff_id)
        REFERENCES SH_STAFF (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT fk_sh_shift_assignments_period
        FOREIGN KEY (period_id)
        REFERENCES SH_SCHEDULE_PERIODS (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT fk_sh_shift_assignments_shift_type
        FOREIGN KEY (shift_type_id)
        REFERENCES SH_SHIFT_TYPES (id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,
    INDEX idx_sh_shift_assignments_period    (period_id),
    INDEX idx_sh_shift_assignments_work_date (work_date),
    INDEX idx_sh_shift_assignments_is_locked (is_locked)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='シフト割り当て結果';
