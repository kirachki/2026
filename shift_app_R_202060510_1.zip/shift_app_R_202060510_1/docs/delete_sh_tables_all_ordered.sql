-- ============================================================
-- SH_* テーブル全件削除（外部キー依存の逆順・子→親）
-- MySQL 8.0+ / InnoDB
--
-- 前提: FOREIGN_KEY_CHECKS=1 のまま実行できる並び。
-- 同伴ルール系テーブルは migrate_staff_shift_companion_rule.sql 適用済みであること。
-- ============================================================

SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;

-- ── 第1層: 期間・種別にぶら下がる明細（休業・需要） ─────────────
DELETE FROM SH_CLOSED_DAYS;
DELETE FROM SH_PERIOD_SHIFT_WEEKDAY_DEMAND;
DELETE FROM SH_PERIOD_SHIFT_DATE_DEMAND;

-- ── 第2層: 期間×チームの制約（SH_SCHEDULE_PERIODS / SH_TEAMS より先） ──
DELETE FROM SH_CONSTRAINTS;

-- ── 第3層: 割当（複数親参照・shift_type_id は NULL 可だが FK あり） ──
DELETE FROM SH_SHIFT_ASSIGNMENTS;

-- ── 第4層: チーム・スタッフ参照のトランザクション系 ───────────────
DELETE FROM SH_LEAVE_REQUESTS;
DELETE FROM SH_STAFF_SHIFT_PAIR_FORBIDDEN;
DELETE FROM SH_STAFF_SHIFT_ELIGIBILITY;

-- ── 第5層: 同伴ルールの子 → 親 ──────────────────────────────────
DELETE FROM SH_STAFF_SHIFT_COMPANION_MEMBER;
DELETE FROM SH_STAFF_SHIFT_COMPANION_TARGET_SHIFT;
DELETE FROM SH_STAFF_SHIFT_COMPANION_RULE;

-- ── 第6層: チームのみ参照（他テーブルから参照されない） ───────────
DELETE FROM SH_LEAVE_HALF_DAY_RULES;

-- ── 第7層: SH_TEAMS に直接ぶら下がるマスタ（相互参照なしのため順序は任意だが統一） ──
DELETE FROM SH_SCHEDULE_PERIODS;
DELETE FROM SH_SHIFT_TYPES;
DELETE FROM SH_STAFF;

-- 勤務時間パターン（SH_STAFF が FK 参照するためスタッフ削除後）
DELETE FROM SH_WORK_PTN;

-- ── 最上位 ────────────────────────────────────────────────────
DELETE FROM SH_TEAMS;
