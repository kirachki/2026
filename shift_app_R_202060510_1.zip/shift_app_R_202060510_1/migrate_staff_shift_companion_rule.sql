-- 既存 DB に SH_STAFF_SHIFT_COMPANION_RULE / MEMBER を追加（何度実行しても安全）
CREATE TABLE IF NOT EXISTS SH_STAFF_SHIFT_COMPANION_RULE (
    id                  INT         NOT NULL AUTO_INCREMENT,
    team_id             INT         NOT NULL COMMENT 'チームID（FK）',
    primary_staff_id    INT         NOT NULL COMMENT '主スタッフID（このスタッフが勤務に入る場合は同伴者が必要）',
    created_at          DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    UNIQUE KEY uq_staff_shift_companion_rule_primary (team_id, primary_staff_id),
    INDEX idx_staff_shift_companion_rule_team (team_id),
    INDEX idx_staff_shift_companion_rule_primary (primary_staff_id),
    CONSTRAINT fk_staff_shift_companion_rule_team
        FOREIGN KEY (team_id)
        REFERENCES SH_TEAMS (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT fk_staff_shift_companion_rule_primary
        FOREIGN KEY (primary_staff_id)
        REFERENCES SH_STAFF (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='主スタッフに対する同伴必須ルール';

CREATE TABLE IF NOT EXISTS SH_STAFF_SHIFT_COMPANION_MEMBER (
    id                  INT         NOT NULL AUTO_INCREMENT,
    rule_id             INT         NOT NULL COMMENT 'SH_STAFF_SHIFT_COMPANION_RULE.id',
    companion_staff_id  INT         NOT NULL COMMENT '同伴者候補スタッフID',
    created_at          DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    UNIQUE KEY uq_staff_shift_companion_member (rule_id, companion_staff_id),
    INDEX idx_staff_shift_companion_member_rule (rule_id),
    INDEX idx_staff_shift_companion_member_staff (companion_staff_id),
    CONSTRAINT fk_staff_shift_companion_member_rule
        FOREIGN KEY (rule_id)
        REFERENCES SH_STAFF_SHIFT_COMPANION_RULE (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT fk_staff_shift_companion_member_staff
        FOREIGN KEY (companion_staff_id)
        REFERENCES SH_STAFF (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='同伴必須ルールの同伴者候補';

CREATE TABLE IF NOT EXISTS SH_STAFF_SHIFT_COMPANION_TARGET_SHIFT (
    id              INT         NOT NULL AUTO_INCREMENT,
    rule_id         INT         NOT NULL COMMENT 'SH_STAFF_SHIFT_COMPANION_RULE.id',
    shift_type_id   INT         NOT NULL COMMENT '対象タスク種別ID（行が0件なら全タスク適用）',
    created_at      DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    UNIQUE KEY uq_staff_shift_companion_target_shift (rule_id, shift_type_id),
    INDEX idx_staff_shift_companion_target_rule (rule_id),
    INDEX idx_staff_shift_companion_target_shift (shift_type_id),
    CONSTRAINT fk_staff_shift_companion_target_rule
        FOREIGN KEY (rule_id)
        REFERENCES SH_STAFF_SHIFT_COMPANION_RULE (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT fk_staff_shift_companion_target_shift
        FOREIGN KEY (shift_type_id)
        REFERENCES SH_SHIFT_TYPES (id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='同伴必須ルールの対象タスク種別';
