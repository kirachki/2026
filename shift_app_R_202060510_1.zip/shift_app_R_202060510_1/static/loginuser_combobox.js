/**
 * t1_loginuser 候補（/staff/loginuser-suggest）共用:
 * - サイドバー「スタッフを追加」: hidden userid + 表示は氏名
 * - 休暇登録の詳細検索「スタッフ名」: hidden staff_q（氏名で LIKE）+ 表示は氏名
 */
(function () {
  'use strict';

  function clearSuggestions(combobox) {
    var el = combobox.querySelector('.staff-loginuser-suggestions');
    if (el) el.innerHTML = '';
  }

  document.body.addEventListener('click', function (ev) {
    var btn = ev.target.closest('.staff-suggest-item');
    if (!btn) return;
    var combobox = btn.closest('.staff-name-combobox');
    if (!combobox) return;
    var disp = btn.getAttribute('data-user-name') || '';
    var uid = btn.getAttribute('data-userid') || '';

    var hidUid = combobox.querySelector('#staff-add-userid-hidden');
    var visAdd = combobox.querySelector('#staff-add-lookup-input');
    if (hidUid && visAdd) {
      visAdd.value = disp;
      hidUid.value = uid;
      clearSuggestions(combobox);
      return;
    }

    var hidQ = combobox.querySelector('.lr-staff-q-hidden');
    var visQ = combobox.querySelector('.lr-staff-q-lookup');
    if (hidQ && visQ) {
      visQ.value = disp;
      hidQ.value = disp;
      clearSuggestions(combobox);
    }
  });

  document.body.addEventListener('submit', function (ev) {
    var form = ev.target;
    if (!form || form.tagName !== 'FORM') return;

    if (form.classList.contains('lr-search-form')) {
      var hid = form.querySelector('.lr-staff-q-hidden');
      var vis = form.querySelector('.lr-staff-q-lookup');
      if (hid && vis) hid.value = vis.value.trim();
      return;
    }

    if (form.classList.contains('add-form') && form.classList.contains('sidebar-nested-form')) {
      var hidU = document.getElementById('staff-add-userid-hidden');
      var visU = document.getElementById('staff-add-lookup-input');
      if (!hidU || hidU.value || !visU) return;
      var v = (visU.value || '').trim();
      if (v && /^[\x20-\x7e]+$/.test(v)) hidU.value = v;
    }
  }, true);

  /** 「追加する」POST 成功後のみフォームをクリア（入力・検索中・サーバエラー時はクリアしない） */
  document.body.addEventListener('htmx:afterRequest', function (ev) {
    var form = ev.detail && ev.detail.elt;
    if (!form || form.tagName !== 'FORM') return;
    if (!form.classList.contains('add-form') || !form.classList.contains('sidebar-nested-form')) return;
    if (!ev.detail.successful) return;
    var xhr = ev.detail.xhr;
    if (!xhr || xhr.status < 200 || xhr.status >= 300) return;
    var body = xhr.responseText || '';
    if (/<p\s+class="staff-add-error"/.test(body)) return;
    form.reset();
    var box = form.querySelector('.staff-loginuser-suggestions');
    if (box) box.innerHTML = '';
  });
})();
