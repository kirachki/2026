/**
 * 休暇登録: 希望日の曜日と勤怠マスタに応じて custom_start_time / custom_end_time を自動セット。
 * DB weekday: 0=月 … 6=日（models.LeaveHalfDayRule）
 */
(function () {
  'use strict';

  var DEFAULT_FROM = '08:50';
  var DEFAULT_TO = '17:30';
  var K_MORNING = 'morning_half';
  var K_AFTERNOON = 'afternoon_half';
  var K_FULL = 'full_day';
  var K_CUSTOM = 'custom';

  function getHalfRules() {
    var el = document.getElementById('lr-half-rules-embedded');
    if (!el || !el.textContent) return {};
    try {
      return JSON.parse(el.textContent.trim());
    } catch (e) {
      return {};
    }
  }

  /** JS Date のローカル曜日 → DB weekday（月=0 … 日=6） */
  function jsDayToDbWeekday(d) {
    var gd = d.getDay();
    return gd === 0 ? 6 : gd - 1;
  }

  function parseYmdLocal(ymd) {
    var p = (ymd || '').trim().split('-');
    if (p.length !== 3) return null;
    var y = parseInt(p[0], 10);
    var m = parseInt(p[1], 10) - 1;
    var day = parseInt(p[2], 10);
    if (isNaN(y) || isNaN(m) || isNaN(day)) return null;
    return new Date(y, m, day);
  }

  function pairComplete(pair) {
    return pair && pair[0] && pair[1];
  }

  function applyKindDefaultReason(form) {
    var kindSelect = form.querySelector('select[name="leave_kind"]');
    var reasonInput = form.querySelector('input[name="reason"]');
    if (!kindSelect || !reasonInput) return;
    if (form.classList.contains('lr-edit-form')) return;
    var lk = kindSelect.value;
    if (lk === K_FULL) reasonInput.value = '全日休';
    else if (lk === K_MORNING) reasonInput.value = '午前休（曜日別時刻マスタ）';
    else if (lk === K_AFTERNOON) reasonInput.value = '午後休（曜日別時刻マスタ）';
  }

  function applyLeaveTimes(form) {
    if (!form) return;
    var dateInput = form.querySelector('input[name="request_date"]');
    var kindSelect = form.querySelector('select[name="leave_kind"]');
    var startInput = form.querySelector('input[name="custom_start_time"]');
    var endInput = form.querySelector('input[name="custom_end_time"]');
    if (!dateInput || !kindSelect || !startInput || !endInput) return;

    var dateVal = dateInput.value;
    if (!dateVal) return;

    var kind = kindSelect.value;
    if (kind === K_CUSTOM) return;

    var d = parseYmdLocal(dateVal);
    if (!d) return;

    var wd = jsDayToDbWeekday(d);
    var rules = getHalfRules();
    var dayRules = rules[String(wd)] || rules[wd] || {};
    var morning = dayRules[K_MORNING];
    var afternoon = dayRules[K_AFTERNOON];

    if (kind === K_MORNING) {
      if (pairComplete(morning)) {
        startInput.value = morning[0];
        endInput.value = morning[1];
      } else {
        startInput.value = DEFAULT_FROM;
        endInput.value = DEFAULT_TO;
      }
      return;
    }
    if (kind === K_AFTERNOON) {
      if (pairComplete(afternoon)) {
        startInput.value = afternoon[0];
        endInput.value = afternoon[1];
      } else {
        startInput.value = DEFAULT_FROM;
        endInput.value = DEFAULT_TO;
      }
      return;
    }
    if (kind === K_FULL) {
      var fromT = morning && morning[0] ? morning[0] : DEFAULT_FROM;
      var toT = afternoon && afternoon[1] ? afternoon[1] : DEFAULT_TO;
      startInput.value = fromT;
      endInput.value = toT;
    }
  }

  function onChange(ev) {
    var t = ev.target;
    if (!t || (t.name !== 'request_date' && t.name !== 'leave_kind')) return;
    var form = t.closest('form');
    if (!form) return;
    if (!form.classList.contains('lr-add-form') && !form.classList.contains('lr-edit-form')) return;
    var panel = document.getElementById('leave-request-panel');
    var quickModal = document.getElementById('quick-lock-modal');
    var inPanel = panel && panel.contains(form);
    var inQuick = quickModal && quickModal.contains(form);
    if (!inPanel && !inQuick) return;
    applyLeaveTimes(form);
    if (!form.classList.contains('lr-edit-form')) {
      applyKindDefaultReason(form);
    }
  }

  document.body.addEventListener('change', onChange);
})();

