-- SH_SCHEDULE_PERIODS にプロテクト状態（閲覧専用）を永続化する列を追加
ALTER TABLE SH_SCHEDULE_PERIODS
    ADD COLUMN schedule_protect_enabled TINYINT(1) NOT NULL DEFAULT 0
        COMMENT 'プロテクト（閲覧専用・DB永続）'
        AFTER status;
