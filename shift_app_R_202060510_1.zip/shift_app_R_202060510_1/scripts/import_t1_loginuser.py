"""Truncate t1_loginuser and import from user.csv (semicolon-separated)."""
from __future__ import annotations

import csv
import sys
from datetime import datetime
from pathlib import Path

from sqlalchemy import text

ROOT = Path(__file__).resolve().parent.parent
CSV_PATH = ROOT / "user.csv"
sys.path.insert(0, str(ROOT))

from database import engine  # noqa: E402


def _parse_dt(val: str):
    v = (val or "").strip().strip('"')
    if not v:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            return datetime.strptime(v, fmt)
        except ValueError:
            continue
    return None


def _parse_row(row: list[str]) -> tuple:
    userid, pwd, user_name, admin_opt, enabled, last_login, created_at, updated_at = row[:8]
    cr = _parse_dt(created_at)
    if cr is None:
        cr = datetime.now()
    return (
        userid.strip('"').strip(),
        pwd.strip('"').strip(),
        user_name.strip('"').strip() if user_name else None,
        int(admin_opt) if str(admin_opt).strip() else 0,
        int(enabled) if str(enabled).strip() else 1,
        _parse_dt(last_login),
        cr,
        _parse_dt(updated_at),
    )


def main() -> int:
    csv_path = Path(sys.argv[1]) if len(sys.argv) > 1 else CSV_PATH
    if not csv_path.is_file():
        print(f"CSV not found: {csv_path}", file=sys.stderr)
        return 1

    rows = None
    used_enc = ""
    for enc in ("utf-8-sig", "utf-8", "cp932"):
        try:
            with open(csv_path, encoding=enc, newline="") as f:
                rows = list(csv.reader(f, delimiter=";", quotechar='"'))
            used_enc = enc
            break
        except UnicodeDecodeError:
            continue

    if rows is None:
        print("Could not decode CSV", file=sys.stderr)
        return 1

    sample = rows[1][2] if len(rows) > 1 and len(rows[1]) > 2 else ""
    print(f"Using encoding: {used_enc} (sample user_name: {sample[:40]!r}...)")

    if not rows:
        print("Empty CSV", file=sys.stderr)
        return 1

    header = [h.strip('"').strip() for h in rows[0]]
    expected = [
        "userid",
        "pwd",
        "user_name",
        "admin_option",
        "Enabled",
        "LastLoginDateTime",
        "created_at",
        "updated_at",
    ]
    if header != expected:
        print(f"Unexpected header: {header}", file=sys.stderr)
        return 1

    data_rows = rows[1:]
    batch: list[tuple] = []
    for row in data_rows:
        if not row or all(not (c or "").strip() for c in row):
            continue
        while len(row) < 8:
            row.append("")
        batch.append(_parse_row(row))

    sql = text(
        """
        INSERT INTO t1_loginuser (
            userid, pwd, user_name, admin_option, Enabled,
            LastLoginDateTime, created_at, updated_at
        ) VALUES (
            :userid, :pwd, :user_name, :admin_option, :enabled,
            :last_login, :created_at, :updated_at
        )
        """
    )

    with engine.begin() as conn:
        conn.execute(text("SET FOREIGN_KEY_CHECKS=0"))
        conn.execute(text("DELETE FROM t1_loginuser"))
        for i in range(0, len(batch), 500):
            chunk = batch[i : i + 500]
            for row in chunk:
                conn.execute(
                    sql,
                    {
                        "userid": row[0],
                        "pwd": row[1],
                        "user_name": row[2],
                        "admin_option": row[3],
                        "enabled": row[4],
                        "last_login": row[5],
                        "created_at": row[6],
                        "updated_at": row[7],
                    },
                )
        conn.execute(text("SET FOREIGN_KEY_CHECKS=1"))

    print(f"Imported {len(batch)} rows into t1_loginuser (after delete).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
