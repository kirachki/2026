"""承認済みの全日休暇のみ SH_SHIFT_ASSIGNMENTS の「休・ロック」行に同期する。
部分休・時間指定休はシフト割当はソルバー側で調整するため、ここではロック行を作らない。
"""
from __future__ import annotations

from sqlalchemy.orm import Session

import models
from date_keys import to_calendar_date


def sync_approved_leave_assignments(
    db: Session,
    team_id: int,
    period: models.SchedulePeriod,
) -> None:
    """
    指定期間内の承認済み全日休暇について、必要なら「休・ロック」行を作成する。
    既存が正しい「休・ロック」、✖（guard_x）、または休・未ロック（ロック解除直後）の
    いずれかの場合は上書きしない。
    """
    p_start = to_calendar_date(period.start_date)
    p_end = to_calendar_date(period.end_date)
    if p_start is None or p_end is None:
        return

    leaves = (
        db.query(models.LeaveRequest)
        .join(models.Staff, models.Staff.id == models.LeaveRequest.staff_id)
        .filter(
            models.LeaveRequest.team_id == team_id,
            models.LeaveRequest.status == "approved",
            models.Staff.team_id == team_id,
            models.Staff.is_active == True,
            models.LeaveRequest.request_date >= p_start,
            models.LeaveRequest.request_date <= p_end,
        )
        .all()
    )
    for lr in leaves:
        lk = getattr(lr, "leave_kind", None) or models.LEAVE_KIND_FULL_DAY
        if lk != models.LEAVE_KIND_FULL_DAY:
            continue
        wd = to_calendar_date(lr.request_date)
        if wd is None or wd < p_start or wd > p_end:
            continue
        # ユニーク制約 (staff_id, work_date) のみ。
        # team_id を絞り込みに含めると、旧チームで作られた行を見落として
        # INSERT 時に重複エラー (Duplicate entry) を起こす。
        existing = (
            db.query(models.ShiftAssignment)
            .filter(
                models.ShiftAssignment.staff_id == lr.staff_id,
                models.ShiftAssignment.work_date == wd,
            )
            .first()
        )
        if existing:
            # 既に「休・ロック」の一行でチームも一致ならそのまま
            if (
                existing.team_id == team_id
                and existing.shift_type_id is None
                and existing.is_locked
                and not getattr(existing, "guard_x", False)
            ):
                continue
            # ✖／✖🔒 — ユーザーの明示より同期で上書きしない
            if getattr(existing, "guard_x", False):
                continue
            # 休・未ロック — ダブルクリックでロック解除した状態を維持（同期で休🔒に戻さない）
            if (
                existing.shift_type_id is None
                and not existing.is_locked
                and not getattr(existing, "guard_x", False)
            ):
                continue
            db.delete(existing)
            db.flush()
        db.add(
            models.ShiftAssignment(
                team_id=team_id,
                staff_id=lr.staff_id,
                period_id=period.id,
                shift_type_id=None,
                work_date=wd,
                is_locked=True,
                guard_x=False,
                source="manual",
            )
        )
