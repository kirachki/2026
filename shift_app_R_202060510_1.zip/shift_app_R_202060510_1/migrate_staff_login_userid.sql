-- SH_STAFF にログインID（t1_loginuser.userid）を保持（任意・NULL可）
ALTER TABLE SH_STAFF
  ADD COLUMN login_userid VARCHAR(50) NULL COMMENT 'ログインID（スタッフ追加時に設定）' AFTER name;

CREATE INDEX idx_staff_team_login_userid ON SH_STAFF (team_id, login_userid);
