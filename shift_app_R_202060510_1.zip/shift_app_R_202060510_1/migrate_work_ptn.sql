-- 勤務時間パターンマスタ SH_WORK_PTN と SH_STAFF.work_ptn_id
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS SH_WORK_PTN (
    id          INT             NOT NULL AUTO_INCREMENT,
    label       VARCHAR(32)     NOT NULL                    COMMENT '表示（例 08:50-17:30）',
    sort_order  INT             NOT NULL DEFAULT 0          COMMENT '一覧・ドロップダウン順',
    created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    UNIQUE KEY uq_sh_work_ptn_label (label),
    INDEX idx_sh_work_ptn_sort (sort_order)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='勤務時間パターンマスタ';

INSERT INTO SH_WORK_PTN (label, sort_order) VALUES
    ('08:50-17:30', 1),
    ('08:50-16:00', 2),
    ('21:00-09:00', 3),
    ('07:50-16:00', 4)
ON DUPLICATE KEY UPDATE sort_order = VALUES(sort_order);

ALTER TABLE SH_STAFF
    ADD COLUMN work_ptn_id INT NULL COMMENT '勤務時間パターン（SH_WORK_PTN）' AFTER employment_type;

ALTER TABLE SH_STAFF
    ADD CONSTRAINT fk_sh_staff_work_ptn
        FOREIGN KEY (work_ptn_id)
        REFERENCES SH_WORK_PTN (id)
        ON DELETE SET NULL
        ON UPDATE CASCADE;
