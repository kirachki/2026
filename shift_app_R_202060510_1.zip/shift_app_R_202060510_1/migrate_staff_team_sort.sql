-- SH_STAFF に「チーム（短縮ラベル）」と「表示順」を追加
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;

ALTER TABLE SH_STAFF
    ADD COLUMN team_label VARCHAR(6) NULL COMMENT 'チーム短縮ラベル（全角6文字想定）' AFTER work_ptn_id,
    ADD COLUMN sort_order INT NOT NULL DEFAULT 500 COMMENT '一覧での表示順（小さいほど上）' AFTER team_label;

CREATE INDEX idx_sh_staff_sort_order ON SH_STAFF (team_id, sort_order);
