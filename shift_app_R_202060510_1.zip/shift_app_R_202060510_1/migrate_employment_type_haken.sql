-- SH_STAFF.employment_type に「派遣（haken）」を追加
-- ddl.sql 由来の ENUM 定義になっている DB 用。VARCHAR(20) 環境では実行不要。
ALTER TABLE SH_STAFF
  MODIFY COLUMN employment_type ENUM(
                        'full_time',
                        'part_time',
                        'haken'
                    ) NOT NULL DEFAULT 'full_time' COMMENT '雇用形態';
