"""スタッフ行の共通並び順（シフト表・サイドバー・最適化入力の一覧順を揃える）。

並び: チーム短縮ラベル（team_label）昇順 → 表示順（sort_order）昇順。
team_label が未設定の行は最後にまとめる。
"""
from __future__ import annotations

from sqlalchemy import case, func, or_

import models


def staff_rows_order_by():
    """SQLAlchemy order_by に渡すタプル。"""
    no_label = or_(
        models.Staff.team_label.is_(None),
        func.trim(models.Staff.team_label) == "",
    )
    return (
        case((no_label, 1), else_=0),
        models.Staff.team_label.asc(),
        models.Staff.sort_order.asc(),
        models.Staff.name.asc(),
        models.Staff.id.asc(),
    )
