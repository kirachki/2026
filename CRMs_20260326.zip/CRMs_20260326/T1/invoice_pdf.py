"""
請求書 PDF 生成（ReportLab）。
他モジュールから再利用する場合は build_invoice_pdf_bytes / save_invoice_pdf_to_path を利用。
"""
from __future__ import annotations

import io
import logging
import re
from decimal import Decimal
from pathlib import Path

import db

logger = logging.getLogger(__name__)

# 1ページあたりの明細行数（MAX）
DETAIL_ROWS_PER_PAGE = 10


def _register_japanese_font():
    """ReportLab の日本語 CID フォントを登録（失敗時は Helvetica）。"""
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.cidfonts import UnicodeCIDFont

    for name in ("HeiseiKakuGo-W5", "HeiseiMin-W3", "MS-Gothic"):
        try:
            pdfmetrics.registerFont(UnicodeCIDFont(name))
            return name
        except Exception:
            continue
    return "Helvetica"


def _fmt_yyyymmdd(v) -> str:
    if v is None:
        return ""
    if hasattr(v, "strftime"):
        return v.strftime("%Y/%m/%d")
    s = str(v).strip()
    # いろいろな DB/入力の揺れを吸収して、最終的に yyyy/mm/dd に寄せる
    # 例:
    # - 2026-03-23
    # - 2026/03/23
    # - 2026-3-23
    # - 20260323
    m = re.match(r"^(\d{4})[-/](\d{1,2})[-/](\d{1,2})", s)
    if m:
        y = m.group(1)
        mo = int(m.group(2))
        d = int(m.group(3))
        return f"{y}/{mo:02d}/{d:02d}"
    m2 = re.match(r"^(\d{4})(\d{2})(\d{2})", s)
    if m2:
        return f"{m2.group(1)}/{m2.group(2)}/{m2.group(3)}"
    return s


def _cell_str(v) -> str:
    if v is None:
        return ""
    return str(v).strip()


def _sum_zeikomi(details: list[dict]) -> Decimal:
    t = Decimal("0")
    for d in details:
        v = d.get("税込金額")
        if v is None:
            continue
        try:
            t += Decimal(str(v).replace(",", "").strip())
        except Exception:
            pass
    return t


def _sanitize_pdf_filename_segment(s: str, max_len: int = 150) -> str:
    """Windows 等で問題になりやすい文字を置換し、長さを制限する。"""
    s = (s or "").strip()
    s = re.sub(r'[\\/:*?"<>|\r\n\t]', "_", s)
    s = s.strip(" .")
    if len(s) > max_len:
        s = s[:max_len]
    return s


def get_invoice_pdf_filename_from_row(row: dict, invoice_no: str = "") -> str:
    """
    保存用 PDF ファイル名。
    形式: 請求書番号_T1_請求書データ_ヘッダ・{宛名_取引先名の値}.pdf
    （宛名_取引先名が空のときは「名称なし」）
    """
    h = row["header"]
    inv_raw = _cell_str(h.get("請求書番号")) or (invoice_no or "").strip()
    meigi = _cell_str(h.get("宛名_取引先名")) or "名称なし"
    part_inv = _sanitize_pdf_filename_segment(inv_raw, max_len=40)
    part_meigi = _sanitize_pdf_filename_segment(meigi, max_len=150)
    return f"{part_inv}_T1_請求書データ_ヘッダ・{part_meigi}.pdf"


def get_invoice_pdf_filename(invoice_no: str) -> str | None:
    """DB から取得してファイル名を返す（データが無い場合は None）。"""
    inv = (invoice_no or "").strip()
    if not inv:
        return None
    row = db.fetch_invoice_for_maintenance(inv)
    if not row:
        return None
    return get_invoice_pdf_filename_from_row(row, invoice_no)


def _fmt_money(v: Decimal) -> str:
    try:
        s = str(v.quantize(Decimal("0.01")))
        parts = s.split(".")
        intp = parts[0]
        if intp.startswith("-"):
            sign, intp = "-", intp[1:]
        else:
            sign = ""
        rev = intp[::-1]
        grouped = ",".join(reversed([rev[i : i + 3] for i in range(0, len(rev), 3)]))
        return sign + grouped + "." + (parts[1] if len(parts) > 1 else "00")
    except Exception:
        return str(v)


def build_invoice_pdf_bytes_from_row(row: dict) -> bytes:
    """
    fetch 済みの請求データ dict（header / details）から PDF バイト列を生成する。
    """
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    from reportlab.platypus import Table, TableStyle

    header = row["header"]
    details = row["details"] or []

    font = _register_japanese_font()
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    w, h = A4

    margin_x = 40
    line_h = 14
    total_zeikomi = _sum_zeikomi(details)

    # 明細テーブル列幅（pt・A4 横幅に収める）
    detail_col_widths = [95, 95, 95, 70, 40, 80]

    # 明細ヘッダ行の背景（淡いグレー）
    _DETAIL_HEADER_BG = colors.HexColor("#e8e8e8")
    _GRID_COLOR = colors.HexColor("#666666")

    # 明細を 10 行ずつ分割（0件でも1チャンク）
    chunks: list[list[dict]] = []
    if not details:
        chunks = [[]]
    else:
        for i in range(0, len(details), DETAIL_ROWS_PER_PAGE):
            chunks.append(details[i : i + DETAIL_ROWS_PER_PAGE])

    def draw_section1(y: float) -> float:
        """セクション1：ヘッダ（請求書番号）"""
        c.setFont(font, 12)
        c.drawString(margin_x, y, f"請求書番号：{_cell_str(header.get('請求書番号'))}")
        return y - line_h * 2

    def draw_section2(y: float) -> float:
        """セクション2：送付先"""
        c.setFont(font, 11)
        c.drawString(margin_x, y, "【送付先】")
        y -= line_h * 1.2
        c.setFont(font, 10)
        lines = [
            f"郵便番号：{_cell_str(header.get('郵便番号'))}",
            f"住所：{_cell_str(header.get('住所'))}",
            f"宛名：{_cell_str(header.get('宛名_取引先名'))}",
            f"担当部署：{_cell_str(header.get('宛名_担当部署'))}",
            f"担当者：{_cell_str(header.get('宛名_担当者'))}",
        ]
        for line in lines:
            c.drawString(margin_x, y, line)
            y -= line_h
        return y - line_h * 0.5

    def draw_section3(y: float) -> float:
        """セクション3：請求書ヘッダ情報"""
        c.setFont(font, 11)
        c.drawString(margin_x, y, "【請求内容】")
        y -= line_h * 1.2
        c.setFont(font, 10)
        c.drawString(margin_x, y, f"件名：{_cell_str(header.get('件名'))}")
        y -= line_h
        c.drawString(margin_x, y, f"発行日：{_fmt_yyyymmdd(header.get('発行日'))}")
        y -= line_h
        c.drawString(margin_x, y, f"請求金額：{_fmt_money(total_zeikomi)}")
        y -= line_h
        c.drawString(margin_x, y, f"支払期限：{_fmt_yyyymmdd(header.get('支払期限'))}")
        y -= line_h
        c.drawString(margin_x, y, f"コメント（振込）：{_cell_str(header.get('コメント_振込'))}")
        y -= line_h
        c.drawString(margin_x, y, f"備考：{_cell_str(header.get('備考欄'))}")
        return y - line_h * 1.5

    def _detail_table_data(chunk: list[dict]) -> list[list[str]]:
        headers = ["請求項目1", "請求項目2", "請求項目3", "単価", "数量", "税抜金額"]
        rows: list[list[str]] = [headers]
        for d in chunk:
            rows.append(
                [
                    _cell_str(d.get("請求項目1"))[:80],
                    _cell_str(d.get("請求項目2"))[:80],
                    _cell_str(d.get("請求項目3"))[:80],
                    _cell_str(d.get("単価")),
                    _cell_str(d.get("数量")),
                    _cell_str(d.get("税抜金額")),
                ]
            )
        return rows

    def draw_detail_block(y_top: float, chunk: list[dict]) -> float:
        """【請求明細】タイトル + 罫線付きテーブル。y_top は下方向へ進む前の基準（canvas 座標: 下が原点）。"""
        c.setFont(font, 11)
        c.drawString(margin_x, y_top, "【請求明細】")
        y_below_title = y_top - line_h * 1.5

        data = _detail_table_data(chunk)
        tbl = Table(data, colWidths=detail_col_widths, repeatRows=1)
        style_cmds: list = [
            ("FONTNAME", (0, 0), (-1, -1), font),
            ("FONTSIZE", (0, 0), (-1, -1), 9),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("LEFTPADDING", (0, 0), (-1, -1), 5),
            ("RIGHTPADDING", (0, 0), (-1, -1), 5),
            ("TOPPADDING", (0, 0), (-1, -1), 5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            # ヘッダ行の背景（淡いグレー）
            ("BACKGROUND", (0, 0), (-1, 0), _DETAIL_HEADER_BG),
            # 罫線（表全体）
            ("GRID", (0, 0), (-1, -1), 0.5, _GRID_COLOR),
        ]
        if len(data) > 1:
            style_cmds.append(("ALIGN", (3, 1), (5, -1), "RIGHT"))
        style_cmds.append(("ALIGN", (3, 0), (5, 0), "CENTER"))
        tbl.setStyle(TableStyle(style_cmds))

        avail_w = w - 2 * margin_x
        tw, th = tbl.wrap(avail_w, h)
        tbl.drawOn(c, margin_x, y_below_title - th)
        return y_below_title - th - 12

    for page_idx, chunk in enumerate(chunks):
        if page_idx > 0:
            c.showPage()
        y = h - 50

        y = draw_section1(y)
        if page_idx == 0:
            y = draw_section2(y)
            y = draw_section3(y)
        draw_detail_block(y, chunk)

    c.save()
    return buf.getvalue()


def build_invoice_pdf_bytes(invoice_no: str) -> bytes | None:
    """
    請求書番号単位で PDF バイト列を生成する。
    データは DB（T1_請求書データ_ヘッダ / 明細）から取得。
    """
    inv = (invoice_no or "").strip()
    if not inv:
        return None
    row = db.fetch_invoice_for_maintenance(inv)
    if not row:
        return None
    return build_invoice_pdf_bytes_from_row(row)


def save_invoice_pdf_to_path(invoice_no: str, output_path: str | Path) -> Path:
    """
    請求書 PDF を指定パスに保存する（サーバー側バッチ等で再利用）。
    """
    p = Path(output_path)
    data = build_invoice_pdf_bytes(invoice_no)
    if not data:
        raise ValueError(f"請求データが見つかりません: {invoice_no}")
    p.write_bytes(data)
    return p.resolve()
