/**
 * 請求書 PDF 生成（機能A）
 * - 引数で請求番号（invoiceNos）を受け取る
 * - invoiceNos ごとに /invoice/pdf/{invoice_no} を通常ダウンロードする
 * - Content-Disposition の filename* があれば保存名に使用する
 * - 必要なら（1件時のみ）ダウンロード後に PDF を新規タブ表示する
 *
 * 使用例:
 *   window.agInvoicePdfFeatureA.createInvoicePdfsToDirectory({
 *     invoiceNos: ['INV001'],
 *     openPdfAfterSave: true
 *   })
 */
(function () {
  if (window.agInvoicePdfFeatureA && window.agInvoicePdfFeatureA.createInvoicePdfsToDirectory) {
    return;
  }

  function sanitizeFilename(s) {
    return String(s || '').replace(/[\\/:*?"<>|]/g, '_').trim();
  }

  function filenameFromContentDisposition(cd) {
    if (!cd) return null;
    // filename*=UTF-8''{encoded}
    var m = /filename\*=UTF-8''([^;\s]+)/i.exec(cd);
    if (m) {
      try {
        return decodeURIComponent(m[1].trim());
      } catch (e) {
        // ignore
      }
    }
    // filename="{...}"
    m = /filename="([^"]+)"/i.exec(cd);
    if (m) return m[1];
    return null;
  }

  async function createInvoicePdfsToDirectory(options) {
    options = options || {};
    var invoiceNos = Array.isArray(options.invoiceNos) ? options.invoiceNos : [];
    var openPdfAfterSave = !!options.openPdfAfterSave;

    if (invoiceNos.length === 0) {
      return { ok: false, errors: ['請求書番号がありません。'], saved: 0 };
    }

    var errs = [];
    var saved = 0;

    for (var i = 0; i < invoiceNos.length; i++) {
      var no = invoiceNos[i];
      if (!no) continue;

      try {
        var res = await fetch('/invoice/pdf/' + encodeURIComponent(no), {
          credentials: 'same-origin',
        });
        if (!res.ok) {
          errs.push(no + ': HTTP ' + res.status);
          continue;
        }

        var cd = res.headers.get('Content-Disposition');
        var filename = sanitizeFilename(filenameFromContentDisposition(cd) || (no + '.pdf')) || (no + '.pdf');
        var blob = await res.blob();
        var url = URL.createObjectURL(blob);

        // 通常ダウンロード（ブラウザ既定のダウンロード先に保存）
        var a = document.createElement('a');
        a.href = url;
        a.download = filename;
        a.style.display = 'none';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);

        if (openPdfAfterSave && invoiceNos.length === 1) {
          window.open(url, '_blank');
        } else {
          setTimeout(function (u) {
            URL.revokeObjectURL(u);
          }, 2000, url);
        }

        saved += 1;
      } catch (e) {
        errs.push(no + ': ' + (e && e.message ? e.message : String(e)));
      }
    }

    return { ok: errs.length === 0, errors: errs, saved: saved };
  }

  window.agInvoicePdfFeatureA = {
    createInvoicePdfsToDirectory: createInvoicePdfsToDirectory,
  };
})();

