-- T1_請求書データ_明細 用 CSV ロードスクリプト

USE sakila;
SET NAMES utf8mb4;

-- 一時的に STRICT_TRANS_TABLES を外して、空日付/数値をエラーにしない
SET @OLD_SQL_MODE = @@SQL_MODE;
SET SQL_MODE = REPLACE(@@SQL_MODE, 'STRICT_TRANS_TABLES', '');

-- 日本語ファイル名は MySQL クライアント側の文字コード差異で参照できないことがあるため、ASCII名に置き換えてください。
-- 例: C:/ProgramData/MySQL/MySQL Server 9.5/Uploads/T1_invoice_detail.csv
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 9.5/Uploads/T1_invoice_detail.csv'
INTO TABLE `T1_請求書データ_明細`
CHARACTER SET cp932
FIELDS TERMINATED BY ','
OPTIONALLY ENCLOSED BY '\"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

-- 元に戻す
SET SQL_MODE = @OLD_SQL_MODE;

