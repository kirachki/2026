"""
FastAPI + htmx サンプル（TOP: 取引先一覧）
"""
import os
from datetime import date, datetime
from pathlib import Path
from urllib.parse import quote

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware

import auth_middleware
import db

# セッション署名鍵（本番では必ず環境変数 CRM_SESSION_SECRET を設定）
SESSION_SECRET = os.environ.get(
    "CRM_SESSION_SECRET",
    "dev-only-change-me-set-CRM_SESSION_SECRET",
)

app = FastAPI(title="FastAPI + htmx CRM")

# 外側から: Session → 要ログイン → ルート（未ログインは /login へ）
app.add_middleware(auth_middleware.RequireLoginMiddleware)
# max_age=None: ブラウザを閉じるとセッション Cookie が消える（新しいブラウザ／プライベートは未ログイン）
app.add_middleware(
    SessionMiddleware,
    secret_key=SESSION_SECRET,
    max_age=None,
    same_site="lax",
    https_only=False,
)

BASE_DIR = Path(__file__).resolve().parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))
templates.env.filters["urlquote"] = lambda u: quote(str(u or ""), safe="")


def safe_next_path(path: str) -> str | None:
    """
    ログイン後のリダイレクト先。同一アプリ内の相対パスのみ許可（オープンリダイレクト防止）。
    """
    if not path or not isinstance(path, str):
        return None
    path = path.strip()
    if not path.startswith("/") or path.startswith("//"):
        return None
    if path.startswith("/login"):
        return None
    if len(path) > 512 or "\n" in path or "\r" in path:
        return None
    return path


def _cell_to_str(v) -> str:
    if v is None:
        return ""
    if isinstance(v, (date, datetime)):
        return v.strftime("%Y-%m-%d")
    s = str(v).strip()
    if len(s) >= 10 and s[:4].isdigit() and s[4:5] == "-" and s.startswith("0000"):
        return ""
    return s


def _mount_first_existing(mount_path: str, name: str, candidates: list[Path]) -> None:
    """最初に存在するディレクトリを StaticFiles でマウントする。"""
    for d in candidates:
        if d.is_dir():
            app.mount(mount_path, StaticFiles(directory=str(d)), name=name)
            return


# TOP・一覧用: /files/（リポジトリ内 static/files を最優先）
_mount_first_existing(
    "/files",
    "files",
    [
        BASE_DIR / "static" / "files",
        BASE_DIR / "SamplesCRM" / "2" / "取引先一覧 - All Gather CRM V3_files",
    ],
)

# メンテ画面用: /ref3/（一覧と別セット。未マウントだとフォームだけ無スタイルになる）
_mount_first_existing(
    "/ref3",
    "ref3",
    [
        BASE_DIR / "static" / "ref3",
        BASE_DIR / "SamplesCRM" / "3" / "木田工務店 - 取引先 - All Gather CRM V3_files",
    ],
)


@app.get("/favicon.ico", include_in_schema=False)
async def favicon():
    """
    ブラウザが自動で GET する。ルートが無いと 404 になるため 204 で応答する。
    （ログイン画面などで favicon 404 が出るのはこれが原因）
    """
    return Response(status_code=204)


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    """Hello サンプルページ"""
    return templates.TemplateResponse(
        request=request, name="index.html", context={"request": request}
    )


@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    """ログイン画面（常に表示。ログイン済みでも URL で開ける）。"""
    nxt = request.query_params.get("next") or ""
    next_field = safe_next_path(nxt) or ""
    return templates.TemplateResponse(
        request=request,
        name="login.html",
        context={
            "request": request,
            "login_error": None,
            "userid_value": "",
            "next_field": next_field,
        },
    )


@app.post("/login", response_class=HTMLResponse)
async def login_submit(request: Request):
    """ログイン処理。成功時は next があればそこへ、なければ /top へ。"""
    form = await request.form()
    userid = (form.get("userid") or "").strip()
    pwd = form.get("pwd") or ""
    next_raw = (form.get("next") or "").strip()

    ok, err_msg = db.verify_login_user(userid, pwd)
    if ok:
        request.session["user_id"] = userid
        db.update_last_login_datetime(userid)
        dest = safe_next_path(next_raw) or "/top"
        return RedirectResponse(url=dest, status_code=303)

    next_field = safe_next_path(next_raw) or ""
    return templates.TemplateResponse(
        request=request,
        name="login.html",
        context={
            "request": request,
            "login_error": err_msg,
            "userid_value": userid,
            "next_field": next_field,
        },
    )


def _top_context(request: Request) -> dict:
    """TOP シェル用テンプレートコンテキスト（ログインユーザー表示名を含む）。"""
    uid = (request.session.get("user_id") or "").strip()
    return {
        "request": request,
        "login_user_name": db.get_login_user_display_name(uid) if uid else "",
    }


@app.get("/top", response_class=HTMLResponse)
async def top(request: Request):
    """TOPメニュー（取引先一覧レイアウト）"""
    return templates.TemplateResponse(
        request=request, name="top.html", context=_top_context(request)
    )


@app.get("/top/{subpath:path}", response_class=HTMLResponse)
async def top_with_path(request: Request, subpath: str):
    """
    TOP シェル（/top/torihikisaki 等の直リンク・ブックマーク用）。
    htmx の hx-push-url と同じ URL をサーバーでも返す。
    """
    return templates.TemplateResponse(
        request=request, name="top.html", context=_top_context(request)
    )


@app.get("/fragment/dashboard", response_class=HTMLResponse)
async def fragment_dashboard(request: Request):
    """htmx: ダッシュボードフラグメント"""
    return templates.TemplateResponse(
        request=request,
        name="fragments/dashboard.html",
        context={"request": request},
    )


@app.get("/fragment/torihikisaki", response_class=HTMLResponse)
async def fragment_torihikisaki(request: Request):
    """htmx: 取引先一覧フラグメント"""
    return templates.TemplateResponse(
        request=request,
        name="fragments/torihikisaki_list.html",
        context={"request": request},
    )


@app.get("/fragment/invoice-data", response_class=HTMLResponse)
async def fragment_invoice_data(request: Request):
    """htmx: 請求データ一覧フラグメント（顧客一覧のSaveAs版）"""
    return templates.TemplateResponse(
        request=request,
        name="fragments/invoice_data_list.html",
        context={"request": request},
    )


@app.get("/fragment/invoice-data/search", response_class=HTMLResponse)
def fragment_invoice_data_search(
    request: Request,
    search_invoice_no: str = "",
    search_customer_name: str = "",
    search_issue_date_from: str = "",
    search_issue_date_to: str = "",
    search_payment_deadline_from: str = "",
    search_payment_deadline_to: str = "",
    _reset: bool = False,
):
    """htmx: 請求書データ検索結果フラグメント（同期: DBアクセスのため def）"""
    if _reset:
        return templates.TemplateResponse(
            request=request,
            name="fragments/invoice_data_results.html",
            context={"request": request, "mode": "initial"},
        )

    has_condition = any(
        v.strip()
        for v in [
            search_invoice_no,
            search_customer_name,
            search_issue_date_from,
            search_issue_date_to,
            search_payment_deadline_from,
            search_payment_deadline_to,
        ]
    )
    if not has_condition:
        return templates.TemplateResponse(
            request=request,
            name="fragments/invoice_data_results.html",
            context={"request": request, "mode": "no_condition"},
        )

    results, result_count, over_limit = db.search_invoices(
        search_invoice_no=search_invoice_no,
        search_customer_name=search_customer_name,
        search_issue_date_from=search_issue_date_from,
        search_issue_date_to=search_issue_date_to,
        search_payment_deadline_from=search_payment_deadline_from,
        search_payment_deadline_to=search_payment_deadline_to,
    )

    return templates.TemplateResponse(
        request=request,
        name="fragments/invoice_data_results.html",
        context={
            "request": request,
            "mode": "results",
            "results": results,
            "result_count": result_count,
            "over_limit": over_limit,
        },
    )


@app.get("/fragment/torihikisaki/search", response_class=HTMLResponse)
def fragment_torihikisaki_search(
    request: Request,
    search_koza_meigi: str = "",
    search_hojin_mei: str = "",
    search_daihyo_sei: str = "",
    search_kanri_sei: str = "",
    _reset: bool = False,
):
    """htmx: 取引先検索結果フラグメント（同期: DBアクセスのため def）"""
    if _reset:
        return templates.TemplateResponse(
            request=request,
            name="fragments/torihikisaki_results.html",
            context={"request": request, "mode": "initial"},
        )

    has_condition = any(
        v.strip()
        for v in [search_koza_meigi, search_hojin_mei,
                   search_daihyo_sei, search_kanri_sei]
    )
    if not has_condition:
        return templates.TemplateResponse(
            request=request,
            name="fragments/torihikisaki_results.html",
            context={"request": request, "mode": "no_condition"},
        )

    results, result_count, over_limit = db.search_accounts(
        search_koza_meigi=search_koza_meigi,
        search_hojin_mei=search_hojin_mei,
        search_daihyo_sei=search_daihyo_sei,
        search_kanri_sei=search_kanri_sei,
    )

    return templates.TemplateResponse(
        request=request,
        name="fragments/torihikisaki_results.html",
        context={
            "request": request,
            "mode": "results",
            "results": results,
            "result_count": result_count,
            "over_limit": over_limit,
        },
    )


@app.get("/account/maintenance", response_class=HTMLResponse)
def account_maintenance(request: Request, tenban: int, koza: str):
    """取引先メンテナンス（新規タブ用フルページ）。T1_AccountAttribute を店番号+口座番号で特定。"""
    row = db.fetch_account_for_maintenance(tenban, koza)
    if not row:
        return HTMLResponse(
            content=(
                "<!DOCTYPE html><html><head><meta charset='utf-8'><title>404</title></head>"
                "<body><p>該当する取引先が見つかりません。</p></body></html>"
            ),
            status_code=404,
        )

    form = {k: _cell_to_str(v) for k, v in row.items()}
    z = form.get("電話番号(市外局番)", "")
    s = form.get("電話番号(市内局番)", "")
    kk = form.get("電話番号(局番)", "")
    phone_parts = [p for p in [z, s, kk] if p]
    phone_combined = "-".join(phone_parts)
    rep_kanji = (form.get("代表者姓(漢字)", "") or "") + (form.get("代表者名(漢字)", "") or "")
    rep_kana = (form.get("代表者姓(カナ)", "") or "") + (form.get("代表者名(カナ)", "") or "")
    mgr_full = (form.get("口座管理者姓(漢字)", "") or "") + (form.get("口座管理者名(漢字)", "") or "")
    title = form.get("法人名(漢字)", "") or "取引先メンテナンス"

    return templates.TemplateResponse(
        request=request,
        name="account_maintenance.html",
        context={
            "request": request,
            "form": form,
            "phone_combined": phone_combined,
            "rep_kanji": rep_kanji,
            "rep_kana": rep_kana,
            "mgr_full": mgr_full,
            "page_title": title,
        },
    )


@app.get("/invoice/maintenance", response_class=HTMLResponse)
def invoice_maintenance(request: Request, invoice_no: str):
    """請求書メンテナンス（新規タブ用フルページ）。T1_請求書データ_ヘッダ + 明細を請求書番号でJOIN。"""
    row = db.fetch_invoice_for_maintenance(invoice_no)
    if not row:
        return HTMLResponse(
            content=(
                "<!DOCTYPE html><html><head><meta charset='utf-8'><title>404</title></head>"
                "<body><p>該当する請求データが見つかりません。</p></body></html>"
            ),
            status_code=404,
        )

    header = row["header"]
    details = row["details"]

    header_form = {k: _cell_to_str(v) for k, v in header.items()}
    detail_rows = [{k: _cell_to_str(v) for k, v in d.items()} for d in details]

    # 表示タイトル
    title = header_form.get("宛名_取引先名") or header_form.get("請求書番号") or "請求データメンテナンス"

    return templates.TemplateResponse(
        request=request,
        name="invoice_maintenance.html",
        context={
            "request": request,
            "header_form": header_form,
            "detail_rows": detail_rows,
            "header_columns": getattr(db, "_INVOICE_HEADER_COLUMNS"),
            "detail_columns": getattr(db, "_INVOICE_DETAIL_COLUMNS"),
            "header_quads": (lambda cols: [
                {
                    "row_no": (i // 4) + 1,
                    "col1": cols[i],
                    "col2": cols[i + 1] if (i + 1) < len(cols) else None,
                    "col3": cols[i + 2] if (i + 2) < len(cols) else None,
                    "col4": cols[i + 3] if (i + 3) < len(cols) else None,
                }
                for i in range(0, len(cols), 4)
            ])(getattr(db, "_INVOICE_HEADER_COLUMNS")),
            "details_section_row_class": (
                ((len(getattr(db, "_INVOICE_HEADER_COLUMNS")) + 3) // 4) + 2
            ),
            "page_title": title,
        },
    )


@app.post("/invoice/maintenance/save")
async def invoice_maintenance_save(request: Request):
    """請求データメンテ画面の保存（検証→補完→DB更新）。"""
    try:
        body = await request.json()
    except Exception:
        return JSONResponse(
            status_code=400,
            content={"ok": False, "errors": ["リクエスト本文が不正です。"]},
        )

    invoice_no = (body.get("invoice_no") or "").strip()
    header = body.get("header") or {}
    detail_rows = body.get("detail_rows") or []
    if not isinstance(header, dict):
        header = {}
    if not isinstance(detail_rows, list):
        detail_rows = []

    err_h = db.validate_invoice_header_for_save(header)
    if err_h:
        return JSONResponse(content={"ok": False, "errors": err_h})

    err_d = db.validate_invoice_detail_rows_for_save(detail_rows)
    if err_d:
        return JSONResponse(content={"ok": False, "errors": err_d})

    ok, msg = db.save_invoice_maintenance(invoice_no, header, detail_rows)
    if ok:
        return JSONResponse(content={"ok": True, "message": msg})
    return JSONResponse(content={"ok": False, "errors": [msg]})


@app.get("/invoice/pdf/{invoice_no}")
def get_invoice_pdf(invoice_no: str):
    """
    請求書番号単位で PDF を返す（請求書一括作成・他機能から再利用）。
    """
    import invoice_pdf as invoice_pdf_mod
    from urllib.parse import quote

    row = db.fetch_invoice_for_maintenance(invoice_no)
    if not row:
        raise HTTPException(
            status_code=404, detail="該当する請求データが見つかりません。"
        )
    data = invoice_pdf_mod.build_invoice_pdf_bytes_from_row(row)
    fn = invoice_pdf_mod.get_invoice_pdf_filename_from_row(row, invoice_no)
    fn_encoded = quote(fn, safe="")
    return Response(
        content=data,
        media_type="application/pdf",
        headers={
            "Content-Disposition": (
                'attachment; filename="invoice.pdf"; '
                f"filename*=UTF-8''{fn_encoded}"
            )
        },
    )


@app.get("/fragment/hello", response_class=HTMLResponse)
async def fragment_hello(request: Request):
    """htmx: Hello サンプルフラグメント（メインフレーム用）"""
    return templates.TemplateResponse(
        request=request,
        name="fragments/hello.html",
        context={"request": request},
    )


@app.get("/hello", response_class=HTMLResponse)
async def hello(name: str = ""):
    """htmx: 画面入力の name を XXX に反映"""
    display_name = name.strip() or "ゲスト"
    return HTMLResponse(
        f"<p id='greeting' class='greeting'>Hello {display_name}さん from FastAPI + htmx!</p>"
    )
