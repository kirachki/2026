"""
Created on Mon April 16 15:19:19 2024
@author: hidtoshi.kurosu@rakuten-bank.co.jp
"""
# standard libraries
import configparser
import csv
import re
import datetime
import logging
import os
import re
from typing import Dict, List, Optional, Union
import time
import pandas as pd
import sys
import time
import win32com.client


# 3rd parties' libraries
import pandas as pd
import selenium
# import pyperclip
from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions
from selenium.common.exceptions import TimeoutException

from datetime import datetime
# from typing import List, Dict
# import pandas as pd
import math
# import re


# constants
formatter: logging.Formatter = logging.Formatter("%(asctime)s %(name)s:%(lineno)s %(funcName)s [%(levelname)s]: %(message)s")
LOGGER: logging.Logger = logging.getLogger(__name__)
handler: logging.Handler = logging.StreamHandler()
handler.setFormatter(formatter)
handler.setLevel(logging.DEBUG)
LOGGER.setLevel(logging.DEBUG)
for _handler in LOGGER.handlers:
    LOGGER.removeHandler(_handler)
LOGGER.addHandler(handler)
LOGGER.propagate = False

BASE_PATH: str = os.path.dirname(__file__)

CONFIG_INI = configparser.ConfigParser(interpolation=configparser.ExtendedInterpolation())
CONFIG_INI_PATH: str = os.path.splitext(__file__)[0] + ".conf"
assert os.path.exists(CONFIG_INI_PATH)
CONFIG_INI.read(CONFIG_INI_PATH, encoding="utf-8")
DEFAULT = CONFIG_INI["DEFAULT"]

INFO_FILE_PATH: str = os.path.join(BASE_PATH, DEFAULT.get("INFO_CSV_FILE"))

AKS_URL: str = DEFAULT.get("AKS_URL")

CHROME_DRIVER: str = os.path.join(BASE_PATH, DEFAULT.get("CHROME_DRIVER"))
IE_DRIVER: str = os.path.join(BASE_PATH, DEFAULT.get("IE_DRIVER"))
FF_DRIVER: str = os.path.join(BASE_PATH, DEFAULT.get("FF_DRIVER"))

WEB_DRIVER: str = DEFAULT.get("WEB_DRIVER")
# WEB_DRIVER: str = DEFAULT.get("WEB_DRIVER")
assert WEB_DRIVER in ("CHROME", "IE", "FF")
DISPLAY_POS:int = 3
DELIMITER="\t"
SEP = ","

    
def set_text(text_input: WebElement, text: str) -> None:
    """
    set text string to <input/>

    called_from: request_query(), set_fromto_date()
    """
    #text_input.send_keys(Keys.CONTROL + "a")
    #text_input.send_keys(Keys.DELETE)
    text_input.clear()
    text_input.send_keys(text)
    return


def get_webdriver_object() -> Union[webdriver.Chrome, webdriver.Ie, webdriver.Firefox]:
    """
    get WebDriver object

    called_from: main()
    """
    global CHROME_DRIVER, IE_DRIVER, FF_DRIVER
    global WEB_DRIVER
    if selenium.__version__.startswith("4."):
        if WEB_DRIVER == "CHROME":
            assert os.path.exists(CHROME_DRIVER)
            chrome_service = webdriver.chrome.service.Service(executable_path=CHROME_DRIVER)
            browser = webdriver.Chrome(service=chrome_service)
        elif WEB_DRIVER == "IE":
            assert os.path.exists(IE_DRIVER)
            ie_service = webdriver.ie.service.Service(executable_path=IE_DRIVER)
            browser = webdriver.Ie(service=ie_service)
        elif WEB_DRIVER == "FF":
            assert os.path.exists(FF_DRIVER)
            ff_service = webdriver.firefox.service.Service(executable_path=FF_DRIVER)
            ff_options = webdriver.FirefoxOptions()
            ff_options.binary_location = "C:/Program Files/Mozilla Firefox/firefox.exe"
            browser = webdriver.Firefox(service=ff_service, options=ff_options)
        # end of if
    elif selenium.__version__.startswith("3."):
        if WEB_DRIVER == "CHROME":
            browser = webdriver.Chrome(executable_path=CHROME_DRIVER)
        elif WEB_DRIVER == "IE":
            browser = webdriver.Ie(executable_path=IE_DRIVER)
        elif WEB_DRIVER == "FF":
            browser = webdriver.Firefox(executable_path=FF_DRIVER)
        # end of if
    else:
        raise f"Unknown selenium version: {selenium.__version__}"
    # end of if
    return browser

def create_folder(folder_path) -> None:
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)

def save_to_csv(data, output_file):
    with open(output_file, 'w', newline='') as f:
        writer = csv.writer(f)
        for row in data:
            writer.writerow(row)

def extract_folder_path(full_path):
    foler_path, _ = os.path.split(full_path)
    return foler_path



def format_to_slash_date(date_string):
    """
    'yyyy-mm-dd 00:00:00' 形式の文字列を 'yyyy/mm/dd' 形式に変換する
    """
    try:
        # 文字列をdatetimeオブジェクトに変換
        dt = datetime.strptime(date_string, '%Y-%m-%d %H:%M:%S')
        # 任意のフォーマットに変換して返す
        return dt.strftime('%Y/%m/%d')
    except ValueError as e:
        return f"エラー: フォーマットが正しくありません ({e})"

def check_date_limit(date_string):
    """
    引数の日付が本日より後の場合は0、本日以前の場合は1を返す
    フォーマット: yyyy/mm/dd
    """
    try:
        # 入力文字列を日付オブジェクトに変換
        target_date = datetime.strptime(date_string, '%Y/%m/%d').date()
        # 本日の日付を取得
        today = datetime.now().date()
        
        # 本日より大きい（未来）場合は0、それ以外（今日を含む過去）は1
        if target_date > today:
            return 0
        else:
            return 1
    except ValueError as e:
        return f"エラー: 日付形式が正しくありません ({e})"


def f_split_month(yyyymmdd_from: str, yyyymmdd_to: str, split_num: int) -> List[Dict[str, int]]:
    """
    指定されたyyyymmdd_from～yyyymmdd_to（どちらも yyyy/mm/dd 形式）の期間をsplit_num分割し、
    各分割のfrom/toをyyyy,mm,ddで返却する。
    返却値: [{'from_yyyy': xxxx, 'from_mm': xx, 'from_dd': xx, 'to_yyyy': xxxx, 'to_mm': xx, 'to_dd': xx}, ...]
    """
    from datetime import datetime, timedelta

    # yyyy/mm/dd形式で受け取り、それを日付に変換して使用
    from_date = datetime.strptime(yyyymmdd_from, "%Y/%m/%d")
    to_date = datetime.strptime(yyyymmdd_to, "%Y/%m/%d")

    total_days = (to_date - from_date).days + 1  # 端点を含める

    result = []
    for i in range(split_num):
        start_offset = (total_days * i) // split_num
        end_offset = (total_days * (i + 1)) // split_num - 1

        split_from = from_date + timedelta(days=start_offset)
        split_to = from_date + timedelta(days=end_offset)

        result.append({
            'from_yyyy': split_from.year,
            'from_mm': split_from.month,
            'from_dd': split_from.day,
            'to_yyyy': split_to.year,
            'to_mm': split_to.month,
            'to_dd': split_to.day
        })
    return result


def format_to_integer_string(value_str):
    """
    "12345.0" のような文字列を "12345" に変換して返す
    """
    try:
        # 一旦 float として読み込み、int にキャストすることで小数点以下を切り捨てる
        num = int(float(value_str))
        return str(num)
    except (ValueError, TypeError) as e:
        return f"エラー: 無効な入力です ({e})"


def clean_excel_value_full(value):
    """
    NaN, NaT, None, "nan" などのゴミを排除し、完全な空文字を返す
    """
    # 1. pandasのisna()を使うのが最も確実 (NaNとNaTの両方を検知可能)
    if pd.isna(value):
        return ""
    
    # 2. 文字列としての "nan" や "nat" のチェック
    val_str = str(value).lower().strip()
    if val_str in ["NaT", "NaN", "nan", "nat"]:
        return ""
    
    # 3. 正常なデータは文字列にして返す
    return str(value)

def parse_and_count_segments(input_str):
    """
    文字列を ":" で分割し、(個数, 分割されたリスト) を返す
    """
    if not input_str:
        return 0, []
    
    # split(":") で分割。区切り文字がない場合は要素1つのリストが返る
    segments = input_str.split(":")
    
    # (要素の数, 要素のリスト) をタプルで返す
    return len(segments), segments


def extract_numbers(text):
    """
    文字列から数字のみを抽出して返す。
    数字が一切含まれない場合は、元の文字列をそのまま返す。
    """
    if text is None:
        return ""

    # 正規表現で「0-9以外の文字」をすべて空文字に置換（削除）する
    # [^0-9] は「0から9ではない文字」という意味
    cleaned = re.sub(r'[^0-9]', '', text)

    # 数字が1つも見つからなかった場合は、仕様通り引数をそのまま返す
    if cleaned == "":
        return text
    
    return cleaned


def pad_left_with_zero(num_str, total_length):
    
    return num_str.zfill(total_length)



def main() -> None:

    # 引数チェック
    if len(sys.argv) < 6:
         sys.exit(1)

    # # 引数:1, 2 振替実施日
    start_date_list = sys.argv[1].split('/')
    end_date_list = sys.argv[2].split('/')

    # LOGGER.info(f"@@@@@ start_date_list : {sys.argv[1]}")
    # LOGGER.info(f"@@@@@ end_date_list : {sys.argv[2]}")



    # wk_Filter_yyyymm = start_date_list[0] + f"{int(start_date_list[1]):02d}"
    # LOGGER.info(f"* wk_Filter_yyyymm {wk_Filter_yyyymm}")

    # 引数:3 処理エクセルのフルパス
    file_name = sys.argv[3]

    # 引数:4 処理エクセルのシート名
    sheet_name = sys.argv[4]

    # 引数:5 スクリーンショット保管場所のフルパス
    screen_save_name = sys.argv[5]

    LOGGER.info(f" *** file_name : {file_name}")

    # LOGGER.info(f" *** sheet_name {sheet_name}")
    # LOGGER.info(f" *** screen_save_name {screen_save_name}")

    # LOGGER.info(f"振替実施日日が{sys.argv[1]}から{sys.argv[2]}までの情報を処理する")

    # # init the driver
    browser: Union[webdriver.Chrome, webdriver.Ie, webdriver.Firefox] = get_webdriver_object()
    browser.implicitly_wait(600.0)
    global AKS_URL
    browser.get(AKS_URL)

    # # 「マスサービス管理」を押す
    # WebDriverWait(browser, 60.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "/html/body/form/table/tbody/tr[3]/td[3]/table/tbody/tr/td/span/div"))).click()
    WebDriverWait(browser, 60.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "/html/body/form/table/tbody/tr[3]/td[5]/table/tbody/tr/td/span/div"))).click()

    # # 「マスサービス受付管理」を押す
    WebDriverWait(browser, 60.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "//input[@type='BUTTON' and @value='マスサービス受付管理']"))).click()

    # # 異常終了、Ctrl+Cでもエクセルを保存させるように改修
    # try:

    # except KeyboardInterrupt:
    #     print("\n処理が中断されました。")
    # except Exception as e:
    #     print("\n[エラー] 予期しないエラーが発生しました。")
    # finally:
    #     print("\n[エラー] 共通フォーマットエクセルを変更を保存します。")
    #     # 汎用エクセルファイルを保存して閉じる
    #     df.to_excel(file_name,sheet_name=sheet_name, index=False)

    #     # 「xログアウト」ボタンを押下
    #     elenment = browser.find_element(By.XPATH, "//*[@id='menuForm']/table/tbody/tr[2]/td/table[1]/tbody/tr[1]/td/button/img")
    #     elenment.click()


    # xlsxを読んで支店番号と口座番号を取得
    # df = pd.read_excel(file_name, sheet_name=sheet_name, header=51)
    # df = pd.read_excel(file_name, sheet_name=sheet_name, header=1)
    df = pd.read_excel(file_name, sheet_name=sheet_name)
    for index, row in df.iterrows():


        # 請求書番号 請求書番号:H177形式の4桁 + α(4桁以内に注釈)でなければクリア
        seikyuu_no = str(row[4])
        if len(seikyuu_no) >= 4 + 4:
            seikyuu_no = ""
        LOGGER.info(f"@@@@@ seikyuu_no : {seikyuu_no}")


        # エビデンス取得済FLG=1 は処理対象外
        taishoo_flg = str(row[16])

        # LOGGER.info(f"@@@@@ taishoo_flg : {taishoo_flg}")

        if taishoo_flg != "0":
            continue

         # 2.支店番号チェック
         # 支店番号 "231.0"なので"230"に補正
        branch_code    = str(row[0])
        if len(branch_code) == 0:
            continue


        try:
            int_branch_code = int(float(branch_code))
            branch_code = str(int_branch_code)
        except Exception as e:
            #LOGGER.info(rf'@@@@@ 数字じゃない @@@@@')
            continue


        if len(branch_code) != 3:
            continue



        # 3.口座番号チェック
        account_number = str(row[1])
        match = re.search(r'\d{7}', account_number)
        if match:
            extracted_number = match.group()
            account_number = str(extracted_number)
            # LOGGER.info(f"@@@@@ extracted_number : {extracted_number}")


        if len(account_number) != 7:
            continue


        #  下記にPhxxの記載のあるフェーズは対応済
        # Ph1.5 : メルマネマスペ	4
        # Ph1.0 : マスペイメント	1 
        #       : メルマネ・マスペ・プラス	5
        #       : 給与賞与振込	6
        # Ph1.0 : 自動引落	2 
        # Ph1.0 : 自動引落(処理済件数）	2 
        #       : 自動引落（振込のみ）	!
        #       : マルチペイメント（ペイジー）	!

        # サービス名
        service_kind = str(row[3])
        if service_kind != "マスペイメント" and \
           service_kind != "自動引落" and \
           service_kind != "自動引落(処理済件数）" and \
           service_kind != "メルマネ・マスペ・プラスＸＸＸＸＸＸ" and \
           service_kind != "メルマネマスペ":
            continue

        # LOGGER.info(f"@@@@@ X service_kind : {service_kind}")



        # 委託者コード
        ctl_itaku_cd = clean_excel_value_full(str(row[5]))
        # LOGGER.info(f"@@@@@ 1 ctl_itaku_cd : {ctl_itaku_cd}")
        if ctl_itaku_cd != "":
            ctl_itaku_cd = format_to_integer_string(ctl_itaku_cd)
            # LOGGER.info(f"@@@@@ 2 ctl_itaku_cd : {ctl_itaku_cd}")

            ctl_itaku_cd = pad_left_with_zero(ctl_itaku_cd,10)
            # LOGGER.info(f"@@@@@ 3 ctl_itaku_cd : {ctl_itaku_cd}")


        # エビデンス取得時の特別対応
        ctl_treat1 = clean_excel_value_full(str(row[6]))
        ctl_treat2 = clean_excel_value_full(str(row[7]))

        # LOGGER.info(f"@@@@@ ctl_treat1 : {ctl_treat1}")
        # LOGGER.info(f"@@@@@ ctl_treat2 : {ctl_treat2}")

        # 振込手数料の場合は別プログラム(34.py)で取得する。その場合はctl_treat1ではなくctl_treat2="ITM"とする。
        if ctl_treat1 == "ITM":
            continue

        # 検索時分割回数
        ctl_search_time = str(row[8])
        # LOGGER.info(f"@@@@@ ctl_search_time : {row[8]}")

        # 抽出期間From
        ctl_from = str(row[13])
        ctl_from = format_to_slash_date(ctl_from)
        # LOGGER.info(f"@@@@@ ctl_from : {ctl_from}")
        start_date_list = ctl_from.split('/')


        # 抽出期間To
        ctl_to = str(row[14])
        ctl_to = format_to_slash_date(ctl_to)
        # LOGGER.info(f"@@@@@ ctl_to : {ctl_to}")
        end_date_list = ctl_to.split('/')

        # 取得タイミング(日付)
        ctl_exec_timing =   str(row[15])
        ctl_exec_timing = format_to_slash_date(ctl_exec_timing)
        # LOGGER.info(f"@@@@@ ctl_exec_timing : {ctl_exec_timing}")


        # エビデンス取得済FLG
        ctl_exec_flg = str(row[16])


        result = check_date_limit(ctl_exec_flg)
        if result == 0:
            LOGGER.info(f"@@@@@ 日付まだ @@@@@")
            continue

        LOGGER.info(f"★★★  {branch_code}-{account_number}-S:{seikyuu_no}-I:{ctl_itaku_cd}-T1:{ctl_treat1}-T2:{ctl_treat2}-F:{ctl_from}-T:{ctl_to}-E:{ctl_exec_timing}")

        # サービス種別を設定する(記号！は下記にない。要追加)
        if service_kind == rf"メルマネマスペ":
            WebDriverWait(browser, 60.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "/html/body/form/table/tbody/tr[1]/td/select/option[6]"))).click()
        elif service_kind == rf"マスペイメント":
            WebDriverWait(browser, 60.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "/html/body/form/table/tbody/tr[1]/td/select/option[1]"))).click()
        elif service_kind == rf"自動引落"  :
            WebDriverWait(browser, 60.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "/html/body/form/table/tbody/tr[1]/td/select/option[2]"))).click()
        elif service_kind == rf"自動引落(処理済件数）"  :
            WebDriverWait(browser, 60.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "/html/body/form/table/tbody/tr[1]/td/select/option[2]"))).click()
        else:
            continue



        # 振替実施日を設定する ※自動引落のみ年入力可
        # 開始年
        if service_kind == r"自動引落" or \
           service_kind == r"自動引落(処理済件数）"  :
            set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[2]/td[1]/input[1]"), start_date_list[0])

        set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[2]/td[1]/input[2]"), start_date_list[1])
        set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[2]/td[1]/input[3]"), start_date_list[2])


        # 終了年
        if service_kind == r"自動引落" or \
           service_kind == r"自動引落(処理済件数）"  :
            set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[2]/td[1]/input[4]"), end_date_list[0])

        # 終了月、終了日
        set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[2]/td[1]/input[5]"), end_date_list[1])
        set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[2]/td[1]/input[6]"), end_date_list[2])

        # 支店、口座番号
        # DLYの場合はクリアする
        if ctl_treat1 == "DLY":
            set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[3]/td[1]/input"), "")
            set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[4]/td[1]/input"), "")
        else:
            set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[3]/td[1]/input"), branch_code)
            set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[4]/td[1]/input"), account_number)

        # 委託者指定
        if ctl_treat1 == "DLY":
            set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[5]/td[1]/input"), "")
        else:
            set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[5]/td[1]/input"), ctl_itaku_cd)


        # 「検索」を押す
        # WebDriverWait(browser, 1000.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "//input[@type='button' and @value='検　索']"))).click()
        # browser.implicitly_wait(3000.0)
        # ページロード自体のタイムアウトを3000秒に設定（これが最も重要です）
        browser.set_page_load_timeout(5000)
        try:
            WebDriverWait(browser, 30).until(expected_conditions.element_to_be_clickable((By.XPATH, "//input[@type='button' and @value='検　索']"))).click()
        except Exception as e:
            LOGGER.info(rf'@@@@@ 検索で例外だよ {e} @@@@@')


        # # 検索結果画面 start---------------------------------------------------------------- 

        # スクリーンショットを取得する
        str_screenshot_name = f"{branch_code}-{account_number}-{seikyuu_no}"
        # 格納フォルダを振り分ける
        if service_kind == r"メルマネマスペ" :
            sub_forder = r"メルマネマスペ"
        elif service_kind == r"マスペイメント"  :
            sub_forder = r"マスペイメント"
        elif service_kind == r"自動引落"  :
            sub_forder = r"自動引落"
        elif service_kind == r"自動引落(処理済件数）"  :
            sub_forder = r"自動引落"
        else:
            sub_forder = r"その他"
        create_folder(rf"{screen_save_name}\{sub_forder}")

        # browser.save_screenshot(rf"{screen_save_name}\{sub_forder}\{str_screenshot_name}.png")

        # # 1ページ単位の処理
        # current_pos_total = 0
        irai_sum = 0
        shori_sum = 0

        current_page_count = 0
        while True:

            current_page_count += 1

            # --loop終了条件--
            browser.implicitly_wait(1300.0)
            th: WebElement = browser.find_element(By.XPATH, "//th[contains(text(), '件中') and contains(text(), '件を表示しています')]")
            # th: WebElement = WebDriverWait(browser, 50000.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "//th[contains(text(), '件中') and contains(text(), '件を表示しています')]"))).click()
            counts = re.findall(r"全(\d+)件中(\d+)-(\d+)件を表示しています", th.text)[0]

            (total_count, display_current_pos_from, display_current_pos_to) = (int(count) for count in counts)
            # LOGGER.info(rf"total:{total_count}, start:{display_current_pos_from}, ends:{display_current_pos_to}")
            # --loop終了条件--

            # tbodyを取得
            tbody = browser.find_element(By.XPATH, f"/html/body/div/form/table[2]/tbody")

            # rowsを取得（ヘッダーのみの場合は3となる）
            tbody_rows =  tbody.find_elements(By.TAG_NAME, "tr")


            date_range = rf"{start_date_list[0]}{start_date_list[1]}{start_date_list[2]}-{end_date_list[0]}{end_date_list[1]}{end_date_list[2]}"

            browser.save_screenshot(rf"{screen_save_name}\{sub_forder}\{str_screenshot_name}-{current_page_count}-{date_range}.png")

            # LOGGER.info(f"\n")
            LOGGER.info(f"@ {str_screenshot_name}-{service_kind} : {total_count} 件")
            LOGGER.info(rf"total:{total_count}, start:{display_current_pos_from}, ends:{display_current_pos_to}")
            # LOGGER.info(rf"tbody_rows:{len(tbody_rows)}")

            if len(tbody_rows) <= DISPLAY_POS:
            #    total_count == 0:
                # LOGGER.info(rf'@@@@@ 処理対象がないため終了します... @@@@@')
                break

            details_tbody  = browser.find_element(By.XPATH, f"/html/body/div/form/table[2]")
            html = details_tbody.get_attribute('outerHTML')
            df_list = pd.read_html(html, header=None)
            internal_table = df_list[0]
            # 先頭２行を削除して、３行目以降のデータを取得する場合は以下。ただし、上記の"header=None"で除去される様子
            # internal_table = df_list[0].iloc[2:]

            time.sleep(2)

            # 依頼件数、処理件数を合計(サービス種別により表示位置が異なる)
            if service_kind == r"メルマネマスペ" :
                # irai_sum = \
                # irai_sum + internal_table.loc[internal_table.iloc[:, 14] == "終了", internal_table.columns[9]].sum()
                # shori_sum = \
                # shori_sum + internal_table.loc[internal_table.iloc[:, 14] == "終了", internal_table.columns[10]].sum()
                irai_sum = 0
                shori_sum = 0


            elif service_kind == r"マスペイメント"  :
                # irai_sum = \
                # irai_sum + internal_table.loc[internal_table.iloc[:, 13] == "終了", internal_table.columns[9]].sum()
                # shori_sum = \
                # shori_sum + internal_table.loc[internal_table.iloc[:, 13] == "終了", internal_table.columns[10]].sum()
                irai_sum = 0
                shori_sum = 0

            elif service_kind == r"自動引落" or\
                 service_kind == r"自動引落(処理済件数）" :

                # 委託者指定の場合
                if ctl_itaku_cd != "":


                    LOGGER.info(f"@@@@@ X1 @@@@@")

                    # 委託者に対して条件がある場合は、条件を取得する
                    # ctl_treat1="IT:SK:NE:0"の場合、count=4で意味は以下の通り
                    # IT:委託者コード
                    # SK:処理済金額（サポート済）
                    # NE:0 not equal 0（サポート済）。EQ:0 equal 0（サポート未）


                    count, out_params = parse_and_count_segments(ctl_treat1)
                    if (
                        count > 1
                        and out_params[0] == "IT"
                        and out_params[1] == "SK"
                        and out_params[2] == "NE"
                        and out_params[3] == "0"
                    ):
                        # ? "処理済み金額が０円のものはカウントしない"の条件を追加する


                        LOGGER.info(f"@@@@@ X1-1 @@@@@")

                        # ↓ 追加条件：15列目の「1つ目の金額」が0円は除外
                        irai_sum = (
                            irai_sum
                            + internal_table.loc[
                                (internal_table.iloc[:, 16] == "終了")
                                & (internal_table.iloc[:, 2].astype(str).str.contains(ctl_itaku_cd))
                                & (internal_table.iloc[:, 4].astype(str).str.contains(branch_code))
                                & (internal_table.iloc[:, 5].astype(str).str.contains(account_number)) 
                                & (~internal_table.iloc[:, 15].astype(str).str.contains(r"^0円\(", na=False)),
                                internal_table.columns[10]
                            ].sum()
                        )


                        # ↓ 追加条件：15列目のカッコ内が「(0円)」でないこと
                        # irai_sum = (
                        #     irai_sum
                        #     + internal_table.loc[
                        #         (internal_table.iloc[:, 16] == "終了")
                        #         & (internal_table.iloc[:, 2].astype(str) == ctl_itaku_cd)
                        #         & (internal_table.iloc[:, 4].astype(str) == branch_code)
                        #         & (internal_table.iloc[:, 5].astype(str) == account_number)
                        #         & (~internal_table.iloc[:, 15].astype(str).str.contains(r"\(0円\)", na=False)),
                        #         internal_table.columns[10]
                        #     ].sum()
                        # )


                        irai_sum = (
                            irai_sum
                            + internal_table.loc[
                                (internal_table.iloc[:, 16] == "終了")
                                & (internal_table.iloc[:, 2].astype(str).str.contains(ctl_itaku_cd))
                                & (internal_table.iloc[:, 4].astype(str).str.contains(branch_code))
                                & (internal_table.iloc[:, 5].astype(str).str.contains(account_number)) ,
                                internal_table.columns[10]
                            ].sum()
                        )



                        shori_sum = (
                            shori_sum
                            + internal_table.loc[
                                (internal_table.iloc[:, 16] == "終了")
                                & (internal_table.iloc[:, 2].astype(str).str.contains(ctl_itaku_cd))
                                & (internal_table.iloc[:, 4].astype(str).str.contains(branch_code))
                                & (internal_table.iloc[:, 5].astype(str).str.contains(account_number)) ,
                                internal_table.columns[12]
                            ].sum()
                        )


                    else:

                        LOGGER.info(f"@@@@@ X1-2 @@@@@")


                        irai_sum = (
                            irai_sum
                            + internal_table.loc[
                                (internal_table.iloc[:, 16] == "終了")
                                & (internal_table.iloc[:, 4].astype(str).str.contains(branch_code))
                                & (internal_table.iloc[:, 5].astype(str).str.contains(account_number)) ,
                                internal_table.columns[10]
                            ].sum()
                        )
                        shori_sum = (
                            shori_sum
                            + internal_table.loc[
                                (internal_table.iloc[:, 16] == "終了")
                                & (internal_table.iloc[:, 4].astype(str).str.contains(branch_code))
                                & (internal_table.iloc[:, 5].astype(str).str.contains(account_number)) ,
                                internal_table.columns[12]
                            ].sum()
                        )
                                # & (internal_table.iloc[:, 2].astype(str).str.contains(ctl_itaku_cd))

                else:

                    LOGGER.info(f"@@@@@ X2 @@@@@")

                    irai_sum = (
                        irai_sum
                        + internal_table.loc[
                            (internal_table.iloc[:, 16] == "終了") 
                            & (internal_table.iloc[:, 4].astype(str).str.contains(branch_code))
                            & (internal_table.iloc[:, 5].astype(str).str.contains(account_number)) ,
                            internal_table.columns[10]
                        ].sum()
                    )
                    shori_sum = (
                        shori_sum
                        + internal_table.loc[
                            (internal_table.iloc[:, 16] == "終了")
                            & (internal_table.iloc[:, 4].astype(str).str.contains(branch_code))
                            & (internal_table.iloc[:, 5].astype(str).str.contains(account_number)) ,
                            internal_table.columns[12]
                        ].sum()
                    )


                            # & (internal_table.iloc[:, 4].astype(str) == branch_code)
                            # & (internal_table.iloc[:, 5].astype(str) == account_number),


            else:
                irai_sum = 0
                shori_sum = 0

            # LOGGER.info(rf'---------------------- irai_sum : {irai_sum}')
            # LOGGER.info(rf'---------------------- shori_sum : {shori_sum}')

            # 依頼件数
            df.iloc[index,9]= irai_sum

            # 処理件数
            df.iloc[index,10]= shori_sum

            # エビデンス取得済FLG
            # row[10] = "1"
            # df.iloc[index,16]= "1"

            # LOGGER.info(rf'***** {total_count}-{display_current_pos_to}')
            # loop終了を判定
            if  total_count <= display_current_pos_to :
                break

            # 「次」を押す
            time.sleep(2)
            # WebDriverWait(browser, 1000.0).until(expected_conditions.element_to_be_clickable((By.LINK_TEXT, "次>>"))).click()
            browser.set_page_load_timeout(5000)
            try:
                WebDriverWait(browser, 30.0).until(expected_conditions.element_to_be_clickable((By.LINK_TEXT, "次>>"))).click()
            except Exception as e:
                LOGGER.info(rf'@@@@@ 次へで例外だよ {e} @@@@@')

        # # 出力イメージを配列に格納
        # out_data.append([branch_code, account_number, seikyuu_no, irai_sum, shori_sum, service_kind, taishoo_gai_flg ])

        WebDriverWait(browser, 300.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "//input[@type='BUTTON' and @value='戻　る']"))).click()

    browser.close()

    df.to_excel(file_name,sheet_name=sheet_name, index=False)

    return

if __name__ == "__main__":
    LOGGER.info("starts")
    main()
    LOGGER.info("ends")

