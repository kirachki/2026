def parse_and_count_segments(input_str):
    """
    文字列を ":" で分割し、(個数, 分割されたリスト) を返す
    """
    if not input_str:
        return 0, []
    
    # split(":") で分割。区切り文字がない場合は要素1つのリストが返る
    segments = input_str.split(":")
    
    # (要素の数, 要素のリスト) をタプルで返す
    return len(segments), segments

# 特別対応の中身を配列に分解します
def main():
    # テストケース
    test_cases = [
        "IT:SK:NE:0",
        "DLY",
        "A:B",
        ""  # 空文字ケース
    ]
    
    # print(f"{'入力文字列':<15} | {'個数':<5} | {'分割後の配列'}")
    # print("-" * 45)
    
    # for case in test_cases:
    #     count, out_params = parse_and_count_segments(case)
    #     print(f"{case:<15} | {count:<5} | {out_params}")

    count, out_params = parse_and_count_segments("IT:SK:NE:0")
    # count, out_params = parse_and_count_segments("DLY")
    print(f"@@@@@@@@@@")
    print(f"{count}")
    if count > 0:
        print(f"{out_params[0]}")
    if count > 1:
        print(f" | {out_params[1]}")
    if count > 2:
        print(f" | {out_params[2]}")
    if count > 3:
        print(f" | {out_params[3]}")
    print()

if __name__ == "__main__":
    main()