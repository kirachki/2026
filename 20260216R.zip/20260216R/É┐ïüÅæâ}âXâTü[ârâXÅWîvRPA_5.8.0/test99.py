# from bs4 import BeautifulSoup

# # 1.html を読み込む（この .py と同じフォルダにある前提）
# with open("1.html", "r", encoding="cp932") as f:
#     html = f.read()

# soup = BeautifulSoup(html, "html.parser")

# body = soup.body

# # body 配下のすべてのタグ（要素）を 1 項目ずつ取得して表示
# for i, tag in enumerate(body.find_all(True), start=1):
#     # 要素のテキストだけを結合して取得
#     text = " ".join(tag.stripped_strings)
#     print(f"{i:03}: <{tag.name}> {text}")

from bs4 import BeautifulSoup

# 1.html を読み込み（文字コードは HTML の指定に合わせて cp932）
with open("1.html", encoding="cp932") as f:
    soup = BeautifulSoup(f, "html.parser")

# 本文中の一番大きなテーブル（今回の明細テーブル）を取得
table = soup.find("table", attrs={"border": "0"})

for row_idx, tr in enumerate(table.find_all("tr"), start=1):
    tds = tr.find_all("td")
    for col_idx, td in enumerate(tds, start=0):
        text = td.get_text(strip=True)
        # if "(123円)" in text:
        if "4,892,660" in text:
            print("行番号:", row_idx)
            print("列番号:", col_idx)
            print("セル内容:", text)

        # 行番号: 3
        # 列番号: 15
        # セル内容: 4,892,660円(123円)
