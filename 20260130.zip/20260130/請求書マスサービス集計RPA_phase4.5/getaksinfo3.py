"""
Created on Mon April 16 15:19:19 2024
@author: hidtoshi.kurosu@rakuten-bank.co.jp
"""
# standard libraries
import configparser
import csv
import re
import datetime
import logging
import os
import re
from typing import Dict, List, Optional, Union
import time
import pandas as pd
import sys
import time
import win32com.client


# 3rd parties' libraries
import pandas as pd
import selenium
# import pyperclip
from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions
from selenium.common.exceptions import TimeoutException

# constants
formatter: logging.Formatter = logging.Formatter("%(asctime)s %(name)s:%(lineno)s %(funcName)s [%(levelname)s]: %(message)s")
LOGGER: logging.Logger = logging.getLogger(__name__)
handler: logging.Handler = logging.StreamHandler()
handler.setFormatter(formatter)
handler.setLevel(logging.DEBUG)
LOGGER.setLevel(logging.DEBUG)
for _handler in LOGGER.handlers:
    LOGGER.removeHandler(_handler)
LOGGER.addHandler(handler)
LOGGER.propagate = False

BASE_PATH: str = os.path.dirname(__file__)

CONFIG_INI = configparser.ConfigParser(interpolation=configparser.ExtendedInterpolation())
CONFIG_INI_PATH: str = os.path.splitext(__file__)[0] + ".conf"
assert os.path.exists(CONFIG_INI_PATH)
CONFIG_INI.read(CONFIG_INI_PATH, encoding="utf-8")
DEFAULT = CONFIG_INI["DEFAULT"]

INFO_FILE_PATH: str = os.path.join(BASE_PATH, DEFAULT.get("INFO_CSV_FILE"))

AKS_URL: str = DEFAULT.get("AKS_URL")

CHROME_DRIVER: str = os.path.join(BASE_PATH, DEFAULT.get("CHROME_DRIVER"))
IE_DRIVER: str = os.path.join(BASE_PATH, DEFAULT.get("IE_DRIVER"))
FF_DRIVER: str = os.path.join(BASE_PATH, DEFAULT.get("FF_DRIVER"))

WEB_DRIVER: str = DEFAULT.get("WEB_DRIVER")
# WEB_DRIVER: str = DEFAULT.get("WEB_DRIVER")
assert WEB_DRIVER in ("CHROME", "IE", "FF")
DISPLAY_POS:int = 3
DELIMITER="\t"
SEP = ","

    
def set_text(text_input: WebElement, text: str) -> None:
    """
    set text string to <input/>

    called_from: request_query(), set_fromto_date()
    """
    #text_input.send_keys(Keys.CONTROL + "a")
    #text_input.send_keys(Keys.DELETE)
    text_input.clear()
    text_input.send_keys(text)
    return


def get_webdriver_object() -> Union[webdriver.Chrome, webdriver.Ie, webdriver.Firefox]:
    """
    get WebDriver object

    called_from: main()
    """
    global CHROME_DRIVER, IE_DRIVER, FF_DRIVER
    global WEB_DRIVER
    if selenium.__version__.startswith("4."):
        if WEB_DRIVER == "CHROME":
            assert os.path.exists(CHROME_DRIVER)
            chrome_service = webdriver.chrome.service.Service(executable_path=CHROME_DRIVER)
            browser = webdriver.Chrome(service=chrome_service)
        elif WEB_DRIVER == "IE":
            assert os.path.exists(IE_DRIVER)
            ie_service = webdriver.ie.service.Service(executable_path=IE_DRIVER)
            browser = webdriver.Ie(service=ie_service)
        elif WEB_DRIVER == "FF":
            assert os.path.exists(FF_DRIVER)
            ff_service = webdriver.firefox.service.Service(executable_path=FF_DRIVER)
            ff_options = webdriver.FirefoxOptions()
            ff_options.binary_location = "C:/Program Files/Mozilla Firefox/firefox.exe"
            browser = webdriver.Firefox(service=ff_service, options=ff_options)
        # end of if
    elif selenium.__version__.startswith("3."):
        if WEB_DRIVER == "CHROME":
            browser = webdriver.Chrome(executable_path=CHROME_DRIVER)
        elif WEB_DRIVER == "IE":
            browser = webdriver.Ie(executable_path=IE_DRIVER)
        elif WEB_DRIVER == "FF":
            browser = webdriver.Firefox(executable_path=FF_DRIVER)
        # end of if
    else:
        raise f"Unknown selenium version: {selenium.__version__}"
    # end of if
    return browser

def create_folder(folder_path) -> None:
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)

def save_to_csv(data, output_file):
    with open(output_file, 'w', newline='') as f:
        writer = csv.writer(f)
        for row in data:
            writer.writerow(row)

def extract_folder_path(full_path):
    foler_path, _ = os.path.split(full_path)
    return foler_path

# def f_get_otherFirstDate(date_str, diff_months):
#     # parse input date string
#     year, month, _ = map(int, date_str.split('/'))
#     # 計算する月
#     new_month = month + diff_months

#     # 年の繰り上げ・繰り下げ処理
#     new_year = year + (new_month - 1) // 12
#     new_month = (new_month - 1) % 12 + 1
#     return f"{new_year}/{new_month}/1"


def main() -> None:

    # 引数チェック
    if len(sys.argv) < 6:
         sys.exit(1)

    # 引数:1, 2 振替実施日
    start_date_list = sys.argv[1].split('/')
    end_date_list = sys.argv[2].split('/')

    # # メルマネ・マスペプラスの場合、振替実施日2ヶ月前の1日を設定
    # start_date2 = f_get_otherFirstDate(sys.argv[1], -2)
    # start_date_list2 = start_date2.split('/')

    wk_Filter_yyyymm = start_date_list[0] + f"{int(start_date_list[1]):02d}"
    LOGGER.info(f"* wk_Filter_yyyymm {wk_Filter_yyyymm}")

    # 引数:3 処理エクセルのフルパス
    file_name = sys.argv[3]

    # 引数:4 処理エクセルのシート名
    sheet_name = sys.argv[4]

    # 引数:5 スクリーンショット保管場所のフルパス
    screen_save_name = sys.argv[5]

    LOGGER.info(f" *** file_name : {file_name}")

    # LOGGER.info(f" *** sheet_name {sheet_name}")
    # LOGGER.info(f" *** screen_save_name {screen_save_name}")

    # LOGGER.info(f"振替実施日日が{sys.argv[1]}から{sys.argv[2]}までの情報を処理する")

    # # init the driver
    browser: Union[webdriver.Chrome, webdriver.Ie, webdriver.Firefox] = get_webdriver_object()
    browser.implicitly_wait(600.0)
    global AKS_URL
    browser.get(AKS_URL)

    # # 「マスサービス管理」を押す
    # WebDriverWait(browser, 60.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "/html/body/form/table/tbody/tr[3]/td[3]/table/tbody/tr/td/span/div"))).click()
    WebDriverWait(browser, 60.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "/html/body/form/table/tbody/tr[3]/td[5]/table/tbody/tr/td/span/div"))).click()

    # # 「マスサービス受付管理」を押す
    WebDriverWait(browser, 60.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "//input[@type='BUTTON' and @value='マスサービス受付管理']"))).click()





    # output header
    out_header = ['支店番号', '口座番号', '請求書番号', '依頼件数', '処理件数', '該当サービス', '処理対象外フラグ', '他行受取ＯＫ　送金人手数料負担', '他行受取不可　送金人手数料負担', '他行受取ＯＫ　受取人手数料負担', 'Dummy']
    out_data = [out_header]

    # xlsxを読んで支店番号と口座番号を取得
    df = pd.read_excel(file_name, sheet_name=sheet_name, header=51)
    for index, row in df.iterrows():

        # 1.処理対象=1でなければ処理対象外
        taishoo_flg = str(row[15])
        if len(taishoo_flg) == 0:
            continue

        try:
            int_taishoo_flg = int(float(taishoo_flg))
            str_taishoo_flg = str(int_taishoo_flg)
        except Exception as e:
            #LOGGER.info(rf'@@@@@ 数字じゃない @@@@@')
            continue

        if len(str_taishoo_flg) != 1:
            continue

        if str_taishoo_flg != "1":
            continue

         # 2.支店番号チェック
         # 支店番号 "231.0"なので"230"に補正
        branch_code    = str(row[1])
        if len(branch_code) == 0:
            continue

        try:
            int_branch_code = int(float(branch_code))
            branch_code = str(int_branch_code)
        except Exception as e:
            #LOGGER.info(rf'@@@@@ 数字じゃない @@@@@')
            continue

        if len(branch_code) != 3:
            continue

        # 3.口座番号チェック
        account_number = str(row[2])
        match = re.search(r'\d{7}', account_number)
        if match:
            extracted_number = match.group()
            account_number = str(extracted_number)
            # LOGGER.info(f"@@@@@ extracted_number : {extracted_number}")

        if len(account_number) != 7:
            continue

        #  下記にPhxxの記載のあるフェーズは対応済
        # Ph1.5 : メルマネマスペ	4
        # Ph1.0 : マスペイメント	1 
        #       : メルマネ・マスペ・プラス	5
        #       : 給与賞与振込	6
        # Ph1.0 : 自動引落	2 
        # Ph1.0 : 自動引落(処理済件数）	2 
        #       : 自動引落（振込のみ）	!
        #       : マルチペイメント（ペイジー）	!

        service_kind = str(row[4])
        if service_kind != "マスペイメント" and \
           service_kind != "自動引落" and \
           service_kind != "自動引落(処理済件数）" and \
           service_kind != "メルマネ・マスペ・プラスＸＸＸＸＸＸ" and \
           service_kind != "メルマネマスペ":
            continue

        # LOGGER.info(f"@@@@@ X service_kind : {service_kind}")


        # 請求書番号 請求書番号:H177形式の4桁 + α(4桁以内に注釈)でなければクリア
        seikyuu_no = str(row[10])
        if len(seikyuu_no) >= 4 + 4:
            seikyuu_no = ""

        # サービス種別を設定する(記号！は下記にない。要追加)
        if service_kind == rf"メルマネマスペ":
            WebDriverWait(browser, 60.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "/html/body/form/table/tbody/tr[1]/td/select/option[6]"))).click()
        elif service_kind == rf"マスペイメント":
            WebDriverWait(browser, 60.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "/html/body/form/table/tbody/tr[1]/td/select/option[1]"))).click()
        elif service_kind == rf"メルマネ・マスペ・プラス"  :
            WebDriverWait(browser, 60.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "/html/body/form/table/tbody/tr[1]/td/select/option[7]"))).click()
        elif service_kind == rf"給与賞与振込"  :
            WebDriverWait(browser, 60.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "/html/body/form/table/tbody/tr[1]/td/select/option[4]"))).click()
        elif service_kind == rf"自動引落"  :
            WebDriverWait(browser, 60.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "/html/body/form/table/tbody/tr[1]/td/select/option[2]"))).click()
        elif service_kind == rf"自動引落(処理済件数）"  :
            WebDriverWait(browser, 60.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "/html/body/form/table/tbody/tr[1]/td/select/option[2]"))).click()
        else:
            continue

        # 振替実施日を設定する ※自動引落のみ年入力可
        # 開始年
        if service_kind == r"自動引落" or \
           service_kind == r"自動引落(処理済件数）"  :
            set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[2]/td[1]/input[1]"), start_date_list[0])

        # 開始月、開始日
        # if service_kind == r"メルマネ・マスペ・プラス"  :
        #     set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[2]/td[1]/input[2]"), start_date_list2[1])
        #     set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[2]/td[1]/input[3]"), start_date_list2[2])
        # else:
        #     set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[2]/td[1]/input[2]"), start_date_list[1])
        #     set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[2]/td[1]/input[3]"), start_date_list[2])
        set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[2]/td[1]/input[2]"), start_date_list[1])
        set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[2]/td[1]/input[3]"), start_date_list[2])



        # 終了年
        if service_kind == r"自動引落" or \
           service_kind == r"自動引落(処理済件数）"  :
            set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[2]/td[1]/input[1]"), end_date_list[0])
            set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[2]/td[1]/input[4]"), end_date_list[0])

        # 終了月、終了日
        set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[2]/td[1]/input[5]"), end_date_list[1])
        set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[2]/td[1]/input[6]"), end_date_list[2])


        # 支店番号
        set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[3]/td[1]/input"), branch_code)

        # 口座番号
        set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[4]/td[1]/input"), account_number)


        # 「検索」を押す
        # WebDriverWait(browser, 1000.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "//input[@type='button' and @value='検　索']"))).click()
        # browser.implicitly_wait(3000.0)
        # ページロード自体のタイムアウトを3000秒に設定（これが最も重要です）
        browser.set_page_load_timeout(5000)
        try:
            WebDriverWait(browser, 30).until(expected_conditions.element_to_be_clickable((By.XPATH, "//input[@type='button' and @value='検　索']"))).click()
        except Exception as e:
            LOGGER.info(rf'@@@@@ 検索で例外だよ {e} @@@@@')


        # # 検索結果画面 start---------------------------------------------------------------- 

        # スクリーンショットを取得する
        str_screenshot_name = f"{branch_code}-{account_number}-{seikyuu_no}"
        # 格納フォルダを振り分ける
        if service_kind == r"メルマネマスペ" :
            sub_forder = r"メルマネマスペ"
        elif service_kind == r"マスペイメント"  :
            sub_forder = r"マスペイメント"
        elif service_kind == r"メルマネ・マスペ・プラス"  :
            sub_forder = r"メルマネ・マスペ・プラス"
        elif service_kind == r"給与賞与振込"  :
            sub_forder = r"給与賞与"
        elif service_kind == r"自動引落"  :
            sub_forder = r"自動引落"
        elif service_kind == r"自動引落(処理済件数）"  :
            sub_forder = r"自動引落"
        elif service_kind == r"マルチペイメント"  :
            sub_forder = r"マルチペイメント"
        else:
            sub_forder = r"その他"
        create_folder(rf"{screen_save_name}\{sub_forder}")

        # browser.save_screenshot(rf"{screen_save_name}\{sub_forder}\{str_screenshot_name}.png")

        # # 1ページ単位の処理
        # current_pos_total = 0
        irai_sum = 0
        shori_sum = 0
        plus_sum_1 = 0
        plus_sum_2 = 0
        plus_sum_3 = 0
        plus_sum_4 = 0

        current_page_count = 0
        while True:

            current_page_count += 1

            # --loop終了条件--
            browser.implicitly_wait(1300.0)
            th: WebElement = browser.find_element(By.XPATH, "//th[contains(text(), '件中') and contains(text(), '件を表示しています')]")
            # th: WebElement = WebDriverWait(browser, 50000.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "//th[contains(text(), '件中') and contains(text(), '件を表示しています')]"))).click()
            counts = re.findall(r"全(\d+)件中(\d+)-(\d+)件を表示しています", th.text)[0]

            (total_count, display_current_pos_from, display_current_pos_to) = (int(count) for count in counts)
            # LOGGER.info(rf"total:{total_count}, start:{display_current_pos_from}, ends:{display_current_pos_to}")
            # --loop終了条件--

            # tbodyを取得
            tbody = browser.find_element(By.XPATH, f"/html/body/div/form/table[2]/tbody")

            # rowsを取得（ヘッダーのみの場合は3となる）
            tbody_rows =  tbody.find_elements(By.TAG_NAME, "tr")


            date_range = rf"{start_date_list[0]}{start_date_list[1]}{start_date_list[2]}-{end_date_list[0]}{end_date_list[1]}{end_date_list[2]}"

            browser.save_screenshot(rf"{screen_save_name}\{sub_forder}\{str_screenshot_name}-{current_page_count}-{date_range}.png")

            # LOGGER.info(f"\n")
            LOGGER.info(f"@ {str_screenshot_name}-{service_kind} : {total_count} 件")
            LOGGER.info(rf"total:{total_count}, start:{display_current_pos_from}, ends:{display_current_pos_to}")
            # LOGGER.info(rf"tbody_rows:{len(tbody_rows)}")

            if len(tbody_rows) <= DISPLAY_POS:
            #    total_count == 0:
                # LOGGER.info(rf'@@@@@ 処理対象がないため終了します... @@@@@')
                break

            details_tbody  = browser.find_element(By.XPATH, f"/html/body/div/form/table[2]")
            html = details_tbody.get_attribute('outerHTML')
            df_list = pd.read_html(html, header=None)
            internal_table = df_list[0]
            # 先頭２行を削除して、３行目以降のデータを取得する場合は以下。ただし、上記の"header=None"で除去される様子
            # internal_table = df_list[0].iloc[2:]

            time.sleep(2)

            # 依頼件数、処理件数を合計(サービス種別により表示位置が異なる)
            if service_kind == r"メルマネマスペ" :
                irai_sum = \
                irai_sum + internal_table.loc[internal_table.iloc[:, 14] == "終了", internal_table.columns[9]].sum()
                shori_sum = \
                shori_sum + internal_table.loc[internal_table.iloc[:, 14] == "終了", internal_table.columns[10]].sum()
            elif service_kind == r"マスペイメント"  :
                irai_sum = \
                irai_sum + internal_table.loc[internal_table.iloc[:, 13] == "終了", internal_table.columns[9]].sum()
                shori_sum = \
                shori_sum + internal_table.loc[internal_table.iloc[:, 13] == "終了", internal_table.columns[10]].sum()
            elif service_kind == r"メルマネ・マスペ・プラス"  :
                # wk_Filter_yyyymm

                # 請求明細には４通りあるが、AKSのソース確認したら以下の３つだけだった。なので４つ目はゼロのまま。
                # 他行受取ＯＫ　送金人手数料負担
                # 他行受取不可　送金人手数料負担
                # 他行受取ＯＫ　受取人手数料負担

                plus_sum_1 = plus_sum_1 + internal_table.loc[
                    (internal_table.iloc[:, 16] == "終了") & 
                    (internal_table.iloc[:, 14].astype(str).str.contains("他行受取ＯＫ　送金人手数料負担")) &
                    (internal_table.iloc[:, 10].astype(str).str.contains(wk_Filter_yyyymm)),
                    internal_table.columns[11]
                ].sum()
                LOGGER.info(f"@@@@@ service_kind : {service_kind}")
                LOGGER.info(f'@@@@@ plus_sum_1 : {plus_sum_1}')

                plus_sum_2 = plus_sum_2 + internal_table.loc[
                    (internal_table.iloc[:, 16] == "終了") & 
                    (internal_table.iloc[:, 14].astype(str).str.contains("他行受取不可　送金人手数料負担")) &
                    (internal_table.iloc[:, 10].astype(str).str.contains(wk_Filter_yyyymm)),
                    internal_table.columns[11]
                ].sum()
                LOGGER.info(f"@@@@@ service_kind : {service_kind}")
                LOGGER.info(f'@@@@@ plus_sum_2 : {plus_sum_2}')

                plus_sum_3 = plus_sum_3 + internal_table.loc[
                    (internal_table.iloc[:, 16] == "終了") & 
                    (internal_table.iloc[:, 14].astype(str).str.contains("他行受取ＯＫ　受取人手数料負担")) &
                    (internal_table.iloc[:, 10].astype(str).str.contains(wk_Filter_yyyymm)),
                    internal_table.columns[11]
                ].sum()
                LOGGER.info(f"@@@@@ service_kind : {service_kind}")
                LOGGER.info(f'@@@@@ plus_sum_3 : {plus_sum_3}')


            elif service_kind == r"給与賞与振込"  :
                irai_sum = 0
                shori_sum = 0
            elif service_kind == r"自動引落" or\
                 service_kind == r"自動引落(処理済件数）" :
                irai_sum = \
                irai_sum + internal_table.loc[internal_table.iloc[:, 16] == "終了", internal_table.columns[10]].sum()
                shori_sum = \
                shori_sum + internal_table.loc[internal_table.iloc[:, 16] == "終了", internal_table.columns[12]].sum()
            else:
                irai_sum = 0
                shori_sum = 0

            # LOGGER.info(f"@@@@@ service_kind : {service_kind}")
            # LOGGER.info(rf'---------------------- irai_sum : {irai_sum}')
            # LOGGER.info(rf'---------------------- shori_sum : {shori_sum}')

            # LOGGER.info(rf'***** {total_count}-{display_current_pos_to}')
            # loop終了を判定
            if  total_count <= display_current_pos_to :
                break

            # 「次」を押す
            time.sleep(2)
            # WebDriverWait(browser, 1000.0).until(expected_conditions.element_to_be_clickable((By.LINK_TEXT, "次>>"))).click()
            browser.set_page_load_timeout(5000)
            try:
                WebDriverWait(browser, 30.0).until(expected_conditions.element_to_be_clickable((By.LINK_TEXT, "次>>"))).click()
            except Exception as e:
                LOGGER.info(rf'@@@@@ 次へで例外だよ {e} @@@@@')


        # JINOSに処理させない時はこのフラグを1にするために設けた
        taishoo_gai_flg = 0
        # if len(seikyuu_no) != 4:
        #     taishoo_gai_flg = 1
        # if irai_sum == 0 and\
        #    shori_sum == 0:
        #     taishoo_gai_flg = 1

        # 出力イメージを配列に格納
        out_data.append([branch_code, account_number, seikyuu_no, irai_sum, shori_sum, service_kind, taishoo_gai_flg,plus_sum_1,plus_sum_2,plus_sum_3,plus_sum_4 ])

        WebDriverWait(browser, 300.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "//input[@type='BUTTON' and @value='戻　る']"))).click()

    browser.close()


    # for row in out_data:
    #     print(row)

    out_file_prefix = rf"{start_date_list[0]}{start_date_list[1]}{start_date_list[2]}-{end_date_list[0]}{end_date_list[1]}{end_date_list[2]}-out"

    # 出力結果はinputと同じ場所に格納
    out_folder_path = extract_folder_path(file_name)
    # csvで保存 
    save_to_csv(out_data, rf"{out_folder_path}\{out_file_prefix}.csv")
    # xlsxで保存 
    tmp_df = pd.DataFrame(out_data)
    tmp_df.to_excel(rf"{out_folder_path}\{out_file_prefix}.xlsx", index = False, header=False)

    return

    # # ---------------------------------------------------------------------------
    # try:
    #     # メニュー画面に戻る
    #     browser.find_element(By.XPATH, "//input[@type='button' and @value='戻　る']").click()

    #     # 「法人管理」を押す
    #     WebDriverWait(browser, 10.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "/html/body/form/table/tbody/tr[1]/td[1]/table/tbody/tr/td/span/div"))).click()

    #     # 「口座検索」を押す
    #     WebDriverWait(browser, 10.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "//input[@type='BUTTON' and @value='口座検索']"))).click()

    #     browser.close()

    # except Exception as e:
    #         LOGGER.info(rf'@@@@@ 処理対象がないため終了します(2/2)... @@@@@')

    # return


if __name__ == "__main__":
    LOGGER.info("starts")
    main()
    LOGGER.info("ends")

