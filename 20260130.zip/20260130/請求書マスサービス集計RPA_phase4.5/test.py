import calendar
from datetime import datetime, timedelta

def f_get_otherFirstDate(date_str, diff_months, date_kbn):
    # parse input date string
    year, month, day = map(int, date_str.split('/'))
    # 計算する月
    new_month = month + diff_months

    # 年の繰り上げ・繰り下げ処理
    new_year = year + (new_month - 1) // 12
    new_month = (new_month - 1) % 12 + 1
    wk_from = f"{new_year}/{new_month}/1"

    # date_strの月末日
    last_day_of_target_month = calendar.monthrange(year, month)[1]
    out_to_date_str = f"{year}/{month}/{last_day_of_target_month}"

    # wk_fromの年末日
    last_day_wk_year = f"{new_year}/12/31"

    # wk_fromの年(yyyy)とdate_strの年(yyyy)の比較
    if new_year == year:
        out_from = wk_from
        out_to = out_to_date_str
        split_required = 0
    else:
        if date_kbn == 1:
            out_from = wk_from
            out_to = last_day_wk_year
        elif date_kbn == 2:
            # 年末日の次の日
            dt = datetime(new_year, 12, 31) + timedelta(days=1)
            out_from = f"{dt.year}/{dt.month}/{dt.day}"
            out_to = out_to_date_str
        else:
            raise ValueError("date_kbn must be 1 or 2")
        split_required = 1

    return split_required, out_from, out_to


def main():
    # テストケースは１個のみ
    # date_str, diff, date_kbn = "2025/12/1", -2, 1
    # date_str, diff, date_kbn = "2026/1/1", -2, 2
    date_str, diff, date_kbn = "2026/2/1", -2, 2
    split_required, out_from, out_to = f_get_otherFirstDate(date_str, diff, date_kbn)
    print(
        f"f_get_otherFirstDate('{date_str}', {diff}, {date_kbn}) => split_required: {split_required}, out_from: {out_from}, out_to: {out_to}"
    )


if __name__ == "__main__":
    main()
