import pandas as pd
import math

def clean_excel_value_full(value):
    """
    NaN, NaT, None, "nan" などのゴミを排除し、完全な空文字を返す
    """
    # 1. pandasのisna()を使うのが最も確実 (NaNとNaTの両方を検知可能)
    if pd.isna(value):
        return ""
    
    # 2. 文字列としての "nan" や "nat" のチェック
    val_str = str(value).lower().strip()
    if val_str in ["nan", "nat"]:
        return ""
    
    # 3. 正常なデータは文字列にして返す
    return str(value)

# ゴミを排除します。
def main():
    # テストデータ（NaN, NaT, None, 文字列のゴミ、正常値）
    test_cases = [
        pd.NA,           # pandas独自の欠損値
        pd.NaT,          # 日付の欠損値
        float('nan'),    # 数値の欠損値
        None,            # None型
        "NaT",           # 文字列としてのNaT
        "2026/02/11",    # 正常な日付文字列
        12345            # 正常な数値
    ]
    
    print(f"{'入力データの種類':<20} | {'結果':<10}")
    print("-" * 40)
    
    for case in test_cases:
        result = clean_excel_value_full(case)
        label = f"{type(case).__name__}"
        print(f"{label:<20} | '{result}'")

if __name__ == "__main__":
    main()
