def format_to_integer_string(value_str):
    """
    "12345.0" のような文字列を "12345" に変換して返す
    """
    try:
        # 一旦 float として読み込み、int にキャストすることで小数点以下を切り捨てる
        num = int(float(value_str))
        return str(num)
    except (ValueError, TypeError) as e:
        return f"エラー: 無効な入力です ({e})"

# 小数点以下を切り捨てます。
def main():
    # 様々なパターンのテストデータ
    test_cases = [
        "12345.0",
        "98765.99",   # 切り捨ての確認
        "100",        # 最初から整数の文字列
        "-50.5",      # 負の数
        "abc"         # エラーケース
    ]
    
    print(f"{'入力文字列':<15} | {'変換後':<10}")
    print("-" * 30)
    
    for case in test_cases:
        result = format_to_integer_string(case)
        print(f"{case:<15} | {result:<10}")

    result = format_to_integer_string("12345.0")
    print(f"12345.0 -> {result}")



if __name__ == "__main__":
    main()