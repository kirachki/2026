# -*- coding: utf-8 -*-

"""
Created on Mon April 16 15:19:19 2024
@author: hidtoshi.kurosu@rakuten-bank.co.jp
"""
# standard libraries
import configparser
import csv
import re
import datetime
import logging
import os
import re
from typing import Dict, List, Optional, Union
import time
import pandas as pd
import sys
import time
import pytz

# 3rd parties' libraries
import pandas as pd
import selenium
# import pyperclip
from datetime import datetime, timedelta
from datetime import datetime

from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.firefox.service import Service
from selenium.webdriver.firefox.options import Options

from bs4 import BeautifulSoup


# constants
formatter: logging.Formatter = logging.Formatter("%(asctime)s %(name)s:%(lineno)s %(funcName)s [%(levelname)s]: %(message)s")
LOGGER: logging.Logger = logging.getLogger(__name__)
handler: logging.Handler = logging.StreamHandler()
handler.setFormatter(formatter)
handler.setLevel(logging.DEBUG)
LOGGER.setLevel(logging.DEBUG)
for _handler in LOGGER.handlers:
    LOGGER.removeHandler(_handler)
LOGGER.addHandler(handler)
LOGGER.propagate = False

BASE_PATH: str = os.path.dirname(__file__)

CONFIG_INI = configparser.ConfigParser(interpolation=configparser.ExtendedInterpolation())
CONFIG_INI_PATH: str = os.path.splitext(__file__)[0] + ".conf"
assert os.path.exists(CONFIG_INI_PATH)
CONFIG_INI.read(CONFIG_INI_PATH, encoding="utf-8")
DEFAULT = CONFIG_INI["DEFAULT"]

INFO_FILE_PATH: str = os.path.join(BASE_PATH, DEFAULT.get("INFO_CSV_FILE"))

AKS_URL: str = DEFAULT.get("AKS_URL")

CHROME_DRIVER: str = os.path.join(BASE_PATH, DEFAULT.get("CHROME_DRIVER"))
IE_DRIVER: str = os.path.join(BASE_PATH, DEFAULT.get("IE_DRIVER"))
FF_DRIVER: str = os.path.join(BASE_PATH, DEFAULT.get("FF_DRIVER"))

WEB_DRIVER: str = DEFAULT.get("WEB_DRIVER")
# WEB_DRIVER: str = DEFAULT.get("WEB_DRIVER")
assert WEB_DRIVER in ("CHROME", "IE", "FF")
DISPLAY_POS:int = 3
DELIMITER="\t"
SEP = ","
CONST_TARGET_TEXT = rf"（H）　法人サポート"

# グローバル変数を定義
filtered_df = None # 置換文字列パラメータ設定エクセル
pdf_save_dir = None

def set_text(text_input: WebElement, text: str) -> None:
    #text_input.send_keys(Keys.CONTROL + "a")
    #text_input.send_keys(Keys.DELETE)
    text_input.clear()
    text_input.send_keys(text)
    return

def get_webdriver_object() -> Union[webdriver.Chrome, webdriver.Ie, webdriver.Firefox]:
    global CHROME_DRIVER, IE_DRIVER, FF_DRIVER
    global WEB_DRIVER
    if selenium.__version__.startswith("4."):
        if WEB_DRIVER == "CHROME":
            assert os.path.exists(CHROME_DRIVER)
            chrome_service = webdriver.chrome.service.Service(executable_path=CHROME_DRIVER)
            browser = webdriver.Chrome(service=chrome_service)
        elif WEB_DRIVER == "IE":
            assert os.path.exists(IE_DRIVER)
            ie_service = webdriver.ie.service.Service(executable_path=IE_DRIVER)
            browser = webdriver.Ie(service=ie_service)
        elif WEB_DRIVER == "FF":
            assert os.path.exists(FF_DRIVER)
            ff_service = webdriver.firefox.service.Service(executable_path=FF_DRIVER)

            # ff_options = webdriver.FirefoxOptions()
            ff_options = Options()
            ff_options.binary_location = "C:/Program Files/Mozilla Firefox/firefox.exe"

            # Firefoxのオプションを設定
            global pdf_save_dir
            ff_options.set_preference("browser.download.folderList", 2)  # 2: 指定したフォルダ
            ff_options.set_preference("browser.download.dir", pdf_save_dir)
            ff_options.set_preference("browser.helperApps.neverAsk.saveToDisk", "application/pdf")  # PDFのMIMEタイプ
            ff_options.set_preference("pdfjs.disabled", True)  # PDFビューアを無効にする

            # ダウンロード確認ダイアログを抑止
            ff_options.set_preference("browser.download.panel.shown", False)
            ff_options.set_preference("browser.download.panel.defaultSession", True)
            ff_options.set_preference("browser.download.useDownloadDir", True)
            ff_options.set_preference("browser.download.manager.showAlertOnComplete", False)
            ff_options.set_preference("browser.download.manager.showWhenStarting", False)
            ff_options.set_preference("browser.download.manager.focusWhenStarting", False)
            ff_options.set_preference("browser.download.manager.closeWhenDone", True)

            browser = webdriver.Firefox(service=ff_service, options=ff_options)
        # end of if
    elif selenium.__version__.startswith("3."):
        if WEB_DRIVER == "CHROME":
            browser = webdriver.Chrome(executable_path=CHROME_DRIVER)
        elif WEB_DRIVER == "IE":
            browser = webdriver.Ie(executable_path=IE_DRIVER)
        elif WEB_DRIVER == "FF":
            browser = webdriver.Firefox(executable_path=FF_DRIVER)
        # end of if
    else:
        raise f"Unknown selenium version: {selenium.__version__}"
    # end of if
    return browser

def create_folder(folder_path) -> None:
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)

def save_to_csv(data, output_file):
    with open(output_file, 'w', newline='') as f:
        writer = csv.writer(f)
        for row in data:
            writer.writerow(row)

def extract_folder_path(full_path):
    foler_path, _ = os.path.split(full_path)
    return foler_path

def wait_for_window(driver, window_handles,timeout=2000):
    time.sleep(round(timeout / 1000))
    wh_now = driver.window_handles
    wh_then = window_handles
    if len(wh_now) > len(wh_then):
        return set(wh_now).difference(set(wh_then)).pop()


def make_Filter_Execl(file_path,sheet_name):
    global filtered_df
    # Excelファイルを読み込んでデータフレームに変換
    df = pd.read_excel(file_path, sheet_name=sheet_name, header=0)
    # フィルタリング可能な形式で内部に保管
    filtered_df = df

# -------------------------------------------------------------------
# (DL:delete line) 
# 対象文字列を発見した行を削除
# -------------------------------------------------------------------
def delete_lines(val_A, target_string, account_type, position, p_account_type):
    modified_val_A = []
    line_pos = 0
    for line in val_A.splitlines():
        line_pos += 1
        if target_string in line and \
            (account_type == "" or account_type == p_account_type) and \
            (position == "" or int(position) == line_pos):
            continue
        modified_val_A.append(line) 
    return '\n'.join(modified_val_A)


# -------------------------------------------------------------------
# (DF:delete from targer) 
# 対象文字列を含め以降の文字列をすべて削除（行は削除しない）
# -------------------------------------------------------------------
def replace_target_strings(val_A, target_string, account_type, position, p_account_type):
    modified_val_A = []
    line_pos = 0
    for line in val_A.splitlines():
        line_pos += 1
        if target_string in line and \
            (account_type == "" or account_type == p_account_type) and \
            (position == "" or int(position) == line_pos):
            line = line.split(target_string)[0]  # 置換対象文字列以降を削除
        modified_val_A.append(line)  # 行そのものは削除せず、修正された行を保持
    return '\n'.join(modified_val_A)  # 結果を単一の文字列として返す

# -------------------------------------------------------------------
# (DT:delete targer) 
# 対象文字列のみを削除
# -------------------------------------------------------------------
def remove_target_strings(val_A, target_string, account_type, position, p_account_type):
    modified_val_A = []
    line_pos = 0
    for line in val_A.splitlines():
        line_pos += 1
        # if target_string in line and \
        if  (account_type == "" or account_type == p_account_type) and \
            (position == "" or int(position) == line_pos):
            line = line.replace(target_string, "")  # target_chars のみを削除
        modified_val_A.append(line)
    return "\n".join(modified_val_A)

# -------------------------------------------------------------------
# (CT:change target)
# 対象文字列を置換文字列に置換
# -------------------------------------------------------------------
def change_target_strings(val_A, target_string, replace_string, account_type, position, p_account_type):
    modified_val_A = []
    line_pos = 0
    for line in val_A.splitlines():
        line_pos += 1
        if  (account_type == "" or account_type == p_account_type) and \
            (position == "" or int(position) == line_pos):
            line = line.replace(target_string, replace_string)
        modified_val_A.append(line)
    return "\n".join(modified_val_A)

# -------------------------------------------------------------------
# (DB:delete blank)
# 先頭空白行を削除 
# 最終的整形で使用する無条件実行のためパラメータ指定はなし（非公開メソット）
# -------------------------------------------------------------------
def remove_leading_newlines(val_A):
    lines = val_A.splitlines()
    while lines and lines[0].strip() == "":
        lines.pop(0)
    return lines

# -------------------------------------------------------------------
# (AR, AL) 
# 指定位置に文字列連結
# -------------------------------------------------------------------
def concat_with_order(val_A, target_string, direction: str, account_type, position, p_account_type):
    # val_A を文字列として処理するために必要な変換を行う
    if isinstance(val_A, list):
        val_A = "\n".join(val_A)
    lines = val_A.splitlines()

    modified_lines = []
    line_pos = 0

    # この関数ではpositionは必須パラメータであるため、未指定の場合は「1」と見做す。
    if position == "":
        position = "1"

    for i, line in enumerate(lines):
        line_pos += 1

        if direction == 'AL' and \
            (account_type == "" or account_type == p_account_type) and \
            (int(position) == line_pos):
            modified_lines.append(target_string + line)
        elif direction == 'AR' and \
            (account_type == "" or account_type == p_account_type) and \
            (int(position) == line_pos):
            modified_lines.append(line + target_string)
        else:
            modified_lines.append(line)

    return "\n".join(modified_lines)


# -------------------------------------------------------------------
# 文字列をパラメータで指示された内容で編集する
# -------------------------------------------------------------------
def edit_string(value_to_filter, val_A, p_account_type):
    global filtered_df
    if filtered_df is not None:
        # 最初の列が指定された値に一致する行をフィルタリング
        filtered_result = filtered_df[filtered_df.iloc[:, 0] == value_to_filter]

        for row in filtered_result.iloc[:, [1, 2, 3, 4, 5]].values:
            edit_action = row[0] # 編集アクション
            target_value = row[1] # ターゲット文字列
            replace_value = row[2] # 置換文字列
            account_type = row[3] # 口座種別(P, C, B)
            position = row[4] # ポジション

            # 置換設定パラメータエクセルから取得した値を補正（"nan"、"-"と入っていたりするので補正する）
            if replace_value is None or pd.isna(replace_value) or replace_value == "-":
                replace_value = ""
            if account_type is None or pd.isna(account_type):
                account_type = ""
            if position is None or pd.isna(position):
                position = ""

            # print(f"Action:{edit_action}, Target:{target_value}, Replace:{replace_value}, Type:{account_type}, Position:{position}")

            # val_A を文字列として処理するために必要な変換を行う
            if isinstance(val_A, list):
                val_A = "\n".join(val_A)

            # 1.(DL:delete line) 対象文字列を発見した行を削除 
            if edit_action == "DL":
                val_A = delete_lines(val_A, target_value, account_type, position, p_account_type)

            # 2.(DF:delete from target) 対象文字列を含め以降の文字列をすべて削除（行は削除しない）
            if edit_action == "DF":
                val_A = replace_target_strings(val_A, target_value, account_type, position, p_account_type)

            # 3.(DT:delete target) 対象文字列のみを削除 
            if edit_action == "DT":
                val_A = remove_target_strings(val_A, target_value, account_type, position, p_account_type)

            # 4.(CT:change target) 対象文字列のみを削除 
            if edit_action == "CT":
                val_A = change_target_strings(val_A, target_value, replace_value, account_type, position, p_account_type)

            # 5.(DB:delete blank) 先頭空白のみの行を削除 ※ 無条件実行なのでパラメータ指定なし
            val_A = remove_leading_newlines(val_A)

            # 6.(AR, AL) 指定位置に文字列連結
            if edit_action == "AL" or edit_action == "AR":
                val_A = concat_with_order(val_A, target_value, edit_action, account_type, position, p_account_type)
    else:
        print("データがロードされていません。まず make_Filter_Execl を実行してください。")
    
    # 最終的な val_A の値を返却
    return val_A

def get_account_type(account_number: str) -> str :
    first_digit = account_number[0]

    if first_digit in ['1', '2', '3', '4']:
        return 'P' # 個人
    elif first_digit in ['5', '6']:
        return 'B' # B個
    elif first_digit in ['7', '8']:
        return 'C' # 法人
    elif first_digit in ['9']:
        return 'O' # 別段
    else:
        return 'Unknown'

def get_utc2jst() -> datetime :
    try:
        # 日時を取得し、JSTに変換
        now_utc = datetime.now(pytz.utc)
        now_jst = now_utc.astimezone(pytz.timezone('Asia/Tokyo'))
        now_jst_formatted = now_jst.strftime('%Y-%m-%d %H:%M:%S')
        return now_jst_formatted
    except Exception as e:
        logging.error('Exception occuer in get_utc2jst:', e)

# 顧客対応履歴のタイトルから第二引数の値を検索する。
# def find_date_by_title(table, target_title):
#     try:
#         # 2行目以降のデータを格納するリスト
#         data = []

#         # テーブルの行を取得
#         rows = table.find_all("tr")[1:]  # 1行目はヘッダーなのでスキップ

#         # LOGGER.info(rf'@@@@@ find_date_by_title 1 @@@@@')

#         for row in rows:
#             cols = row.find_all("td")
#             cols = [col.get_text(strip=True) for col in cols]
#             data.append(cols)

#         target_row_value = None

#         # LOGGER.info(rf'@@@@@ find_date_by_title 2 @@@@@')

#         # 最終行から探す(2回目以降は"【再送】"を付加しているので仕様変更
#         for i in range(len(data) - 1, -1, -1):
#             # if len(data[i]) >= 7 and data[i][6] == target_title):
#             if len(data[i]) >= 7 and (data[i][6] == target_title or data[i][6] == "【再送】" + target_title):
#                 target_row_value = data[i][2]
#                 break

#         # LOGGER.info(rf'@@@@@ find_date_by_title 3 @@@@@')


#         # LOGGER.info(f" *** target_title : {target_title}")
#         # LOGGER.info(f" *** target_row_value : {target_row_value}")
#         # print(data)

#         if target_row_value:
#             # target_row_valueを含むを探す
#             for row in data:

#                 if target_row_value in row[6]:
#                     # LOGGER.info(rf'@@@@@ then 1 @@@@@')
#                     # print(row[2])
#                     # print(row[3])
#                     # print(row[6])
#                     return row[3]

#         # LOGGER.info(rf'@@@@@ find_date_by_title 4 @@@@@')

#         return None

#     except Exception as e:
#         logging.error('Exception occuer in find_date_by_title:', e)



# 送信に対する返信がxxx日以内かどかをチェックする
def is_within_period(date_str, days):
    try:

        LOGGER.info(f"date_str : {date_str} ")
        LOGGER.info(f"days : {days} ")

        # 現在の日付を取得
        current_date = datetime.now()

        # LOGGER.info(rf'@@@@@ is_within_period 1 @@@@@')

        # 指定された日付をdatetimeオブジェクトに変換
        target_date = datetime.strptime(date_str, "%Y/%m/%d %H:%M:%S")

        # LOGGER.info(rf'@@@@@ is_within_period 2 @@@@@')

        # 指定された日数前の日付を計算
        # period_start_date = current_date - timedelta(days=days)
        period_start_date = current_date - timedelta(days=int(days))

        # LOGGER.info(rf'@@@@@ is_within_period 3 @@@@@')

        # 判定
        if target_date >= period_start_date:
            return 0
        else:
            return 1

    except Exception as e:
        logging.error('Exception occuer in is_within_period:', e)
        return -1



# 承認者一覧画面で第二引数で指定された名前を探す。
def find_row_index(table, search_string):
    rows = table.find_all("tr")[1:]  # 1行目はヘッダーなのでスキップ
    search_string = search_string.replace("\u3000"," ")

    for idx, row in enumerate(rows):
        cols = row.find_all("td")
        if len(cols) > 1 :
            target_string = cols[1].get_text(strip=True).replace("\u3000"," ")
            if search_string in target_string:
                return idx + 1  # ヘッダーをスキップしているので+1で実際の行番号を返す

    return -1  # 該当する行がない場合

# ==========================================================================================
def scan_table_by_date(p_idx, p_data,p_target_callNo,  p_span):

    LOGGER.info(f"\n")
    LOGGER.info(f" *** p_idx: {p_idx}")
    LOGGER.info(f" *** p_callNo: {p_target_callNo}")

    try:
        # for i in range(1, len(p_data)):
        for i in range(0, p_idx):
            row = p_data[i]

            # LOGGER.info(f" ** row[6]: {row[6]}")


            if str(p_target_callNo) in str(row[6]):
                # print(row[2])
                # print(row[3])
                # print(row[6])
                LOGGER.info(f" *** i    : {i}")
                LOGGER.info(f" *** date: {row[3]}")

                date = row[3]

                if date:

                    # 関数を呼び出して結果を取得（result=0であれば指定範囲内）
                    result = is_within_period(date, p_span)
                    if result == 0:
                        LOGGER.info(f"{date} は過去 {p_span} 日以内です。")
                        return 0
                    else:
                        LOGGER.info(f"{date} は過去 {p_span} より過去です。")
                        return 1
                else:
                    LOGGER.info(f"直近で当行からメールした履歴が見つかりませんでした。")
                    return 9

        return 9


    except Exception as e:
        logging.error('Exception occuer in scan_table_by_date:', e)



# 顧客対応履歴のタイトルから第二引数の値を検索する。
def scan_table_by_Keyword(table, target_title, p_span):

    try:

        # 2行目以降のデータを格納するリスト
        data = []

        # テーブル（list of DataFrame）の最初のDataFrameを取得し、行データをリスト化
        # rows = table[0].values.tolist()[1:]  # 1行目はヘッダーなのでスキップ
        rows = table.find_all("tr")[1:]  # 1行目はヘッダーなのでスキップ

        # for row in rows:
        #     # rowsはlist（DataFrameの各行の値リスト）なので、そのまま追加
        #     data.append(row)
        for row in rows:
            cols = row.find_all("td")
            cols = [col.get_text(strip=True) for col in cols]
            data.append(cols)

        # 最初から探す (2回目以降は"【再送】"を付加しているので仕様変更)
        target_row_value = None  # 初期化を追加
        for i in range(len(data)):

            if len(data[i]) >= 7 and (data[i][6] == target_title or data[i][6] == "【再送】" + target_title):

                p_target_callNo = data[i][2]
                p_target_title = data[i][6]

                # LOGGER.info(f" *** p_idx: {i}")
                # LOGGER.info(f" *** p_callNo: {p_target_callNo}")


                # # tableと検索文字列を指定して、行のインデックスを取得
                return_value = scan_table_by_date(i, data,p_target_callNo,  p_span )
                LOGGER.info(f" *** rtn : {return_value}")

                # match return_value:
                #     case 0:
                #         # 期限内に有効回答あり（メール送信しない）
                #         return 0
                #     case 1:
                #         # 期限外有効回答あり（メール送信する）
                #         return 1    
                #     case 9:
                #         # 回答なし
                #         pass

                if return_value == 0:
                    # 期限内に有効回答あり（メール送信しない）
                    return 0
                elif return_value == 1:
                    # 期限外有効回答あり（メール送信する）
                    return 1    
                elif return_value == 9:
                        # 回答なし
                        pass


            # 日付がp_spanを超過していたら終了
            date = data[i][3]
            result = is_within_period(date, p_span)
            if result != 0:
                LOGGER.info(f"\n")
                LOGGER.info(f"{date} は過去 {p_span} より過去ですね。そもそも")
                LOGGER.info(f"{i} ですね。その時の行番号は")
                return 9

        
        return 9

    except Exception as e:
        logging.error('Exception occuer in scan_table_by_Keyword:', e)
# ==========================================================================================



def main() -> None:

    # 引数チェック
    if len(sys.argv) < 6:
         sys.exit(1)

    # LOGGER.info(f" *** len(sys.argv): {len(sys.argv)}")


    # 引数1：FAQ番号
    FAQ_No = sys.argv[1]

    # 引数2：メールテンプレート番号
    Mail_Template_No = sys.argv[2]

    # 引数:3,4 処理エクセルのフルパスとシート名
    file_name = sys.argv[3]
    sheet_name = sys.argv[4]

    # 引数:5,6 置換設定パラメータエクセルのフルパスとシート名
    replace_file_name = sys.argv[5]
    replace_sheet_name = sys.argv[6]

    # 引数:7 テスト送信用メールアドレス(任意パラメータ)
    # try:
    #     test_mailaddr = sys.argv[7]
    # except IndexError:
    #     test_mailaddr = ""

    # 引数:8 直近返信メール・チェック用キーワード(任意パラメータ)
    try:
        p_seach_keyword = sys.argv[7]
    except IndexError:
        p_seach_keyword = ""

    # 引数:9 直近返信メール・受信有効期間（単位：日）(任意パラメータ)
    try:
        p_old_mail_span = sys.argv[8]
    except IndexError:
        p_old_mail_span = ""

    # 引数:10 送信前承認者名(任意パラメータ)
    try:
        p_app_name = sys.argv[9]
    except IndexError:
        p_app_name = ""


    # LOGGER.info(f" *** FAQ_No: {FAQ_No}")
    # LOGGER.info(f" *** Mail_Template_No: {Mail_Template_No}")
    # LOGGER.info(f" *** file_name: {file_name}")
    # LOGGER.info(f" *** sheet_name: {sheet_name}")
    # LOGGER.info(f" *** replace_file_name: {replace_file_name}")
    # LOGGER.info(f" *** replace_sheet_name: {replace_sheet_name}")
    # # LOGGER.info(f" *** test_mailaddr: {test_mailaddr}")
    # LOGGER.info(f" *** p_seach_keyword: {p_seach_keyword}")
    # LOGGER.info(f" *** p_old_mail_span: {p_old_mail_span}")
    # LOGGER.info(f" *** p_app_name: {p_app_name}")


    # 置換文字列パラメータ設定エクセルを読み込み
    make_Filter_Execl(replace_file_name,replace_sheet_name)

    # driver 初期化
    browser: Union[webdriver.Chrome, webdriver.Ie, webdriver.Firefox] = get_webdriver_object()
    browser.implicitly_wait(60.0)
    global AKS_URL
    browser.get(AKS_URL)

    # SSO、ソフトフォン起動を待たないとエラーになる
    time.sleep(12)

    browser.set_window_size(1366, 807)

    # time.sleep(5)
    browser.switch_to.frame(0)

    # サイドバーメニューの「受付グループ変更」から「 法人サポート 」を選択
    # time.sleep(1)
    browser.find_element(By.NAME, "SelectReceptionCallSupportGroup").click()
    # time.sleep(1)

    # メニューから法人サポートを設定する -------------------------------------------------------
    html = browser.page_source
    soup = BeautifulSoup(html, "html.parser")
    table = soup.find("table", {"cellspacing": "2", "border": "0", "cellpadding": "0"})

    # 2行目以降のデータを格納するリスト
    data = []
    if table:
        rows = table.find_all("tr")[1:]  # 1行目はヘッダーなのでスキップ
        for row in rows:
            cols = row.find_all("td")
            cols = [col.get_text(strip=True) for col in cols]
            # print(cols)
            data.append(cols)

    # tableと検索文字列を指定して、行のインデックスを取得
    idx = find_row_index(table, CONST_TARGET_TEXT)
    # LOGGER.info(f"検索文字列が含まれる行のインデックス: {idx}")

    if idx == -1 :
        LOGGER.info(f"法人サポートメニューが発見できなかった: {idx}")

    # browser.find_element(By.CSS_SELECTOR, "tr:nth-child(5) .ico-etc").click()
    browser.find_element(By.CSS_SELECTOR, rf"tr:nth-child({idx + 1}) .ico-etc").click()
    # ---------------------------------------------------------------------

    # サイドバーメニューの「コール管理」から「コール受付」を選択
    # time.sleep(1)
    browser.find_element(By.CSS_SELECTOR, "tr:nth-child(1) .btn-parent-menu > img").click()
    # time.sleep(1)
    browser.find_element(By.CSS_SELECTOR, "tr:nth-child(2) > .menu-select-mid img").click()

    # 異常終了、Ctrl+Cでもエクセルを保存させるように改修
    try:

        # エクセルを読んで処理対象フラグ、支店番号、口座番号を取得（1行目はヘッダ。指定は0オリジン
        df = pd.read_excel(file_name, sheet_name=sheet_name, header=0)

        # testmod_fllg = 0
        for index, row in df.iterrows():

            # テスト送信の場合は１件のみ
            # if testmod_fllg == 1:
            #     break

            # 1.処理対象=1でなければ処理対象外
            taishoo_flg = str(row[1])
            try:
                int_taishoo_flg = int(float(taishoo_flg))
                str_taishoo_flg = str(int_taishoo_flg)
            except Exception as e:
            #LOGGER.info(rf'@@@@@ 数字じゃない @@@@@')
                continue

            if len(str_taishoo_flg) != 1:
                continue

            # 1でなかればRPAは処理しない（つまり、右記は対象外。9:送信不要リストに存在しているためRPA処理対象外）
            if str_taishoo_flg != "1":
                continue


            # 2.支店番号チェック
            # 支店番号 "231.0"なので"230"に補正
            branch_code    = str(row[3])
            if len(branch_code) == 0:
                continue

            try:
                int_branch_code = int(float(branch_code))
                branch_code = str(int_branch_code)
            except Exception as e:
                #LOGGER.info(rf'@@@@@ 数字じゃない @@@@@')
                continue

            if len(branch_code) != 3:
                continue

            # 3.口座番チェック
            account_number = str(row[4])
            match = re.search(r'\d{7}', account_number)
            if match:
                extracted_number = match.group()
                account_number = str(extracted_number)

            if len(account_number) != 7:
                continue

            # 3.口座種別チェック(P, C, B)
            account_type = get_account_type(account_number)
            if account_type is None or pd.isna(account_type):
                account_type = ""

            LOGGER.info(f"@@@@@ : {branch_code}-{account_number}-{account_type}")

            try:
                # 「トップ」画面 ↓↓↓ --------------------------------------------------
                # 顧客タイプの"法人"に選択
                # time.sleep(1)
                browser.find_element(By.NAME, "custType").click()
                dropdown = browser.find_element(By.NAME, "custType")
                dropdown.find_element(By.XPATH, "//option[. = '法人']").click()

                #  支店＋口座番号を入力 
                # LOGGER.info(rf'@@@@@ 支店＋口座番号を入力  @@@@@')
                # time.sleep(1)
                WebDriverWait(browser, 20.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "//*[@id='branchAccountNumber']"))).send_keys(f"{branch_code}{account_number}")

                #  検索ボタン
                # LOGGER.info(rf'@@@@@ 検索ボタン  @@@@@')
                # time.sleep(1)
                WebDriverWait(browser, 20.0).until(expected_conditions.element_to_be_clickable((By.CSS_SELECTOR, ".btn-head-col:nth-child(1) > .btn-head > img"))).click()

                # 「コール受付」画面 ↓↓↓ -----------------------------------------------------------


                # --------------------------
                #  送信可否を確認する
                # --------------------------
                #  1.口座ステータスチェック
                elenment = browser.find_element(By.XPATH, "//*[@id='callInformationForm']/table[3]/tbody/tr[10]/td[2]/span")
                # elenment.click()
                val_status = elenment.text
                # LOGGER.info(f"@@@@@ 口座ステータス : {val_status}")
                if val_status == "解約":
                    df.iloc[index,6]= "1" 
                    # continue
                    raise Exception("status=1")

                #  2.直近の返信履歴チェック
                # 対応履歴テーブルを取得(指定期間に返信があれば返信があったとみなし送信不要とする)
                html = browser.page_source
                soup = BeautifulSoup(html, "html.parser")
                table = soup.find("table", {"cellspacing": "2", "border": "0", "cellpadding": "0"})

                # ================================================================================================
                # # 送信に対する返信があった日付を取得
                # date = find_date_by_title(table, p_seach_keyword)
                # # LOGGER.info(f"date : {date} ")

                # if date:

                #     # 関数を呼び出して結果を取得（result=0であれば指定範囲内）
                #     result = is_within_period(date, p_old_mail_span)
                #     if result == 0:
                #         LOGGER.info(f"{date} は過去 {p_old_mail_span} 日以内です。")
                #         df.iloc[index,6]= "2" 
                #         # continue
                #         raise Exception("status=2")
                #     else:
                #         LOGGER.info(f"{date} は過去 {p_old_mail_span} 日以内ではありません。")
                # else:
                #     LOGGER.info(f"直近で当行からメールした履歴が見つかりませんでした。")
                # ================================================================================================
                return_value = scan_table_by_Keyword(table,p_seach_keyword,p_old_mail_span)
                # match return_value:
                #     case 0:
                #         LOGGER.info(f"期間内に有効回答あり（メール送信しない）")
                #         df.iloc[index,6]= "2" 
                #         raise Exception("status=2")
                #     case 1:
                #         LOGGER.info(f"期間外に有効回答あり（メール送信する）")
                #     case 9:
                #         LOGGER.info(f"回答なし（メール送信する）")

                if return_value == 0:
                    LOGGER.info(f"期間内に有効回答あり（メール送信しない）")
                    df.iloc[index,6]= "2" 
                    raise Exception("status=2")
                elif return_value == 1:
                    LOGGER.info(f"期間外に有効回答あり（メール送信する）")
                elif return_value == 9:
                    LOGGER.info(f"回答なし（メール送信する）")

                # ================================================================================================


                # --------------------------
                #  送信処理
                # --------------------------
                #  コール新規作成ボタン
                LOGGER.info(rf'@@@@@ コール新規作成ボタン  @@@@@')
                time.sleep(1)
                browser.find_element(By.CSS_SELECTOR, ".btn-head-col:nth-child(2) img").click()

                # 「コールメイン」画面 ↓↓↓ -----------------------------------------------------------
                #  FAQボタン 
                LOGGER.info(rf'@@@@@ FAQボタン @@@@@')
                time.sleep(4)
                window_handles= browser.window_handles
                browser.find_element(By.CSS_SELECTOR, ".item:nth-child(2) > .btn-subwin:nth-child(1) > img").click()
                win9033 = wait_for_window(browser,window_handles, 2000)
                browser.switch_to.window(win9033)
                
                # 「FAQ検索」画面 ↓↓↓ -----------------------------------------------------------
                # FAQ番号入力
                LOGGER.info(rf'@@@@@ FAQ番号入力 @@@@@')
                time.sleep(2)
                browser.find_element(By.CSS_SELECTOR, ".btn-head-col:nth-child(2) img").click()
                browser.find_element(By.ID, "faqId").send_keys(FAQ_No)
                
                # 検索ボタン
                LOGGER.info(rf'@@@@@ FAQ番号で検索 @@@@@')
                time.sleep(2)
                WebDriverWait(browser, 20.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "//*[@id='searchFAQList']/table[2]/tbody/tr/td/table/tbody/tr/td[1]/button/img"))).click()

                time.sleep(2)

                # FAQ選択(子windowをclose)
                browser.find_element(By.CSS_SELECTOR, "#select > img").click()
                # 「FAQ検索」画面 ↑↑↑ -----------------------------------------------------------

                # 親Windowにswitch
                time.sleep(2)
                browser.switch_to.window(window_handles[0])
                time.sleep(2)
                browser.switch_to.frame(0)
                time.sleep(2)
                browser.find_element(By.ID, "callMainCallDetail.ansText").click()


                # 「保存ボタン」を押下
                WebDriverWait(browser, 20.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "//*[@id='callmain']/table[2]/tbody/tr[1]/td/table/tbody/tr/td[1]/button/img"))).click()
                time.sleep(4)

                # 「メール返信作成ボタン」を押下
                WebDriverWait(browser, 20.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "//*[@id='mailTable']/tbody/tr/td[1]/button/img"))).click()
                time.sleep(1)


                # 「返信メール詳細」画面 ↓↓↓ -----------------------------------------------------------
                # 「テンプレート検索ボタン」を押下
                WebDriverWait(browser, 20.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "//*[@id='searchTemplateText']/img"))).click()

                win9033 = wait_for_window(browser,window_handles, 2000)
                browser.switch_to.window(win9033)

                # 「メールテンプレート検索」画面 ↓↓↓ -----------------------------------------------------------
                # メールテンプレート番号入力
                LOGGER.info(rf'@@@@@ メールテンプレート番号入力 @@@@@')
                time.sleep(2)
                browser.find_element(By.ID, "templateId").send_keys(Mail_Template_No)
                time.sleep(2)
                
                # 検索ボタン
                LOGGER.info(rf'@@@@@ メールテンプレート番号で検索 @@@@@')
                time.sleep(1)
                WebDriverWait(browser, 20.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "//*[@id='searchBodyTemplateList']/table[2]/tbody/tr/td/table/tbody/tr/td[1]/button/img"))).click()

                # time.sleep(2)

                # FAQ選択(子windowをclose)
                browser.find_element(By.CSS_SELECTOR, "#select > img").click()
                # 「メールテンプレート検索」画面 ↑↑↑ -----------------------------------------------------------


                # 親Windowにswitch
                browser.switch_to.window(window_handles[0])
                browser.switch_to.frame(0)

                # -----------------------
                # 1.subjectを編集する
                # -----------------------
                elenment = browser.find_element(By.XPATH, "//*[@id='title']")
                elenment.click()
                val_a = elenment.get_attribute("value")
                # time.sleep(2)
                val_a = edit_string("S", val_a, account_type)
                elenment.clear()
                elenment.send_keys(val_a)

                # -----------------------
                # 2.Body headerを編集する
                # -----------------------
                elenment = browser.find_element(By.XPATH, "//*[@id='headerInsLineFeed']")
                elenment.click()
                val_a = elenment.get_attribute("value")
                # time.sleep(2)
                # ------------------------------------------------
                val_a = edit_string("H", val_a, account_type)
                if isinstance(val_a, list):
                    val_a = "\n".join(val_a)
                modified_val_a = []
                for line in val_a.splitlines():
                    modified_val_a.append(line)
                elenment.clear()
                elenment.send_keys("\n".join(modified_val_a))
                time.sleep(1)

                # -----------------------
                # 3.Bodyを編集する
                # -----------------------
                elenment = browser.find_element(By.XPATH, "//*[@id='textInsLineFeed']")
                elenment.click()
                val_a = elenment.get_attribute("value")
                # time.sleep(2)

                val_a = edit_string("B", val_a, account_type)
                if isinstance(val_a, list):
                    val_a = "\n".join(val_a)
                modified_val_a = []
                for line in val_a.splitlines():
                    modified_val_a.append(line)
                elenment.clear()
                elenment.send_keys("\n".join(modified_val_a))

                time.sleep(2)

                # ====================================================================================================================================
                # 送信ボタン
                LOGGER.info(rf'@@@@@ 送信ボタン @@@@@')
                # time.sleep(2)
                browser.find_element(By.CSS_SELECTOR, ".btn-head-col:nth-child(4) img").click()

                # 承認ボタン
                LOGGER.info(rf'@@@@@ 承認ボタン @@@@@')
                # time.sleep(2)
                WebDriverWait(browser, 20.0).until(expected_conditions.element_to_be_clickable((By.XPATH,"//*[@id='replyMailSendForm']/table[2]/tbody/tr[1]/td/table/tbody/tr/td[3]/button/img"))).click()
                # time.sleep(2)

                # ここで承認者を選択するためにテーブル検索
                LOGGER.info(rf'@@@@@ 承認者を選択するためにテーブル検索 @@@@@')
                # time.sleep(2)
                # table = soup.find("table", {"cellspacing": "2", "border": "0", "cellpadding": "0"})

                html = browser.page_source
                soup = BeautifulSoup(html, "html.parser")
                table = soup.find("table", {"cellspacing": "2", "border": "0", "cellpadding": "0"})

                # 2行目以降のデータを格納するリスト
                data = []
                if table:
                    rows = table.find_all("tr")[1:]  # 1行目はヘッダーなのでスキップ
                    for row in rows:
                        cols = row.find_all("td")
                        cols = [col.get_text(strip=True) for col in cols]
                        # print(cols)
                        data.append(cols)

                # tableと検索文字列を指定して、行のインデックスを取得
                idx = find_row_index(table, p_app_name)
                LOGGER.info(f"検索文字列が含まれる行のインデックス: {idx}")

                if idx == -1 :
                    df.iloc[index,6]= "98" 
                    continue

                # 行を選択
                time.sleep(1)
                browser.find_element(By.CSS_SELECTOR, rf"tr:nth-child({idx + 1}) .ico-etc").click()
                time.sleep(1)

                # OKボタン
                time.sleep(1)
                browser.find_element(By.CSS_SELECTOR, ".btn-head-col:nth-child(1) img").click()
                time.sleep(1)

                # 送信日時
                df.iloc[index,2]= get_utc2jst() 
                # 未送信理由(00:正常送信済、01:)
                df.iloc[index,6]= "0" 


                #  コール新規作成ボタン
                LOGGER.info(rf'@@@@@ クリアボタン（通常）  @@@@@')
                time.sleep(1)
                browser.find_element(By.CSS_SELECTOR, ".btn-head-col:nth-child(1) img").click()

                LOGGER.info(rf'@@@@@ 8 @@@@@')
                LOGGER.info(rf' ')

                # 「コールメイン」画面 ↑↑↑ -----------------------------------------------------------

            except Exception as e:
                # システム例外を記録して処理は継続する
                if df.iloc[index,6] == "":
                    df.iloc[index,6]= "99" 

                # LOGGER.info(rf'@@@@@   @@@@@')
                # LOGGER.info(rf' ')
                time.sleep(1)
                browser.find_element(By.CSS_SELECTOR, ".btn-head-col:nth-child(1) img").click()

                # 汎用エクセルファイルを保存して継続
                # df.to_excel(file_name,sheet_name=sheet_name, index=False)

                continue

            LOGGER.info(rf'@@@@@ 9 @@@@@@')
            LOGGER.info(rf' ')

            # ==============================================================================

    except KeyboardInterrupt:
        print("\n処理が中断されました。")
    except Exception as e:
        print("\n[エラー] 予期しないエラーが発生しました。")
    finally:
        print("\n[エラー] 共通フォーマットエクセルを変更を保存します。")
        # 汎用エクセルファイルを保存して閉じる
        df.to_excel(file_name,sheet_name=sheet_name, index=False)

        # 「xログアウト」ボタンを押下
        elenment = browser.find_element(By.XPATH, "//*[@id='menuForm']/table/tbody/tr[2]/td/table[1]/tbody/tr[1]/td/button/img")
        elenment.click()

    return

if __name__ == "__main__":
    LOGGER.info("starts")
    main()
    LOGGER.info("ends")
