import uuid
from fastapi import FastAPI, HTTPException, status
from schema import SupportRequest, SupportResponse, SupportTicket, TicketStatus
from agent import SupportAgent

app = FastAPI(
    title="Hybrid Customer Support API",
    description="AIと人間が協調するハイブリッド型カスタマーサポートのバックエンドサンプル",
    version="1.0.0"
)

# AIエージェントの初期化
agent = SupportAgent()

# 擬似データベース（メモリ上にチケットを保存）
ticket_db = {}

@app.post(
    "/api/v1/support/tickets", 
    response_model=SupportResponse, 
    status_code=status.HTTP_201_CREATED,
    summary="問い合わせの新規受付"
)
async def create_ticket(request: SupportRequest):
    """
    ユーザーからの新規問い合わせを受け付け、AIが対応方針を自動で判定します。
    """
    # 1. LLMエージェントを呼び出して、問い合わせを分析
    analysis = agent.process_message(request.message)
    
    # 2. チケットIDの一意な生成
    ticket_id = f"TICK-{uuid.uuid4().hex[:8].upper()}"
    
    # 3. 判定結果に応じたステータスとレスポンスの分岐
    if analysis.next_action == "AI":
        ticket_status = TicketStatus.AI_RESOLVED
        assigned_to = "AI"
        return_message = analysis.draft_reply  # ユーザーへの直接の回答
    else:
        ticket_status = TicketStatus.HUMAN_REQUIRED
        assigned_to = "Human"
        # オペレーターへの引き継ぎ文言をセット
        return_message = f"【オペレーターへ引き継ぎ】\n理由: {analysis.reason}\n要約: {analysis.draft_reply}"

    # 4. データベース（メモリ）へ保存
    new_ticket = SupportTicket(
        ticket_id=ticket_id,
        user_id=request.user_id,
        initial_message=request.message,
        ai_response=analysis.draft_reply if assigned_to == "AI" else None,
        status=ticket_status,
        assigned_to=assigned_to
    )
    ticket_db[ticket_id] = new_ticket

    # 5. クライアントへのレスポンス
    return SupportResponse(
        ticket_id=ticket_id,
        status=ticket_status,