from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from pydantic import BaseModel, Field
from typing import Literal

# 1. LLMに判定させたい構造をPydanticで定義
class RouteClassification(BaseModel):
    next_action: Literal["AI", "HUMAN"] = Field(
        ..., 
        description="問い合わせの対応担当。一般的な質問、配送、簡単な使い方などは'AI'。クレーム、返金、個人情報の変更、複雑なトラブルは'HUMAN'を選択。"
    )
    reason: str = Field(..., description="そのアクションを選択した理由。")
    draft_reply: str = Field(
        ..., 
        description="AI対応の場合はユーザーへの丁寧な回答。HUMAN対応の場合は、人間のオペレーターに向けた『この顧客は何に困っているか』の要約と引き継ぎメモ。"
    )

class SupportAgent:
    def __init__(self):
        # 最新のGPT-4oモデル、あるいはgpt-4o-mini等を利用
        self.llm = ChatOpenAI(model="gpt-4o-mini", temperature=0.2)
        
        # 構造化出力をLLMにバインド
        self.structured_llm = self.llm.with_structured_output(RouteClassification)
        
        # プロンプトの定義
        self.prompt = ChatPromptTemplate.from_messages([
            ("system", """
あなたは大手ECサイトの高度なカスタマーサポート・ルーティングAIです。
入力された顧客からの問い合わせを分析し、以下のルールに従って対応を振り分けてください。

【振り分けルール】
1. AIが対応すべきケース ("AI"):
   - 一般的な質問（送料、返品規定、一般的な営業時間など）
   - 簡単な使い方の質問
   - 配送状況の確認方法の案内など、マニュアル対応が可能なもの
   
2. 人間（オペレーター）が対応すべきケース ("HUMAN"):
   - 強い不満や怒りを含んだクレーム
   - 返金、キャンセル、アカウントの削除要求
   - 複雑な技術的トラブルや、個人情報の個別確認が必要なケース

【出力フォーマット】
指定されたPydanticのスキーマ（next_action, reason, draft_reply）に厳密に従って出力してください。
            """),
            ("human", "顧客からの問い合わせ: {customer_message}")
        ])
        
        # チェーンの結合
        self.chain = self.prompt | self.structured_llm

    def process_message(self, message: str) -> RouteClassification:
        """
        ユーザーのメッセージを解析し、分類と下書きテキストを返します。
        """
        try:
            result = self.chain.invoke({"customer_message": message})
            return result
        except Exception as e:
            # 万が一のLLMエラー時のフォールバック（安全のため有人対応へ）
            return RouteClassification(
                next_action="HUMAN",
                reason=f"LLMエラーが発生したため有人にエスカレーションします: {str(e)}",
                draft_reply="システムエラーにより、自動回答が生成できませんでした。オペレーターが順次対応いたします。"
            )