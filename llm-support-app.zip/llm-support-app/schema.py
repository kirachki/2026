from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime

# ユーザーからの問い合わせリクエスト
class SupportRequest(BaseModel):
    user_id: str = Field(..., example="user_123")
    message: str = Field(..., example="商品の配送状況を確認したいのですが、どうなっていますか？")

# サポートチケットのステータス定義
class TicketStatus:
    AI_RESOLVED = "AI_RESOLVED"       # AIが自動回答して解決
    HUMAN_REQUIRED = "HUMAN_REQUIRED" # 有人対応が必要
    COMPLETED = "COMPLETED"           # 完了

# 擬似データベースに保存されるチケットの構造
class SupportTicket(BaseModel):
    ticket_id: str
    user_id: str
    initial_message: str
    ai_response: Optional[str] = None
    status: str
    assigned_to: Optional[str] = None # 'AI' または 'Human'
    created_at: datetime = Field(default_factory=datetime.utcnow)

# APIが返すレスポンス
class SupportResponse(BaseModel):
    ticket_id: str
    status: str
    assigned_to: str
    message: str  # ユーザーに返す、またはオペレーターに表示する文言