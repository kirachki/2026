llm-support-app/
│
├── main.py          # FastAPIのメインエントリーポイント
├── schema.py        # Pydanticデータモデル（リクエスト/レスポンス）
├── agent.py         # LangChainを活用したLLMロジック
└── requirements.txt # 依存ライブラリ一覧


export OPENAI_API_KEY="your-openai-api-key"

