from datetime import datetime

def check_date_limit(date_string):
    """
    引数の日付が本日より後の場合は0、本日以前の場合は1を返す
    フォーマット: yyyy/mm/dd
    """
    try:
        # 入力文字列を日付オブジェクトに変換
        target_date = datetime.strptime(date_string, '%Y/%m/%d').date()
        # 本日の日付を取得
        today = datetime.now().date()
        
        # 本日より大きい（未来）場合は0、それ以外（今日を含む過去）は1
        if target_date > today:
            return 0
        else:
            return 1
    except ValueError as e:
        return f"エラー: 日付形式が正しくありません ({e})"

# 本日より後の場合は0、本日以前の場合は1を返します。
def main():
    # 本日の日付を表示（確認用）
    today_str = datetime.now().strftime('%Y/%m/%d')
    print(f"--- 本日の日付: {today_str} ---\n")
    
    # テストケース
    # 1. 過去の日付, 2. 今日の日付, 3. 未来の日付
    test_cases = [
        "2023/01/01", 
        today_str,    
        "2026/12/31"  
    ]
    
    print(f"{'判定する日付':<15} | {'結果':<5} | {'備考'}")
    print("-" * 40)
    
    for case in test_cases:
        result = check_date_limit(case)
        
        # 備考のラベル付け
        if result == 0:
            note = "本日より未来 (0)"
        elif result == 1:
            note = "本日以前 (1)"
        else:
            note = "エラー"
            
        print(f"{case:<15} | {result:<5} | {note}")

    result = check_date_limit("2026/02/12")
    print(f"2026/02/12 -> {result}")



if __name__ == "__main__":
    main()