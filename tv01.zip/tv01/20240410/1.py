import json
import time
import signal
import sys
from datetime import datetime
from os import abort
from sanic import Sanic
from sanic import response
from sanic import request
from selenium import webdriver
from selenium.webdriver import Firefox, FirefoxOptions
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys

# 設定ファイルからログイン情報を取得
login_info = json.load(open("login_info.json", "r", encoding="utf-8"))
site_name = "sec_rakuten"
url_login = login_info[site_name]["url"]
USER = login_info[site_name]["id"]
PASS = login_info[site_name]["pass"]
CRYPT = login_info[site_name]["crypt"]

# 設定ファイルから注文情報を取得
order_info = json.load(open("order_info.json", "r", encoding="utf-8"))
order_name = "order_info"
ORDER_AMOUNT = order_info[order_name]["orderamount"]
TOTAL_AMOUNT = order_info[order_name]["totalamount"]
INTERVAL = order_info[order_name]["interval"]
TICKER1 = order_info[order_name]["ticker1"]
TICKER2 = order_info[order_name]["ticker2"]
TICKER3 = order_info[order_name]["ticker3"]




class WebDriverManager:
    _instance = None

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(WebDriverManager, cls).__new__(cls, *args, **kwargs)
            cls._instance.browser = cls._instance.start_browser()
        return cls._instance

    @staticmethod
    def start_browser():
        # FirefoxのWebDriverを指定してブラウザを起動
        browser = webdriver.Firefox()
        return browser

    def get_browser(self):
        return self.browser


def rsec_top():
    browser.implicitly_wait(10)
    print('***** start', datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')
    browser.get(url_login)
    browser.find_element(By.XPATH, "//input[@id='form-login-id']").send_keys(USER)
    browser.find_element(By.XPATH, "//input[@id='form-login-pass']").send_keys(PASS)
    WebDriverWait(browser, 10).until(ec.element_to_be_clickable((By.XPATH, "//button[@type='submit' and @id='login-btn']"))).click()
    print('***** rsec_login', datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')

    # 自動ログアウト機能を停止
    browser.find_element(By.CSS_SELECTOR, ".pcm-gl-auto-logout-btn").click()
    assert browser.switch_to.alert.text == "「自動ログアウト」機能*を停止します。\n\n*自動ログアウト機能とは、最後の操作が行われてから30分経過した際に、自動的にログアウトする機能です。\nログアウトするまで、離席時などのセキュリティにはご注意ください。\nこの機能はお客様のセキュリティ保護のため、ログインする度に設定がONに戻ります。"
    browser.switch_to.alert.accept()
    print('***** rsec_top', datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')

def rsec_order():
    # find_ticker():
    browser.find_element(By.NAME, "stoc-type-01").click()
    dropdown = browser.find_element(By.NAME, "stoc-type-01")
    dropdown.find_element(By.XPATH, "//option[. = '米国株式']").click()
    browser.find_element(By.ID, "search-stock-01").click()
    browser.find_element(By.ID, "search-stock-01").send_keys(TICKER1)
    browser.find_element(By.CSS_SELECTOR, "#searchStockFormSearchBtn > .rex-icon-search-outline").click()
    print('***** rsec_find_ticker', datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')

    # 検索された銘柄画面で「売り注文」押下
    element = browser.find_element(By.CSS_SELECTOR, ".pcmm-btlk-function > .pcmm-btlk__text")
    actions = ActionChains(browser)
    actions.move_to_element(element).perform()
    element = browser.find_element(By.CSS_SELECTOR, "body")
    actions = ActionChains(browser)
    element = browser.find_element(By.CSS_SELECTOR, ".pcmm-btlk-sell")
    browser.find_element(By.CSS_SELECTOR, ".pcmm-btlk-sell > .pcmm-btlk__text").click()
    print('***** rsec_select_sell', datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')

    # 保有銘柄一覧画面で特定口座セクションの「売り」押下
    browser.find_element(By.CSS_SELECTOR, "#specific-account .pcmm-btlk__text").click()
    WebDriverWait(browser, 10).until(ec.element_to_be_clickable((By.XPATH, "//label[@class='pcmm-rbtn-group__label' and @for='price-market']"))).click()
    print('***** rsec_select_ticker', datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')

    # 4.売り注文 / 受付画面
    # 4-1.orderValue (数量)
    WebDriverWait(browser, 10).until(ec.element_to_be_clickable((By.XPATH, "//input[@id='orderValueInput']"))).send_keys(ORDER_AMOUNT)
    print('***** 数量入力    ' , datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')

    # 4-2.Price (成行注文)
    # WebDriverWait(browser, 10).until(ec.element_to_be_clickable((By.XPATH, "//label[@class='pcmm-rbtn-group__label' and @for='price-market']"))).click()
    time.sleep(3)
    element = browser.find_element(By.CSS_SELECTOR, "#pcmm-foreign-stock-order-form-sct--price .pcmm-rbtn-group__item:nth-child(2) > .pcmm-rbtn-group__label")
    time.sleep(3)
    browser.execute_script("arguments[0].scrollIntoView(true);", element)
    time.sleep(3)
    element.click()
    print('***** 成行注文選択' , datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')



    # 4-3.payment-method (決済方法:ドルで受け取る)
    time.sleep(3)
    browser.find_element(By.CSS_SELECTOR, "#pcmm-foreign-stock-order-form-sct--payment-method .pcmm-rbtn-group__item:nth-child(1) > .pcmm-rbtn-group__label").click()
    browser.find_element(By.CSS_SELECTOR, "#pcmm-foreign-stock-order-form-sct--payment-method .pcmm-rbtn-group__item:nth-child(2) > .pcmm-rbtn-group__label").click()
    print('***** 決済方法ドル' , datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')



    # 4-4.取引暗証番号
    # WebDriverWait(browser, 10).until(ec.element_to_be_clickable((By.XPATH, "//input[@id='password"))).send_keys(CRYPT)
    browser.implicitly_wait(1)
    element = browser.find_element(By.XPATH, "//input[@id='password']")
    element.send_keys(CRYPT)
    browser.implicitly_wait(0.1)
    print('***** 取引暗証番号' , datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')


    # 4-5.確認方法 (省略する)
    # WebDriverWait(browser, 10).until(EC.element_to_be_clickable((By.XPATH, "//label[contains(@class, 'pcmm-foreign-stock-chb-normal__label')]"))).click()
    browser.find_element(By.CSS_SELECTOR, ".pcmm-foreign-stock-chb-normal__label").click()
    print('***** 確認方法省略' , datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')

    # 4-5.「注文内容を確認する」を押す
    # element = browser.find_element(By.ID, "orderSubmit")
    # browser.execute_script("arguments[0].scrollIntoView(true);", element)
    # element.click()
    print('***** 注文内する  ' , datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')
    
    # 次の準備
    browser.execute_script("window.scrollTo(0, 0);")
    


if __name__ == "__main__":

    web_driver_manager = WebDriverManager()
    browser = web_driver_manager.get_browser()

    # 例としてGoogleにアクセスしてタイトルを取得
    browser.get("https://www.google.com")
    print("Title of the page:", browser.title)

    rsec_top()
    rsec_order()

    time.sleep(10)
    rsec_order()

    time.sleep(10)
    rsec_order()

    time.sleep(10)
    rsec_order()


    browser.quit()
