import sqlite3

def create_table(conn):
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS tbl_arert (
                    col_1 INTEGER PRIMARY KEY,
                    col_2 TEXT
                 )''')
    conn.commit()

def insert_sample_data(conn):
    c = conn.cursor()
    sample_data = [
        (1, 'data1'),
        (2, 'data2'),
        (3, 'data3'),
        (4, 'data4'),
        (5, 'data5'),
        (6, 'data6'),
        (7, 'data7'),
        (8, 'data8'),
        (9, 'data9'),
        (10, 'data10')
    ]
    c.executemany('INSERT INTO tbl_arert (col_1, col_2) VALUES (?, ?)', sample_data)
    conn.commit()

def main():
    conn = sqlite3.connect('example.sqlite3')
    create_table(conn)
    insert_sample_data(conn)
    conn.close()

if __name__ == "__main__":
    main()
