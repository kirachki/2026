import sqlite3

#
SQLiteデータベースへの接続
conn = sqlite3.connect
('example.sqlite3')
cursor = conn.cursor
()

# テーブルの削除（存在する場合）
cursor.
execute("DROP TABLE IF EXISTS booked_webhook"
)

# インデックスの削除（存在する場合）
# cursor.
execute("DROP INDEX IF EXISTS idx_col1"
)
# cursor.
execute("DROP INDEX IF EXISTS idx_col2_col3"
)

# テーブルの作成
cursor.
execute("""
    CREATE TABLE booked_webhook (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        message TEXT,
        exchange TEXT,
        ticker TEXT,
        price INTEGER,
        interval INTEGER,
        booked_dtm TEXT DEFAULT (strftime ('%Y-%m-%d %H:%M:%f', 'now')),
        ordered_flg INTEGER DEFAULT 0
    )
"""
)

# インデックスの作成
-- cursor.
-- execute("CREATE INDEX idx_col1 ON booked_webhook (col1)"
-- )
-- cursor.
-- execute("CREATE INDEX idx_col2_col3 ON booked_webhook (col2, col3)"
-- )

# 変更をコミットして接続を閉じる
conn.
commit
()
conn.
close
()
