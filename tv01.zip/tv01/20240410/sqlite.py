import sqlite3

def main():
    print('*** db_connect ***')
    conn = db_connect()

    print('*** db_fetch ***')
    results = db_fetch(conn)

    print('*** process_results ***')
    persons_list = process_results(results)

    print('*** display ***')
    display(persons_list)

    print('*** db_disconnect ***')
    db_disconnect(conn)



def db_connect():
    conn = sqlite3.connect('example.sqlite3')
    conn.row_factory = sqlite3.Row
    return conn

def db_fetch(conn):
    c = conn.cursor()
    c.execute('select col_1, col_2 from tbl_arert')
    return c.fetchall()

def db_disconnect(conn):
    conn.close()

def process_results(results):
    persons_list = []
    for r in results:
        # print(r['col_2'])  # col_1 を表示
        persons_list.append(r)
    return persons_list

def db_insert(conn, data):
    c = conn.cursor()
    c.execute('INSERT INTO tbl_arert (col_1, col_2) VALUES (?, ?)', data)
    conn.commit()

def db_update(conn, new_value, condition_value):
    c = conn.cursor()
    c.execute('UPDATE tbl_arert SET col_1 = ? WHERE col_2 = ?', (new_value, condition_value))
    conn.commit()

# この関数はdisplay関数がどのように実装されているかに依存します。
def display(data):
    for row in data:
        print(dict(row))  # SQLite3.Row をディクショナリに変換して表示



if __name__ == "__main__":
    main()
