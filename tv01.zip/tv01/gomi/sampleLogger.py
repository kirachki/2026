import json
import logging
import logging.config
from pandas import DataFrame
from typing import Any, Dict


def func_key_search(key: str, data: Dict[str, Any]) -> bool:
    if key in data:
        return True
    else:
        for item in data.values():
            if isinstance(item, list):
                for sublist in item:
                    if key in sublist:
                        return True
            elif isinstance(item, dict):
                if key in item:
                    return True
    return False


def get_stock_info(ticker_name: str, data: Dict[str, Any]) -> DataFrame:
    # 指定されたticker_nameが存在するかチェックし、情報を取得します
    for item in data["ticker_info"]:
        if ticker_name in item:
            stock_info = item[ticker_name]
            break
    else:
        # 指定されたticker_nameが存在しない場合はNoneを返します
        return None
    
    # 取得した情報をDataFrame形式に変換して返します
    df = DataFrame([stock_info])
    return df





# 設定ファイルからログ設定を読み込む
logging.config.fileConfig('logging_config.ini')

# ログメッセージの出力
logging.debug('これはデバッグメッセージです')
logging.info('これは情報メッセージです')
logging.warning('これは警告メッセージです')
logging.error('これはエラーメッセージです')
logging.critical(rf"これはクリティカルメッセージです")

# with open('ticker_info.json', 'r') as file:
#     data = json.load(file)

# JSONファイルを読み込む
try:
    with open('ticker_info.json', 'r') as file:
        data = json.load(file)
        print("構文は正しいです。")
except json.JSONDecodeError as e:
    print("構文に問題があります:", e)


print(func_key_search("NVDA", data))  # True
# print(func_key_search("NVDA"))  # True
# print(func_key_search("MU"))    # True
# print(func_key_search("AAPL"))  # False


# "NVDA" の情報を取得します
ticker_df = get_stock_info("NVDA", data)
# print(get_stock_info("NVDA", data))

# # 取得した情報を表示します
# if ticker_df is not None:
#     print("Ticker Information:")
#     print(ticker_df)
# else:
#     print("Ticker not found.")

exchange = ticker_df['exchange']
OrderPerTran = ticker_df['OrderPerTran']
OrderPerHour =ticker_df['OrderPerHour']
OrderPerDay = ticker_df['OrderPerDay']
MinPrice =ticker_df['MinPrice']
MaxRrice =ticker_df['MaxRrice']
interval =ticker_df['interval']
side = ticker_df['side']
AccountType = ticker_df['AccountType']
print(f"Exchange: {ticker_df['side']}")


# print("\n***** AccountType *****")
# for account_type in data["AccountType"]:
#     print(account_type)



# # "table" 内のデータを表示
# print("\nTable data:")
# for row in data["ticker_info"]:
#     for key, value in row.items():
#         print(f"{key}: {value}")



# print("\n***** キーで検索 *****")
# for row in data["ticker_info"]:
#     if "NVDA" in row:
#         row_data = row["NVDA"]
#         print("Key1: NVDA")
#         for column_key, value in row_data.items():
#             print(f"{column_key}: {value}")
#         break

