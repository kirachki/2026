import argparse
import config
import json
import time
import signal
import sys
from datetime import datetime, timedelta
import pytz

from os import abort
from datetime import datetime
# from typing import List, Any, Tuple
from selenium import webdriver
from selenium.webdriver import Firefox, FirefoxOptions
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from pooldbconnect import SQLiteConnectionPool



def get_utc2jst() -> datetime :
    try:
        # 日時を取得し、JSTに変換
        now_utc = datetime.now(pytz.utc)
        print(rf"@@@@@@@@@@ now_utc : {now_utc}")
        now_jst = now_utc.astimezone(pytz.timezone('Asia/Tokyo'))

        return now_jst
    except Exception as e:
        print('Exception occuer in get_utc2jst:', e)
        return now_utc


def main():
    now_jst = get_utc2jst()
    print(rf"@@@@@@@@@@ now_jst : {now_jst}")



if __name__ == "__main__":

    main()
