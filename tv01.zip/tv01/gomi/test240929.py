from datetime import datetime, timedelta

def check_email_action(debit_apply_date, first_email_date, second_email_date, third_email_date, days_365=365, days_15=15):
    # 日付がセットされていないか、正しい形式でない場合はNoneとして扱う
    try:
        debit_apply_date = datetime.strptime(debit_apply_date, '%Y-%m-%d')
    except ValueError:
        return "デビット申込日が無効です"
    
    try:
        first_email_date = datetime.strptime(first_email_date, '%Y-%m-%d') if first_email_date else None
    except ValueError:
        # ②が無効な場合は、① + days_15で補完
        first_email_date = debit_apply_date + timedelta(days=days_15)
        print(f"first_email_date : {first_email_date}")
    
    try:
        second_email_date = datetime.strptime(second_email_date, '%Y-%m-%d') if second_email_date else None
    except ValueError:
        # ③が無効な場合は、① + (days_15 * 2)で補完
        second_email_date = debit_apply_date + timedelta(days=days_15 * 2)
    
    try:
        third_email_date = datetime.strptime(third_email_date, '%Y-%m-%d') if third_email_date else None
    except ValueError:
        # ④が無効な場合は、① + (days_15 * 3)で補完
        third_email_date = debit_apply_date + timedelta(days=days_15 * 3)

    today = datetime.today()

    # ②、③、④すべて値がセットされている場合
    if first_email_date and second_email_date and third_email_date:
        if today >= debit_apply_date + timedelta(days=days_365):
            return "破棄"
    
    # ②、③に値がセットされていて、④が空白の場合
    if first_email_date and second_email_date and not third_email_date:
        if today >= second_email_date + timedelta(days=days_15):
            return "３回目メール送信"

    # ②に値がセットされていて、③、④が空白の場合
    if first_email_date and not second_email_date and not third_email_date:
        if today >= first_email_date + timedelta(days=days_15):
            return "２回目メール送信"

    # ②、③、④すべて値がセットされていない場合
    if not first_email_date and not second_email_date and not third_email_date:
        if today >= debit_apply_date + timedelta(days=days_15):
            return "１回目メール送信"
    
    return "何もしない"

# テストケースの配列
test_cases = [
    # ケース 1: ②が無効
    {'debit_apply_date': '2023-01-01', 'first_email_date': 'invalid', 'second_email_date': '2023-01-20', 'third_email_date': '2023-01-30'},
    
    # ケース 2: ③が無効
    {'debit_apply_date': '2023-01-01', 'first_email_date': '2023-01-10', 'second_email_date': 'invalid', 'third_email_date': None},
    
    # ケース 3: ④が無効
    {'debit_apply_date': '2023-01-01', 'first_email_date': '2023-01-10', 'second_email_date': '2023-01-20', 'third_email_date': 'invalid'},
    
    # ケース 4: ②、③、④がすべて無効
    {'debit_apply_date': '2023-09-01', 'first_email_date': 'invalid', 'second_email_date': 'invalid', 'third_email_date': 'invalid'},
]

# 各テストケースをチェック
for i, case in enumerate(test_cases, 1):
    result = check_email_action(
        case['debit_apply_date'], 
        case['first_email_date'], 
        case['second_email_date'], 
        case['third_email_date'], 
        days_365=365, days_15=15
    )
    print(f"テストケース {i}: {result}")
