def add_and_multiply(x, y, out_add, out_multiply):
    out_add[0] = x + y  # 加算結果を out_add[0] に格納
    out_multiply[0] = x * y  # 乗算結果を out_multiply[0] に格納

# out型の引数として使用するための空のリストを準備
add_result = [0]
multiply_result = [0]

# 関数を呼び出して、結果を out 型の引数に格納
add_and_multiply(3, 5, add_result, multiply_result)

# 結果を出力
print("加算結果:", add_result[0])
print("乗算結果:", multiply_result[0])
