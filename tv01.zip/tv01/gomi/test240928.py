import re
from datetime import datetime

def format_date(input_str, output_str):
    # 日付パターンを正規表現で定義（yyyy/mm/dd、yy/mm/dd、mm/dd/yy、mm/dd/yyyyを認識する）
    date_patterns = [
        r'(\d{4})[/-](\d{2})[/-](\d{2})',   # yyyy/mm/dd
        r'(\d{2})[/-](\d{2})[/-](\d{2})',   # yy/mm/dd, mm/dd/yy
        r'(\d{2})[/-](\d{2})[/-](\d{4})'    # mm/dd/yyyy
    ]

    # 日付が認識できたかのフラグ
    date_found = False

    # 各パターンに対してチェックを行う
    for pattern in date_patterns:
        match = re.search(pattern, input_str)
        if match:
            try:
                # yyyy/mm/dd の場合
                if len(match.group(1)) == 4:  
                    date_obj = datetime.strptime(match.group(0), "%Y/%m/%d")
                # mm/dd/yyyy の場合
                elif len(match.group(3)) == 4 and int(match.group(1)) <= 12:  
                    date_obj = datetime.strptime(match.group(0), "%m/%d/%Y")
                # mm/dd/yy の場合
                elif int(match.group(1)) <= 12:  
                    date_obj = datetime.strptime(match.group(0), "%m/%d/%y")
                else:  # yy/mm/dd の場合
                    date_obj = datetime.strptime(match.group(0), "%y/%m/%d")

                # yyyy/mm/dd形式にフォーマット
                output_str = date_obj.strftime("%Y/%m/%d")
                date_found = True
                break
            except ValueError:
                continue

    if date_found:
        return 0, output_str
    else:
        return -1, output_str


# テストデータのリスト
test_cases = [
    "2024/09/17",
    "2024/09/17佐々木",
    "佐々木",
    "佐々木2024/09/17",
    "24/09/17佐々木",
    "解約済み",
    "佐々木24/09/17",
    "24/12/17返信あり",
    "2024/09/17　佐々木",
    "佐々木　2024/09/17",
    "24/09/17　佐々木",
    "09/17/2022　佐々木",
    "09/17/22　佐々木",
    "　佐々木09/17/2022",
    "　佐々木09/17/22",
    "佐々木　24/09/17"
]

# 各テストケースをテスト
for test_case in test_cases:
    result, formatted_date = format_date(test_case, "")
    print(f"Input: {test_case}")
    if result == 0:
        print(f"Result: OK, Formatted Date: {formatted_date}")
    else:
        print(f"Result: NG, Could not format date")
    print("-" * 50)
