import sqlite3
from datetime import datetime, timedelta
import pytz


def get_current_jst() -> str:
    try:
        # 日時を取得し、JSTに変換
        now_utc = datetime.now(pytz.utc)
        now_jst = now_utc.astimezone(pytz.timezone('Asia/Tokyo'))
        dtm = now_jst.strftime('%Y-%m-%d %H:%M:%S.%f')
        return dtm
    except Exception as e:
        print('Exception occuer in get_current_dtm:', e)
        return ''

if __name__ == "__main__":
    # SQLiteに接続
    conn = sqlite3.connect('your_database.db')
    c = conn.cursor()

    # SQLクエリを実行してデータを挿入
    # c.execute("INSERT INTO booked_webhook (booked_dtm, update_dtm) VALUES (?, ?)",
    #         (now_jst.strftime('%Y-%m-%d %H:%M:%S.%f'), now_jst.strftime('%Y-%m-%d %H:%M:%S.%f')))
    current_jst = get_current_jst()
    print(current_jst)

    # コミットして変更を保存
    conn.commit()
    