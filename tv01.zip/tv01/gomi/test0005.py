import pandas as pd
import requests
from bs4 import BeautifulSoup
from io import StringIO

# 現在のページのURL
current_url = 'https://finance.yahoo.co.jp/stocks/ranking/up'  # テーブルがあるHTMLのURL
# current_url = driver.current_url  # SeleniumのWebDriverのインスタンスからURLを取得する

# HTMLを取得
response = requests.get(current_url)
html_content = response.content

# BeautifulSoupを使用してHTMLを解析
soup = BeautifulSoup(html_content, 'html.parser')

# HTMLからテーブルを読み取り
tables = pd.read_html(str(soup))

# テーブルが複数ある場合、適切なテーブルを選択
table_index = 0  # テーブルのインデックスを選択
df = tables[table_index]

# Excelファイルに保存
excel_file = 'table_data.xlsx'
df.to_excel(excel_file, index=False)
