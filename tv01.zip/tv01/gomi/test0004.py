import pandas as pd

# HTMLからテーブルを読み取り
url = 'https://finance.yahoo.co.jp/stocks/ranking/up'  # テーブルがあるHTMLのURL
tables = pd.read_html(url)

# テーブルが複数ある場合、適切なテーブルを選択
table_index = 0  # テーブルのインデックスを選択
df = tables[table_index]

# Excelファイルに保存
excel_file = 'table_data.xlsx'
df.to_excel(excel_file, index=False)


# テーブルの内容を簡単なテキストとしてPDFに保存
pdf_file = 'table_data.pdf'
with open(pdf_file, 'w') as f:
    f.write(df.to_string(index=False))

