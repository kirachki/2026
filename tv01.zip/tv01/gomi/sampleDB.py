import sqlite3
from pooldbconnect import SQLiteConnectionPool

def select_data(connection):
    cursor = connection.cursor()
    # cursor.execute("SELECT * FROM table_name")
    cursor.execute("select col_1, col_2 from tbl_arert")
    rows = cursor.fetchall()
    for row in rows:
        print(row)
    cursor.close()

def update_data(connection, data):
    cursor = connection.cursor()
    cursor.execute("UPDATE tbl_arert SET col_2 = ? WHERE col_1 = ?", data)
    connection.commit()
    cursor.close()

def insert_data(connection, data):
    cursor = connection.cursor()
    cursor.execute("INSERT INTO tbl_arert (col_1, col_2) VALUES (?, ?)", data)
    connection.commit()
    cursor.close()

if __name__ == "__main__":

    try:

        # SQLite3のコネクションプールを作成
        connection_pool = SQLiteConnectionPool(max_connections=2)

        # コネクションを取得
        connection1 = connection_pool.get_connection()
        connection2 = connection_pool.get_connection()

        # 3つ目のコネクションを要求してエラーが発生する
        # connection3 = connection_pool.get_connection()  # エラー発生

        # トランザクションの開始
        connection1.commit()

        # selectメソッドの使用例
        select_data(connection1)

        # updateメソッドの使用例
        update_data(connection2, ("update****XX","8"))

        # insertメソッドの使用例
        insert_data(connection2, ("15", "insert******"))

        # selectメソッドの使用例
        select_data(connection1)

        connection1.commit()

        # コネクションを解放
        connection_pool.release_connection(connection1)
        connection_pool.release_connection(connection2)

    except ConnectionError as e:
        print("コネクションエラーが発生しました:", e)
    except sqlite3.Error as e:
        connection1.rollback()  # ロールバック
        print("SQLiteエラーが発生しました:", e)
