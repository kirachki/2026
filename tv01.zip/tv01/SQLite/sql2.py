import sqlite3

# SELECT booked_webhook.*,order_history.AccountType,order_history.ordered_amount
# FROM order_history, booked_webhook 
# WHERE order_history.webhook_id = booked_webhook.id 
#   AND booked_webhook.ticker =  'NVDA' 
# --   AND datetime(ordered_dtm, 'localtime') >= datetime('now', '{Duration}', 'localtime')"

def select_webhook(conn):
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM booked_webhook ORDER BY id DESC LIMIT 2;")
    rows = cursor.fetchall()
    for row in rows:
        print(row)
    cursor.close()

def select_order(conn):
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM order_history ORDER BY webhook_id DESC LIMIT 2;")
    rows = cursor.fetchall()
    for row in rows:
        print(row)
    cursor.close()


def main():
    conn = sqlite3.connect('example.sqlite3')
    print("***** select_webhook *****")
    select_webhook(conn)
    print("***** select_order *****")
    select_order(conn)
    conn.close()

if __name__ == "__main__":
    main()
