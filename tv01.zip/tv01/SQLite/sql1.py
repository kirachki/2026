import sqlite3

def drop_objects(conn):
    c = conn.cursor()
    c.execute('''DROP INDEX IF EXISTS idx_booked_dtm''')
    c.execute('''DROP TABLE IF EXISTS booked_webhook''')

    c.execute('''DROP INDEX IF EXISTS idx_webhook_id''')
    c.execute('''DROP TABLE IF EXISTS order_history''')
    conn.commit()

def create_objects(conn):
    c = conn.cursor()

    # reason_code = 0:正常 99:異常 11～:リクエスト内容不正 21～:conf設定外 41～:期間内の売買回数超過などDBチェック
    c.execute('''CREATE TABLE booked_webhook (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        message TEXT,
        exchange TEXT,
        ticker TEXT,
        price INTEGER,
        interval INTEGER,
        booked_dtm TEXT DEFAULT (strftime ('%Y-%m-%d %H:%M:%f', 'now')),
        update_dtm TEXT DEFAULT (strftime ('%Y-%m-%d %H:%M:%f', 'now')),
        reason_code INTEGER DEFAULT 0
        )''')
    conn.commit()

    c.execute('''CREATE INDEX idx_booked_dtm ON booked_webhook (booked_dtm)''')
    conn.commit()

    # reason_code = 0:正常 99:異常
    # webhook_id = booked_webhookのPK
    c.execute('''CREATE TABLE order_history (
        ordered_id INTEGER PRIMARY KEY AUTOINCREMENT,
        ordered_dtm TEXT DEFAULT (strftime ('%Y-%m-%d %H:%M:%f', 'now')),
        ordered_update_dtm TEXT DEFAULT (strftime ('%Y-%m-%d %H:%M:%f', 'now')),
        ordered_status INTEGER DEFAULT 0,
        ordered_amount INTEGER DEFAULT 0,
        AccountType TEXT,
        order_comment TEXT,
        webhook_id INTEGER
        )''')
    conn.commit()

    c.execute('''CREATE INDEX idx_webhook_id ON order_history (webhook_id)''')
    conn.commit()



def insert_sample_data(conn):
    c = conn.cursor()
    sample_data = [
        ('sell', 'NASDA', 'NVDA',  123, 1),
    ]
    c.executemany('INSERT INTO booked_webhook (message, exchange, ticker, price, interval) VALUES (?, ?, ?, ?, ?)', sample_data)
    conn.commit()

    sample_data1 = [
        ('', 1),
    ]
    c.executemany('INSERT INTO order_history (order_comment, webhook_id)  VALUES (?, ?)', sample_data1)
    conn.commit()


def select_data(conn):
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM booked_webhook ORDER BY id DESC LIMIT 2;")
    rows = cursor.fetchall()
    for row in rows:
        print(row)

    cursor.execute("SELECT * FROM order_history ORDER BY webhook_id DESC LIMIT 2;")
    rows = cursor.fetchall()
    for row in rows:
        print(row)


    cursor.close()


def main():
    conn = sqlite3.connect('example.sqlite3')
    drop_objects(conn)
    create_objects(conn)
    # insert_sample_data(conn)
    select_data(conn)
    conn.close()

if __name__ == "__main__":
    main()
