INSERT INTO my_table (col1, col2, col3, time_column, long_column)
VALUES ('value1', 123, 3.14, '2024-04-12 12:34:56.789', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.');
