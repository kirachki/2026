# from selenium import webdriver

# class WebDriverManager:
#     _instance_count = 0
#     _max_instances = 1

#     def __new__(cls, *args, **kwargs):
#         if cls._instance_count < cls._max_instances:
#             cls._instance_count += 1
#             instance = super(WebDriverManager, cls).__new__(cls, *args, **kwargs)
#             instance.browser = cls.start_browser()
#             return instance
#         else:
#             raise Exception("Maximum number of instances reached.")

#     @staticmethod
#     def start_browser():
#         # FirefoxのWebDriverを指定してブラウザを起動
#         browser = webdriver.Firefox()
#         return browser

#     def get_browser(self):
#         return self.browser

from selenium import webdriver

class WebDriverManager:
    _instance_count = 0
    _max_instances = 1

    def __new__(cls, *args, **kwargs):
        if cls._instance_count < cls._max_instances:
            cls._instance_count += 1
            instance = super(WebDriverManager, cls).__new__(cls, *args, **kwargs)
            instance.browser = cls.start_browser()
            return instance
        else:
            raise Exception("Maximum number of instances reached.")

    @staticmethod
    def start_browser():
        # FirefoxのWebDriverを指定してブラウザを起動
        browser = webdriver.Firefox()
        return browser

    def get_browser(self):
        return self.browser

    def get_browser_handle(self):
        return self.browser.current_window_handle
