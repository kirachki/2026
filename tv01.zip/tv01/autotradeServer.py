from sanic import Sanic
from sanic import response
from sanic import request
import json
import subprocess

app = Sanic(__name__)

@app.route('/webhook', methods=['POST'])
async def webhook(request):
    try:
        data =request.json
        message = data['message']
        exchange = data['exchange']
        ticker = data['ticker']
        price = data['price']
        interval = data['interval']

        subprocess.run(["python", "autotradeClient.py", \
                        "--message", message, \
                        "--exchange", exchange, \
                        "--ticker", ticker, \
                        "--price", price, \
                        "--interval", interval])

        return response.text('success', status=200)

    except Exception as e:
        # log the error message
        # app.logger.error(f"Error: {str(e)}")

        # return an error response to the client
        return {"error": str(e)}, 400

if __name__ == '__main__':
    # app.run()

    try:
        # Create Sanic object called app
        app.run(port=5000)

    except Exception as e:
        print(e)
