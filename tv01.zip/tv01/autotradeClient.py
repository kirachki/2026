import logging
import logging.config
import argparse
import config
import json
import time
import signal
import sys
import pytz
import pandas as pd
import subprocess
from pandas import DataFrame
from datetime import datetime, timedelta
from os import abort
from datetime import datetime
from pooldbconnect import SQLiteConnectionPool
from typing import Any, Dict

def order_check(message, exchange, ticker, price, interval) -> int:
    try:

        # 0.設定ファイルからログ設定を読み込む
        logging.config.fileConfig('logging_config.ini')

        print("\n")
        logging.critical(rf"***** order_check start  : {get_utc2jst()} *****")

        # 1.設定ファイルの読込み
        # 1-1.注文情報
        try:
            with open("ticker_info.json", "r", encoding="utf-8") as file:
                data = json.load(file)
                # logging.info(rf"構文は正しいです。")
        except json.JSONDecodeError as e:
            logging.error(rf"構文に問題があります。")

        # 2.エラーチェック
        reason_code = 0

        # 2.conf設定制限チェック（error range : 10-40）
        # 2-1.指定されたtickerの売買情報が存在していれば取得
        if reason_code == 0:
            if func_key_search(ticker, data):
                ticker_df = get_stock_info(ticker, data)
                exchange = str(ticker_df['exchange'].iloc[0])
                OrderPerTran = ticker_df['OrderPerTran'].iloc[0]
                OrderPerHour = int(ticker_df['OrderPerHour'].iloc[0])
                OrderPerDay = int(ticker_df['OrderPerDay'].iloc[0])
                MinPrice = float(ticker_df['MinPrice'].iloc[0])
                MaxPrice = float(ticker_df['MaxRrice'].iloc[0])
                interval = int(ticker_df['interval'].iloc[0])
                side = str(ticker_df['side'].iloc[0])
                AccountType = str(ticker_df['AccountType'].iloc[0])
            else:
                reason_code = 11

        # 2-2.売買区分チェック
        if reason_code == 0 and \
            message != side:
            reason_code = 12

        if reason_code == 0 and \
            message == "both" and \
            (side != "but" and side != "sell"):
            reason_code = 13

        if reason_code == 0 and \
            exchange != exchange:
            reason_code = 14

        # 2-3.価格制限チェック
        if reason_code == 0 and \
            float(price) < MinPrice:
            reason_code = 15

        if reason_code == 0 and \
            float(price) > MaxPrice:
            reason_code = 16

        # 3:設定期間内の売買回数超過などDBのチェック（error range : 41-60）
        connection_pool = SQLiteConnectionPool(max_connections=1)
        connection1 = connection_pool.get_connection()

        if reason_code == 0:
            # 1時間以内の売買回数チェック
            duration = "-1 hour"
            if not check_order_history(connection1, int(OrderPerHour), duration, ticker):
                reason_code = 41

        if reason_code == 0:
            # 24時間以内の売買回数チェック
            duration = "-24 hour"
            if not check_order_history(connection1, int(OrderPerDay), duration, ticker):
                reason_code = 42

        # 4.webhook の内容を記録して、そのPKを取得しておく
        booking_webhook(connection1, message, exchange, ticker, price, interval, reason_code)
        webhook_id = get_booked_key(connection1)

        # 5.上記1～3で注文対象外となった場合はその理由コードを返却する。
        logging.debug(f'reason_code : {reason_code}')
        logging.debug(f'webhook_id  : {webhook_id}')

        logging.critical(rf"***** order_check finish : {get_utc2jst()} *****")

        # 注文条件に満たない場合は、その理由を記録してリターン
        if reason_code != 0:
            update_error_reason(connection1, webhook_id, reason_code)
            connection_pool.release_connection(connection1)
            return reason_code

        # 注文
        logging.critical(rf"***** order start        : {get_utc2jst()} *****")

        subprocess.run(["python", "autotradeRsec.py", \
                        "--OrderPerTran", str(OrderPerTran), \
                        "--AccountType", AccountType, \
                        "--ticker", ticker, \
                        "--webhook_id", str(webhook_id)])

        return 0
    except Exception as e:
        return 99
    finally:
        logging.critical(rf"***** order finish       : {get_utc2jst()} *****")

def booking_webhook(connection, message, exchange, ticker, price, interval, reason_code):
    try:
        now_jst = get_utc2jst()
        cursor = connection.cursor()
        cursor.execute("INSERT INTO booked_webhook (message, exchange, ticker, price, interval, reason_code, booked_dtm, update_dtm) \
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)", (message, exchange, ticker, price, interval, reason_code, now_jst, now_jst))
        connection.commit()
        cursor.close()
        return 0
    except Exception as e:
        logging.error('Exception occuer in booking_webhook:', e)
        connection.rollback()
        return 1 
    finally:
        connection.rollback()

def get_booked_key(connection) -> int:
    try:
        webhook_id = 0
        cursor = connection.cursor()
        cursor.execute("SELECT id FROM booked_webhook ORDER BY id DESC LIMIT 1")
        webhook_id = cursor.fetchone()[0]  # 直接int型で受け取る
        cursor.close()
        return int(webhook_id)
    except Exception as e:
        logging.error('Exception occuer in get_booked_key:', e)
        return 0
    finally:
        connection.rollback()

def check_order_history(connection, OrderCount, Duration, ticker) -> bool:
    try:
        cursor = connection.cursor()
        sql_query = (
            "SELECT COUNT(*) "
            "FROM order_history, booked_webhook "
            f"WHERE order_history.webhook_id = booked_webhook.id "
            f"  AND booked_webhook.ticker =  '{ticker}' "
            f"  AND datetime(ordered_dtm, 'localtime') >= datetime('now', '{Duration}', 'localtime')"
        )
        cursor.execute(sql_query)
        result = cursor.fetchone()
        logging.debug(rf"{Duration}以内の注文回数 : {result[0]}")
        cursor.close()

        if OrderCount > result[0]:
            return True
        else:
            return False

    except Exception as e:
        logging.error('Exception occuer in get_booked_key:', e)
        return False
    finally:
        connection.rollback()

def update_error_reason(connection, webhook_id, reason_code):
    try:
        cursor = connection.cursor()
        cursor.execute(f"UPDATE booked_webhook SET reason_code = '{reason_code}' WHERE id = '{webhook_id}'")
        connection.commit()
        cursor.close()
        return 0 
    except Exception as e:
        logging.error('Exception occuer in select_data:', e)
        return 1
    finally:
        connection.rollback()

def func_key_search(key: str, data: Dict[str, Any]) -> bool:
    if key in data:
        return True
    else:
        for item in data.values():
            if isinstance(item, list):
                for sublist in item:
                    if key in sublist:
                        return True
            elif isinstance(item, dict):
                if key in item:
                    return True
    return False

def get_utc2jst() -> datetime :
    try:
        # 日時を取得し、JSTに変換
        now_utc = datetime.now(pytz.utc)
        now_jst = now_utc.astimezone(pytz.timezone('Asia/Tokyo'))
        now_jst_formatted = now_jst.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
        return now_jst_formatted
    except Exception as e:
        logging.error('Exception occuer in get_utc2jst:', e)

def get_stock_info(ticker_name: str, data: Dict[str, Any]) -> DataFrame:
    # 指定されたticker_nameが存在するかチェックし、情報を取得します
    for item in data["ticker_info"]:
        if ticker_name in item:
            stock_info = item[ticker_name]
            break
    else:
        # 指定されたticker_nameが存在しない場合はNoneを返します
        return None
    
    # 取得した情報をDataFrame形式に変換して返します
    df = DataFrame([stock_info])
    return df

def main():
    try:
        parser = argparse.ArgumentParser()
        parser.add_argument("--message", help="Trade side (buy or sell or both)", choices=["buy", "sell", "both"])
        parser.add_argument("--exchange", help="Exchange")
        parser.add_argument("--ticker", help="Ticker")
        parser.add_argument("--price", help="Price")
        parser.add_argument("--interval", help="Interval")

        args = parser.parse_args()
        message = args.message.lower()
        exchange = args.exchange.upper()
        ticker = args.ticker.upper()
        price = float(args.price)
        interval = int(args.interval)

        reason_code = order_check(message, exchange, ticker, price, interval)

        return 0
    except Exception as e:
        logging.error(f"Error xxxxxx : {e}")
        return 1

if __name__ == "__main__":
    main()