
import sqlite3
from queue import Queue

# class SQLiteConnectionPool:
#     def __init__(self, max_connections=2):
#         self.max_connections = max_connections
#         self.connections = Queue(maxsize=max_connections)
#         for _ in range(max_connections):
#             connection = sqlite3.connect('example.db')
#             self.connections.put(connection)

#     def get_connection(self):
#         return self.connections.get()

#     def release_connection(self, connection):
#         self.connections.put(connection)


class SQLiteConnectionPool:
    def __init__(self, max_connections):
        self.max_connections = max_connections
        self.connections = []

    def get_connection(self):
        if len(self.connections) >= self.max_connections:
            raise ConnectionError("Maximum connections reached")
        connection = sqlite3.connect("example.sqlite3")
        self.connections.append(connection)
        return connection

    def release_connection(self, connection):
        connection.close()
        self.connections.remove(connection)



# if __name__ == "__main__":
    # # SQLite3のコネクションプールを作成
    # connection_pool = SQLiteConnectionPool(max_connections=2)

    # # コネクションを取得
    # connection1 = connection_pool.get_connection()
    # connection2 = connection_pool.get_connection()

    # # ここでconnection1、connection2を使用してデータベース操作を行う

    # # コネクションを解放
    # connection_pool.release_connection(connection1)
    # connection_pool.release_connection(connection2)
