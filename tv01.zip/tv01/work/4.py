import json
import time
import signal
import sys
from datetime import datetime
from os import abort
from sanic import Sanic
from sanic import response
from sanic import request
from selenium.webdriver import Firefox, FirefoxOptions
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys

def wait_and_click_element(browser, selector):
    wait = WebDriverWait(browser, 10)
    element = wait.until(ec.element_to_be_clickable((By.CSS_SELECTOR, selector)))
    element.click()

# 楽天証券ログイン > 売り注文画面
def rsec_connect():
    # 設定ファイルからログイン情報を取得
    login_info = json.load(open("login_info.json", "r", encoding="utf-8"))

    # ログインサイト名
    site_name = "sec_rakuten"

    # ログイン画面URL
    url_login = login_info[site_name]["url"]

    # ユーザー名、パスワード、暗証番号の指定
    USER = login_info[site_name]["id"]
    PASS = login_info[site_name]["pass"]
    CRYPT = login_info[site_name]["crypt"]

    # Firefoxのヘッドレスモードを有効にする
    options = FirefoxOptions()
    options.add_argument('--headless')

    # Firefoxを起動する
    browser = Firefox(options=options)

    # 1.ログイン画面
    # Input userid
    print('***** 開始　　　　', datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')
    browser.get(url_login)
    browser.find_element(By.XPATH, "//input[@id='form-login-id']").send_keys(USER)

    # Input password
    browser.find_element(By.XPATH, "//input[@id='form-login-pass']").send_keys(PASS)

    # Press login button
    browser.find_element(By.XPATH, "//button[@id='login-btn']").click()


    # 設定ファイルから注文情報を取得
    order_info = json.load(open("order_info.json", "r", encoding="utf-8"))

    # 注文情報
    order_name = "order_info"
    # ログイン画面URL
    ORDER_AMOUNT = order_info[order_name]["orderamount"]
    TOTAL_AMOUNT = order_info[order_name]["totalamount"]
    INTERVAL = order_info[order_name]["interval"]
    TICKER1 = order_info[order_name]["ticker1"]
    TICKER2 = order_info[order_name]["ticker2"]
    TICKER3 = order_info[order_name]["ticker3"]

    print('***** ログイン画面', datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')

    # 2.トップ画面
    # 自動ログアウト機能を停止
    browser.find_element(By.CSS_SELECTOR, ".pcm-gl-auto-logout-btn").click()
    assert browser.switch_to.alert.text == "「自動ログアウト」機能*を停止します。\n\n*自動ログアウト機能とは、最後の操作が行われてから30分経過した際に、自動的にログアウトする機能です。\nログアウトするまで、離席時などのセキュリティにはご注意ください。\nこの機能はお客様のセキュリティ保護のため、ログインする度に設定がONに戻ります。"
    browser.switch_to.alert.accept()

    # 銘柄指定検索（米国株式固定）
    print('***** 銘柄指定検索', datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')
    browser.find_element(By.NAME, "stoc-type-01").click()
    dropdown = browser.find_element(By.NAME, "stoc-type-01")
    dropdown.find_element(By.XPATH, "//option[. = '米国株式']").click()
    browser.find_element(By.ID, "search-stock-01").click()
    browser.find_element(By.ID, "search-stock-01").send_keys(TICKER1)
    browser.find_element(By.CSS_SELECTOR, "#searchStockFormSearchBtn > .rex-icon-search-outline").click()
    print('***** トップ画面', datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')

    # 「売り注文」押下
    element = browser.find_element(By.CSS_SELECTOR, ".pcmm-btlk-function > .pcmm-btlk__text")
    actions = ActionChains(browser)
    actions.move_to_element(element).perform()
    element = browser.find_element(By.CSS_SELECTOR, "body")
    actions = ActionChains(browser)
    element = browser.find_element(By.CSS_SELECTOR, ".pcmm-btlk-sell")
    browser.find_element(By.CSS_SELECTOR, ".pcmm-btlk-sell > .pcmm-btlk__text").click()

    browser.find_element(By.CSS_SELECTOR, "#specific-account .pcmm-btlk__text").click()
    # browser.implicitly_wait(2)


    print('***** 「売り注文」', datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')


    # orderValue (数量)
    element = browser.find_element(By.XPATH, "//input[@id='orderValueInput']")
    # element = browser.find_element(By.ID, "orderValueInput")
    browser.execute_script("arguments[0].scrollIntoView(true);", element)
    time.sleep(1)
    element.click()
    element.send_keys(ORDER_AMOUNT)
    print('***** 数量入力' , datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')

    # Price (成行注文)
    # 要素が表示されるまでページをスクロールする(待機させないと成行が選択されないのでsleepは絶対に削除しない)
    time.sleep(2)
    element = browser.find_element(By.CSS_SELECTOR, "#pcmm-foreign-stock-order-form-sct--price .pcmm-rbtn-group__item:nth-child(2) > .pcmm-rbtn-group__label")
    time.sleep(2)
    browser.execute_script("arguments[0].scrollIntoView(true);", element)
    time.sleep(2)
    element.click()
    time.sleep(2)

    print('***** 成行注文選択' , datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')

    # # payment-method (決済方法:ドルで受け取る)
    browser.find_element(By.CSS_SELECTOR, "#pcmm-foreign-stock-order-form-sct--payment-method .pcmm-rbtn-group__item:nth-child(1) > .pcmm-rbtn-group__label").click()
    browser.find_element(By.CSS_SELECTOR, "#pcmm-foreign-stock-order-form-sct--payment-method .pcmm-rbtn-group__item:nth-child(2) > .pcmm-rbtn-group__label").click()
    print('***** 決済方法:ドルで受け取る' , datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')

    # password (取引暗証番号)
    browser.implicitly_wait(1)
    # time.sleep(1)
    # element = browser.find_element(By.ID, "password")
    element = browser.find_element(By.XPATH, "//input[@id='password']")
    element.send_keys(CRYPT)
    browser.implicitly_wait(0.1)
    print('***** 取引暗証番号' , datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')

    # 確認方法 (省略する)
    browser.find_element(By.CSS_SELECTOR, ".pcmm-foreign-stock-chb-normal__label").click()
    print('***** 確認方法 (省略する)' , datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')

    # 「注文内容を確認する」を押す
    element = browser.find_element(By.ID, "orderSubmit")
    browser.execute_script("arguments[0].scrollIntoView(true);", element)
    time.sleep(0.1)
    element.click()
    print('***** 「注文内容を確認する」を押す' , datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')


    browser.quit()

# Create Sanic object called app
app = Sanic(__name__)

#Create root
@app.route('/')
async def root(request):
    return response.text('online')

#Listen for signals and submit orders
@app.route('/webhook', methods=['POST'])
async def webhook(request):
    print(request.method)

    if request.method == 'POST':
        try:
            # print('***** curenttime1', datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')
            #Parse the signal data
            data =request.json

            # print(data)
            print(data['message'])
            print(data['ticker'])
            print(data['price'])
            print(data['interval'])

            # print('***** curenttime2', datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')
            browser = rsec_connect()
            # rsec_disconnect(browser)

            return response.text('success', status=200)

        except Exception as e:
            print("An error occurred while processing the request body:", e)
            return response.text('error', status=500)
    else:
        return response.text('error', status=400) 


if __name__ == "__main__":
    app.run(port=5000)
