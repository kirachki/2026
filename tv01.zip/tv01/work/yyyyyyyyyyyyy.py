from selenium import webdriver

# 既に起動されているブラウザのハンドルを取得するためのオプションを指定
options = webdriver.ChromeOptions()
options.debugger_address = "localhost:9222"  # 9222はデフォルトのChrome DevToolsポート

# 既存のブラウザに接続
driver = webdriver.Chrome(options=options)

# すべてのウィンドウのハンドルとタイトルを取得
for handle in driver.window_handles:
    driver.switch_to.window(handle)
    title = driver.title
    print("ウィンドウハンドル:", handle, "タイトル:", title)
    if title == "ホーム | 楽天証券":
        print("条件に一致するウィンドウが見つかりました。")
        break

# ブラウザを閉じる（必要に応じて）
# driver.quit()
