import json
import time
import signal
import sys
from datetime import datetime
# from typing import List, Any, Tuple
from os import abort
from sanic import Sanic
from sanic import response
from sanic import request
from selenium import webdriver
from selenium.webdriver import Firefox, FirefoxOptions
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from pooldbconnect import SQLiteConnectionPool
from poolwebdriver import WebDriverManager

# Create Sanic object called app
app = Sanic(__name__)

#Create root
@app.route('/')
async def root(request):
    return response.text('online')

#Listen for signals and submit orders
@app.route('/webhook', methods=['POST'])
async def webhook(request):
    print(request.method)

    if request.method == 'POST':
        try:
            #Parse the signal data
            data =request.json
            message = data['message']
            exchange = data['exchange']
            ticker = data['ticker']
            price = data['price']
            interval = data['interval']
            rsec_order(message, exchange, ticker, price, interval)
            return response.text('success', status=200)
        except Exception as e:
            print("An error occurred while processing the request body:", e)
            return response.text('error', status=500)
    else:
        return response.text('error', status=400) 

def rsec_top() -> int:
    try:

        # 設定ファイルからログイン情報を取得
        login_info = json.load(open("login_info.json", "r", encoding="utf-8"))
        site_name = "sec_rakuten"
        url_login = login_info[site_name]["url"]
        USER = login_info[site_name]["id"]
        PASS = login_info[site_name]["pass"]

        browser.implicitly_wait(15)
        browser.get(url_login)
        browser.find_element(By.XPATH, "//input[@id='form-login-id']").send_keys(USER)
        browser.find_element(By.XPATH, "//input[@id='form-login-pass']").send_keys(PASS)
        WebDriverWait(browser, 10).until(ec.element_to_be_clickable((By.XPATH, "//button[@type='submit' and @id='login-btn']"))).click()

        # 自動ログアウト機能を停止
        browser.find_element(By.CSS_SELECTOR, ".pcm-gl-auto-logout-btn").click()
        assert browser.switch_to.alert.text == "「自動ログアウト」機能*を停止します。\n\n*自動ログアウト機能とは、最後の操作が行われてから30分経過した際に、自動的にログアウトする機能です。\nログアウトするまで、離席時などのセキュリティにはご注意ください。\nこの機能はお客様のセキュリティ保護のため、ログインする度に設定がONに戻ります。"
        browser.switch_to.alert.accept()

        print('***** rser top displayed', datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')

    except Exception as e:
        print('Exception occuer in rsec_top:', e)
        return 1 
    finally:
        return 0 

def rsec_order(message, exchange, ticker, price, interval) -> int:

    try:
        # find_ticker():
        browser.find_element(By.NAME, "stoc-type-01").click()
        dropdown = browser.find_element(By.NAME, "stoc-type-01")
        dropdown.find_element(By.XPATH, "//option[. = '米国株式']").click()
        browser.find_element(By.ID, "search-stock-01").click()
        browser.find_element(By.ID, "search-stock-01").send_keys(TICKER1)
        browser.find_element(By.CSS_SELECTOR, "#searchStockFormSearchBtn > .rex-icon-search-outline").click()
        # print('***** rsec_find_ticker', datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')
    except Exception as e:
        print('Exception occuer in rsec_order:', e)
        return 1 
    finally:
        return 0 


if __name__ == "__main__":

    # initial process
    web_driver_manager = WebDriverManager()
    browser = web_driver_manager.get_browser()

    # display top
    rsec_top()

    # server boot up
    app.run(port=5969)
    print('***** app.run ', datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')
    
    def signal_handler(sig, frame):
        print('You pressed Ctrl+C!')
        browser.quit()
        sys.exit(0)

    signal.signal(signal.SIGINT, signal_handler)
    print('Press Ctrl+C to disconnect.')

