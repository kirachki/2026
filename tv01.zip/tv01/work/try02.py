# import ccxt
import argparse
import config

parser = argparse.ArgumentParser()
parser.add_argument("--side", help="Trade side (buy or sell)", choices=["buy", "sell"])
parser.add_argument("--symbol", help="Symbol")
parser.add_argument("--amount", help="Amount")
args = parser.parse_args()
side = args.side.lower()
symbol = args.symbol.upper()
amount = float(args.amount)

# bitget_exchange = ccxt.bitget({
#     "apiKey": config.bitget_api_key,
#     "secret": config.bitget_secret_key,
#     "password": config.bitget_password,
#     "enableRateLimit": True
# })

# bitget_exchange.options["defaultType"] = "future"

try:
    print(f"********** 出来た1！！ ****************")
    print(f"side   : {side}****************")
    print(f"symbol : {symbol}****************")
    print(f"amount : {amount}****************")
    print(f"********** 出来た2！！ ****************")
except ccxt.BaseError as e:
    print(f"Error fetching positions: {e}")
    exit(1)

# has_long_position = False
# has_short_position = False

# for position in positions:
#     if position['info']['symbol'] == symbol:
#         if position['info']['holdSide'] == 'long' and float(position['info']['available']) > 0:
#             has_long_position = True
#         elif position['info']['holdSide'] == 'short' and float(position['info']['available']) > 0:
#             has_short_position = True

# if (side == "buy" and has_short_position) or (side == "sell" and has_long_position):
#     bitget_exchange.create_order(symbol, "market", side, amount, params={"reduceOnly": True})
#     bitget_exchange.create_order(symbol, "market", side, amount)
# else:
#     bitget_exchange.create_order(symbol, "market", side, amount)
