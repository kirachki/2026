import json
import time
import signal
import sys
from datetime import datetime
# from typing import List, Any, Tuple
from os import abort
from sanic import Sanic
from sanic import response
from sanic import request
from selenium import webdriver
from selenium.webdriver import Firefox, FirefoxOptions
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
# from pooldbconnect import SQLiteConnectionPool

class WebDriverManager:
    _instance_count = 0
    _max_instances = 2

    def __new__(cls, *args, **kwargs):
        if cls._instance_count < cls._max_instances:
            cls._instance_count += 1
            instance = super(WebDriverManager, cls).__new__(cls, *args, **kwargs)
            instance.browser = cls.start_browser()
            return instance
        else:
            raise Exception("Maximum number of instances reached.")

    @staticmethod
    def start_browser():
        # FirefoxのWebDriverを指定してブラウザを起動
        browser = webdriver.Firefox()
        return browser

    def get_browser(self):
        return self.browser

def rsec_top() -> int:
    try:
        # 設定ファイルからログイン情報を取得
        login_info = json.load(open("login_info.json", "r", encoding="utf-8"))
        site_name = "sec_rakuten"
        url_login = login_info[site_name]["url"]
        USER = login_info[site_name]["id"]
        PASS = login_info[site_name]["pass"]

        browser1.implicitly_wait(15)
        browser1.get(url_login)
        browser1.find_element(By.XPATH, "//input[@id='form-login-id']").send_keys(USER)
        browser1.find_element(By.XPATH, "//input[@id='form-login-pass']").send_keys(PASS)
        WebDriverWait(browser1, 10).until(ec.element_to_be_clickable((By.XPATH, "//button[@type='submit' and @id='login-btn']"))).click()

        # 自動ログアウト機能を停止
        browser1.find_element(By.CSS_SELECTOR, ".pcm-gl-auto-logout-btn").click()
        assert browser1.switch_to.alert.text == "「自動ログアウト」機能*を停止します。\n\n*自動ログアウト機能とは、最後の操作が行われてから30分経過した際に、自動的にログアウトする機能です。\nログアウトするまで、離席時などのセキュリティにはご注意ください。\nこの機能はお客様のセキュリティ保護のため、ログインする度に設定がONに戻ります。"
        browser1.switch_to.alert.accept()

        print('***** rser top displayed', datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')

    except Exception as e:
        print('Exception occuer in rsec_top:', e)
        return 1 
    finally:
        return 0 



def test() -> int:

    try:
        print("11111111111111111111111")

        # browser1.get("https://www.rakuten.co.jp")
        print("Title of the page :", browser1.title)

        rsec_order()

        print("22222222222222222222222")
    except Exception as e:
        print('Exception occuer in rsec_order:', e)
        return 1 
    finally:
        return 0 


def rsec_order() -> int:

    try:
        print("333333333333333333333333")

        print("Title of the page 1:", browser1.title)

        print("444444444444444444444444")

        # dropdown = browser1.find_element(By.NAME, "stoc-type-01")
        print("33333333333333333")
    except Exception as e:
        print('Exception occuer in rsec_order:', e)
        return 1 
    finally:
        return 0 


if __name__ == "__main__":
    try:
        # WebDriverManagerのインスタンスを作成
        web_driver_manager1 = WebDriverManager()

        # ブラウザを取得
        browser1 = web_driver_manager1.get_browser()

        # 例としてGoogleにアクセスしてタイトルを取得
        # browser1.get("https://www.example.com")
        # print("Title of the page 1:", browser1.title)

        # browser1.get("https://www.yahoo.co.jp")
        # print("Title of the page 1:", browser1.title)

        rsec_top()

        test()

        # ブラウザを閉じる
        browser1.quit()

    except Exception as e:
        print(e)
