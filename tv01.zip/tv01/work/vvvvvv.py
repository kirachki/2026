from datetime import datetime
from os import abort
from sanic import Sanic
from sanic import response
from sanic import request

if __name__  == '__main__':
    print("*** 2-0 ***")

    app = Sanic(__name__)

    print("*** 2 ***")

    #Create root
    @app.route('/')
    async def root(request):
        print("*** 3 ***")
        return response.text('online')

    #Listen for signals and submit orders
    @app.route('/webhook', methods=['POST'])
    async def webhook(request):
        print("*** 4 ***")

        print(request.method)

        if request.method == 'POST':
            try:
                #Parse the signal data
                data =request.json

                # print(data)
                print('*** 1 ***')
                print(data['message'])
                print(data['ticker'])
                print(data['price'])
                print(data['interval'])

                print('*** 2 ***')

                return response.text('success', status=200)

            except Exception as e:
                print("An error occurred while processing the request body:", e)
                return response.text('error', status=500)
        else:
            return response.text('error', status=400) 

    #Run app
    print("*** 1 ***")
    # Create Sanic object called app
    app.run(port=5000)
    print("*** 1-1 ***")
