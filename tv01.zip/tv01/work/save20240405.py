import json
import time
from selenium.webdriver import Firefox, FirefoxOptions
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec

from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities

# from selenium.webdriver.common.by import By
# from selenium.webdriver.support.ui import WebDriverWait
# from selenium.webdriver.support import expected_conditions as EC

def wait_and_click_element(browser, selector):
    wait = WebDriverWait(browser, 10)
    element = wait.until(ec.element_to_be_clickable((By.CSS_SELECTOR, selector)))
    element.click()



# 設定ファイルからログイン情報を取得
login_info = json.load(open("login_info.json", "r", encoding="utf-8"))

# ログインサイト名
site_name = "sec_rakuten"

# ログイン画面URL
url_login = login_info[site_name]["url"]

# ユーザー名、パスワード、暗証番号の指定
USER = login_info[site_name]["id"]
PASS = login_info[site_name]["pass"]
CRYPT = login_info[site_name]["crypt"]

# Firefoxのヘッドレスモードを有効にする
options = FirefoxOptions()
# options.add_argument('--headless')

# Firefoxを起動する
browser = Firefox(options=options)

# Input userid
browser.get(url_login)
browser.find_element(By.ID, "form-login-id").send_keys(USER)

# Input password
browser.find_element(By.ID, "form-login-pass").send_keys(PASS)

# Press login button
browser.find_element(By.ID, "login-btn").click()

# ページロード完了まで待機
# WebDriverWait(browser, 10).until(ec.presence_of_element_located((By.ID, "asset_total_possess_btn")))

browser.find_element(By.CSS_SELECTOR, ".pcm-gl-auto-logout-btn").click()
assert browser.switch_to.alert.text == "「自動ログアウト」機能*を停止します。\n\n*自動ログアウト機能とは、最後の操作が行われてから30分経過した際に、自動的にログアウトする機能です。\nログアウトするまで、離席時などのセキュリティにはご注意ください。\nこの機能はお客様のセキュリティ保護のため、ログインする度に設定がONに戻ります。"
browser.switch_to.alert.accept()

browser.find_element(By.NAME, "stoc-type-01").click()
dropdown = browser.find_element(By.NAME, "stoc-type-01")
dropdown.find_element(By.XPATH, "//option[. = '米国株式']").click()
browser.find_element(By.ID, "search-stock-01").click()
browser.find_element(By.ID, "search-stock-01").send_keys("NVDA")

browser.find_element(By.CSS_SELECTOR, "#searchStockFormSearchBtn > .rex-icon-search-outline").click()

element = browser.find_element(By.CSS_SELECTOR, ".pcmm-btlk-function > .pcmm-btlk__text")
browser.implicitly_wait(2)

actions = ActionChains(browser)
browser.implicitly_wait(2)

actions.move_to_element(element).perform()
browser.implicitly_wait(2)

element = browser.find_element(By.CSS_SELECTOR, "body")
browser.implicitly_wait(2)

actions = ActionChains(browser)

element = browser.find_element(By.CSS_SELECTOR, ".pcmm-btlk-sell")
browser.find_element(By.CSS_SELECTOR, ".pcmm-btlk-sell > .pcmm-btlk__text").click()
browser.implicitly_wait(2)


browser.find_element(By.CSS_SELECTOR, "#specific-account .pcmm-btlk__text").click()
print('*** 0 ***')
browser.implicitly_wait(2)

# ---------------------------------------------------------------------------------------------
# 数量
browser.find_element(By.ID, "orderValueInput").click()
browser.find_element(By.ID, "orderValueInput").send_keys("1")
time.sleep(10)

# 成行
# 要素が表示されるまでページをスクロールする
element = browser.find_element(By.CSS_SELECTOR, "#pcmm-foreign-stock-order-form-sct--price .pcmm-rbtn-group__item:nth-child(2) > .pcmm-rbtn-group__label")
# element = browser.find_element(By.CSS_SELECTOR, "#pcmm-foreign-stock-order-form-sct--estimated-profit-loss > .pcmm-foreign-stock-order-form__box--right > .pcmm--is-dis-flex")
browser.implicitly_wait(2)
time.sleep(2)
browser.execute_script("arguments[0].scrollIntoView(true);", element)
browser.implicitly_wait(2)
time.sleep(2)
element.click()


browser.implicitly_wait(2)
time.sleep(2)

print('*** 1 ***')

# ドルで受け取る
# browser.find_element(By.CSS_SELECTOR, "#pcmm-foreign-stock-order-form-sct--price .pcmm-rbtn-group__item:nth-child(2) > .pcmm-rbtn-group__label").click()
print('*** 2 ***')
browser.find_element(By.CSS_SELECTOR, "#pcmm-foreign-stock-order-form-sct--payment-method .pcmm-rbtn-group__item:nth-child(1) > .pcmm-rbtn-group__label").click()
browser.find_element(By.CSS_SELECTOR, "#pcmm-foreign-stock-order-form-sct--payment-method .pcmm-rbtn-group__item:nth-child(2) > .pcmm-rbtn-group__label").click()

# 暗証番号
browser.implicitly_wait(2)
time.sleep(2)
print('*** 3 ***')
# browser.find_element(By.ID, "password").send_keys(CRYPT)

element = browser.find_element(By.ID, "password")
element.send_keys("1196")
# element.send_keys(CRYPT)
browser.implicitly_wait(2)



element.send_keys(Keys.TAB)
element.click()

element.send_keys(Keys.TAB)

time.sleep(5)

element.click()

print('*** 4 ***')
# 確認方法 (省略する)
# browser.implicitly_wait(2)
# time.sleep(2)
# browser.find_element(By.CSS_SELECTOR, ".pcmm-foreign-stock-chb-normal__label").click()









print('*** 5 ***')
time.sleep(5)
# 注文内容を確認する
# element = browser.find_element(By.ID, "orderSubmit")
# browser.execute_script("arguments[0].scrollIntoView(true);", element)
# element.click()
wait_and_click_element(browser, "#orderSubmit")

print('*** 6 ***')

time.sleep(10)




# browser.find_element(By.ID, "orderValueInput").click()
# print('*** 11 ***')

# # orderValue (数量)
# browser.find_element(By.ID, "orderValueInput").send_keys("1")
# print('*** 12 ***')
# browser.implicitly_wait(2)
# time.sleep(10)

# # Price (成行)
# # 要素がクリック可能になるまで待機してからクリックする
# # browser.find_element(By.ID, "price-market").click()
# wait = WebDriverWait(browser, 100)
# element = wait.until(ec.element_to_be_clickable((By.ID, "price-market")))
# element.click()

# print('*** 12-1 ***')

# # payment-method (決済方法:ドルで受け取る)
# browser.find_element(By.ID, "payment-method--dollar").click()
# time.sleep(10)

# print('*** 12-2 ***')


# # password (取引暗証番号)
# browser.find_element(By.ID, "password").send_keys("1195")
# print('*** 16 ***')
# browser.implicitly_wait(2)
# time.sleep(10)

# # 確認方法 (省略する)
# # browser.find_element(By.CSS_SELECTOR, ".pcmm-foreign-stock-chb-normal__label").click()

# # 注文内容を確認する
# browser.find_element(By.ID, "orderSubmit").click()
# print('*** 17 ***')
# browser.implicitly_wait(2)
# time.sleep(5)

browser.quit()


