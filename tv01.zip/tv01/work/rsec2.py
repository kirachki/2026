from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# ブラウザのハンドルを取得してログインする関数
def login_to_rakuten(browser):
    # ウィンドウハンドルを取得
    window_handles = browser.window_handles
    
    # 各ウィンドウを順にチェックし、「楽天証券」のタイトルを持つウィンドウを探す
    for handle in window_handles:
        browser.switch_to.window(handle)
        if "米国株式取引 売り注文 - 注文 - 外国株式 - 楽天証券[PC]" in browser.title:
            print("ログインが完了しました。")
            return True
    
    # 「楽天証券」のタイトルを持つウィンドウが見つからない場合はエラーを出力
    print("楽天証券のタブが見つかりませんでした。")
    return False

# ブラウザを起動してログインする
def main():
    # ここではChromeを使用していますが、適宜ブラウザを変更してください
    browser = webdriver.Chrome()
    
    # 一度楽天証券のサイトにアクセスし、ログイン画面を開いた状態にする
    browser.get("https://www.rakuten-sec.co.jp/")
    time.sleep(5)  # ウェブサイトが読み込まれるまで待機
    
    # ログイン処理を行う
    login_success = login_to_rakuten(browser)
    
    # ログインが成功した場合はブラウザをクローズする
    if login_success:
        browser.quit()

if __name__ == "__main__":
    main()
