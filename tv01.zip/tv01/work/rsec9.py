import json
import time
import signal
import sys
from selenium.webdriver import Firefox, FirefoxOptions
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys

def wait_and_click_element(browser, selector):
    wait = WebDriverWait(browser, 10)
    element = wait.until(ec.element_to_be_clickable((By.CSS_SELECTOR, selector)))
    element.click()

# 楽天証券ログイン > 売り注文画面
def rsec_connect():
    # 設定ファイルからログイン情報を取得
    login_info = json.load(open("login_info.json", "r", encoding="utf-8"))

    # ログインサイト名
    site_name = "sec_rakuten"

    # ログイン画面URL
    url_login = login_info[site_name]["url"]

    # ユーザー名、パスワード、暗証番号の指定
    USER = login_info[site_name]["id"]
    PASS = login_info[site_name]["pass"]
    CRYPT = login_info[site_name]["crypt"]

    # Firefoxのヘッドレスモードを有効にする
    options = FirefoxOptions()
    # options.add_argument('--headless')

    # Firefoxを起動する
    browser = Firefox(options=options)

    # 1.ログイン画面
    # Input userid
    browser.get(url_login)
    browser.find_element(By.ID, "form-login-id").send_keys(USER)

    # Input password
    browser.find_element(By.ID, "form-login-pass").send_keys(PASS)

    # Press login button
    browser.find_element(By.ID, "login-btn").click()

    # 2.トップ画面
    # 自動ログアウト機能を停止
    browser.find_element(By.CSS_SELECTOR, ".pcm-gl-auto-logout-btn").click()
    assert browser.switch_to.alert.text == "「自動ログアウト」機能*を停止します。\n\n*自動ログアウト機能とは、最後の操作が行われてから30分経過した際に、自動的にログアウトする機能です。\nログアウトするまで、離席時などのセキュリティにはご注意ください。\nこの機能はお客様のセキュリティ保護のため、ログインする度に設定がONに戻ります。"
    browser.switch_to.alert.accept()

    # 銘柄指定検索（米国株式固定）
    browser.find_element(By.NAME, "stoc-type-01").click()
    dropdown = browser.find_element(By.NAME, "stoc-type-01")
    dropdown.find_element(By.XPATH, "//option[. = '米国株式']").click()
    browser.find_element(By.ID, "search-stock-01").click()
    browser.find_element(By.ID, "search-stock-01").send_keys("NVDA")
    browser.find_element(By.CSS_SELECTOR, "#searchStockFormSearchBtn > .rex-icon-search-outline").click()

    # 「売り注文」押下
    element = browser.find_element(By.CSS_SELECTOR, ".pcmm-btlk-function > .pcmm-btlk__text")
    actions = ActionChains(browser)
    actions.move_to_element(element).perform()
    element = browser.find_element(By.CSS_SELECTOR, "body")
    actions = ActionChains(browser)
    element = browser.find_element(By.CSS_SELECTOR, ".pcmm-btlk-sell")
    browser.find_element(By.CSS_SELECTOR, ".pcmm-btlk-sell > .pcmm-btlk__text").click()

    browser.find_element(By.CSS_SELECTOR, "#specific-account .pcmm-btlk__text").click()
    browser.implicitly_wait(2)

    # 売り注文受付画面(別メソッドに移動)
    # # orderValue (数量)
    # browser.find_element(By.ID, "orderValueInput").click()
    # browser.find_element(By.ID, "orderValueInput").send_keys("1")

    # Price (成行注文)
    # 要素が表示されるまでページをスクロールする(待機させないと成行が選択されないのでsleepは絶対に削除しない)
    time.sleep(5)
    element = browser.find_element(By.CSS_SELECTOR, "#pcmm-foreign-stock-order-form-sct--price .pcmm-rbtn-group__item:nth-child(2) > .pcmm-rbtn-group__label")
    time.sleep(5)
    browser.execute_script("arguments[0].scrollIntoView(true);", element)
    time.sleep(5)
    element.click()
    time.sleep(5)

    # print('*** 1 ***')

    # # payment-method (決済方法:ドルで受け取る)
    browser.find_element(By.CSS_SELECTOR, "#pcmm-foreign-stock-order-form-sct--payment-method .pcmm-rbtn-group__item:nth-child(1) > .pcmm-rbtn-group__label").click()
    browser.find_element(By.CSS_SELECTOR, "#pcmm-foreign-stock-order-form-sct--payment-method .pcmm-rbtn-group__item:nth-child(2) > .pcmm-rbtn-group__label").click()

    # password (取引暗証番号)
    browser.implicitly_wait(2)
    time.sleep(2)
    element = browser.find_element(By.ID, "password")
    element.send_keys(CRYPT)
    browser.implicitly_wait(2)

    # 確認方法 (省略する)
    browser.find_element(By.CSS_SELECTOR, ".pcmm-foreign-stock-chb-normal__label").click()

    return browser

# ブラウザ終了
def rsec_disconnect(browser):
    browser.quit()

def rsec_order(browser, order_volume):

    # 注文数量を指定
    browser.find_element(By.ID, "orderValueInput").click()
    browser.find_element(By.ID, "orderValueInput").send_keys(order_volume)

    # 「注文内容を確認する」を押す
    element = browser.find_element(By.ID, "orderSubmit")
    browser.execute_script("arguments[0].scrollIntoView(true);", element)
    time.sleep(5)
    element.click()

    return browser


def main():
    browser = rsec_connect()

    def signal_handler(sig, frame):
        print('You pressed Ctrl+C!')
        rsec_disconnect(browser)
        sys.exit(0)

    signal.signal(signal.SIGINT, signal_handler)
    print('Press Ctrl+C to disconnect.')

    order_volume = 3
    rsec_order(browser,order_volume)

    while True:
        time.sleep(1)


if __name__ == "__main__":
    main()
