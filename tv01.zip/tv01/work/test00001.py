from selenium import webdriver
from selenium.webdriver.common.by import By

# 起動中のブラウザを探す
browser = webdriver.Remote(command_executor='http://localhost:4444/wd/hub', desired_capabilities={})

# タイトルが"売り注文"で始まるウィンドウを探す
target_window_handle = None
for handle in browser.window_handles:
    browser.switch_to.window(handle)
    if browser.title.startswith("売り注文"):
        target_window_handle = handle
        break

# 対象のウィンドウが見つかった場合に処理を実行
if target_window_handle:
    browser.switch_to.window(target_window_handle)
    # 注文数量を指定（例: 100）
    order_volume = "100"
    order_value_input = browser.find_element(By.ID, "orderValueInput")
    order_value_input.click()
    order_value_input.send_keys(order_volume)
else:
    print("対象のウィンドウが見つかりませんでした。")

# ブラウザを閉じる
browser.quit()
