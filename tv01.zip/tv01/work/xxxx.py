from selenium.webdriver import Chrome, ChromeOptions
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys

def wait_and_click_element(browser, selector):
    wait = WebDriverWait(browser, 10)
    element = wait.until(ec.element_to_be_clickable((By.CSS_SELECTOR, selector)))
    element.click()

# 楽天証券ログイン > 売り注文画面
def rsec_order():

    print('***** 準備        ', datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')

    # Chromeをヘッドレスモードで起動する
    options = ChromeOptions()
    # options.add_argument('--headless')
    browser = Chrome(options=options)
    browser.get(url_login)

    # -------------------------------------
    # 1.ログイン画面
    # -------------------------------------
    print('***** 開始        ', datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')

    # Input userid
    element = WebDriverWait(browser, 10).until(ec.element_to_be_clickable((By.XPATH, "/html/body/div[2]/div[1]/div[2]/div[1]/div[2]/div/form/div/div[1]/input[1]")))
    element.send_keys(USER)
    print('***** 1            ', datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')

    # Input password
    element = WebDriverWait(browser, 10).until(ec.element_to_be_clickable((By.XPATH, "/html/body/div[2]/div[1]/div[2]/div[1]/div[2]/div/form/div/div[1]/input[2]")))
    element.send_keys(PASS)
    print('***** 2            ', datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')

    # Press login button
    element = WebDriverWait(browser, 10).until(ec.element_to_be_clickable((By.XPATH, "/html/body/div[2]/div[1]/div[2]/div[1]/div[2]/div/form/ul/li[1]/button")))
    element.click()
    print('***** 3            ', datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')

    print('***** ログイン画面', datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')

    # -------------------------------------
    # 2.トップ画面
    # -------------------------------------
    # 自動ログアウト機能を停止
    browser.find_element(By.CSS_SELECTOR, ".pcm-gl-auto-logout-btn").click()
    assert browser.switch_to.alert.text == "「自動ログアウト」機能*を停止します。\n\n*自動ログアウト機能とは、最後の操作が行われてから30分経過した際に、自動的にログアウトする機能です。\nログアウトするまで、離席時などのセキュリティにはご注意ください。\nこの機能はお客様のセキュリティ保護のため、ログインする度に設定がONに戻ります。"
    browser.switch_to.alert.accept()

    # 銘柄指定検索（米国株式固定）
    print('***** 銘柄指定検索', datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')
    browser.find_element(By.NAME, "stoc-type-01").click()
    dropdown = browser.find_element(By.NAME, "stoc-type-01")
    dropdown.find_element(By.XPATH, "//option[. = '米国株式']").click()
    browser.find_element(By.ID, "search-stock-01").click()
    browser.find_element(By.ID, "search-stock-01").send_keys(TICKER1)
    browser.find_element(By.CSS_SELECTOR, "#searchStockFormSearchBtn > .rex-icon-search-outline").click()
    print('***** トップ画面  ', datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')

    # 「売り注文」押下
    element = browser.find_element(By.CSS_SELECTOR, ".pcmm-btlk-function > .pcmm-btlk__text")
    actions = ActionChains(browser)
    actions.move_to_element(element).perform()
    element = browser.find_element(By.CSS_SELECTOR, "body")
    actions = ActionChains(browser)
    element = browser.find_element(By.CSS_SELECTOR, ".pcmm-btlk-sell")
    browser.find_element(By.CSS_SELECTOR, ".pcmm-btlk-sell > .pcmm-btlk__text").click()

    # -------------------------------------
    # 3.保有銘柄一覧画面
    # -------------------------------------
    # 特定口座セクションの「売り」押下
    browser.find_element(By.CSS_SELECTOR, "#specific-account .pcmm-btlk__text").click()
    print('***** 「売り注文」', datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')

    # -------------------------------------
    # 4.売り注文 / 受付画面
    # -------------------------------------
    # 4-1.orderValue (数量)
    time.sleep(2)
    element = browser.find_element(By.XPATH, "//input[@id='orderValueInput']")
    browser.execute_script("arguments[0].scrollIntoView(true);", element)
    time.sleep(2)
    element.click()
    element.send_keys(ORDER_AMOUNT)
    print('***** 数量入力    ' , datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')

    # 4-2.Price (成行注文)
    time.sleep(2)
    element = browser.find_element(By.CSS_SELECTOR, "#pcmm-foreign-stock-order-form-sct--price .pcmm-rbtn-group__item:nth-child(2) > .pcmm-rbtn-group__label")
    browser.execute_script("arguments[0].scrollIntoView(true);", element)
    time.sleep(2)
    element
