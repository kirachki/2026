import json
from selenium.webdriver import Firefox, FirefoxOptions
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
import time

# 設定ファイルからログイン情報を取得
login_info = json.load(open("login_info.json", "r", encoding="utf-8"))

# ログインサイト名
site_name = "sec_rakuten"

# ログイン画面URL
url_login = login_info[site_name]["url"]

# ユーザー名とパスワードの指定
USER = login_info[site_name]["id"]
PASS = login_info[site_name]["pass"]

# Firefoxのヘッドレスモードを有効にする
options = FirefoxOptions()
# options.add_argument('--headless')

# Firefoxを起動する
browser = Firefox(options=options)

window_handles = browser.window_handles

for handle in window_handles:
    browser.switch_to.window(handle)
    # if browser.title.startswith("楽天証券") and browser.title.endswith("証券"):
    # if browser.title.startswith("米国"):
    if "米国株式取引 売り注文 | 注文 | 外国株式 | 楽天証券[PC]" in browser.title:
        print("楽天証券のログイン画面を見つけました。ログイン処理を開始します。")
    else:
        print("楽天証券のログイン画面を見つてない。")

browser.quit()
