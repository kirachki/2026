import requests
import json

# webhook_url = 'https://f504-110-131-91-224.ngrok-free.app/webhook'
webhook_url = 'http://127.0.0.1:5000/webhook'

# data = {'message': 'sell', 'exchange': 'TSE', 'ticker': 'TOPIX', 'price': '900.00', 'interval': '1'}
# data = {'message': 'sell', 'exchange': 'NASDA', 'ticker': 'MSFT', 'price': '850.00', 'interval': '1'}

# data = {'message': 'sell', 'exchange': 'NASDA', 'ticker': 'NVDA', 'price': '850.00', 'interval': '1'}
# data = {'message': 'sell', 'exchange': 'BATS', 'ticker': 'APPL', 'price': '850.00', 'interval': '1'}

# data = {'message': 'sell', 'exchange': 'BATS', 'ticker': 'NVDA', 'price': '900.01', 'interval': '1'}
# data = {'message': 'sell', 'exchange': 'BATS', 'ticker': 'APPL', 'price': '900.01', 'interval': '1'}

data = {'message': 'sell', 'exchange': 'BATS', 'ticker': 'NVDA', 'price': '129.37', 'interval': '1'}
# data = {'message': 'sell', 'exchange': 'BATS', 'ticker': 'MU', 'price': '900.01', 'interval': '1'}

r = requests.post(webhook_url, data=json.dumps(data), headers={'Content-Type': 'application/json'})
