import json
import time
import signal
import sys
from datetime import datetime
# from typing import List, Any, Tuple
from os import abort
from sanic import Sanic
from sanic import response
from sanic import request

from selenium import webdriver
from selenium.webdriver import Firefox, FirefoxOptions
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from pooldbconnect import SQLiteConnectionPool

app = Sanic(__name__)

#Create root
@app.route('/')
async def root(request):
    return response.text('online')

#Listen for signals and submit orders
@app.route('/webhook', methods=['POST'])
async def webhook(request):
    if request.method == 'POST':
        try:
            #Parse the signal data
            data =request.json
            # print(data['message'])
            # print(data['exchange'])
            # print(data['ticker'])
            # print(data['price'])
            # print(data['interval'])

            message = data['message']
            exchange = data['exchange']
            ticker = data['ticker']
            price = data['price']
            interval = data['interval']

            # request order
            r_sec_order(message, exchange, ticker, price, interval)

            return response.text('success', status=200)

        except Exception as e:
            print("An error occurred while processing webhook request:", e)
            return response.text('error', status=500)
    else:
        return response.text('error', status=400) 



class WebDriverManager:
    _instance_count = 0
    _max_instances = 2

    def __new__(cls, *args, **kwargs):
        if cls._instance_count < cls._max_instances:
            cls._instance_count += 1
            instance = super(WebDriverManager, cls).__new__(cls, *args, **kwargs)
            instance.browser = cls.start_browser()
            return instance
        else:
            raise Exception("Maximum number of instances reached.")

    @staticmethod
    def start_browser():
        # FirefoxのWebDriverを指定してブラウザを起動
        browser = webdriver.Firefox()
        return browser

    def get_browser(self):
        return self.browser




def r_sec_order(message, exchange, ticker, price, interval) -> int:
    try:

        print('***** order start  ' , datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')

        # 設定ファイルからログイン情報を取得
        login_info = json.load(open("login_info.json", "r", encoding="utf-8"))
        site_name = "sec_rakuten"
        url_login = login_info[site_name]["url"]
        USER = login_info[site_name]["id"]
        PASS = login_info[site_name]["pass"]

        # 設定ファイルから注文情報を取得
        order_info = json.load(open("order_info.json", "r", encoding="utf-8"))
        order_name = "order_info"
        CRYPT = order_info[order_name]["crypt"]
        ORDER_AMOUNT = order_info[order_name]["orderamount"]
        TOTAL_AMOUNT = order_info[order_name]["totalamount"]
        INTERVAL = order_info[order_name]["interval"]
        TICKER1 = order_info[order_name]["ticker1"]
        TICKER2 = order_info[order_name]["ticker2"]
        TICKER3 = order_info[order_name]["ticker3"]

        connection_pool = SQLiteConnectionPool(max_connections=1)
        connection1 = connection_pool.get_connection()

        # エラーチェック
        ordered_flg = 0
        # 1:リクエスト内容不正 
        if ordered_flg == 0 and \
            message != "sell":
            ordered_flg = 1

        if ordered_flg == 0 and \
            exchange != "BATS":
            ordered_flg = 1

        # 2:conf設定外
        if ordered_flg == 0 and \
            (ticker != TICKER1 and \
            ticker != TICKER2 and \
            ticker != TICKER3):
            ordered_flg = 2

        if float(price) <= 900:
            ordered_flg = 2

        # 3:期間内の売買回数超過


        # webhook の内容を記録して、そのPKを取得
        booking_webhook(connection1, message, exchange, ticker, price, interval, ordered_flg)
        webhook_id = get_booked_key(connection1)

        print(f'***** ordered_flg : {ordered_flg} *****')
        if ordered_flg != 0:
            connection_pool.release_connection(connection1)
            return 0

        print(f'***** webhook_id   : {webhook_id} *****')


        # ブラウザを起動して注文する
        web_driver_manager1 = WebDriverManager()
        browser = web_driver_manager1.get_browser()
        browser.implicitly_wait(15)
        browser.get(url_login)
        browser.find_element(By.XPATH, "//input[@id='form-login-id']").send_keys(USER)
        browser.find_element(By.XPATH, "//input[@id='form-login-pass']").send_keys(PASS)
        WebDriverWait(browser, 10).until(ec.element_to_be_clickable((By.XPATH, "//button[@type='submit' and @id='login-btn']"))).click()

        # 自動ログアウト機能を停止
        # browser.find_element(By.CSS_SELECTOR, ".pcm-gl-auto-logout-btn").click()
        # assert browser.switch_to.alert.text == "「自動ログアウト」機能*を停止します。\n\n*自動ログアウト機能とは、最後の操作が行われてから30分経過した際に、自動的にログアウトする機能です。\nログアウトするまで、離席時などのセキュリティにはご注意ください。\nこの機能はお客様のセキュリティ保護のため、ログインする度に設定がONに戻ります。"
        # browser.switch_to.alert.accept()


        # find_ticker():
        browser.find_element(By.NAME, "stoc-type-01").click()
        dropdown = browser.find_element(By.NAME, "stoc-type-01")
        dropdown.find_element(By.XPATH, "//option[. = '米国株式']").click()
        browser.find_element(By.ID, "search-stock-01").click()
        browser.find_element(By.ID, "search-stock-01").send_keys(TICKER1)
        browser.find_element(By.CSS_SELECTOR, "#searchStockFormSearchBtn > .rex-icon-search-outline").click()

        # 検索された銘柄画面で「売り注文」押下
        element = browser.find_element(By.CSS_SELECTOR, ".pcmm-btlk-function > .pcmm-btlk__text")
        actions = ActionChains(browser)
        actions.move_to_element(element).perform()
        element = browser.find_element(By.CSS_SELECTOR, "body")
        actions = ActionChains(browser)
        element = browser.find_element(By.CSS_SELECTOR, ".pcmm-btlk-sell")
        browser.find_element(By.CSS_SELECTOR, ".pcmm-btlk-sell > .pcmm-btlk__text").click()

        # 保有銘柄一覧画面で特定口座セクションの「売り」押下
        browser.find_element(By.CSS_SELECTOR, "#specific-account .pcmm-btlk__text").click()
        WebDriverWait(browser, 10).until(ec.element_to_be_clickable((By.XPATH, "//label[@class='pcmm-rbtn-group__label' and @for='price-market']"))).click()

        browser.execute_script("window.scrollTo(100, 100);")


        # 4.売り注文 / 受付画面
        # 4-1.orderValue (数量)
        WebDriverWait(browser, 10).until(ec.element_to_be_clickable((By.XPATH, "//input[@id='orderValueInput']"))).send_keys(ORDER_AMOUNT)

        # 4-2.Price (成行注文)
        time.sleep(3)
        element = browser.find_element(By.CSS_SELECTOR, "#pcmm-foreign-stock-order-form-sct--price .pcmm-rbtn-group__item:nth-child(2) > .pcmm-rbtn-group__label")
        time.sleep(3)
        browser.execute_script("arguments[0].scrollIntoView(true);", element)
        time.sleep(3)
        element.click()

        # 4-3.payment-method (決済方法:ドルで受け取る)
        time.sleep(3)
        browser.find_element(By.CSS_SELECTOR, "#pcmm-foreign-stock-order-form-sct--payment-method .pcmm-rbtn-group__item:nth-child(1) > .pcmm-rbtn-group__label").click()
        browser.find_element(By.CSS_SELECTOR, "#pcmm-foreign-stock-order-form-sct--payment-method .pcmm-rbtn-group__item:nth-child(2) > .pcmm-rbtn-group__label").click()


        # 4-4.取引暗証番号
        browser.implicitly_wait(2)
        element = browser.find_element(By.XPATH, "//input[@id='password']")
        element.send_keys(CRYPT)

        # 4-5.確認方法 (省略する)
        browser.implicitly_wait(4)
        browser.find_element(By.CSS_SELECTOR, ".pcmm-foreign-stock-chb-normal__label").click()

        # 4-5.「注文内容を確認する」を押す
        browser.implicitly_wait(4)
        browser.switch_to.active_element.send_keys(Keys.TAB)
        browser.switch_to.active_element.click()
        print('***** order finish ' , datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')
        browser.quit()

        # ordr の内容を記録(PKはwebhookのPK)
        booking_order(connection1, webhook_id)

        connection_pool.release_connection(connection1)
    except Exception as e:
        print('Exception occuer in rsec_order:', e)
        return 99
    # finally:
        print('***** order finish', datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], '*****')
        # 次の準備
        # browser.execute_script("window.scrollTo(0, 0);")
        browser.quit()
        return 0 

def booking_webhook(connection, message, exchange, ticker, price, interval, ordered_flg):
    try:
        cursor = connection.cursor()
        cursor.execute("INSERT INTO booked_webhook (message, exchange, ticker, price, interval, ordered_flg) \
        VALUES (?, ?, ?, ?, ?, ?)", (message, exchange, ticker, price, interval, ordered_flg))
        connection.commit()
        cursor.close()
        return 0
    except Exception as e:
        print('Exception occuer in booking_webhook:', e)
        connection.rollback()
        return 1 
    finally:
        connection.rollback()

def booking_order(connection, webhook_id):
    try:
        cursor = connection.cursor()
        cursor.execute("INSERT INTO order_history (order_comment, webhook_id)  VALUES (?, ?)", ('', webhook_id))
        connection.commit()
        cursor.close()
        return 0
    except Exception as e:
        print('Exception occuer in booking_order:', e)
        connection.rollback()
        return 1 
    finally:
        connection.rollback()

# def get_booked_key(connection) -> int:
#     try:
#         cursor = connection.cursor()
#         # cursor.execute("SELECT * FROM table_name")
#         cursor.execute("SELECT id FROM booked_webhook ORDER BY id DESC LIMIT 1")
#         rows = cursor.fetchall()
#         for row in rows:
#             # print(row)
#             # print(row[0])  # idの値を表示
#             break
#         webhook_id = row[0] 
#         cursor.close()
#         return int(webhook_id)
#     except Exception as e:
#         print('Exception occuer in get_booked_key:', e)
#         return 0
#     finally:
#         connection.rollback()

def get_booked_key(connection) -> int:
    try:
        webhook_id = 0
        cursor = connection.cursor()
        cursor.execute("SELECT id FROM booked_webhook ORDER BY id DESC LIMIT 1")
        webhook_id = cursor.fetchone()[0]  # 直接int型で受け取る
        cursor.close()
        return int(webhook_id)
    except Exception as e:
        print('Exception occuer in get_booked_key:', e)
        return 0
    finally:
        connection.rollback()


def select_data(connection):
    try:
        cursor = connection.cursor()
        # cursor.execute("SELECT * FROM table_name")
        cursor.execute("select * from booked_webhook")
        rows = cursor.fetchall()
        for row in rows:
            print(row)
        return 0 
    except Exception as e:
        print('Exception occuer in select_data:', e)
        return 1
    finally:
        cursor.close()

def update_data(connection):
    try:
        cursor = connection.cursor()
        # cursor.execute("UPDATE booked_webhook SET col_2 = ? WHERE col_1 = ?", data)
        connection.commit()
        cursor.close()
        return 0 
    except Exception as e:
        print('Exception occuer in select_data:', e)
        return 1
    finally:
        connection.rollback()


        # id INTEGER PRIMARY KEY AUTOINCREMENT,
        # booked_dtm TEXT DEFAULT (strftime ('%Y-%m-%d %H:%M:%f', 'now')),
        # update_dtm TEXT DEFAULT (strftime ('%Y-%m-%d %H:%M:%f', 'now')),
        # ordered_flg INTEGER DEFAULT 0,
        # webhook_id INTEGER 






if __name__ == "__main__":
    try:
        # Create Sanic object called app
        app.run(port=5000)

    except Exception as e:
        print(e)
