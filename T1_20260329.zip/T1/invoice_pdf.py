"""
請求書 PDF 生成（ReportLab）。
他モジュールから再利用する場合は build_invoice_pdf_bytes / save_invoice_pdf_to_path を利用。
"""
from __future__ import annotations

import io
import logging
import math
import os
import re
import unicodedata
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation
from pathlib import Path

import db

logger = logging.getLogger(__name__)

# 1ページあたりの明細行数（MAX）
DETAIL_ROWS_PER_PAGE = 10

# sample.pdf と同系の TrueType（Windows: meiryo.ttc 内の Meiryo UI / Meiryo UI Bold）
_INVOICE_PDF_FONT_REGULAR = "InvoicePdfMeiryoUI"
_INVOICE_PDF_FONT_BOLD = "InvoicePdfMeiryoUIBold"
_MEIRYO_UI_TTC_SUBFONT_INDEX = 2


def _register_fallback_cjk_font() -> str:
    """Meiryo UI が使えない環境向け: ReportLab 日本語 CID（失敗時 Helvetica）。"""
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.cidfonts import UnicodeCIDFont

    for name in ("HeiseiKakuGo-W5", "HeiseiMin-W3", "MS-Gothic"):
        try:
            pdfmetrics.registerFont(UnicodeCIDFont(name))
            return name
        except Exception:
            continue
    return "Helvetica"


def _register_invoice_pdf_fonts() -> tuple[str, str]:
    """
    PDFs/sample.pdf と同じファミリー（Meiryo UI / Meiryo UI Bold）を登録する。
    Windows の meiryo.ttc・meiryob.ttc のサブフォント index 2 を使用。
    失敗時は通常・太字とも同一のフォールバックフォントを返す。
    """
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont

    reg = _INVOICE_PDF_FONT_REGULAR
    bold = _INVOICE_PDF_FONT_BOLD
    if reg in pdfmetrics.getRegisteredFontNames() and bold in pdfmetrics.getRegisteredFontNames():
        return reg, bold

    windir = Path(os.environ.get("WINDIR", r"C:\Windows"))
    meiryo_ttc = windir / "Fonts" / "meiryo.ttc"
    meiryob_ttc = windir / "Fonts" / "meiryob.ttc"

    try:
        if meiryo_ttc.is_file() and meiryob_ttc.is_file():
            pdfmetrics.registerFont(
                TTFont(
                    reg,
                    str(meiryo_ttc),
                    subfontIndex=_MEIRYO_UI_TTC_SUBFONT_INDEX,
                )
            )
            pdfmetrics.registerFont(
                TTFont(
                    bold,
                    str(meiryob_ttc),
                    subfontIndex=_MEIRYO_UI_TTC_SUBFONT_INDEX,
                )
            )
            return reg, bold
    except Exception as e:
        logger.warning("Meiryo UI の登録に失敗しました。フォールバックを使います: %s", e)

    fb = _register_fallback_cjk_font()
    return fb, fb


def _read_invoice_hanko_side_text_lines() -> list[str]:
    """static/files/invoice_hanko_side_text.txt からハンコ左横の印字用行を読む（UTF-8）。無い・読めない場合は空。"""
    text_path = Path(__file__).resolve().parent / "static" / "files" / "invoice_hanko_side_text.txt"
    if not text_path.is_file():
        logger.debug("請求書ハンコ横テキストがありません: %s", text_path)
        return []
    try:
        raw = text_path.read_text(encoding="utf-8")
    except Exception as e:
        logger.warning("請求書ハンコ横テキストを読み込めません: %s", e)
        return []
    lines = [ln.rstrip("\r\n") for ln in raw.splitlines()]
    while lines and lines[-1] == "":
        lines.pop()
    return lines


def _draw_invoice_hanko_top_right(
    canvas_obj,
    page_w: float,
    page_h: float,
    margin_x: float,
    font: str,
    font_bold: str,
    line_h: float,
) -> None:
    """請求書1枚目の右上にハンコ画像と、その左側のテキスト（外部ファイル）を描画する。"""
    from reportlab.lib.utils import ImageReader
    from reportlab.pdfbase import pdfmetrics

    side_lines = _read_invoice_hanko_side_text_lines()

    path = Path(__file__).resolve().parent / "PDFs" / "invoice_hanko.png"
    if not path.is_file():
        logger.debug("請求書ハンコ画像がありません: %s", path)
        return
    try:
        ir = ImageReader(str(path))
        iw, ih = ir.getSize()
    except Exception as e:
        logger.warning("請求書ハンコ画像を読み込めません: %s", e)
        return
    if iw <= 0 or ih <= 0:
        return
    max_h_pt = 87.0  # 基準 58pt の 1.5 倍
    stamp_h = max_h_pt
    stamp_w = stamp_h * (float(iw) / float(ih))
    x = page_w - margin_x - stamp_w
    top_inset = 32.0
    y = page_h - top_inset - stamp_h

    # 宛先と同じ行送り。1 行目のみ他行より大きめ（+3pt = 13pt。従来 +1pt からさらに +2pt）。全体左寄せ（ハンコ左端から gap を空けたブロック内）
    gap = 10.0
    fs_addr = 10
    fs_first = fs_addr + 3
    leading = line_h
    max_text_w = 0.0
    for i, line in enumerate(side_lines):
        if not line:
            continue
        fs_use = fs_first if i == 0 else fs_addr
        fn_use = font_bold if i == 0 else font
        max_text_w = max(max_text_w, pdfmetrics.stringWidth(line, fn_use, fs_use))
    text_left_x = x - gap - max_text_w if max_text_w > 0 else x - gap
    # 開始行を宛先1行目相当から 1 行分下げる（前回比 1 行上）
    y_baseline_top = y + stamp_h - 3 - leading
    for i, line in enumerate(side_lines):
        yy = y_baseline_top - i * leading
        if line:
            fs_use = fs_first if i == 0 else fs_addr
            canvas_obj.setFont(font_bold if i == 0 else font, fs_use)
            canvas_obj.drawString(text_left_x, yy, line)

    canvas_obj.drawImage(ir, x, y, width=stamp_w, height=stamp_h, mask="auto")


def _fmt_issue_date_jp(v) -> str:
    """PDF 用に日付を「yyyy年MM月dd日」形式（月日は2桁）で返す。発行日・支払期限など共通。"""
    if v is None:
        return ""
    if hasattr(v, "strftime"):
        return v.strftime("%Y年%m月%d日")
    s = str(v).strip()
    m = re.match(r"^(\d{4})[-/](\d{1,2})[-/](\d{1,2})", s)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        return f"{y}年{mo:02d}月{d:02d}日"
    m2 = re.match(r"^(\d{4})(\d{2})(\d{2})", s)
    if m2:
        return f"{m2.group(1)}年{m2.group(2)}月{m2.group(3)}日"
    return s


def _cell_str(v) -> str:
    if v is None:
        return ""
    return str(v).strip()


def _digits_postal_code_7(v) -> str:
    """
    ヘッダの郵便番号値から最大7桁の数字列を返す。
    「1234567.0」等を数字だけ拾うと8桁になるため、数値として整数化してから桁を取る。
    """
    if v is None:
        return ""
    if isinstance(v, Decimal):
        try:
            if v == v.to_integral_value():
                v = int(v)
            else:
                s = "".join(c for c in str(v) if c.isdigit())
                return s[:7] if len(s) > 7 else s
        except (InvalidOperation, ValueError, OverflowError):
            v = str(v)
    if isinstance(v, bool):
        return ""
    if isinstance(v, int):
        s = str(abs(v))
        return s[:7] if len(s) > 7 else s
    if isinstance(v, float):
        try:
            if math.isfinite(v) and v == int(v) and v >= 0:
                s = str(int(v))
                return s[:7] if len(s) > 7 else s
        except (ValueError, OverflowError):
            pass
    s = unicodedata.normalize("NFKC", _cell_str(v))
    if not s:
        return ""
    s2 = re.sub(r"[\s\u3000\-ー－―（）()〒]", "", s)
    if re.fullmatch(r"\d+\.\d+", s2):
        try:
            f = float(s2)
            if math.isfinite(f) and f == int(f) and f >= 0:
                s2 = str(int(f))
        except ValueError:
            pass
    digits = "".join(c for c in s2 if c.isdigit())
    if len(digits) > 7:
        digits = digits[:7]
    return digits


def _pdf_fill_width_with_char(ch: str, font_name: str, font_size: float, max_width_pt: float) -> str:
    """1文字を横に繰り返し、max_width_pt を埋める（ページ幅いっぱいの罫線風テキスト用）。"""
    from reportlab.pdfbase import pdfmetrics

    if max_width_pt <= 0:
        return ""
    c0 = (ch or "_")[:1] or "_"
    sw = pdfmetrics.stringWidth(c0, font_name, font_size)
    if sw <= 0:
        return c0 * 80
    n = int(max_width_pt / sw)
    return c0 * max(1, n)


def _fmt_detail_tax_rate_label(header: dict) -> str:
    """
    請求ヘッダの税率に 100 を掛け、「課税N%」形式で返す（明細の消費税列は全行これを使う）。
    主に `消費税率`（DB）。空のとき `消費税` を参照。値は小数税率（例 0.1 → 課税10%）を想定。
    """
    raw = header.get("消費税率")
    if raw is None or (isinstance(raw, str) and not str(raw).strip()):
        raw = header.get("消費税")
    if raw is None:
        return ""
    s = str(raw).strip().replace(",", "")
    if not s:
        return ""
    try:
        x = float(s)
    except ValueError:
        return ""
    pct = int(round(x * 100))
    return f"課税{pct}%"


def _parse_invoice_amount_sum(v) -> float:
    """税抜金額などを合計用に float 化。空・不正は 0。"""
    if v is None:
        return 0.0
    s = str(v).strip().replace(",", "").replace("¥", "").replace("￥", "")
    if not s:
        return 0.0
    try:
        return float(s)
    except ValueError:
        return 0.0


def _fmt_pdf_detail_unit_price(v) -> str:
    """明細・単価：整数部は3桁区切りカンマ、小数点以下は常に3桁（0埋め）。"""
    raw = _cell_str(v)
    if not raw:
        return ""
    s = raw.replace(",", "").replace("¥", "").replace("￥", "")
    try:
        q = Decimal(s).quantize(Decimal("0.001"), rounding=ROUND_HALF_UP)
    except InvalidOperation:
        return raw
    sign = "-" if q < 0 else ""
    q = abs(q)
    ip = int(q)
    rem = (q - Decimal(ip)).quantize(Decimal("0.001"), rounding=ROUND_HALF_UP)
    frac_int = int((rem * 1000).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    frac_s = f"{frac_int:03d}"
    return sign + f"{ip:,}.{frac_s}"


def _fmt_pdf_detail_quantity(v) -> str:
    """明細・数量：整数部はカンマ区切り。小数があるときのみ小数部を表示（末尾0省略）。"""
    raw = _cell_str(v)
    if not raw:
        return ""
    s = raw.replace(",", "").replace("¥", "").replace("￥", "")
    try:
        d = Decimal(s)
    except InvalidOperation:
        return raw
    sign = "-" if d < 0 else ""
    da = abs(d)
    if da == da.to_integral_value(rounding=ROUND_HALF_UP):
        return sign + f"{int(da):,}"
    ip = int(da)
    rem = da - Decimal(ip)
    rem_s = format(rem, "f")
    dec_part = rem_s.split(".", 1)[1].rstrip("0")
    return sign + f"{ip:,}.{dec_part}"


def _fmt_pdf_detail_tax_excluded_amount(v) -> str:
    """明細・税抜金額：整数のみ（四捨五入）、カンマ区切り。小数点以下は表示しない。"""
    raw = _cell_str(v)
    if not raw:
        return ""
    s = raw.replace(",", "").replace("¥", "").replace("￥", "")
    try:
        q = Decimal(s).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    except InvalidOperation:
        return raw
    sign = "-" if q < 0 else ""
    return sign + f"{int(abs(q)):,}"


def _header_consumption_tax_rate_float(header: dict) -> float:
    """ヘッダの消費税率（小数。例 0.1 = 10%）。取得できなければ 0.0。"""
    raw = header.get("消費税率")
    if raw is None or (isinstance(raw, str) and not str(raw).strip()):
        raw = header.get("消費税")
    if raw is None:
        return 0.0
    s = str(raw).strip().replace(",", "")
    if not s:
        return 0.0
    try:
        return float(s)
    except ValueError:
        return 0.0


def _fmt_invoice_footer_tax_row_label(header: dict) -> str:
    """明細合計ブロックの消費税行ラベル：消費税（ヘッダ税率×100%）。"""
    pct = int(round(_header_consumption_tax_rate_float(header) * 100))
    return f"消費税（{pct}%）"


def _fmt_pdf_amount_integer_commas(x: float) -> str:
    """PDF 明細フッター等用の整数＋カンマ表記。"""
    return f"{int(round(x)):,}"


def _sanitize_pdf_filename_segment(s: str, max_len: int = 150) -> str:
    """Windows 等で問題になりやすい文字を置換し、長さを制限する。"""
    s = (s or "").strip()
    s = re.sub(r'[\\/:*?"<>|\r\n\t]', "_", s)
    s = s.strip(" .")
    if len(s) > max_len:
        s = s[:max_len]
    return s


def get_invoice_pdf_filename_from_row(row: dict, invoice_no: str = "") -> str:
    """
    保存用 PDF ファイル名。
    形式: 請求書番号_T1_請求書データ_ヘッダ・{宛名_取引先名の値}.pdf
    （宛名_取引先名が空のときは「名称なし」）
    """
    h = row["header"]
    inv_raw = _cell_str(h.get("請求書番号")) or (invoice_no or "").strip()
    meigi = _cell_str(h.get("宛名_取引先名")) or "名称なし"
    part_inv = _sanitize_pdf_filename_segment(inv_raw, max_len=40)
    part_meigi = _sanitize_pdf_filename_segment(meigi, max_len=150)
    return f"{part_inv}_T1_請求書データ_ヘッダ・{part_meigi}.pdf"


def get_invoice_pdf_filename(invoice_no: str) -> str | None:
    """DB から取得してファイル名を返す（データが無い場合は None）。"""
    inv = (invoice_no or "").strip()
    if not inv:
        return None
    row = db.fetch_invoice_for_maintenance(inv)
    if not row:
        return None
    return get_invoice_pdf_filename_from_row(row, invoice_no)


def _fmt_postal_code_jp(v) -> str:
    """郵便番号を PDF 用に「〒999-9999」形式で表示する（7桁にできない場合は数字のみ）。"""
    digits = _digits_postal_code_7(v)
    if len(digits) == 7:
        return f"\u3012{digits[:3]}-{digits[3:]}"
    return digits


def _wrap_pdf_text_to_lines(
    text: str,
    font_name: str,
    font_size: float,
    max_width: float,
    max_lines: int,
) -> list[str]:
    """
    幅 max_width に収まるよう折り返し、ちょうど max_lines 要素のリストを返す（不足は空文字で埋める）。
    収めきれない場合は最終行を「…」付きで省略する。
    """
    from reportlab.pdfbase import pdfmetrics

    def sw(s: str) -> float:
        if not s:
            return 0.0
        return pdfmetrics.stringWidth(s, font_name, font_size)

    raw = (text or "").replace("\r\n", "\n").replace("\r", "\n")
    paras = [p.strip() for p in raw.split("\n")]
    lines_out: list[str] = []
    p_idx = 0
    rest = ""

    def take_next_paragraph() -> bool:
        nonlocal p_idx, rest
        while p_idx < len(paras):
            p = paras[p_idx]
            p_idx += 1
            if p:
                rest = p
                return True
        return False

    overflow = False
    while len(lines_out) < max_lines:
        if not rest:
            if not take_next_paragraph():
                break
        if sw(rest) <= max_width:
            lines_out.append(rest)
            rest = ""
            continue
        lo, hi = 1, len(rest)
        best = 1
        while lo <= hi:
            mid = (lo + hi) // 2
            if sw(rest[:mid]) <= max_width:
                best = mid
                lo = mid + 1
        else:
                hi = mid - 1
        lines_out.append(rest[:best])
        rest = rest[best:].lstrip()

    if rest or p_idx < len(paras):
        overflow = True

    while len(lines_out) < max_lines:
        lines_out.append("")
    lines_out = lines_out[:max_lines]

    if overflow:
        ell = "…"
        nlast = lines_out[-1]
        while nlast and sw(nlast + ell) > max_width:
            nlast = nlast[:-1]
        lines_out[-1] = nlast + ell

    return lines_out


def build_invoice_pdf_bytes_from_row(row: dict) -> bytes:
    """
    fetch 済みの請求データ dict（header / details）から PDF バイト列を生成する。
    """
    from xml.sax.saxutils import escape

    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER, TA_LEFT
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.pdfgen import canvas
    from reportlab.platypus import Paragraph, Table, TableStyle

    header = row["header"]
    details = row["details"] or []

    font, font_bold = _register_invoice_pdf_fonts()
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    w, h = A4

    margin_x = 40
    line_h = 14

    # 請求書・御請求金額直下の罫線（「━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━」相当の ━ 繰り返し）
    _INVOICE_RULE_BAR = "\u2501"
    _INVOICE_RULE_REPEAT_COUNT = 30

    # 明細テーブル列幅（pt・5列：請求内訳は基準幅、単価・数量・金額は均等、消費税はその2/3幅で短縮分を請求内訳へ）
    _avail_tbl = w - 2 * margin_x
    _w_detail_base = 118 * 2
    _rest = max(0.0, _avail_tbl - _w_detail_base)
    _w_mid = _rest / 4.0
    _w_tax = _w_mid * (2.0 / 3.0)
    _w_detail = _w_detail_base + (_w_mid - _w_tax)
    detail_col_widths = [_w_detail, _w_mid, _w_mid, _w_mid, _w_tax]

    # 明細ヘッダ行の背景（淡いグレー）
    _DETAIL_HEADER_BG = colors.HexColor("#e8e8e8")
    _GRID_COLOR = colors.HexColor("#666666")
    _DETAIL_GRID_INNER_W = 0.5
    _DETAIL_GRID_OUTER_W = 1.5  # 明細表の外枠・太線区画（1段太い）
    # 罫線を「透明」に見せる用。PDF では下層の線の上に透明ストロークを重ねても消えないため、地色で上書きする。
    _DETAIL_TABLE_LINE_HIDE = colors.white

    # 明細を 10 行ずつ分割（0件でも1チャンク）
    chunks: list[list[dict]] = []
    if not details:
        chunks = [[]]
    else:
        for i in range(0, len(details), DETAIL_ROWS_PER_PAGE):
            chunks.append(details[i : i + DETAIL_ROWS_PER_PAGE])

    def draw_section2(y: float) -> float:
        """セクション2：送付先（見出しなし。住所・宛名はラベルなし・各2行分を確保）"""
        y -= line_h
        fs = 10
        max_text_w = w - 2 * margin_x
        c.setFont(font, fs)

        c.drawString(margin_x, y, _fmt_postal_code_jp(header.get("郵便番号")))
        y -= line_h

        for part in _wrap_pdf_text_to_lines(
            _cell_str(header.get("住所")), font, fs, max_text_w, 2
        ):
            c.drawString(margin_x, y, part)
            y -= line_h

        fs_meigi = fs + 2
        for part in _wrap_pdf_text_to_lines(
            _cell_str(header.get("宛名_取引先名")), font_bold, fs_meigi, max_text_w, 2
        ):
            c.setFont(font_bold, fs_meigi)
            c.drawString(margin_x, y, part)
            y -= line_h

        y -= line_h
        c.setFont(font, fs)
        c.drawString(margin_x, y, _cell_str(header.get("宛名_担当部署")))
        y -= line_h
        _tanto = _cell_str(header.get("宛名_担当者"))
        c.drawString(margin_x, y, _tanto + ("　様" if _tanto else ""))
        y -= line_h

        from reportlab.pdfbase import pdfmetrics

        _zairyu = "請求書在中"
        pad = 5
        fs_zairyu = fs + 2
        _shift5 = 5 * pdfmetrics.stringWidth("\u3000", font_bold, fs_zairyu)
        _zw = pdfmetrics.stringWidth(_zairyu, font_bold, fs_zairyu)
        box_w = _zw + 2 * pad
        box_h = fs_zairyu + 2 * pad
        box_bottom = y - box_h
        box_left = margin_x + _shift5
        c.setStrokeColor(colors.black)
        c.setLineWidth(1)
        c.rect(box_left, box_bottom, box_w, box_h, stroke=1, fill=0)
        c.setFont(font_bold, fs_zairyu)
        c.drawString(box_left + pad, box_bottom + pad + 2, _zairyu)

        return box_bottom - line_h * 0.8

    def draw_section3(y: float) -> float:
        """セクション3：請求書ヘッダ情報（先頭に請求書タイトル・区切り線・挨拶文）"""
        from reportlab.pdfbase import pdfmetrics

        max_text_w = w - 2 * margin_x

        # 請求書在中の下〜請求書ラベルまでの縦余白（1行分削減済み）
        y -= line_h * 2

        inv_no = _cell_str(header.get("請求書番号"))
        fs_meta = 10
        fs_box = fs_meta - 1
        _hdr_rule_w = pdfmetrics.stringWidth(
            _INVOICE_RULE_BAR * _INVOICE_RULE_REPEAT_COUNT, font, fs_meta
        )
        _y_sei_baseline = y - line_h
        _fs_sei_title = 11  # 従来 13pt 太字から 2pt 小さく・通常ウェイト
        c.setFont(font, _fs_sei_title)
        c.drawString(margin_x, _y_sei_baseline, "請求書")
        _date_jp = _fmt_issue_date_jp(header.get("発行日"))
        _pad_box = 5
        _row_h = line_h + 6
        _lab_w = max(
            pdfmetrics.stringWidth("請求番号", font, fs_box),
            pdfmetrics.stringWidth("発行日", font, fs_box),
        ) + 2 * _pad_box
        _val_w_raw = max(
            pdfmetrics.stringWidth(inv_no, font, fs_box),
            pdfmetrics.stringWidth(_date_jp, font, fs_box),
        ) + 2 * _pad_box
        _val_w = _val_w_raw * 1.2
        _box_w = _lab_w + _val_w
        _box_h = 2 * _row_h
        _y_top_row_baseline = y - 2
        _box_bottom = _y_top_row_baseline - _row_h - _pad_box - 2
        _box_left = w - margin_x - _box_w
        _x_split = _box_left + _lab_w
        _y_split = _box_bottom + _row_h
        c.setStrokeColor(colors.black)
        c.setLineWidth(1)
        c.rect(_box_left, _box_bottom, _box_w, _box_h, stroke=1, fill=0)
        c.line(_x_split, _box_bottom, _x_split, _box_bottom + _box_h)
        c.line(_box_left, _y_split, _box_left + _box_w, _y_split)
        _bl_top = _box_bottom + _row_h + _pad_box + 2
        _bl_bot = _box_bottom + _pad_box + 2
        c.setFont(font, fs_box)
        c.drawString(_box_left + _pad_box, _bl_top, "請求番号")
        c.drawString(_x_split + _pad_box, _bl_top, inv_no)
        c.drawString(_box_left + _pad_box, _bl_bot, "発行日")
        c.drawString(_x_split + _pad_box, _bl_bot, _date_jp)

        _sei_cell_line_y = _y_sei_baseline - 5
        c.setStrokeColor(colors.black)
        c.setLineWidth(1)
        c.line(margin_x, _sei_cell_line_y, margin_x + _hdr_rule_w, _sei_cell_line_y)

        y = _sei_cell_line_y - line_h * 0.9
        c.setFont(font, fs_meta)
        c.drawString(margin_x, y, "下記の通りご請求申し上げます。")
        y -= line_h * 1.15

        fs_k = 10
        c.setFont(font, fs_k)

        def _sw(s: str) -> float:
            return pdfmetrics.stringWidth(s, font, fs_k)

        _lab_w = max(_sw("件名"), _sw("支払期限"))
        _gap = _sw("\u3000") * 2
        x_value_col = margin_x + _lab_w + _gap

        c.drawString(margin_x, y, "件名")
        c.drawString(x_value_col, y, _cell_str(header.get("件名")))
        y -= line_h
        c.drawString(margin_x, y, "支払期限")
        c.drawString(x_value_col, y, _fmt_issue_date_jp(header.get("支払期限")))
        # 支払期限行の次の行位置へ移動 + その直下に空行を1行分挿入（計 line_h×2）
        y -= line_h * 2
        return y - line_h * 1.5

    _detail_hdr_style = ParagraphStyle(
        name="invDetailHdr",
        fontName=font,
        alignment=TA_CENTER,
        leading=10,
        spaceBefore=0,
        spaceAfter=0,
    )

    def _detail_hdr_cell(en: str, ja: str) -> Paragraph:
        return Paragraph(
            f'<font size="5">{escape(en)}</font><br/>'
            f'<font size="9">{escape(ja)}</font>',
            _detail_hdr_style,
        )

    def _detail_header_row() -> list:
        return [
            _detail_hdr_cell("Detail estimate", "請求内訳"),
            _detail_hdr_cell("Unit price", "単価"),
            _detail_hdr_cell("Quantity", "数量"),
            _detail_hdr_cell("Amount", "金額"),
            _detail_hdr_cell("Tax", "消費税"),
        ]

    _detail_item_style = ParagraphStyle(
        name="invDetailItem",
        fontName=font,
        fontSize=6,
        leading=8,
        alignment=TA_LEFT,
        spaceBefore=0,
        spaceAfter=0,
    )

    def _detail_breakdown_cell(d: dict) -> Paragraph:
        """請求項目1 改行 請求項目2 + 半角スペース + 請求項目3"""
        i1 = _cell_str(d.get("請求項目1"))[:500]
        i2 = _cell_str(d.get("請求項目2"))[:300]
        i3 = _cell_str(d.get("請求項目3"))[:300]
        line2 = f"{i2} {i3}".strip()
        if i1 and line2:
            xml = f"{escape(i1)}<br/>{escape(line2)}"
        elif i1:
            xml = escape(i1)
        else:
            xml = escape(line2)
        return Paragraph(xml, _detail_item_style)

    def _detail_body_rows(chunk: list[dict]) -> list[list]:
        _tax_col = _fmt_detail_tax_rate_label(header)
        rows: list[list] = []
        for d in chunk:
            rows.append(
                [
                    _detail_breakdown_cell(d),
                    _fmt_pdf_detail_unit_price(d.get("単価")),
                    _fmt_pdf_detail_quantity(d.get("数量")),
                    _fmt_pdf_detail_tax_excluded_amount(d.get("税抜金額")),
                    _tax_col,
                ]
            )
        return rows

    def draw_detail_block(
        y_top: float,
        chunk: list[dict],
        *,
        show_footer: bool,
        show_okyu_header: bool,
    ) -> float:
        """1ページ目: 御請求金額＋下線→御請求内容→明細。続ページ: 御請求内容以降のみ。"""
        from reportlab.pdfbase import pdfmetrics

        y = y_top

        subtotal = 0.0
        tax_amt = 0
        grand = 0.0
        # 1ページ目ヘッダの「… 也」は全明細合計。表末の合計3行は最終ページのみ。
        if show_footer or show_okyu_header:
            subtotal = sum(_parse_invoice_amount_sum(d.get("税抜金額")) for d in details)
            rate = _header_consumption_tax_rate_float(header)
            tax_amt = math.floor(subtotal * rate + 1e-9)
            grand = subtotal + tax_amt

        if show_okyu_header:
            # 同一行の「御請求金額」ラベルと金額＋「也」: 従来 13pt 太字 → 2pt 小さく通常
            _fs_okyu_row = 11
            _hdr_rule_w = pdfmetrics.stringWidth(
                _INVOICE_RULE_BAR * _INVOICE_RULE_REPEAT_COUNT, font, 10
            )
            _y_okyu_baseline = y
            lbl_okyu = "御請求金額"
            amt_head = _fmt_pdf_amount_integer_commas(grand) + "\u3000" + "也"
            sw_lbl = pdfmetrics.stringWidth(lbl_okyu, font, _fs_okyu_row)
            sw_amt = pdfmetrics.stringWidth(amt_head, font, _fs_okyu_row)
            x_rule_right = margin_x + _hdr_rule_w
            _also_shift_pt = 2.0
            x_amt_head = x_rule_right - sw_amt - _also_shift_pt
            _min_amt_x = margin_x + sw_lbl + pdfmetrics.stringWidth("\u3000", font, _fs_okyu_row)
            if x_amt_head < _min_amt_x:
                x_amt_head = _min_amt_x
            c.setFont(font, _fs_okyu_row)
            c.drawString(margin_x, y, lbl_okyu)
            c.drawString(x_amt_head, y, amt_head)

            _okyu_cell_line_y = _y_okyu_baseline - 5
            c.setStrokeColor(colors.black)
            c.setLineWidth(1)
            c.line(margin_x, _okyu_cell_line_y, margin_x + _hdr_rule_w, _okyu_cell_line_y)

            y = _okyu_cell_line_y - line_h * 0.9

        y -= line_h
        # 「御請求内容」「(JPY)」同一行: 従来 11pt 通常 → 3pt 小さく（太字は未使用のまま）
        fs_detail_title = 8
        _jpy_lbl = "(JPY)"
        c.setFont(font, fs_detail_title)
        sw_jpy = pdfmetrics.stringWidth(_jpy_lbl, font, fs_detail_title)
        c.drawString(margin_x, y, "御請求内容")
        c.drawString(w - margin_x - sw_jpy, y, _jpy_lbl)
        y_below_title = y - 4

        data = [_detail_header_row()] + _detail_body_rows(chunk)
        if show_footer:
            data.extend(
                [
                    ["", "合計", "", _fmt_pdf_amount_integer_commas(subtotal), ""],
                    ["", _fmt_invoice_footer_tax_row_label(header), "", _fmt_pdf_amount_integer_commas(tax_amt), ""],
                    ["", "御請求金額", "", _fmt_pdf_amount_integer_commas(grand), ""],
                ]
            )

        tbl = Table(data, colWidths=detail_col_widths, repeatRows=1)
        style_cmds: list = [
            ("FONTNAME", (0, 1), (-1, -1), font),
            ("FONTSIZE", (0, 1), (-1, -1), 8),
            ("FONTSIZE", (0, 1), (0, -1), 6),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("LEFTPADDING", (0, 0), (-1, -1), 5),
            ("RIGHTPADDING", (0, 0), (-1, -1), 5),
            ("TOPPADDING", (0, 0), (-1, -1), 5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            # ヘッダ行の背景（淡いグレー）
            ("BACKGROUND", (0, 0), (-1, 0), _DETAIL_HEADER_BG),
            # 罫線：内側は従来どおり、外枠だけ太線
            ("INNERGRID", (0, 0), (-1, -1), _DETAIL_GRID_INNER_W, _GRID_COLOR),
            ("BOX", (0, 0), (-1, -1), _DETAIL_GRID_OUTER_W, _GRID_COLOR),
            ("LINEBELOW", (0, 0), (-1, 0), _DETAIL_GRID_OUTER_W, _GRID_COLOR),
        ]
        if len(data) > 1:
            style_cmds.append(("ALIGN", (0, 1), (0, -1), "LEFT"))
            style_cmds.append(("ALIGN", (1, 1), (4, -1), "RIGHT"))
        style_cmds.append(("ALIGN", (1, 0), (4, 0), "CENTER"))

        if show_footer:
            n = len(data)
            for i in range(3):
                r = n - 3 + i
                # 単価・数量列を結合してラベル表示（センター）
                style_cmds.append(("SPAN", (1, r), (2, r)))
                style_cmds.append(("FONTNAME", (1, r), (2, r), font))
                style_cmds.append(("ALIGN", (1, r), (2, r), "CENTER"))
                # 金額列・消費税列を結合し、数値は右寄せ
                style_cmds.append(("SPAN", (3, r), (4, r)))
                style_cmds.append(("ALIGN", (3, r), (4, r), "RIGHT"))
                style_cmds.append(("FONTNAME", (3, r), (4, r), font))
                # フッター3行：請求内訳列（0列）の左罫線・下辺を地色で上書き（グリッドの線を消す）
                _hide_w = 2
                style_cmds.append(
                    ("LINEBEFORE", (0, r), (0, r), _hide_w, _DETAIL_TABLE_LINE_HIDE)
                )
                style_cmds.append(
                    ("LINEBELOW", (0, r), (0, r), _hide_w, _DETAIL_TABLE_LINE_HIDE)
                )
            # 合計行の直上（明細末行の下辺）を外枠と同じ太さ
            r_footer0 = n - 3
            if r_footer0 > 0:
                style_cmds.append(
                    (
                        "LINEBELOW",
                        (0, r_footer0 - 1),
                        (-1, r_footer0 - 1),
                        _DETAIL_GRID_OUTER_W,
                        _GRID_COLOR,
                    )
                )

        # 表の最下行の下辺（御請求金額行）：請求内訳列0は不可視、1〜4列のみ太線
        _bottom_hide_w = max(3.0, _DETAIL_GRID_OUTER_W * 2)
        if show_footer:
            style_cmds.append(
                ("LINEBELOW", (1, -1), (4, -1), _DETAIL_GRID_OUTER_W, _GRID_COLOR)
            )
            style_cmds.append(
                ("LINEBELOW", (0, -1), (0, -1), _bottom_hide_w, _DETAIL_TABLE_LINE_HIDE)
            )
        else:
            style_cmds.append(
                ("LINEBELOW", (0, -1), (-1, -1), _DETAIL_GRID_OUTER_W, _GRID_COLOR)
            )

        tbl.setStyle(TableStyle(style_cmds))

        avail_w = w - 2 * margin_x
        tw, th = tbl.wrap(avail_w, h)
        _y_tbl_bottom = y_below_title - th
        tbl.drawOn(c, margin_x, _y_tbl_bottom)
        # 単価列の左（請求内訳|単価の境）をヘッダ〜表下端まで外枠と同じ太さで一本描く
        _x_unit_left = margin_x + detail_col_widths[0]
        c.saveState()
        c.setStrokeColor(_GRID_COLOR)
        c.setLineWidth(_DETAIL_GRID_OUTER_W)
        c.line(_x_unit_left, _y_tbl_bottom, _x_unit_left, y_below_title)
        c.restoreState()
        return _y_tbl_bottom - 12

    # ページフッター（各改ページごと・用紙下端からの固定位置）
    _PAGE_FOOTER_FS = 9
    _PAGE_FOOTER_LEADING = 22.0  # 行間を従来の約2倍（旧 11pt 相当）
    _PAGE_FOOTER_BANK_LEADING = 16.0
    _PAGE_FOOTER_ULINE_LEADING = 11.0
    _PAGE_FOOTER_TRANSFER_FS = _PAGE_FOOTER_FS - 2
    _PAGE_FOOTER_TRANSFER_LEADING = 11.0
    _PAGE_FOOTER_BASELINE_BOTTOM = 38.0 + 2 * line_h
    _PAGE_FOOTER_TRANSFER_NOTICE = (
        "下記の口座までお振込をお願い致します。お振込時の手数料につきましては"
        "お客様ご負担とさせていただいております。予めご了承ください。"
    )
    # 下から積むため「下記の口座…」行の直下は口座枠の上辺（rect）。旧 +2pt だと罫線と密着しやすい。
    _PAGE_FOOTER_CLEARANCE_NOTICE_ABOVE_BANK_RULE_PT = 8.0

    def draw_page_footer() -> None:
        from reportlab.pdfbase import pdfmetrics

        fw = w - 2 * margin_x
        fs = _PAGE_FOOTER_FS
        lead = _PAGE_FOOTER_LEADING
        lead_bank = _PAGE_FOOTER_BANK_LEADING
        y = _PAGE_FOOTER_BASELINE_BOTTOM
        c.setFillColor(colors.black)
        _fw_space = "\u3000"

        _bank_lbl_prefix = "　　"  # 先頭の全角スペース2（各行同じ左位置）
        _bank_lbl_bodies = ("支店名", "口座番号", "名義人")
        fs_bank = fs + 1  # 従来より1pt小さい（fs+2→fs+1）
        _sw = lambda s: pdfmetrics.stringWidth(s, font, fs_bank)
        colon = "："
        # 左揃え：接頭辞→本文は同一X。コロンは最長本文幅で縦に揃え、値列はその右で揃え
        x_bank_text = margin_x + 4.0
        x_body0 = x_bank_text + _sw(_bank_lbl_prefix)
        body_col_w = max(_sw(b) for b in _bank_lbl_bodies)
        x_colon = x_body0 + body_col_w
        x_bank_value = x_colon + _sw(colon + _fw_space)
        v_shiten = _cell_str(header.get("店番"))
        v_koza = _cell_str(header.get("決済口座"))
        v_meigi = _cell_str(header.get("口座名義人"))
        comment_line = _cell_str(header.get("コメント_振込"))

        def draw_bank_row(body: str, value: str) -> None:
            nonlocal y
            c.setFont(font, fs_bank)
            c.drawString(x_bank_text, y, _bank_lbl_prefix)
            c.drawString(x_body0, y, body)
            c.drawString(x_colon, y, colon)
            c.drawString(x_bank_value, y, value)
            y += lead_bank

        # 下から：名義人 → 口座番号 → 支店名 → 振込案内（支店名の直上）→ コメント → ハイフン罫線3行
        # 口座枠エリアを 1 行分下げる（ページ下方向＝y を減らす）。上の振込案内と枠が被らないよう枠上端より上へ y を進める。
        y -= lead
        _y_bank_block_base = y
        _bank_box_pad_top = 3.0
        _bank_box_pad_bottom = 10.0
        _bank_box_h = 3 * lead_bank + _bank_box_pad_top + _bank_box_pad_bottom
        _bank_rect_bottom = _y_bank_block_base - _bank_box_pad_bottom
        c.saveState()
        c.setStrokeColor(colors.black)
        c.setLineWidth(0.5)
        c.rect(
            margin_x,
            _bank_rect_bottom,
            fw,
            _bank_box_h,
            stroke=1,
            fill=0,
        )
        c.restoreState()
        draw_bank_row("名義人", v_meigi)
        draw_bank_row("口座番号", v_koza)
        draw_bank_row("支店名", v_shiten)
        _bank_box_top = _bank_rect_bottom + _bank_box_h
        _c_notice_bank = _PAGE_FOOTER_CLEARANCE_NOTICE_ABOVE_BANK_RULE_PT
        if y < _bank_box_top + _c_notice_bank:
            y = _bank_box_top + _c_notice_bank
        fs_notice = _PAGE_FOOTER_TRANSFER_FS
        lead_notice = _PAGE_FOOTER_TRANSFER_LEADING
        c.setFont(font, fs_notice)
        for ln in _wrap_pdf_text_to_lines(
            _PAGE_FOOTER_TRANSFER_NOTICE, font, fs_notice, fw, 12
        ):
            if not ln:
                continue
            c.drawString(margin_x, y, ln)
            y += lead_notice
        c.setFont(font, fs)
        c.drawString(margin_x, y, comment_line)
        lead_uline = _PAGE_FOOTER_ULINE_LEADING
        y += lead_uline
        uline = _pdf_fill_width_with_char("-", font, fs, fw)
        c.drawString(margin_x, y, uline)
        y += lead_uline
        c.drawString(margin_x, y, uline)
        y += lead_uline
        c.drawString(margin_x, y, uline)

    _num_chunk_pages = len(chunks)
    for page_idx, chunk in enumerate(chunks):
        if page_idx > 0:
            c.showPage()
        y = h - 50

        if page_idx == 0:
            y = draw_section2(y)
            y = draw_section3(y)
            _draw_invoice_hanko_top_right(c, w, h, margin_x, font, font_bold, line_h)
        draw_detail_block(
            y,
            chunk,
            show_footer=(page_idx == _num_chunk_pages - 1),
            show_okyu_header=(page_idx == 0),
        )
        draw_page_footer()

    c.save()
    return buf.getvalue()


def build_invoice_pdf_bytes(invoice_no: str) -> bytes | None:
    """
    請求書番号単位で PDF バイト列を生成する。
    データは DB（T1_請求書データ_ヘッダ / 明細）から取得。
    """
    inv = (invoice_no or "").strip()
    if not inv:
        return None
    row = db.fetch_invoice_for_maintenance(inv)
    if not row:
        return None
    return build_invoice_pdf_bytes_from_row(row)


def save_invoice_pdf_to_path(invoice_no: str, output_path: str | Path) -> Path:
    """
    請求書 PDF を指定パスに保存する（サーバー側バッチ等で再利用）。
    """
    p = Path(output_path)
    data = build_invoice_pdf_bytes(invoice_no)
    if not data:
        raise ValueError(f"請求データが見つかりません: {invoice_no}")
    p.write_bytes(data)
    return p.resolve()
