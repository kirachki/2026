"""
MySQL データベース接続・クエリモジュール (PyMySQL)
"""
import hashlib
import logging
import unicodedata

import pymysql
from pymysql.cursors import DictCursor

logger = logging.getLogger(__name__)

# _DB_CONFIG = {
#     "host": "10.1.100.30",
#     "user": "jinostest",
#     "password": "jinostest",
#     "database": "jinostest",
#     "charset": "utf8mb4",
#     "cursorclass": DictCursor,
# }
_DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "kuro0711",
    "database": "sakila",
    "charset": "utf8mb4",
    "cursorclass": DictCursor,
}



# 画面の検索パラメータ名 → テーブルのカラム名
_SEARCH_COLUMN_MAP = {
    "search_koza_meigi": "`口座名義(漢字)`",
    "search_hojin_mei":  "`法人名(漢字)`",
    "search_daihyo_sei": "CONCAT(`代表者姓(漢字)`, `代表者名(漢字)`)",
    "search_kanri_sei":  "CONCAT(`口座管理者姓(漢字)`, `口座管理者名(漢字)`)",
}

_SELECT_COLUMNS = """\
    `店番号`,
    `口座番号`,
    `MDAS-ID`,
    `口座名義(漢字)`,
    `法人名(漢字)`,
    `住所(漢字)`,
    CONCAT_WS('-', `電話番号(市外局番)`, `電話番号(市内局番)`, `電話番号(局番)`) AS `電話番号`,
    CONCAT(`代表者姓(漢字)`, `代表者名(漢字)`) AS `代表者名`,
    CONCAT(`口座管理者姓(漢字)`, `口座管理者名(漢字)`) AS `口座管理者`\
"""

DISPLAY_LIMIT = 100


def _get_connection():
    return pymysql.connect(**_DB_CONFIG)


_INVOICE_SEARCH_SELECT = """\
    `請求書番号`,
    `宛名_取引先名` AS `取引先名`,
    `件名`,
    `メモ備忘` AS `メモ備考`,
    `発行日`,
    `支払期限`\
"""


def search_invoices(
    search_invoice_no: str = "",
    search_customer_name: str = "",
    search_subject: str = "",
    search_memo: str = "",
    search_issue_date_from: str = "",
    search_issue_date_to: str = "",
    search_payment_deadline_from: str = "",
    search_payment_deadline_to: str = "",
) -> tuple[list[dict], int, bool]:
    """
    T1_請求書データ_ヘッダ を検索し (results, result_count, over_limit) を返す。
    over_limit=True の場合、結果は先頭 DISPLAY_LIMIT 件のみ。
    """
    params_map = {
        "search_invoice_no": (search_invoice_no or "").strip(),
        "search_customer_name": (search_customer_name or "").strip(),
        "search_subject": (search_subject or "").strip(),
        "search_memo": (search_memo or "").strip(),
        "search_issue_date_from": (search_issue_date_from or "").strip(),
        "search_issue_date_to": (search_issue_date_to or "").strip(),
        "search_payment_deadline_from": (search_payment_deadline_from or "").strip(),
        "search_payment_deadline_to": (search_payment_deadline_to or "").strip(),
    }

    where_parts: list[str] = []
    bind_values: list[str] = []

    if params_map["search_invoice_no"]:
        where_parts.append("`請求書番号` LIKE %s")
        bind_values.append(f"%{params_map['search_invoice_no']}%")

    if params_map["search_customer_name"]:
        # スキーマ上の取引先名カラムは `宛名_取引先名` です（画面は「取引先名」表示）
        where_parts.append("`宛名_取引先名` LIKE %s")
        bind_values.append(f"%{params_map['search_customer_name']}%")

    if params_map["search_subject"]:
        where_parts.append("`件名` LIKE %s")
        bind_values.append(f"%{params_map['search_subject']}%")

    if params_map["search_memo"]:
        where_parts.append("`メモ備忘` LIKE %s")
        bind_values.append(f"%{params_map['search_memo']}%")

    if params_map["search_issue_date_from"]:
        where_parts.append("`発行日` >= %s")
        bind_values.append(params_map["search_issue_date_from"])

    if params_map["search_issue_date_to"]:
        where_parts.append("`発行日` <= %s")
        bind_values.append(params_map["search_issue_date_to"])

    if params_map["search_payment_deadline_from"]:
        where_parts.append("`支払期限` >= %s")
        bind_values.append(params_map["search_payment_deadline_from"])

    if params_map["search_payment_deadline_to"]:
        where_parts.append("`支払期限` <= %s")
        bind_values.append(params_map["search_payment_deadline_to"])

    sql = f"SELECT {_INVOICE_SEARCH_SELECT} FROM `T1_請求書データ_ヘッダ`"
    if where_parts:
        sql += " WHERE " + " AND ".join(where_parts)
    sql += f" LIMIT {DISPLAY_LIMIT + 1}"

    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, bind_values)
            rows = cur.fetchall()
    finally:
        conn.close()

    over_limit = len(rows) > DISPLAY_LIMIT
    if over_limit:
        rows = rows[:DISPLAY_LIMIT]

    return rows, len(rows) if not over_limit else DISPLAY_LIMIT, over_limit


def search_accounts(
    search_koza_meigi: str = "",
    search_hojin_mei: str = "",
    search_daihyo_sei: str = "",
    search_kanri_sei: str = "",
) -> tuple[list[dict], int, bool]:
    """
    T1_AccountAttribute を検索し (results, result_count, over_limit) を返す。
    over_limit=True の場合、結果は先頭 100 件のみ。
    """
    params_map = {
        "search_koza_meigi": search_koza_meigi.strip(),
        "search_hojin_mei":  search_hojin_mei.strip(),
        "search_daihyo_sei": search_daihyo_sei.strip(),
        "search_kanri_sei":  search_kanri_sei.strip(),
    }

    where_parts: list[str] = []
    bind_values: list[str] = []
    for key, col_expr in _SEARCH_COLUMN_MAP.items():
        val = params_map.get(key, "")
        if val:
            where_parts.append(f"{col_expr} LIKE %s")
            bind_values.append(f"%{val}%")

    sql = f"SELECT {_SELECT_COLUMNS} FROM `T1_AccountAttribute`"
    if where_parts:
        sql += " WHERE " + " AND ".join(where_parts)
    sql += f" LIMIT {DISPLAY_LIMIT + 1}"

    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, bind_values)
            rows = cur.fetchall()
    finally:
        conn.close()

    over_limit = len(rows) > DISPLAY_LIMIT
    if over_limit:
        rows = rows[:DISPLAY_LIMIT]

    return rows, len(rows) if not over_limit else DISPLAY_LIMIT, over_limit


_MAINTENANCE_SELECT = """\
    `店番号`,
    `口座番号`,
    `AIS開設日`,
    `法人名(漢字)`,
    `法人コード`,
    `登録番号`,
    `設立日`,
    `口座名義(漢字)`,
    `口座名義(カナ)`,
    `住所(漢字)`,
    `電話番号(市外局番)`,
    `電話番号(市内局番)`,
    `電話番号(局番)`,
    `代表者姓(漢字)`,
    `代表者名(漢字)`,
    `代表者姓(カナ)`,
    `代表者名(カナ)`,
    `口座管理者姓(漢字)`,
    `口座管理者名(漢字)`,
    `Emailアドレス`,
    `ホームページアドレス`\
"""


def fetch_account_for_maintenance(tenban: int, koza: str) -> dict | None:
    """店番号 + 口座番号で T1_AccountAttribute を1件取得（メンテ画面用）。"""
    sql = f"SELECT {_MAINTENANCE_SELECT} FROM `T1_AccountAttribute` WHERE `店番号` = %s AND `口座番号` = %s LIMIT 1"
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, (tenban, koza.strip()))
            row = cur.fetchone()
    finally:
        conn.close()
    return row


_INVOICE_HEADER_COLUMNS: list[str] = [
    "請求書番号",
    "郵便番号",
    "住所",
    "取引先コード",
    "宛名_取引先名",
    "宛名_担当部署",
    "宛名_担当者",
    "自行住所",
    "自行電話_FAX番号",
    "自行営業担当者",
    "自行部署名",
    "発行日",
    "決済方法",
    "発行者",
    "営業担当者",
    "消費税率",
    "消費税端数",
    "件名",
    "請求金額",
    "支払期限",
    "決済口座",
    "コメント_振込",
    "備考欄",
    "店番",
    "口座名義人",
    "役職",
    "敬称",
    "削除フラグ",
    "メモ備忘",
]

_INVOICE_DETAIL_COLUMNS: list[str] = [
    "請求書番号",
    "明細番号",
    "請求項目1",
    "請求項目2",
    "請求項目3",
    "単価",
    "数量",
    "税抜金額",
    "税抜金額端数処理区分",
    "消費税",
    "税込金額",
    "プロジェクトコード",
    "科目コード",
    "中分類",
    "小分類",
    "消費税区分",
]


def _invoice_header_select_expr(col: str) -> str:
    return f"h.`{col}` AS `header_{col}`"


def _invoice_detail_select_expr(col: str) -> str:
    return f"d.`{col}` AS `detail_{col}`"


def fetch_invoice_for_maintenance(invoice_no: str) -> dict | None:
    """
    請求書番号で T1_請求書データ_ヘッダ と T1_請求書データ_明細 を JOINして取得する。
    戻り値: {"header": {col: value}, "details": [{col: value}, ...]}
    """
    invoice_no = (invoice_no or "").strip()
    if not invoice_no:
        return None

    header_select = ", ".join(_invoice_header_select_expr(c) for c in _INVOICE_HEADER_COLUMNS)
    detail_select = ", ".join(_invoice_detail_select_expr(c) for c in _INVOICE_DETAIL_COLUMNS)
    sql = (
        "SELECT "
        f"{header_select}, {detail_select} "
        "FROM `T1_請求書データ_ヘッダ` h "
        "LEFT JOIN `T1_請求書データ_明細` d "
        "  ON h.`請求書番号` = d.`請求書番号` "
        "WHERE h.`請求書番号` = %s "
        "ORDER BY d.`明細番号`"
    )

    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, (invoice_no,))
            rows = cur.fetchall()
    finally:
        conn.close()

    if not rows:
        return None

    first = rows[0]
    header = {c: first.get(f"header_{c}") for c in _INVOICE_HEADER_COLUMNS}
    details: list[dict] = []
    for r in rows:
        # LEFT JOIN のため、明細0件の場合は detailカラムが全て NULL になり得る。
        # そのケースは「明細0行」になるようにスキップする。
        detail_no = r.get("detail_明細番号")
        if detail_no is None or str(detail_no).strip() == "":
            continue
        details.append({c: r.get(f"detail_{c}") for c in _INVOICE_DETAIL_COLUMNS})

    return {"header": header, "details": details}


def search_zip_master_suggestions(q_raw: str, *, limit: int = 15) -> list[dict[str, str]]:
    """
    zipMaster を zipcode の前方一致で検索（入力は数字以外を除去した接頭辞）。
    戻り値: [{"zipcode": str, "address1": str}, ...]（最大 limit 件）
    """
    # 全角数字・互換文字を半角へ（「２」だけだと LIKE が一致しない）
    normalized = unicodedata.normalize("NFKC", q_raw or "")
    digits = "".join(c for c in normalized if c.isdigit())
    if not digits:
        return []
    if len(digits) > 10:
        digits = digits[:10]
    lim = max(1, min(int(limit), 50))
    conn = None
    try:
        conn = _get_connection()
        with conn.cursor() as cur:
            cur.execute(
                "SELECT `zipcode`, `address1` FROM `zipMaster` "
                "WHERE `zipcode` LIKE %s ORDER BY `zipcode` ASC LIMIT %s",
                (digits + "%", lim),
            )
            rows = cur.fetchall() or []
    except Exception as e:
        logger.warning("search_zip_master_suggestions: %s", e)
        return []
    finally:
        if conn is not None:
            conn.close()
    out: list[dict[str, str]] = []
    for r in rows:
        out.append(
            {
                "zipcode": str(r.get("zipcode") or ""),
                "address1": str(r.get("address1") or ""),
            }
        )
    return out


_INVOICE_HEADER_REQUIRED: tuple[tuple[str, str], ...] = (
    ("郵便番号", "郵便番号"),
    ("住所", "住所"),
    ("取引先名", "宛名_取引先名"),
    ("担当部署", "宛名_担当部署"),
    ("担当者", "宛名_担当者"),
    ("決済方法", "決済方法"),
    ("消費税率", "消費税率"),
    ("件名", "件名"),
    ("支払期限", "支払期限"),
    ("決済口座", "決済口座"),
    ("店番", "店番"),
    ("口座名義人", "口座名義人"),
)


def validate_invoice_header_for_save(header: dict) -> list[str]:
    """
    請求書ヘッダの保存前チェック。
    戻り値: エラーメッセージのリスト（空なら OK）。
    """
    errs: list[str] = []

    def g(name: str) -> str:
        v = header.get(name)
        if v is None:
            return ""
        return str(v).strip()

    for label, key in _INVOICE_HEADER_REQUIRED:
        if not g(key):
            errs.append(f"請求書ヘッダ：{label}は必須です。")

    if g("郵便番号"):
        znorm = unicodedata.normalize("NFKC", g("郵便番号"))
        zip_digits = "".join(c for c in znorm if c.isdigit())
        if len(zip_digits) != 7:
            errs.append("請求書ヘッダ：郵便番号は数字7桁で入力してください。")

    km = g("決済方法")
    if km and km not in ("振込", "引落"):
        errs.append("請求書ヘッダ：決済方法は「振込」または「引落」を選択してください。")

    def maxlen_if_nonempty(label: str, key: str, n: int) -> None:
        s = g(key)
        if s and len(s) > n:
            errs.append(f"請求書ヘッダ：{label}は{n}文字以内で入力してください。")

    # 取引先名・件名・メモ備忘は同一の扱い（スキーマの VARCHAR 長に合わせる）
    maxlen_if_nonempty("取引先名", "宛名_取引先名", 255)
    maxlen_if_nonempty("件名", "件名", 255)
    maxlen_if_nonempty("メモ備忘", "メモ備忘", 500)

    return errs


def validate_invoice_detail_rows_for_save(detail_rows: list[dict]) -> list[str]:
    """
    請求書明細の保存前チェック。
    detail_rows: 各行に excluded (bool) とカラム名のキーを含む。
    """
    from decimal import Decimal, InvalidOperation

    errs: list[str] = []

    def gv(row: dict, k: str) -> str:
        v = row.get(k)
        if v is None:
            return ""
        return str(v).strip()

    for i, row in enumerate(detail_rows, start=1):
        if row.get("excluded"):
            continue

        if not gv(row, "単価"):
            errs.append(f"請求書明細：第{i}行目の単価は必須です。")
        else:
            try:
                Decimal(str(gv(row, "単価")).replace(",", "").strip())
            except (InvalidOperation, ValueError):
                errs.append(f"請求書明細：第{i}行目の単価は数値で入力してください。")

        if not gv(row, "数量"):
            errs.append(f"請求書明細：第{i}行目の数量は必須です。")
        else:
            try:
                int(str(gv(row, "数量")).strip())
            except ValueError:
                errs.append(f"請求書明細：第{i}行目の数量は整数で入力してください。")

        tax_k = gv(row, "消費税区分")
        if not tax_k:
            errs.append(f"請求書明細：第{i}行目の消費税区分を選択してください。")
        elif tax_k not in ("内税", "外税", "非課税", "不課税"):
            errs.append(
                f"請求書明細：第{i}行目の消費税区分はドロップダウンから選択してください。"
            )

        fk = gv(row, "税抜金額端数処理区分")
        if not fk:
            errs.append(
                f"請求書明細：第{i}行目の税抜金額端数処理区分を選択してください。"
            )
        elif fk not in ("0", "1"):
            errs.append(
                f"請求書明細：第{i}行目の税抜金額端数処理区分は「切り上げ」または「切捨て」を選択してください。"
            )

        if (
            not gv(row, "請求項目1")
            and not gv(row, "請求項目2")
            and not gv(row, "請求項目3")
        ):
            errs.append(
                f"請求書明細：第{i}行目の請求項目1縲鰀3のいずれかを入力してください。"
            )

    return errs


def _parse_decimal_loose(s: str):
    from decimal import Decimal, InvalidOperation

    try:
        return Decimal(str(s).replace(",", "").strip())
    except (InvalidOperation, ValueError):
        return None


def _apply_detail_tax_excluded_amount(row: dict) -> None:
    """単価×数量を税抜金額にセット（検証済み行向け）。
    現状 save_invoice_maintenance からは呼ばれていない（呼び出しはコメントアウト）。"""
    from decimal import Decimal

    d = _parse_decimal_loose(str(row.get("単価") or ""))
    q = int(str(row.get("数量")).strip())
    if d is None:
        return
    row["_税抜金額_decimal"] = d * Decimal(q)


def _header_value_for_persist(col: str, raw) -> object:
    """ヘッダ INSERT/UPDATE 用に値を変換（請求書番号キー以外のカラム）。"""
    from datetime import datetime
    from decimal import Decimal, InvalidOperation

    if raw is None:
        s = ""
    else:
        s = str(raw).strip()
    if col == "発行日":
        if not s:
            return None
        try:
            return datetime.strptime(s[:10], "%Y-%m-%d").date()
        except ValueError:
            return None
    if col == "消費税端数":
        if not s:
            return None
        try:
            return int(s)
        except ValueError:
            return None
    if col == "請求金額":
        if not s:
            return None
        try:
            return Decimal(s.replace(",", ""))
        except (InvalidOperation, ValueError):
            return None
    if col == "郵便番号":
        if not s:
            return None
        zd = "".join(c for c in unicodedata.normalize("NFKC", s) if c.isdigit())
        return zd if zd else None
    return s if s != "" else None


def _header_insert_tuple(invoice_no: str, header: dict) -> tuple:
    """T1_請求書データ_ヘッダ INSERT 用タプル（_INVOICE_HEADER_COLUMNS 順）。"""
    uid = (invoice_no or "").strip()
    return tuple(
        uid if c == "請求書番号" else _header_value_for_persist(c, header.get(c))
        for c in _INVOICE_HEADER_COLUMNS
    )


def _detail_cell_for_insert(col: str, row: dict, invoice_no: str, line_no: int):
    """INSERT 用の1セル値。"""
    from decimal import Decimal, InvalidOperation

    if col == "請求書番号":
        return invoice_no
    if col == "明細番号":
        return str(line_no)
    if col == "税抜金額":
        v = row.get("_税抜金額_decimal")
        if v is not None:
            return v
        return _parse_decimal_loose(str(row.get("税抜金額") or "")) or Decimal("0")
    if col == "数量":
        return int(str(row.get("数量") or "").strip())
    if col == "税抜金額端数処理区分":
        s = str(row.get(col) or "").strip()
        if not s:
            return None
        try:
            return int(s)
        except ValueError:
            return None
    if col == "税込金額":
        s = str(row.get(col) or "").strip()
        if not s:
            return None
        try:
            return Decimal(s.replace(",", ""))
        except (InvalidOperation, ValueError):
            return None
    v = row.get(col)
    if v is None:
        return None
    s = str(v).strip()
    return s if s != "" else None


_MSG_COPY_INVOICE_NO_EXISTS = (
    "指定された請求番号はすでに存在しています。コピーの場合は新規の請求番号を設定してください。"
)


def save_invoice_maintenance(
    invoice_no: str,
    header: dict,
    detail_rows: list[dict],
    *,
    copy_save: bool = False,
) -> tuple[bool, str]:
    """
    請求ヘッダ: 請求書番号が T1_請求書データ_ヘッダ に存在すれば UPDATE、なければ INSERT。
    明細: 全削除後に未チェック行のみ再INSERT。
    copy_save が True のときは新規コピー保存のみ許可し、請求書番号が既存ならエラーとする。
    戻り値: (成功, メッセージ) 失敗時は False と DB/例外メッセージ。
    """
    uid = (invoice_no or "").strip()
    if not uid:
        return False, "請求書番号がありません。"

    # （無効化）DB登録前に単価×数量で税抜金額を補完する処理。再開する場合は以下の for を戻す。
    # for row in detail_rows:
    #     if row.get("excluded"):
    #         continue
    #     _apply_detail_tax_excluded_amount(row)

    set_parts: list[str] = []
    set_values: list = []
    for col in _INVOICE_HEADER_COLUMNS:
        if col == "請求書番号":
            continue
        set_parts.append(f"`{col}`=%s")
        set_values.append(_header_value_for_persist(col, header.get(col)))

    update_sql = (
        "UPDATE `T1_請求書データ_ヘッダ` SET "
        + ", ".join(set_parts)
        + " WHERE `請求書番号`=%s"
    )
    set_values.append(uid)

    insert_header_sql = (
        "INSERT INTO `T1_請求書データ_ヘッダ` ("
        + ", ".join(f"`{c}`" for c in _INVOICE_HEADER_COLUMNS)
        + ") VALUES ("
        + ", ".join(["%s"] * len(_INVOICE_HEADER_COLUMNS))
        + ")"
    )
    insert_header_params = list(_header_insert_tuple(uid, header))

    header_exists_sql = (
        "SELECT 1 FROM `T1_請求書データ_ヘッダ` WHERE `請求書番号`=%s LIMIT 1"
    )

    delete_sql = "DELETE FROM `T1_請求書データ_明細` WHERE `請求書番号`=%s"

    cols = _INVOICE_DETAIL_COLUMNS
    placeholders = ", ".join(["%s"] * len(cols))
    insert_sql = (
        "INSERT INTO `T1_請求書データ_明細` ("
        + ", ".join(f"`{c}`" for c in cols)
        + f") VALUES ({placeholders})"
    )

    conn = _get_connection()
    try:
        conn.autocommit(False)
        try:
            with conn.cursor() as cur:
                cur.execute(header_exists_sql, (uid,))
                header_exists = cur.fetchone() is not None
                if copy_save and header_exists:
                    conn.rollback()
                    return False, _MSG_COPY_INVOICE_NO_EXISTS
                if header_exists:
                    cur.execute(update_sql, set_values)
                else:
                    cur.execute(insert_header_sql, insert_header_params)
                cur.execute(delete_sql, (uid,))
                line_no = 1
                for row in detail_rows:
                    if row.get("excluded"):
                        continue
                    params = [
                        _detail_cell_for_insert(c, row, uid, line_no) for c in cols
                    ]
                    cur.execute(insert_sql, params)
                    line_no += 1
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        return True, "請求データを保存しました。"
    except Exception as e:
        logger.exception("save_invoice_maintenance: %s", e)
        return False, str(e)
    finally:
        conn.close()


def _password_sha256_hex(plain: str) -> str:
    """MySQL SHA2(plain, 256) と同じ 64 文字 hex（小文字）。"""
    return hashlib.sha256((plain or "").encode("utf-8")).hexdigest()


def verify_login_user(userid: str, plain_password: str) -> tuple[bool, str]:
    """
    T1_LoginUser を照合する。
    戻り値: (成功時 True と空文字, 失敗時 False とユーザー向けメッセージ)
    """
    uid = (userid or "").strip()
    if not uid:
        return False, "ユーザーIDを入力してください。"

    if not (plain_password or "").strip():
        return False, "パスワードを入力してください。"

    pwd_hex = _password_sha256_hex(plain_password or "")
    sql = (
        "SELECT `userid`, `pwd`, `Enabled` FROM `T1_LoginUser` WHERE `userid` = %s LIMIT 1"
    )

    try:
        conn = _get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute(sql, (uid,))
                row = cur.fetchone()
        finally:
            conn.close()
    except Exception as e:
        logger.exception("verify_login_user DB error: %s", e)
        return False, "ログイン処理中にエラーが発生しました。しばらくしてから再度お試しください。"

    if not row:
        return False, "ユーザーIDまたはパスワードが正しくありません。"

    stored = (row.get("pwd") or "").strip()
    if stored.lower() != pwd_hex.lower():
        return False, "ユーザーIDまたはパスワードが正しくありません。"

    enabled = row.get("Enabled")
    if enabled is None or int(enabled) != 1:
        return False, "このアカウントは利用できません（無効）。"

    return True, ""


def get_login_user_display_name(userid: str) -> str:
    """
    ログインIDに対応する表示名（T1_LoginUser.user_name）。
    未設定・取得失敗時は userid を返す。
    """
    uid = (userid or "").strip()
    if not uid:
        return ""
    sql = "SELECT `user_name` FROM `T1_LoginUser` WHERE `userid` = %s LIMIT 1"
    try:
        conn = _get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute(sql, (uid,))
                row = cur.fetchone()
        finally:
            conn.close()
    except Exception as e:
        logger.warning("get_login_user_display_name: %s", e)
        return uid
    if not row:
        return uid
    name = (row.get("user_name") or "").strip()
    return name if name else uid


def update_last_login_datetime(userid: str) -> None:
    """成功ログイン後に LastLoginDateTime を更新する。"""
    uid = (userid or "").strip()
    if not uid:
        return
    sql = "UPDATE `T1_LoginUser` SET `LastLoginDateTime` = NOW() WHERE `userid` = %s"
    try:
        conn = _get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute(sql, (uid,))
            conn.commit()
        finally:
            conn.close()
    except Exception as e:
        logger.warning("update_last_login_datetime failed: %s", e)
