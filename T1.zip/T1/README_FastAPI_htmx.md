# FastAPI + htmx Hello World サンプル

## 概要

- **FastAPI**: バックエンドAPI
- **htmx**: フロントで「ボタンクリック → サーバーから部分HTML取得 → 表示」を実現

## 実行手順

### 1. 仮想環境の作成（推奨）

```powershell
cd c:\study\CRMs\T1
python -m venv venv
.\venv\Scripts\Activate.ps1
```

### 2. 依存関係のインストール

```powershell
pip install -r requirements.txt
```

### 3. サーバーの起動

```powershell
uvicorn main:app --reload
```

### 4. ブラウザで確認

- ブラウザで **http://127.0.0.1:8000** を開く
- 「Hello を取得」ボタンをクリックすると、その下に「Hello from FastAPI + htmx!」と表示される

## 取引先一覧・メンテナンス

- **取引先一覧**: http://127.0.0.1:8000/top（左メニューから取引先一覧を開き、検索）
- **取引先メンテナンス（新規タブ）**: 一覧の「法人名(漢字)」リンクをクリックすると、**毎回新しいブラウザタブ**で開きます。
  - URL: `/account/maintenance?tenban={店番号}&koza={口座番号}`（`koza` は URL エンコード済みで渡されます）
- **静的ファイル**: 一覧画面は `SamplesCRM/2/..._files` を `/files` で配信。メンテ画面の見た目用 CSS 等は `SamplesCRM/3/..._files` を `/ref3` で配信（フォルダが存在する場合）。

## 補足

- 開発時は `--reload` でコード変更時に自動再読み込み
- API ドキュメント: http://127.0.0.1:8000/docs
