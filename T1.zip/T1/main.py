"""
FastAPI + htmx サンプル（TOP: 取引先一覧）
"""
from datetime import date, datetime
from pathlib import Path
from urllib.parse import quote

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

import db

app = FastAPI(title="FastAPI + htmx CRM")

BASE_DIR = Path(__file__).resolve().parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))
templates.env.filters["urlquote"] = lambda u: quote(str(u or ""), safe="")


def _cell_to_str(v) -> str:
    if v is None:
        return ""
    if isinstance(v, (date, datetime)):
        return v.strftime("%Y-%m-%d")
    s = str(v).strip()
    if len(s) >= 10 and s[:4].isdigit() and s[4:5] == "-" and s.startswith("0000"):
        return ""
    return s


# サンプルCRMのCSS・アイコン等を /files/ で配信
_sample_files = BASE_DIR / "SamplesCRM" / "2" / "取引先一覧 - All Gather CRM V3_files"
if _sample_files.exists():
    app.mount("/files", StaticFiles(directory=str(_sample_files)), name="files")

# 取引先参照画面サンプル（SamplesCRM/3）の静的ファイル
_ref3_files = BASE_DIR / "SamplesCRM" / "3" / "木田工務店 - 取引先 - All Gather CRM V3_files"
if _ref3_files.exists():
    app.mount("/ref3", StaticFiles(directory=str(_ref3_files)), name="ref3")


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    """Hello サンプルページ"""
    return templates.TemplateResponse("index.html", {"request": request})


@app.get("/top", response_class=HTMLResponse)
async def top(request: Request):
    """TOPメニュー（取引先一覧レイアウト）"""
    return templates.TemplateResponse("top.html", {"request": request})


@app.get("/fragment/dashboard", response_class=HTMLResponse)
async def fragment_dashboard(request: Request):
    """htmx: ダッシュボードフラグメント"""
    return templates.TemplateResponse(
        "fragments/dashboard.html", {"request": request}
    )


@app.get("/fragment/torihikisaki", response_class=HTMLResponse)
async def fragment_torihikisaki(request: Request):
    """htmx: 取引先一覧フラグメント"""
    return templates.TemplateResponse(
        "fragments/torihikisaki_list.html",
        {"request": request},
    )


@app.get("/fragment/torihikisaki/search", response_class=HTMLResponse)
def fragment_torihikisaki_search(
    request: Request,
    search_koza_meigi: str = "",
    search_hojin_mei: str = "",
    search_daihyo_sei: str = "",
    search_kanri_sei: str = "",
    _reset: bool = False,
):
    """htmx: 取引先検索結果フラグメント（同期: DBアクセスのため def）"""
    if _reset:
        return templates.TemplateResponse(
            "fragments/torihikisaki_results.html",
            {"request": request, "mode": "initial"},
        )

    has_condition = any(
        v.strip()
        for v in [search_koza_meigi, search_hojin_mei,
                   search_daihyo_sei, search_kanri_sei]
    )
    if not has_condition:
        return templates.TemplateResponse(
            "fragments/torihikisaki_results.html",
            {"request": request, "mode": "no_condition"},
        )

    results, result_count, over_limit = db.search_accounts(
        search_koza_meigi=search_koza_meigi,
        search_hojin_mei=search_hojin_mei,
        search_daihyo_sei=search_daihyo_sei,
        search_kanri_sei=search_kanri_sei,
    )

    return templates.TemplateResponse(
        "fragments/torihikisaki_results.html",
        {
            "request": request,
            "mode": "results",
            "results": results,
            "result_count": result_count,
            "over_limit": over_limit,
        },
    )


@app.get("/account/maintenance", response_class=HTMLResponse)
def account_maintenance(request: Request, tenban: int, koza: str):
    """取引先メンテナンス（新規タブ用フルページ）。T1_AccountAttribute を店番号+口座番号で特定。"""
    row = db.fetch_account_for_maintenance(tenban, koza)
    if not row:
        return HTMLResponse(
            content=(
                "<!DOCTYPE html><html><head><meta charset='utf-8'><title>404</title></head>"
                "<body><p>該当する取引先が見つかりません。</p></body></html>"
            ),
            status_code=404,
        )

    form = {k: _cell_to_str(v) for k, v in row.items()}
    z = form.get("電話番号(市外局番)", "")
    s = form.get("電話番号(市内局番)", "")
    kk = form.get("電話番号(局番)", "")
    phone_parts = [p for p in [z, s, kk] if p]
    phone_combined = "-".join(phone_parts)
    rep_kanji = (form.get("代表者姓(漢字)", "") or "") + (form.get("代表者名(漢字)", "") or "")
    rep_kana = (form.get("代表者姓(カナ)", "") or "") + (form.get("代表者名(カナ)", "") or "")
    mgr_full = (form.get("口座管理者姓(漢字)", "") or "") + (form.get("口座管理者名(漢字)", "") or "")
    title = form.get("法人名(漢字)", "") or "取引先メンテナンス"

    return templates.TemplateResponse(
        "account_maintenance.html",
        {
            "request": request,
            "form": form,
            "phone_combined": phone_combined,
            "rep_kanji": rep_kanji,
            "rep_kana": rep_kana,
            "mgr_full": mgr_full,
            "page_title": title,
        },
    )


@app.get("/fragment/hello", response_class=HTMLResponse)
async def fragment_hello(request: Request):
    """htmx: Hello サンプルフラグメント（メインフレーム用）"""
    return templates.TemplateResponse(
        "fragments/hello.html", {"request": request}
    )


@app.get("/hello", response_class=HTMLResponse)
async def hello(name: str = ""):
    """htmx: 画面入力の name を XXX に反映"""
    display_name = name.strip() or "ゲスト"
    return HTMLResponse(
        f"<p id='greeting' class='greeting'>Hello {display_name}さん from FastAPI + htmx!</p>"
    )
