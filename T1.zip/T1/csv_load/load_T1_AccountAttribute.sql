-- T1_AccountAttribute 用 CSV ロードスクリプト（先頭200件用）

USE sakila;

-- 一時的に STRICT_TRANS_TABLES を外して、空日付をエラーにしない
SET @OLD_SQL_MODE = @@SQL_MODE;
SET SQL_MODE = REPLACE(@@SQL_MODE,'STRICT_TRANS_TABLES','');

LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 9.5/Uploads/AccountAttribute_200.csv'
INTO TABLE T1_AccountAttribute
CHARACTER SET cp932
FIELDS TERMINATED BY ','
OPTIONALLY ENCLOSED BY '\"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

-- 元に戻す
SET SQL_MODE = @OLD_SQL_MODE;
