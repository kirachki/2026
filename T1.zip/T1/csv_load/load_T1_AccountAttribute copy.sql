-- T1_AccountAttribute 用 CSV ロードスクリプト
USE sakila;

LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 9.5/Uploads/AccountAttribute.csv'
INTO TABLE T1_AccountAttribute
CHARACTER SET cp932
FIELDS TERMINATED BY ','
OPTIONALLY ENCLOSED BY '\"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;
