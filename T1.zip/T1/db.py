"""
MySQL データベース接続・クエリモジュール (PyMySQL)
"""
import pymysql
from pymysql.cursors import DictCursor

_DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "kuro0711",
    "database": "sakila",
    "charset": "utf8mb4",
    "cursorclass": DictCursor,
}

# 画面の検索パラメータ名 → テーブルのカラム名
_SEARCH_COLUMN_MAP = {
    "search_koza_meigi": "`口座名義(漢字)`",
    "search_hojin_mei":  "`法人名(漢字)`",
    "search_daihyo_sei": "CONCAT(`代表者姓(漢字)`, `代表者名(漢字)`)",
    "search_kanri_sei":  "CONCAT(`口座管理者姓(漢字)`, `口座管理者名(漢字)`)",
}

_SELECT_COLUMNS = """\
    `店番号`,
    `口座番号`,
    `MDAS-ID`,
    `口座名義(漢字)`,
    `法人名(漢字)`,
    `住所(漢字)`,
    CONCAT_WS('-', `電話番号(市外局番)`, `電話番号(市内局番)`, `電話番号(局番)`) AS `電話番号`,
    CONCAT(`代表者姓(漢字)`, `代表者名(漢字)`) AS `代表者名`,
    CONCAT(`口座管理者姓(漢字)`, `口座管理者名(漢字)`) AS `口座管理者`\
"""

DISPLAY_LIMIT = 100


def _get_connection():
    return pymysql.connect(**_DB_CONFIG)


def search_accounts(
    search_koza_meigi: str = "",
    search_hojin_mei: str = "",
    search_daihyo_sei: str = "",
    search_kanri_sei: str = "",
) -> tuple[list[dict], int, bool]:
    """
    T1_AccountAttribute を検索し (results, result_count, over_limit) を返す。
    over_limit=True の場合、結果は先頭 100 件のみ。
    """
    params_map = {
        "search_koza_meigi": search_koza_meigi.strip(),
        "search_hojin_mei":  search_hojin_mei.strip(),
        "search_daihyo_sei": search_daihyo_sei.strip(),
        "search_kanri_sei":  search_kanri_sei.strip(),
    }

    where_parts: list[str] = []
    bind_values: list[str] = []
    for key, col_expr in _SEARCH_COLUMN_MAP.items():
        val = params_map.get(key, "")
        if val:
            where_parts.append(f"{col_expr} LIKE %s")
            bind_values.append(f"%{val}%")

    sql = f"SELECT {_SELECT_COLUMNS} FROM `T1_AccountAttribute`"
    if where_parts:
        sql += " WHERE " + " AND ".join(where_parts)
    sql += f" LIMIT {DISPLAY_LIMIT + 1}"

    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, bind_values)
            rows = cur.fetchall()
    finally:
        conn.close()

    over_limit = len(rows) > DISPLAY_LIMIT
    if over_limit:
        rows = rows[:DISPLAY_LIMIT]

    return rows, len(rows) if not over_limit else DISPLAY_LIMIT, over_limit


_MAINTENANCE_SELECT = """\
    `店番号`,
    `口座番号`,
    `AIS開設日`,
    `法人名(漢字)`,
    `法人コード`,
    `登録番号`,
    `設立日`,
    `口座名義(漢字)`,
    `口座名義(カナ)`,
    `住所(漢字)`,
    `電話番号(市外局番)`,
    `電話番号(市内局番)`,
    `電話番号(局番)`,
    `代表者姓(漢字)`,
    `代表者名(漢字)`,
    `代表者姓(カナ)`,
    `代表者名(カナ)`,
    `口座管理者姓(漢字)`,
    `口座管理者名(漢字)`,
    `Emailアドレス`,
    `ホームページアドレス`\
"""


def fetch_account_for_maintenance(tenban: int, koza: str) -> dict | None:
    """店番号 + 口座番号で T1_AccountAttribute を1件取得（メンテ画面用）。"""
    sql = f"SELECT {_MAINTENANCE_SELECT} FROM `T1_AccountAttribute` WHERE `店番号` = %s AND `口座番号` = %s LIMIT 1"
    conn = _get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, (tenban, koza.strip()))
            row = cur.fetchone()
    finally:
        conn.close()
    return row
