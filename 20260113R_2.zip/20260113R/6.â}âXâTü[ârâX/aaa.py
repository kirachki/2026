import datetime
import re

def f_nextYear(text: str, offset_days: int) -> str:
    """
    引数1のテキストに含まれる全角数字の西暦(YYYY)を、
    今年の最終営業日からoffset_days(負数)経過していれば翌年に置換する。
    """
    today = datetime.date.today()
    current_year = today.year
    
    # 今年の最終日(12/31)から土日を除いた最終営業日を特定
    last_day = datetime.date(current_year, 12, 31)
    # 0=Mon, 1=Tue, 2=Wed, 3=Thu, 4=Fri, 5=Sat, 6=Sun
    while last_day.weekday() >= 5:
        last_day -= datetime.timedelta(days=1)
    
    # 判定基準日の計算（土日をスキップしながら逆算）
    target_date = last_day
    days_to_subtract = abs(offset_days)
    
    count = 0
    while count < days_to_subtract:
        target_date -= datetime.timedelta(days=1)
        # 土日でなければカウント
        if target_date.weekday() < 5:
            count += 1
            
    # 現在が判定基準日以降であれば置換処理を行う
    if today >= target_date:
        current_year_full = str(current_year).translate(str.maketrans('0123456789', '０１２３４５６７８９'))
        next_year_full = str(current_year + 1).translate(str.maketrans('0123456789', '０１２３４５６７８９'))
        return text.replace(current_year_full, next_year_full)
    
    return text

# --- テストコード ---
if __name__ == "__main__":
    # テスト用テキスト
    sample_text = "現在は２０２６年度のプロジェクトが進行中です。"
    
    print(f"【実行日】: {datetime.date.today()}")
    
    # パターン1: -3の場合 (2025/12/31が水曜なら、29, 30, 31と遡るイメージ)
    result1 = f_nextYear(sample_text, -3)
    print(f"結果(-3): {result1}")
    
    # パターン2: -5の場合
    result2 = f_nextYear(sample_text, -5)
    print(f"結果(-5): {result2}")
    