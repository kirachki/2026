# -*- coding: utf-8 -*-

"""
Created on Mon April 16 15:19:19 2024
@author: hidtoshi.kurosu@rakuten-bank.co.jp
"""
# standard libraries
import configparser
import csv
import re
import datetime
import logging
import os
import re
from typing import Dict, List, Optional, Union
import time
import pandas as pd
import sys
import time
import win32com.client

# 3rd parties' libraries
import pandas as pd
import selenium
# import pyperclip
from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.firefox.service import Service
from selenium.webdriver.firefox.options import Options

# constants
formatter: logging.Formatter = logging.Formatter("%(asctime)s %(name)s:%(lineno)s %(funcName)s [%(levelname)s]: %(message)s")
LOGGER: logging.Logger = logging.getLogger(__name__)
handler: logging.Handler = logging.StreamHandler()
handler.setFormatter(formatter)
handler.setLevel(logging.DEBUG)
LOGGER.setLevel(logging.DEBUG)
for _handler in LOGGER.handlers:
    LOGGER.removeHandler(_handler)
LOGGER.addHandler(handler)
LOGGER.propagate = False

BASE_PATH: str = os.path.dirname(__file__)

CONFIG_INI = configparser.ConfigParser(interpolation=configparser.ExtendedInterpolation())
CONFIG_INI_PATH: str = os.path.splitext(__file__)[0] + ".conf"
assert os.path.exists(CONFIG_INI_PATH)
CONFIG_INI.read(CONFIG_INI_PATH, encoding="utf-8")
DEFAULT = CONFIG_INI["DEFAULT"]

INFO_FILE_PATH: str = os.path.join(BASE_PATH, DEFAULT.get("INFO_CSV_FILE"))

AKS_URL: str = DEFAULT.get("AKS_URL")

CHROME_DRIVER: str = os.path.join(BASE_PATH, DEFAULT.get("CHROME_DRIVER"))
IE_DRIVER: str = os.path.join(BASE_PATH, DEFAULT.get("IE_DRIVER"))
FF_DRIVER: str = os.path.join(BASE_PATH, DEFAULT.get("FF_DRIVER"))

WEB_DRIVER: str = DEFAULT.get("WEB_DRIVER")
# WEB_DRIVER: str = DEFAULT.get("WEB_DRIVER")
assert WEB_DRIVER in ("CHROME", "IE", "FF")
DISPLAY_POS:int = 3
DELIMITER="\t"
SEP = ","

# グローバル変数を定義
pdf_save_dir = None

def set_text(text_input: WebElement, text: str) -> None:
    """
    set text string to <input/>

    called_from: request_query(), set_fromto_date()
    """
    #text_input.send_keys(Keys.CONTROL + "a")
    #text_input.send_keys(Keys.DELETE)
    text_input.clear()
    text_input.send_keys(text)
    return

def get_webdriver_object() -> Union[webdriver.Chrome, webdriver.Ie, webdriver.Firefox]:
    """
    get WebDriver object

    called_from: main()
    """
    global CHROME_DRIVER, IE_DRIVER, FF_DRIVER
    global WEB_DRIVER
    if selenium.__version__.startswith("4."):
        if WEB_DRIVER == "CHROME":
            assert os.path.exists(CHROME_DRIVER)
            chrome_service = webdriver.chrome.service.Service(executable_path=CHROME_DRIVER)
            browser = webdriver.Chrome(service=chrome_service)
        elif WEB_DRIVER == "IE":
            assert os.path.exists(IE_DRIVER)
            ie_service = webdriver.ie.service.Service(executable_path=IE_DRIVER)
            browser = webdriver.Ie(service=ie_service)
        elif WEB_DRIVER == "FF":
            assert os.path.exists(FF_DRIVER)
            ff_service = webdriver.firefox.service.Service(executable_path=FF_DRIVER)

            # ff_options = webdriver.FirefoxOptions()
            ff_options = Options()
            ff_options.binary_location = "C:/Program Files/Mozilla Firefox/firefox.exe"

            # Firefoxのオプションを設定
            global pdf_save_dir
            ff_options.set_preference("browser.download.folderList", 2)  # 2: 指定したフォルダ
            ff_options.set_preference("browser.download.dir", pdf_save_dir)
            ff_options.set_preference("browser.helperApps.neverAsk.saveToDisk", "application/pdf")  # PDFのMIMEタイプ
            ff_options.set_preference("pdfjs.disabled", True)  # PDFビューアを無効にする

            # ダウンロード確認ダイアログを抑止
            ff_options.set_preference("browser.download.panel.shown", False)
            ff_options.set_preference("browser.download.panel.defaultSession", True)
            ff_options.set_preference("browser.download.useDownloadDir", True)
            ff_options.set_preference("browser.download.manager.showAlertOnComplete", False)
            ff_options.set_preference("browser.download.manager.showWhenStarting", False)
            ff_options.set_preference("browser.download.manager.focusWhenStarting", False)
            ff_options.set_preference("browser.download.manager.closeWhenDone", True)

            browser = webdriver.Firefox(service=ff_service, options=ff_options)
        # end of if
    elif selenium.__version__.startswith("3."):
        if WEB_DRIVER == "CHROME":
            browser = webdriver.Chrome(executable_path=CHROME_DRIVER)
        elif WEB_DRIVER == "IE":
            browser = webdriver.Ie(executable_path=IE_DRIVER)
        elif WEB_DRIVER == "FF":
            browser = webdriver.Firefox(executable_path=FF_DRIVER)
        # end of if
    else:
        raise f"Unknown selenium version: {selenium.__version__}"
    # end of if
    return browser

def create_folder(folder_path) -> None:
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)

def save_to_csv(data, output_file):
    with open(output_file, 'w', newline='') as f:
        writer = csv.writer(f)
        for row in data:
            writer.writerow(row)

def extract_folder_path(full_path):
    foler_path, _ = os.path.split(full_path)
    return foler_path

def main() -> None:

    # 引数チェック
    if len(sys.argv) < 6:
         sys.exit(1)

    # 引数:1, 2 ”入出金明細発行_検索”画面の”取引日指定”欄
    start_date_list = sys.argv[1].split('/')
    end_date_list = sys.argv[2].split('/')

    # 引数:3 処理エクセルのフルパス
    file_name = sys.argv[3]

    # 引数:4 処理エクセルのシート名
    sheet_name = sys.argv[4]

    # 引数:5 PDFの保管場所のフルパス
    global pdf_save_dir
    pdf_save_dir = sys.argv[5]

    LOGGER.info(f" *** file_name {file_name}")
    LOGGER.info(f" *** sheet_name {sheet_name}")
    LOGGER.info(f" *** pdf_save_dir {pdf_save_dir}")

    # pdfを保存するフォルダが存在しない場合は作成し、存在する場合は配下のファイルをすべて削除する
    if not os.path.exists(pdf_save_dir):
        os.makedirs(pdf_save_dir)
    else:
        for file in os.listdir(pdf_save_dir):
            file_path = os.path.join(pdf_save_dir, file)
            if os.path.isfile(file_path):
                os.remove(file_path)

    LOGGER.info(f"入出金明細発行画面で取引日が{sys.argv[1]}から{sys.argv[2]}までの情報を処理する")

    # driver 初期化
    browser: Union[webdriver.Chrome, webdriver.Ie, webdriver.Firefox] = get_webdriver_object()
    browser.implicitly_wait(15.0)
    global AKS_URL
    browser.get(AKS_URL)

    # メインメニュの「共通」を押す
    WebDriverWait(browser, 10.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "/html/body/form/table/tbody/tr[2]/td[1]/table/tbody/tr/td/span/div"))).click()

    # 「共通」メニューの「入出金明細発行」を押す
    WebDriverWait(browser, 10.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "//input[@type='BUTTON' and @value='入出金明細発行']"))).click()

    # output header
    out_header = ['支店番号', '口座番号', 'pdf格納場所']
    out_data = [out_header]

    # エクセルを読んで処理対象フラグ、支店番号、口座番号を取得（1行目はヘッダ。指定は0オリジン）
    df = pd.read_excel(file_name, sheet_name=sheet_name, header=0)

    for index, row in df.iterrows():

        # # 1.処理対象=1でなければ処理対象外
        taishoo_flg = str(row[14])
        try:
            int_taishoo_flg = int(float(taishoo_flg))
            str_taishoo_flg = str(int_taishoo_flg)
        except Exception as e:
           #LOGGER.info(rf'@@@@@ 数字じゃない @@@@@')
            continue

        if len(str_taishoo_flg) != 1:
            continue

        # 2.支店番号チェック
        # 支店番号 "231.0"なので"230"に補正
        branch_code    = str(row[2])
        if len(branch_code) == 0:
            continue

        try:
            int_branch_code = int(float(branch_code))
            branch_code = str(int_branch_code)
        except Exception as e:
            #LOGGER.info(rf'@@@@@ 数字じゃない @@@@@')
            continue

        if len(branch_code) != 3:
            continue

        # # 3.口座番号チェック
        account_number = str(row[3])
        match = re.search(r'\d{7}', account_number)
        if match:
            extracted_number = match.group()
            account_number = str(extracted_number)

        if len(account_number) != 7:
            continue

        LOGGER.info(f"@@@@@ : {branch_code}-{account_number}")

        # 支店番号
        set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[1]/td/input"), branch_code)

        # 口座番号
        set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[2]/td/input"), account_number)

        # 取引指定日を設定する
        # 開始年
        set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[4]/td/input[1]"), start_date_list[0])
        # 開始月
        set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[4]/td/input[2]"), start_date_list[1])
        # 開始日
        set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[4]/td/input[3]"), start_date_list[2])

        # 終了年
        set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[4]/td/input[4]"), end_date_list[0])
        # 終了月
        set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[4]/td/input[5]"), end_date_list[1])
        # 終了日
        set_text(browser.find_element(By.XPATH, "/html/body/form/table/tbody/tr[4]/td/input[6]"), end_date_list[2])

        # 「入出金明細_一覧」画面で「検索」を押す
        WebDriverWait(browser, 100000.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "//input[@type='BUTTON' and @value='検　索']"))).click()
        browser.implicitly_wait(3000.0)

        # 「入出金明細_一覧」画面で「PDFに出力」を押す
        browser.find_element(By.CSS_SELECTOR, "td > input:nth-child(1)").click()
        assert browser.switch_to.alert.text == "出力しますか？"
        browser.switch_to.alert.accept()

        # 出力したpdfファイルのパスをエクセルに記入する。
        pdf_file_path = rf"{pdf_save_dir}\{branch_code}{account_number}_balance.pdf"
        # 1019000849_balance.pdf
        LOGGER.info(f"@@@@@ pdf_file_path : {pdf_file_path}")

        # 出力イメージを配列に格納
        out_data.append([branch_code, account_number, pdf_file_path ])

        # 「入出金明細_一覧」画面で「戻る」を押す
        time.sleep(1)
        WebDriverWait(browser, 100000.0).until(expected_conditions.element_to_be_clickable((By.XPATH, "//input[@type='button' and @value='戻　る']"))).click()

    browser.close()

    out_file_prefix = "pdfList"

    # 出力結果はinputと同じ場所に格納
    # out_folder_path = extract_folder_path(pdf_save_dir)
    out_folder_path = pdf_save_dir
    # csvで保存 
    save_to_csv(out_data, rf"{out_folder_path}\{out_file_prefix}.csv")
    # xlsxで保存 
    tmp_df = pd.DataFrame(out_data)
    tmp_df.to_excel(rf"{out_folder_path}\{out_file_prefix}.xlsx", index = False, header=False)

    return

if __name__ == "__main__":
    LOGGER.info("starts")
    main()
    LOGGER.info("ends")
