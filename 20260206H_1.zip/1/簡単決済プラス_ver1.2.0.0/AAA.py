import datetime

def f_split_month(yyyymm: str, split_num: int):
    # yyyymmから前月を計算
    year = int(yyyymm[:4])
    month = int(yyyymm[4:6])
    if month == 1:
        prev_year = year - 1
        prev_month = 12
    else:
        prev_year = year
        prev_month = month - 1

    # 前月の月初と月末を求める
    from_date = datetime.date(prev_year, prev_month, 1)
    if prev_month == 12:
        next_month = 1
        next_year = prev_year + 1
    else:
        next_month = prev_month + 1
        next_year = prev_year
    to_date = datetime.date(next_year, next_month, 1) - datetime.timedelta(days=1)

    # 分割
    total_days = (to_date - from_date).days + 1
    base_days = total_days // split_num
    extra_days = total_days % split_num

    result = []
    current_from = from_date
    for i in range(split_num):
        days = base_days + (1 if i < extra_days else 0)
        current_to = current_from + datetime.timedelta(days=days - 1)
        result.append({
            "from": current_from.strftime("%Y%m%d"),
            "to": current_to.strftime("%Y%m%d")
        })
        current_from = current_to + datetime.timedelta(days=1)
    return result

def main():
    # テストケース
    test_cases = [
        ("202507", 2),
        ("202507", 3),
        ("202401", 2),
        ("202312", 4),
    ]
    for yyyymm, split_num in test_cases:
        print(f"入力: {yyyymm}, 分割数: {split_num}")
        res = f_split_month(yyyymm, split_num)
        for idx, r in enumerate(res):
            print(f"  {idx+1}分割目: from={r['from']}, to={r['to']}")
        print("")

if __name__ == "__main__":
    main()