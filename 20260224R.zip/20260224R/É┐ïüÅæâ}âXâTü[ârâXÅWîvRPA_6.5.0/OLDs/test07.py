import re

def extract_numbers(text):
    """
    文字列から数字のみを抽出して返す。
    数字が一切含まれない場合は、元の文字列をそのまま返す。
    """
    if text is None:
        return ""

    # 正規表現で「0-9以外の文字」をすべて空文字に置換（削除）する
    # [^0-9] は「0から9ではない文字」という意味
    cleaned = re.sub(r'[^0-9]', '', text)

    # 数字が1つも見つからなかった場合は、仕様通り引数をそのまま返す
    if cleaned == "":
        return text
    
    return cleaned

# 数字だけにします。
def main():
    # テストケース
    test_cases = [
        "4,892,660円",
        "(0円)",
        "123,456,114,892,660円",
        "金額なし",    # 数字が含まれないパターン
        "1,500.50円"   # 小数点が含まれる場合（数字以外なのでドットも消える）
    ]
    
    print(f"{'入力文字列':<25} | {'抽出結果'}")
    print("-" * 45)
    
    for case in test_cases:
        result = extract_numbers(case)
        print(f"{case:<25} | {result}")

if __name__ == "__main__":
    main()
